import React, { Component } from 'react';

import './App.css';

import MessageBubble from "./component/messgeBubble";
import ButtonsGridList from "./component/buttonsGridList";
import FooterTextField from './component/footerTextField';
import HeaderAppBar from './component/headerAppBar';
import { requestDataFromApi, getButtonArray, getMessageToDisplay, generateSessionId, imageGenerator, GATracking} from './utils';
import { connect } from 'react-redux';
import { updateButtons, updateMessages, refreshSession } from './actions';
import ReactLoading from 'react-loading';
import { botResponseConstants } from "./utils/constant";



class App extends Component {
  constructor(props) {
    super(props);
    this.onClickRefresh = this.onClickRefresh.bind(this);
    GATracking.InitializeTracking();
    GATracking.TrackPageView(window.location.pathname + window.location.search);    
  }

  
  state = {
    buttonArray: [],
    message: "",
    botAgent: imageGenerator()
  }

  scrollToBottom = () => {
    this.messagesEnd.scrollIntoView({ behavior: "smooth" });
  }

  componentDidMount() {
    GATracking.TrackEvent(GATracking.EventCategory.sessionStart,GATracking.EventType.pageLoaded,'First API hit to load chatbot', 0, true);
    this.scrollToBottom();
  }

  componentWillMount() {
    generateSessionId();
    this.getRequestData();
    
  }


  getRequestData = async () => {
    let result = await requestDataFromApi();
    let message = getMessageToDisplay(result);
    if(message === botResponseConstants.partialContentMessage){
      GATracking.TrackEvent(GATracking.EventCategory.sessionEnd, GATracking.EventType.conversationStopped, 'Conversation Ended Abruptly, server error');
    }
    this.props.addMessage(message.replace("Mili", this.state.botAgent.text), true);
    this.props.updateButtons(getButtonArray(result));
    return result;
  }

  componentDidUpdate(prevProps, prevStates) {
    this.scrollToBottom();
  }
  onClickRefresh(isRefresh) {
    if (isRefresh && this.props) {
      this.props.refreshMessage();
      this.getRequestData();
      GATracking.TrackEvent(GATracking.EventCategory.userInteraction,GATracking.EventType.pageRefeshed,'Refresh button clicked to refresh session');
      GATracking.TrackEvent(GATracking.EventCategory.sessionStart,GATracking.EventType.pageRefeshed,'Session refreshed with same session ID');
    }
  }



  render() {
    

    const chatbotLoader = <div className="chat bot scatter-Dots"><ReactLoading type="bubbles" color="#999999" height={'70px'} width={'60px'} className={"scatterDots"} /></div>
    let buttonCarousel = this.props.buttons ? <ButtonsGridList buttonsArray={this.props.buttons} /> : <div />
    const messageObjectArray = this.props.messages;
    
    let messageBubbles = <div />, typingLoader = <div />, lastMessageObject = "", disabled = false;

    
    if (messageObjectArray && messageObjectArray.length > 0) {
      
      lastMessageObject = (messageObjectArray[messageObjectArray.length - 1]);
      messageBubbles = messageObjectArray.map((item, index) => {
        return <MessageBubble key={index} isBot={item.isBot} time={item.time} buttonObject={item.buttons} message={item.message} />
      });
      
      if (lastMessageObject.isBot) {
        disabled = lastMessageObject.message.toString().toLowerCase().includes("good day");
      }else{
        typingLoader = chatbotLoader;
        buttonCarousel = <div />;
      }
    }
    return (

      <div className="App">

        <HeaderAppBar bot={this.state.botAgent} onClickRefresh={this.onClickRefresh} />
        <div className="chat-body-msg">
          {messageBubbles}
          {typingLoader}
          {buttonCarousel}
          <div style={{ float: "left", clear: "both", paddingBottom : "30px" }}
            ref={(el) => { this.messagesEnd = el; }}>
          </div>
        </div>
        <FooterTextField disabled={disabled} />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  messages: state.messages,
  buttons: state.buttons
})

const mapDispatchToProps = dispatch => ({
  addMessage: (text, isBot) => dispatch(updateMessages(text, isBot)),
  updateButtons: (buttons) => dispatch(updateButtons(buttons)),
  refreshMessage: () => dispatch(refreshSession())
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);

