import React, { Component } from 'react';
import AppBar from '@material-ui/core/AppBar';
import IconButton from '@material-ui/core/IconButton';
import Toolbar from '@material-ui/core/Toolbar';




class HeaderAppBar extends Component {

        onClick = (e) =>{
         
            this.props.onClickRefresh(true);
        }
    
    
        botImage = this.props.bot;
        render(){

        
        return (
            <AppBar className="appBar" elevation={0} position="sticky" style={{ background: "#f8f7f7"}}>
                <Toolbar variant="dense" className = "toolBar">
                <IconButton color="inherit" aria-label="Menu" className="chatBotLogoContainer">
                <p className="onlineindicator"></p>
                <img  className="chatBotLogo" src={this.botImage.img} alt="Bot-head-logo" />
          </IconButton>
          <div className="heading">
              <div>
                <h5>{this.botImage.text}</h5>
                <h6>Max Life Online Assistant</h6>
              </div>
              <p onClick = {(e) =>this.onClick(e)}>Refresh</p>
          </div>
                    
                </Toolbar>
            </AppBar>
        );
    }
}

export default HeaderAppBar;
