
const defaultState = {
  messages: [],
  buttons: []
}


const messages = (state = defaultState, action) => {
  switch (action.type) {
    case 'REFRESH_SESSION':
      return Object.assign({},
        {
          messages: [],
          buttons: []
        });
    case 'END_SESSION_BUTTONS':
      return Object.assign({},
        {
          messages: [...state.messages],
          buttons: []
        });
    case 'UPDATE_MESSAGES':
      return Object.assign({},
        {
          messages: [...state.messages, {
            message: action.message,
            isBot: action.isBot,
            time: action.time
          }],
          buttons: [...state.buttons]
        });
    case 'UPDATE_BUTTONS':
      if (action.buttons.length > 0) {
        return Object.assign({},
          {
            messages: [...state.messages],
            buttons: action.buttons
          });
      }else{
        return Object.assign({},
          {
            messages: [...state.messages],
            buttons: []
          });
      }      
    default:
      return state
  }

}

export default messages;