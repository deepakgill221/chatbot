﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Drawing.Imaging;
using System.Data.OleDb;
using System.Runtime.InteropServices;
using System.IO.Compression;
using log4net;
namespace Image_Compression
{
    public partial class Form1 : Form
    {

        clsLogger ClsLogger;
        clsFolders folderCls;
    
        int TotalPolicy = 0;
        int count = 0;
        IniParser iniParser;
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load);
           
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Hide();
            btnCompress_Click();
        }

        private void btnCompress_Click()
        {
            try
            {
                log4net.Config.XmlConfigurator.Configure();
                logger.Info("Application started");
                iniParser = new IniParser();

                if (iniParser.ParseIniFile())
                {
                    logger.Info("Details extracted from ini file");
                    if (ExtractFiles())
                    {
                        logger.Info("All folders extracted successfully");
                        string[] policyFolders = Directory.GetDirectories(Path.GetDirectoryName(iniParser.getZippepath()) + "\\UnZippedFolder");
                        TotalPolicy = policyFolders.Length;
                        logger.Info("Total foledrs to compress : " + TotalPolicy);
                        logger.Info("Initializing logger class ");
                        ClsLogger = new clsLogger();
                        ClsLogger.InitializeLogFile();

                        if (policyFolders.Length > 0)
                        {
                            foreach (string policyFolder in policyFolders)
                            {
                                logger.Info("Processing policy : " + Path.GetFileName(policyFolder));
                                clsTiffCompressor TiffCompressor = new clsTiffCompressor();
                                clsPDFCompressor PDFCompressor = new clsPDFCompressor();
                                clsJPEGCompressor JPEGCompressor = new clsJPEGCompressor();
                                folderCls = new clsFolders();
                                if (InitializeFolders(policyFolder))
                                {
                                    
                                    ClsLogger.FileStatus = false;
                                    string[] files = Directory.GetFiles(policyFolder, "*", SearchOption.AllDirectories);
                                    logger.Info("Total files in policy folder : " + files.Length);
                                    foreach (string file in files)
                                    {
                                        logger.Debug("File to compress : " + Path.GetFileName(file));
                                        try
                                        {
                                            if (Path.GetExtension(file).ToLower().Equals(".tiff") || Path.GetExtension(file).ToLower().Equals(".tif"))
                                            {
                                                logger.Debug("File is of type tif");
                                                TiffCompressor.ProcessTiffFile(file, folderCls, ClsLogger);
                                            }
                                            else if (Path.GetExtension(file).ToLower().Equals(".pdf"))
                                            {
                                                logger.Debug("File is of type pdf");
                                                PDFCompressor.ProcessPdfFile(file, folderCls, ClsLogger);

                                            }
                                            else if (Path.GetExtension(file).ToLower().Equals(".jpeg") || Path.GetExtension(file).ToLower().Equals(".jpg"))
                                            {
                                                logger.Debug("File is of type jpeg");
                                                JPEGCompressor.CompressJPEG(file, folderCls, ClsLogger);
                                            }
                                        }
                                        catch (Exception ex)
                                        {

                                        }

                                    }
                                    logger.Info("All files processed");

                                    long dirSize = DirSize(new DirectoryInfo(folderCls.getDestFolder()));

                                    if (new DirectoryInfo(folderCls.getDestFolder()).GetFiles().Length < 3)
                                    {
                                        logger.Info("Folder does not contain 3 files, case of error");
                                        MarkAsError();
                                        ClsLogger.WriteLogs(folderCls.getPolicyNo(), "Unable to process all files");
                                    }
                                    else if ((dirSize / 1024) > 348 || !ClsLogger.FileStatus)
                                    {
                                        logger.Info("Folder size greater than 348 KB , case of error");
                                        MarkAsError();
                                        if ((dirSize / 1024) > 348)
                                            ClsLogger.WriteLogs(folderCls.getPolicyNo(), "Folder size greater than 348 KB");
                                        else
                                            ClsLogger.WriteLogs(folderCls.getPolicyNo(), "PHOTO image greater than 49 KB");

                                    }
                                    else if ((dirSize / 1024) <= 348)
                                    {
                                        logger.Info("Folder size less than 348 KB");
                                        MarkAsSuccess();
                                        ClsLogger.WriteLogs(folderCls.getPolicyNo(), "All files compressed successfully");
                                    }

                                }
                                else
                                {
                                    logger.Info("Folders not created, exiting the app");
                                }
                            }
                            logger.Info("All folders processed successfully");
                            logger.Info("Closing the app");
                            MessageBox.Show("All folders processed successfully");
                            Close();
                        }
                        else
                        {
                            logger.Info("No policy folder found for compressing");
                            logger.Info("Closing the app");
                            Close();
                        }
                    }
                    else
                    {
                        logger.Info("Unable to extract zip folders");
                        logger.Info("Closing the app");
                        Close();
                    }
                }
                else
                {
                    logger.Info("Unable to extract details from ini file");
                    logger.Info("Closing the app");
                    Close();
                }
            }

            catch (Exception ex)
            {
                logger.Info("Error : " + ex.Message);
                MessageBox.Show(ex.Message);
                logger.Info("Closing the app");
                Close();
            }
        }

        private bool InitializeFolders(string polfolder)
        {
            try
            {

                if (folderCls != null)
                {
                    logger.Info("Creating all folders");
                    folderCls.setPolicyNo(Path.GetFileName(polfolder));
                    folderCls.setPolicyFolder(polfolder);
                    folderCls.setErrFolder(Path.GetDirectoryName(iniParser.getZippepath()) + "\\Error");
                    //folderCls.setBkpFolder(Path.GetDirectoryName(txtOutputPath.Text) + "\\Backup");
                    folderCls.setDestFolder(iniParser.getOutputpath() + "\\" + folderCls.getPolicyNo());
                    folderCls.setTempFolder(Path.GetDirectoryName(iniParser.getZippepath()) + "\\Temp\\" + folderCls.getPolicyNo());
                    if (!Directory.Exists(polfolder))
                        Directory.CreateDirectory(polfolder);
                    if (!Directory.Exists(folderCls.getTempFolder()))
                        Directory.CreateDirectory(folderCls.getTempFolder());
                    if (!Directory.Exists(folderCls.getDestFolder()))
                        Directory.CreateDirectory(folderCls.getDestFolder());
                    if (!Directory.Exists(folderCls.getErrFolder()))
                        Directory.CreateDirectory(folderCls.getErrFolder());
                    logger.Info("Policy folder : " + folderCls.getPolicyFolder());
                    logger.Info("Error folder : " + folderCls.getErrFolder());
                    logger.Info("Temp folder : " + folderCls.getTempFolder());
                    logger.Info("Destination folder : " + folderCls.getDestFolder());
                  

                    return true;
                }
                else
                    return false;

            }
            catch (Exception ex)
            {
                logger.Info("Error while craeting folders : " + ex.Message);
                return false;
            }
        }

        public static long DirSize(DirectoryInfo dir)
        {
            try
            {
                return dir.GetFiles().Sum(fi => fi.Length) +
                 dir.GetDirectories().Sum(di => DirSize(di));
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public void MarkAsError()
        {
            try
            {
                logger.Info("marking the folder as error");

                string folderToMove = folderCls.getErrFolder() + "\\" + folderCls.getPolicyNo();
                if (!Directory.Exists(folderToMove))
                    Directory.CreateDirectory(folderToMove);
                string[] filesToMove = Directory.GetFiles(folderCls.getDestFolder());
                foreach (string file in filesToMove)
                {
                    string destFile = System.IO.Path.Combine(folderToMove, Path.GetFileName(file));
                    System.IO.File.Copy(file, destFile, true);
                }
                foreach (string file in filesToMove)
                {
                    File.Delete(file);
                }
                string[] UnZipFiles = Directory.GetFiles(folderCls.getPolicyFolder(), "*", SearchOption.AllDirectories);
                foreach (string file in UnZipFiles)
                {
                    File.Delete(file);
                }
                //if(Directory.GetFiles(folderCls.getPolicyFolder()).Length == 0)
                //{
                //    Directory.Delete(folderCls.getPolicyFolder());
                //}
                Directory.Delete(folderCls.getDestFolder());
                string[] files = Directory.GetFiles(folderCls.getPolicyFolder(), "*", SearchOption.AllDirectories);
                foreach (string file in files)
                {
                    File.Delete(file);
                }


                if (Directory.GetFiles(folderCls.getPolicyFolder() + "\\" + folderCls.getPolicyNo()).Length == 0)
                    Directory.Delete(folderCls.getPolicyFolder() + "\\" + folderCls.getPolicyNo());
                if (Directory.GetFiles(folderCls.getPolicyFolder()).Length == 0 && (Directory.GetDirectories(folderCls.getPolicyFolder()).Length == 0))
                    Directory.Delete(folderCls.getPolicyFolder());
                //string[] innerDir = Directory.GetDirectories(folderCls.getPolicyFolder());
                //Directory.Delete(innerDir[0]);
                //Directory.Delete(folderCls.getPolicyFolder());
                logger.Info("folder marked as error");
            }
            catch (Exception ex)
            {
                logger.Info("Error while marking the folder as error : " + ex.Message);
            }
        }


        public void MarkAsSuccess()
        {
            try
            {
                //string folderToMove = folderCls.getBkpFolder() + "\\" + folderCls.getPolicyNo();
                //if (!Directory.Exists(folderToMove))
                //    Directory.CreateDirectory(folderToMove);
                logger.Info("marking the folder as success");

                string[] filesToMove = Directory.GetFiles(folderCls.getPolicyFolder(), "*", SearchOption.AllDirectories);
                foreach (string file in filesToMove)
                {
                    //string destFile = System.IO.Path.Combine(folderToMove, Path.GetFileName(file));
                    //File.Copy(file, destFile, true);
                    File.Delete(file);
                }
                if (Directory.GetFiles(folderCls.getTempFolder()).Length == 0)
                    Directory.Delete(folderCls.getTempFolder());
                string[] innerDir = Directory.GetDirectories(folderCls.getPolicyFolder());
                Directory.Delete(innerDir[0]);
                Directory.Delete(folderCls.getPolicyFolder());
                logger.Info("folder marked as success");
            }
            catch (Exception ex)
            {
                logger.Info("Error while marking the folder as success : " + ex.Message);
            }
        }

     


        public bool ExtractFiles()
        {
            try
            {
                string[] zipPath = Directory.GetFiles(iniParser.getZippepath());
                string UnZipPath = Path.GetDirectoryName(iniParser.getZippepath()) + "\\UnZippedFolder";

                logger.Info("Extracting files from zipped path : " + iniParser.getZippepath() + " to : " + UnZipPath);
                if (!Directory.Exists(UnZipPath))
                    Directory.CreateDirectory(UnZipPath);
                logger.Info("Created directory : " + UnZipPath);
                foreach (string path in zipPath)
                {
                    try
                    {
                        
                        string extractPath = UnZipPath + "\\" + Path.GetFileNameWithoutExtension(path);
                        ZipFile.ExtractToDirectory(path, extractPath);
                        logger.Info("Extracted folder : " + path);
                    }

                    catch (Exception ex)
                    {
                        logger.Info("Error while extracting folder from : " + path + " .Error : " + ex.Message);
                    }

                }
                return true;
            }
            catch (Exception ex)
            {
                logger.Info("Error : " + ex.Message);
                return false;
            }
        }


    }
}
