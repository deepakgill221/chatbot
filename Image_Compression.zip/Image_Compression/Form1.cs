﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Drawing.Imaging;
using System.Data.OleDb;
using System.Runtime.InteropServices;
using System.IO.Compression;
using log4net;
using System.Threading;
using System.Configuration;

namespace Image_Compression
{
    public partial class Form1 : Form
    {
        
        //clsLogger ClsLogger;
        //clsFolders folderCls;

        int TotalPolicy = 0;
        int count = 0;
        IniParser iniParser;
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load);
           
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            bool status = false;
            log4net.Config.XmlConfigurator.Configure();
            logger.Info("Application started");
            iniParser = new IniParser();
            Hide();

            try
            {
            if (iniParser.ParseIniFile())
            {

                logger.Info("Details extracted from ini file");
                status = ExtractFiles();

            }
            else
            {
                    
                 logger.Info("Unable to extract details from ini file");
                 logger.Info("Closing the app");
                 Close();
                    
            }

            if (status == true)
            {

                logger.Info("All folders extracted successfully");

                    string pdfpath = Convert.ToString(System.Configuration.ConfigurationSettings.AppSettings["TotalThread"]);
                    int _ThreadTotal = Convert.ToInt32(pdfpath);

                    for (int i = 1; i <= _ThreadTotal; i++)
                    {

                            Thread thread = new Thread(btnCompress_Click);
                            thread.Start(i);
                           
                    }

            }

            else
            {
                logger.Info("Unable to extract zip folders");
                logger.Info("Closing the app");
                Close();
            }

        }
              catch (Exception ex)
            {

                logger.Info("Error : " + ex.Message);
                MessageBox.Show(ex.Message);
                logger.Info("Closing the app");


            }

           
        }

        public void btnCompress_Click(object Parameter)
        {
            int Process = (int)Parameter;         
                clsLogger ClsLogger = new clsLogger();
                clsFolders folderCls;
                try
                {
                    bool isCompletedSuccessfully;
                    Thread th = Thread.CurrentThread;
                    string _thname = th.Name;
                    string UnZipPath = Path.GetDirectoryName(iniParser.getZippepath()) + "\\UnZippedFolder";
                    string UnZipPath1 = UnZipPath + "\\Process_" + Process;
                    string[] policyFolders = Directory.GetDirectories(Path.GetDirectoryName(iniParser.getZippepath()) + "\\UnZippedFolder" + "\\Process_" + Process);
                    TotalPolicy = policyFolders.Length;
                    logger.Info("Total folders to compress : " + TotalPolicy);
                    logger.Info("Initializing logger class ");
                    ClsLogger.InitializeLogFile();
                if (policyFolders.Length > 0)
                    {
                        foreach (string policyFolder in policyFolders)
                        {
                            logger.Info("Processing policy : " + Path.GetFileName(policyFolder));
                            clsTiffCompressor TiffCompressor = new clsTiffCompressor();
                            clsPDFCompressor PDFCompressor = new clsPDFCompressor();
                            clsJPEGCompressor JPEGCompressor = new clsJPEGCompressor();
                            folderCls = new clsFolders();
                            if (InitializeFolders(policyFolder, folderCls))
                            {

                                ClsLogger.FileStatus = false;
                                string[] files = Directory.GetFiles(policyFolder, "*", SearchOption.AllDirectories);
                                logger.Info("Total files in policy folder : " + files.Length);
                                string logFileName = string.Empty;
                                string logException = string.Empty;

                                foreach (string file in files)
                                {
                                    logger.Debug("File to compress : " + Path.GetFileName(file));
                                    try
                                    {
                                        if (Path.GetExtension(file).ToLower().Equals(".tiff") || Path.GetExtension(file).ToLower().Equals(".tif"))
                                        {
                                            logger.Debug("File is of type tiff");


                                               var  task = Task.Run(() =>
                                               {
                                          return  TiffCompressor.ProcessTiffFile(file, folderCls, ClsLogger);
                                               });


                                               isCompletedSuccessfully = task.Wait(TimeSpan.FromMilliseconds(3000));

                                            if (!isCompletedSuccessfully)

                                               {
                                                 throw new TimeoutException("The function has taken longer than the maximum time allowed.");
                                               }


                                        }
                                        else if (Path.GetExtension(file).ToLower().Equals(".pdf"))
                                        {
                                            logger.Debug("File is of type pdf");
                                              var task = Task.Run(() =>
                                              {
                                        return PDFCompressor.ProcessPdfFile(file, folderCls, ClsLogger);
                                             });

                                                isCompletedSuccessfully = task.Wait(TimeSpan.FromMilliseconds(3000));

                                              if (!isCompletedSuccessfully)

                                              {
                                                  throw new TimeoutException("The function has taken longer than the maximum time allowed.");
                                              }

                                        }
                                        else if (Path.GetExtension(file).ToLower().Equals(".jpeg") || Path.GetExtension(file).ToLower().Equals(".jpg"))
                                        {
                                            logger.Debug("File is of type jpeg");
                                             var    task = Task.Run(() =>
                                                 {
                                            JPEGCompressor.CompressJPEG(file, folderCls, ClsLogger);
                                                 });


                                            isCompletedSuccessfully = task.Wait(TimeSpan.FromMilliseconds(3000));

                                             if (!isCompletedSuccessfully)

                                              {
                                               throw new TimeoutException("The file has taken longer than the maximum time allowed.");
                                              }
                                        }



                                    }
                                    catch (Exception ex)
                                    {
                                        string strException = string.Empty;
                                        if (Path.GetExtension(file).ToLower().Equals(".tiff") || Path.GetExtension(file).ToLower().Equals(".tif"))
                                        {
                                            strException = "Invalid Tiff : ";
                                        }
                                        strException = strException + ex.Message;
                                        logFileName = logFileName.Length <= 0 ? Path.GetFileName(file) : logFileName + ", " + Path.GetFileName(file);
                                        logException = logException.Length <= 0 ? strException : logException + ", " + strException;
                                    }

                                }
                                logger.Info("All files processed");

                                long dirSize = DirSize(new DirectoryInfo(folderCls.getDestFolder()));

                                if (new DirectoryInfo(folderCls.getDestFolder()).GetFiles().Length < 3)
                                {
                                    logger.Info("Folder does not contain 3 files, case of error");
                                    MarkAsError(folderCls);
                                    logFileName = logFileName.Length <= 0 ? folderCls.getPolicyNo() + " Folder" : logFileName + ", " + folderCls.getPolicyNo() + " Folder";
                                    logException = logException.Length <= 0 ? "Folder does not contain 3 files so unable to process files." : logException + ", " + "Folder does not contain 3 files so unable to process files.";
                                    ClsLogger.WriteLogs(folderCls.getPolicyNo(), logException, logFileName);
                                }
                                else if ((dirSize / 1024) > 349 || !ClsLogger.FileStatus)
                                {
                                    logger.Info("Folder size greater than 349 KB , case of error");
                                    MarkAsError(folderCls);
                                    if ((dirSize / 1024) > 349)
                                    {
                                        logFileName = logFileName.Length <= 0 ? folderCls.getPolicyNo() + " Folder" : logFileName + ", " + folderCls.getPolicyNo() + " Folder";
                                        logException = logException.Length <= 0 ? "Folder size greater than 349 KB." : logException + ", " + "Folder size greater than 349 KB.";
                                        ClsLogger.WriteLogs(folderCls.getPolicyNo(), logException, logFileName);
                                        //ClsLogger.WriteLogs(folderCls.getPolicyNo(), "Folder size greater than 349 KB", folderCls.getPolicyNo() + " Folder");
                                    }
                                    else
                                    {
                                        logFileName = logFileName.Length <= 0 ? folderCls.getPolicyNo() + " Folder" : logFileName + ", " + folderCls.getPolicyNo() + " Folder";
                                        logException = logException.Length <= 0 ? "PHOTO image greater than 49 KB." : logException + ", " + "PHOTO image greater than 49 KB.";
                                        ClsLogger.WriteLogs(folderCls.getPolicyNo(), logException, logFileName);
                                        //ClsLogger.WriteLogs(folderCls.getPolicyNo(), "PHOTO image greater than 49 KB", folderCls.getPolicyNo() + " Folder");
                                    }

                                }
                                else if ((dirSize / 1024) <= 349)
                                {
                                    logger.Info("Folder size less than 349 KB");
                                    MarkAsSuccess(folderCls);
                                    logFileName = logFileName.Length <= 0 ? folderCls.getPolicyNo() + " Folder" : logFileName + ", " + folderCls.getPolicyNo() + " Folder";
                                    logException = logException.Length <= 0 ? "All files compressed successfully." : logException + ", " + "All files compressed successfully.";
                                    ClsLogger.WriteLogs(folderCls.getPolicyNo(), logException, logFileName);
                                    //ClsLogger.WriteLogs(folderCls.getPolicyNo(), "All files compressed successfully", folderCls.getPolicyNo() + " Folder");
                                }

                            }
                            else
                            {
                                logger.Info("Folders not created, exiting the app");
                            }
                        }
                        logger.Info("All folders for Process" + Process + " processed successfully");
                        logger.Info("Closing the app");
                        MessageBox.Show("All folders for Process" + Process + " processed successfully");
                        Close();
                    }
                    else
                    {
                        logger.Info("No policy folder found for compressing");
                        logger.Info("Closing the app");
                        Close();
                    }




                }
                catch (InvalidOperationException ex)
                {
                    logger.Info("Error : " + ex.Message);
                    MessageBox.Show(ex.Message);
                    logger.Info("Closing the app");
                }

                catch (Exception ex)
                {
                    logger.Info("Error : " + ex.Message);
                    MessageBox.Show(ex.Message);
                    logger.Info("Closing the app");
                    //                Close();
                }
            
        }

        private bool InitializeFolders(string polfolder, clsFolders folderCls)
        {
            try
            {

                if (folderCls != null)
                {
                    logger.Info("Creating all folders");
                    folderCls.setPolicyNo(Path.GetFileName(polfolder));
                    folderCls.setPolicyFolder(polfolder);
                    folderCls.setErrFolder(Path.GetDirectoryName(iniParser.getZippepath()) + "\\Error");
                    //folderCls.setBkpFolder(Path.GetDirectoryName(txtOutputPath.Text) + "\\Backup");
                    folderCls.setDestFolder(iniParser.getOutputpath() + "\\" + folderCls.getPolicyNo());
                    folderCls.setTempFolder(Path.GetDirectoryName(iniParser.getZippepath()) + "\\Temp\\" + folderCls.getPolicyNo());
                    if (!Directory.Exists(polfolder))
                        Directory.CreateDirectory(polfolder);
                    if (!Directory.Exists(folderCls.getTempFolder()))
                        Directory.CreateDirectory(folderCls.getTempFolder());
                    if (!Directory.Exists(folderCls.getDestFolder()))
                        Directory.CreateDirectory(folderCls.getDestFolder());
                    if (!Directory.Exists(folderCls.getErrFolder()))
                        Directory.CreateDirectory(folderCls.getErrFolder());
                    logger.Info("Policy folder : " + folderCls.getPolicyFolder());
                    logger.Info("Error folder : " + folderCls.getErrFolder());
                    logger.Info("Temp folder : " + folderCls.getTempFolder());
                    logger.Info("Destination folder : " + folderCls.getDestFolder());
                  

                    return true;
                }
                else
                    return false;

            }
            catch (Exception ex)
            {
                logger.Info("Error while craeting folders : " + ex.Message);
                return false;
            }
        }

        public static long DirSize(DirectoryInfo dir)
        {
            try
            {
                return dir.GetFiles().Sum(fi => fi.Length) +
                 dir.GetDirectories().Sum(di => DirSize(di));
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public void MarkAsError(clsFolders folderCls)
        {
            try
            {
                logger.Info("marking the folder as error");

                string folderToMove = folderCls.getErrFolder() + "\\" + folderCls.getPolicyNo();
                if (!Directory.Exists(folderToMove))
                    Directory.CreateDirectory(folderToMove);
                string[] filesToMove = Directory.GetFiles(folderCls.getDestFolder());
                foreach (string file in filesToMove)
                {
                    string destFile = System.IO.Path.Combine(folderToMove, Path.GetFileName(file));
                    System.IO.File.Copy(file, destFile, true);
                }
                foreach (string file in filesToMove)
                {
                    File.Delete(file);
                }
                string[] UnZipFiles = Directory.GetFiles(folderCls.getPolicyFolder(), "*", SearchOption.AllDirectories);
                foreach (string file in UnZipFiles)
                {
                    File.Delete(file);
                }
                //if(Directory.GetFiles(folderCls.getPolicyFolder()).Length == 0)
                //{
                //    Directory.Delete(folderCls.getPolicyFolder());
                //}
                Directory.Delete(folderCls.getDestFolder());
                string[] files = Directory.GetFiles(folderCls.getPolicyFolder(), "*", SearchOption.AllDirectories);
                foreach (string file in files)
                {
                    File.Delete(file);
                }


                if (Directory.GetFiles(folderCls.getPolicyFolder() + "\\" + folderCls.getPolicyNo()).Length == 0)
                    Directory.Delete(folderCls.getPolicyFolder() + "\\" + folderCls.getPolicyNo());
                if (Directory.GetFiles(folderCls.getPolicyFolder()).Length == 0 && (Directory.GetDirectories(folderCls.getPolicyFolder()).Length == 0))
                    Directory.Delete(folderCls.getPolicyFolder());
                //string[] innerDir = Directory.GetDirectories(folderCls.getPolicyFolder());
                //Directory.Delete(innerDir[0]);
                //Directory.Delete(folderCls.getPolicyFolder());
                logger.Info("folder marked as error");
            }
            catch (Exception ex)
            {
                logger.Info("Error while marking the folder as error : " + ex.Message);
            }
        }


        public void MarkAsSuccess(clsFolders folderCls)
        {
            try
            {
                //string folderToMove = folderCls.getBkpFolder() + "\\" + folderCls.getPolicyNo();
                //if (!Directory.Exists(folderToMove))
                //    Directory.CreateDirectory(folderToMove);
                logger.Info("marking the folder as success");

                string[] filesToMove = Directory.GetFiles(folderCls.getPolicyFolder(), "*", SearchOption.AllDirectories);
                foreach (string file in filesToMove)
                {
                    //string destFile = System.IO.Path.Combine(folderToMove, Path.GetFileName(file));
                    //File.Copy(file, destFile, true);
                    File.Delete(file);
                }
                if (Directory.GetFiles(folderCls.getTempFolder()).Length == 0)
                    Directory.Delete(folderCls.getTempFolder());
                string[] innerDir = Directory.GetDirectories(folderCls.getPolicyFolder());
                Directory.Delete(innerDir[0]);
                Directory.Delete(folderCls.getPolicyFolder());
                logger.Info("folder marked as success");
            }
            catch (Exception ex)
            {
                logger.Info("Error while marking the folder as success : " + ex.Message);
            }
        }

     


        public bool ExtractFiles()
        {
            try
            {
                string pdfpath = Convert.ToString(System.Configuration.ConfigurationSettings.AppSettings["TotalThread"]);
                int _ThreadTotal = Convert.ToInt32(pdfpath);

                string[] zipPath = Directory.GetFiles(iniParser.getZippepath());
                string UnZipPath = Path.GetDirectoryName(iniParser.getZippepath()) + "\\UnZippedFolder";

                logger.Info("Extracting files from zipped path : " + iniParser.getZippepath() + " to : " + UnZipPath);
                if (!Directory.Exists(UnZipPath))
                    Directory.CreateDirectory(UnZipPath);
                logger.Info("Created directory : " + UnZipPath);

                int zipcount = zipPath.Count();
                if (_ThreadTotal != 0 && _ThreadTotal <= zipcount)
                {

                int Thread_Folder_Count = zipcount / _ThreadTotal;//Number of files to process with one thread
                int Thread_Folder_Rem = zipcount % _ThreadTotal;//Remainder

                int min = 0;

                for (int i = 1; i <= _ThreadTotal; i++)
                {
                    string UnZipPath1 = UnZipPath + "\\Process_" + i;

                    logger.Info("Extracting files from zipped path : " + iniParser.getZippepath() + " to : " + UnZipPath);
                    if (!Directory.Exists(UnZipPath1))
                        Directory.CreateDirectory(UnZipPath1);
                    logger.Info("Created directory : " + UnZipPath1);
                    for (int k = min; k <= (min + (Thread_Folder_Count - 1)); k++)
                    {
                        string extractPath = UnZipPath1 + "\\" + Path.GetFileNameWithoutExtension(zipPath[k]);
                        ZipFile.ExtractToDirectory(zipPath[k], extractPath);

                    }
                    min = min + Thread_Folder_Count;

                }
                if (Thread_Folder_Rem > 0)
                {
                    string UnZipPath1 = UnZipPath + "\\Process_" + (_ThreadTotal);
                    logger.Info("Extracting files from zipped path : " + iniParser.getZippepath() + " to : " + UnZipPath);
                    if (!Directory.Exists(UnZipPath1))
                        Directory.CreateDirectory(UnZipPath1);
                    logger.Info("Created directory : " + UnZipPath1);
                    for (int k = min; k <= zipcount - 1; k++)
                    {
                        string extractPath = UnZipPath1 + "\\" + Path.GetFileNameWithoutExtension(zipPath[k]);
                        ZipFile.ExtractToDirectory(zipPath[k], extractPath);

                    }

                }

                return true;
            }

                else
                {
                    return false;

                }
            }
            catch (Exception ex)
            {
                logger.Info("Error : " + ex.Message);
                return false;
            }
        }


    }
}
