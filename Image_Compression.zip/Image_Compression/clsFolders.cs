﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Image_Compression
{
    class clsFolders
    {
        public string destinationfolder;
        public string policyFolder;
        public string tempFolder;
        public string errFolder;
        
      //  public string bkpfolder;
        public string policyNo;

        public string getDestFolder()
        {
            return this.destinationfolder;
        }
        public void setDestFolder(string destFolder)
        {
            this.destinationfolder = destFolder;
        }

        public void setPolicyFolder(string policyFolder)
        {
            this.policyFolder = policyFolder;
        }
        public string getPolicyFolder()
        {
            return this.policyFolder;
        }

        public void setTempFolder(string tempFolder)
        {
            this.tempFolder = tempFolder;
        }
        public string getTempFolder()
        {
            return this.tempFolder;
        }

        public void setErrFolder(string errFolder)
        {
            this.errFolder = errFolder;
        }
        public string getErrFolder()
        {
           return this.errFolder ;
        }

        public string getPolicyNo()
        {
            return this.policyNo;            
        }
        public void setPolicyNo(string policyNumber)
        {
            this.policyNo = policyNumber;
        }

    }
}
