﻿using log4net;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Image_Compression
{
  public  class clsTiffCompressor
    {
        public string[] jpegPaths;
        ArrayList arrayLst;
        int count = 0;
        Int64 fileLength;
        string fileName;
       
        clsFolders ClsFolder;
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public bool ProcessTiffFile(string filePath, clsFolders folderCls, clsLogger ClsLogger)
        {
            fileName = Path.GetFileName(filePath);
            bool flag = false;
            try
            {
                fileLength = new FileInfo(filePath).Length;
                ClsFolder = folderCls;
                if (fileName.Contains("PHOTO"))
                {
                    logger.Info(fileName + "is a PHOTO ");
                    if (fileLength / 1024 >= 49)
                    {
                        logger.Info("file size >= 49 KB, hence processing");
                        if (CompressTiffFile_PHOTO(filePath, ClsLogger))
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = false;
                        }
                    }
                    else
                    {
                        logger.Info("file size less than 49 KB, hence copying");
                        File.Copy(filePath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(filePath));
                        logger.Info("file copied");
                        flag = true;
                        ClsLogger.FileStatus = true;
                        logger.Info("file status set to " + ClsLogger.FileStatus);
                    }

                }
                else if (fileName.Contains("POA") || fileName.Contains("POI"))
                {
                    logger.Info(fileName + "is not a  PHOTO ");
                    if (fileLength / 1024 >= 149)
                    {
                        logger.Info("file size >= 149 KB, hence processing");
                        if (CompressTiffFile(filePath))
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = false;
                        }
                    }
                    else
                    {
                        logger.Info("file size less than 149 KB, hence copying");
                        File.Copy(filePath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(filePath));
                        logger.Info("file copied");
                        return true;
                    }
                }
                return flag;
            }
            catch (Exception ex)
            {
                logger.Info("Error : " + ex.Message);
                //log exception in excel here.
                //ClsLogger.WriteLogs(folderCls.getPolicyNo(), "Invalid Tiff : " + ex.Message, fileName);
                throw;
                //return false;
            }
        }
        public bool CompressTiffFile(string filePath)
        {
            try
            {
                bool successFlag = false;
               
                if (SplitTiff(filePath))
                    if (CompressTiff())
                        if (MergeTiffFile())
                            successFlag = true;
                //DeleteTempFolders();
                logger.Info("file processed successfully");
                return successFlag;
            }
            catch (Exception ex)
            {
                logger.Info("Error while compressing tiff file : " + ex.Message);
                throw;
            }
        }

        public bool CompressTiffFile_PHOTO(string filePath, clsLogger ClsLogger)
        {
            try
            {
                bool successFlag = false;
                if (SplitTiff(filePath))
                {
                   
                    string source = ClsFolder.getTempFolder() + "\\0" + Path.GetFileNameWithoutExtension(filePath) + ".jpeg";
                    logger.Info("compressing file at loc : " + source);
                    ImageResizer resizer = new ImageResizer(48000, source, ClsFolder.getTempFolder() + "\\1" + fileName);   //22000
                    resizer.ScaleImage();
                    string destPath = ClsFolder.getDestFolder() + "\\" + fileName;
                    //var image = System.Drawing.Image.FromFile(ClsFolder.getTempFolder() + "\\1" + fileName);
                    //image.Save(destPath, ImageFormat.Tiff);
                    File.Copy(ClsFolder.getTempFolder() + "\\1" + fileName, destPath);//Added by Anuj
                    logger.Info("file compressed and saved at loc : " + destPath);
                    if (!((new FileInfo(destPath).Length) / 1024 >= 49))
                    {
                        logger.Info("filesize < 49 after compressing,so pass the request");
                        ClsLogger.FileStatus = true;
                        logger.Info("filestatus set to :" + ClsLogger.FileStatus);
                    }
                    else
                    {
                        logger.Info("filesize >= 49 after compressing,case of error");
                        ClsLogger.FileStatus = false;
                        logger.Info("filestatus set to : " + ClsLogger.FileStatus);
                    }

                }
              //  DeleteTempFolders();


                successFlag = true;
                return successFlag;
            }
            catch (Exception ex)
            {
                logger.Info("Error while compressing tiff file PHOTO : " + ex.Message);
                throw;
                //return false;
            }
        }

        public bool SplitTiff(string filePath)
        {
            arrayLst = new ArrayList();
            try
            {
                logger.Info("Splitting tiff file");
                string file = Path.GetFullPath(filePath);
                int i = 0;

                SplitAsJPEG(file, ClsFolder.getTempFolder());
                logger.Info("file splitted successfully");
                jpegPaths = arrayLst.ToArray(typeof(string)) as string[]; //new string[count];
                return true;

            }
            catch (Exception ex)
            {
                logger.Info("Error while splitting tiff : " + ex.Message);
                throw;
                //return false;
            }
        }

       

        private void SplitAsJPEG(string pstrInputFilePath, string pstrOutputPath)
        {
            System.Drawing.Image tiffImage = System.Drawing.Image.FromFile(pstrInputFilePath);
            //get the globally unique identifier (GUID)
            Guid objGuid = tiffImage.FrameDimensionsList[0];
            //create the frame dimension
            FrameDimension dimension = new FrameDimension(objGuid);
            //Gets the total number of frames in the .tiff file
            int noOfPages = tiffImage.GetFrameCount(dimension);
            ImageCodecInfo encodeInfo = null;
            ImageCodecInfo[] imageEncoders = ImageCodecInfo.GetImageEncoders();
            count = count + noOfPages;
            for (int j = 0; j < imageEncoders.Length; j++)
            {
                if (imageEncoders[j].MimeType == "image/tiff")
                {
                    encodeInfo = imageEncoders[j];
                    break;
                }
            }

            // Save the tiff file in the output directory.
            if (!Directory.Exists(pstrOutputPath))
                Directory.CreateDirectory(pstrOutputPath);

            var encoder = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
            var encParams = new EncoderParameters(1);
            encParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 1L);


            foreach (Guid guid in tiffImage.FrameDimensionsList)
            {
                for (int index = 0; index < noOfPages; index++)
                {

                    arrayLst.Add(string.Concat(pstrOutputPath, @"\", index + Path.GetFileNameWithoutExtension(pstrInputFilePath), ".jpeg"));
                    FrameDimension currentFrame = new FrameDimension(guid);
                    EncoderParameters parameters = new EncoderParameters();
                    parameters.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.ColorDepth, 1L);
                    tiffImage.SelectActiveFrame(currentFrame, index);

                    tiffImage.Save(string.Concat(pstrOutputPath, @"\", index + Path.GetFileNameWithoutExtension(pstrInputFilePath), ".jpeg"), encodeInfo, parameters);
                    //Modified by Shilpa 14Sep17
                }
                tiffImage.Dispose();
            }
            logger.Info("file splitted at loc : " + pstrOutputPath);

        }

        public bool CompressTiff()
        {
            try
            {
                int i = 0;
                string[] ZippedPath = new string[jpegPaths.Length];
                // splitProgress.Maximum=jpegPaths.g
                int cnt = 0;

                foreach (string path in jpegPaths)
                {

                    string fileRelativePath = fileName;

                    /*New method*/
                    string x = ClsFolder.getTempFolder() + "\\zip_" + Path.GetFileNameWithoutExtension(fileName) + "\\";
                    if (!Directory.Exists(x))
                        Directory.CreateDirectory(x);
                    fileRelativePath = string.Concat(x, @"\", fileRelativePath);
                    /*end new method*/
                    ZippedPath[cnt] = fileRelativePath;
                    cnt++;
                    if (fileName.Contains("PHOTO"))
                    {
                        ImageResizer resizer = new ImageResizer(48000, path, fileRelativePath);
                        resizer.ScaleImage();
                    }
                    else
                    {
                        ImageResizer resizer = new ImageResizer(148000, path, fileRelativePath);      //20400
                        resizer.ScaleImage();
                    }


                }
               
                return true;
            }
            catch (Exception ex)
            {
                logger.Info("Error while compressing tiff file : " + ex.Message);
                throw;
                //return false;
            }
        }

        private bool MergeTiffFile()
        {
            try
            {
                logger.Info("Merging tiff files from loc : " + ClsFolder.getTempFolder());
                string path = ClsFolder.getTempFolder() + "\\zip_" + Path.GetFileNameWithoutExtension(fileName);
                string[] files = Directory.GetFiles(path);
                System.Drawing.Imaging.ImageCodecInfo codec = null;

                foreach (System.Drawing.Imaging.ImageCodecInfo cCodec in System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders())
                {
                    if (cCodec.CodecName == "Built-in TIFF Codec")
                        codec = cCodec;
                }

                System.Drawing.Imaging.EncoderParameters imagePararms = new System.Drawing.Imaging.EncoderParameters(1);
                imagePararms.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)System.Drawing.Imaging.EncoderValue.MultiFrame);
                //    string[] files = Directory.GetFiles(Path.GetDirectoryName(txtTiffFilePath.Text));
                if (files.Length == 1)
                {
                    System.IO.File.Copy((string)files[0], ClsFolder.getDestFolder() + "\\" + fileName, true);
                }
                else if (files.Length >= 1)
                {
                    //System.Drawing.Image DestinationImage = System.Drawing.Image.FromFile(ZippedPaths[0], true);
                    System.Drawing.Image DestinationImage = (System.Drawing.Image)(new System.Drawing.Bitmap((string)files[0]));

                    //DestinationImage.Save(destinationFolder, codec, imagePararms);
                    DestinationImage.Save(ClsFolder.getDestFolder(), codec, imagePararms);

                    imagePararms.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)System.Drawing.Imaging.EncoderValue.FrameDimensionPage);


                    for (int i = 1; i < files.Length; i++)
                    {
                        System.Drawing.Image img = (System.Drawing.Image)(new System.Drawing.Bitmap((string)files[i]));

                        DestinationImage.SaveAdd(img, imagePararms);
                        img.Dispose();
                    }

                    imagePararms.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)System.Drawing.Imaging.EncoderValue.Flush);
                    DestinationImage.SaveAdd(imagePararms);
                    imagePararms.Dispose();
                    DestinationImage.Dispose();
                    logger.Info("file merged and saved at loc : " + ClsFolder.getDestFolder());
                    //Deleting compressed splitted files after merging
                    foreach (string file in files)
                    {
                        if (System.IO.File.Exists(file))
                            System.IO.File.Delete(file);
                    }
                    //Deleting folder zip after merging the files
                    //if (Directory.Exists(path))
                    //    Directory.Delete(path);
                }
                return true;
            }
            catch (Exception ex)
            {
                logger.Info("Error while merging file : " + ex.Message);
                throw;
                //return false;
            }

        }

        public bool DeleteTempFolders()
        {
           try
            {
                string[] tempFiles_TIF = Directory.GetFiles(ClsFolder.getTempFolder(), "*.tif", SearchOption.AllDirectories);
                foreach (string file in tempFiles_TIF)
                {
                    File.Delete(file);
                }
                string[] tempFiles_JPEG = Directory.GetFiles(ClsFolder.getTempFolder(), "*.jpeg", SearchOption.AllDirectories);
                foreach (string file in tempFiles_JPEG)
                {
                    File.Delete(file);
                }
                string[] folder = Directory.GetDirectories(ClsFolder.getTempFolder());
                foreach (string subFolder in folder)
                {
                    if (Directory.GetFiles(subFolder).Length == 0)
                        Directory.Delete(subFolder);
                }
                return true;
            }
            catch(Exception ex)
            {
                logger.Info("Error while deleting Temp folders : " + ex.Message);
                throw;
                //return false;
            }
        }
    }
}
