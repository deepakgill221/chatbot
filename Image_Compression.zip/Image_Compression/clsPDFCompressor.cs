﻿using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JPEG_Encoder;
using PdfSharp.Drawing;
using log4net;

namespace Image_Compression
{
    class clsPDFCompressor
    {

        string fileName;
        //string policyNumber;
        //string destinationFolder;
        //string tempFolder;
        Int64 fileLength;
        clsFolders ClsFolder;
        public bool status_Photofile;
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        public bool ProcessPdfFile(string filePath, clsFolders foldercls, clsLogger ClsLogger)
        {
            try
            {
                ClsFolder = foldercls;
                fileLength = new FileInfo(filePath).Length;
                fileName = Path.GetFileName(filePath);
                bool successFlag = false;
                if (fileName.Contains("PHOTO"))
                {
                    logger.Info("file is a PHOTO");
                    if (fileLength / 1024 >= 49)
                    {
                        logger.Info("file size less than 49 KB, hence compressing");
                        logger.Info("splitting file");
                        if (SplitPDF(filePath))
                        {
                            logger.Info("file splitted");
                            logger.Info("converting pdf to jpeg ");
                            if (PDFtoJPEG())
                            {
                                logger.Info("converted pdf to jpeg ");
                                logger.Info("cropping the file ");
                                if (CropImage())
                                {
                                    logger.Info("files cropped");
                                    logger.Info("compressing files");
                                    if (CompressJPEG())
                                    {
                                        logger.Info("files compressed");
                                        logger.Info("converting jpeg to pdf ");
                                        if (JPEGToPDF())
                                        {
                                            logger.Info("converted jpeg to pdf ");
                                            logger.Info("merging files");
                                            if (MergePDF(ClsLogger))
                                            {
                                                logger.Info("files merged");
                                                successFlag = true;

                                            }
                                        }
                                    }
                                }
                            }
                        }
                   }
                    else
                    {
                        logger.Info("file size less than 49 KB, hence copying");
                        File.Copy(filePath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(filePath));
                        logger.Info("file copied");
                        ClsLogger.FileStatus = true;
                        logger.Info("file status set to " + ClsLogger.FileStatus);
                    }
                }
                else if (fileName.Contains("POA") || fileName.Contains("POI"))
                {
                    logger.Info("file is a PHOTO");

                    if (fileLength / 1024 >= 99)
                    {
                        //if (SplitPDF(filePath))
                        //    if (PDFtoJPEG())
                        //        if (CropImage())
                        //            if (CompressJPEG())
                        //                if (JPEGToPDF())
                        //                    if (MergePDF(ClsLogger))
                        //                        successFlag = true;
                        logger.Info("file size less than 49 KB, hence compressing");
                        logger.Info("splitting file");
                        if (SplitPDF(filePath))
                        {
                            logger.Info("file splitted");
                            logger.Info("converting pdf to jpeg ");
                            if (PDFtoJPEG())
                            {
                                logger.Info("converted pdf to jpeg ");
                                logger.Info("cropping the file ");
                                if (CropImage())
                                {
                                    logger.Info("files cropped");
                                    logger.Info("compressing files");
                                    if (CompressJPEG())
                                    {
                                        logger.Info("files compressed");
                                        logger.Info("converting jpeg to pdf ");
                                        if (JPEGToPDF())
                                        {
                                            logger.Info("converted jpeg to pdf ");
                                            logger.Info("merging files");
                                            if (MergePDF(ClsLogger))
                                            {
                                                logger.Info("files merged");
                                                successFlag = true;

                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        logger.Info("file size less than 99 KB, hence copying");
                        File.Copy(filePath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(filePath));
                        logger.Info("file copied");
                    }

                }
                return successFlag;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool SplitPDF(string inputPath)
        {
            try
            {
                string outputPath = ClsFolder.getTempFolder() + "\\SplittedPDF";
                if (!Directory.Exists(outputPath))
                    System.IO.Directory.CreateDirectory(outputPath);
                FileInfo file = new FileInfo(inputPath);
                string name = file.Name.Substring(0, file.Name.LastIndexOf("."));
                using (PdfReader reader = new PdfReader(inputPath))
                {

                    for (int pagenumber = 1; pagenumber <= reader.NumberOfPages; pagenumber++)
                    {
                        string filename = pagenumber.ToString() + ".pdf";
                        iTextSharp.text.Document document = new iTextSharp.text.Document();
                        PdfCopy copy = new PdfCopy(document, new FileStream(outputPath + "\\" + filename, FileMode.Create));
                        document.Open();
                        copy.AddPage(copy.GetImportedPage(reader, pagenumber));
                        document.Close();
                    }
                    reader.Dispose();    //Modified by Shilpa 14Sep17
                }
                return true;
            }
            catch (System.Exception ex)
            {
                logger.Info("Error while splitting file" + ex.Message);
                return false;
            }

        }

        public bool PDFtoJPEG()
        {
            try
            {
                string JPEGFolder = ClsFolder.getTempFolder() + "\\JPEG";
                if (!Directory.Exists(JPEGFolder))
                    System.IO.Directory.CreateDirectory(JPEGFolder);
                string[] pdfFiles = Directory.GetFiles(ClsFolder.getTempFolder() + "\\SplittedPDF");
                foreach (string file in pdfFiles)
                {
                    Spire.Pdf.PdfDocument doc = new Spire.Pdf.PdfDocument();
                    doc.LoadFromFile(file);
                    System.Drawing.Image bmp = doc.SaveAsImage(0);
                    System.Drawing.Image emf = doc.SaveAsImage(0, Spire.Pdf.Graphics.PdfImageType.Metafile);
                    System.Drawing.Image zoomImg = new Bitmap((int)(emf.Size.Width * 2), (int)(emf.Size.Height * 2));
                    using (Graphics g = Graphics.FromImage(zoomImg))
                    {
                        g.ScaleTransform(2.0f, 2.0f);
                        g.DrawImage(emf, new System.Drawing.Rectangle(new System.Drawing.Point(0, 0), emf.Size), new System.Drawing.Rectangle(new System.Drawing.Point(0, 0), emf.Size), GraphicsUnit.Pixel);
                    }
                    string filetoSave = System.IO.Path.ChangeExtension(System.IO.Path.GetFileName(file), ".jpeg");
                    emf.Save(JPEGFolder + "//" + filetoSave, ImageFormat.Jpeg);
                    emf.Dispose();

                    File.Delete(file);
                }
                if (Directory.GetFiles(ClsFolder.getTempFolder() + "\\SplittedPDF").Length == 0)
                    Directory.Delete(ClsFolder.getTempFolder() + "\\SplittedPDF");
                return true;
            }
            catch (System.Exception ex)
            {
                logger.Info("Error while converting pdf to jpeg" + ex.Message);
                return false;
            }
        }

        public bool CropImage()
        {
            try
            {
                string[] files = Directory.GetFiles(ClsFolder.getTempFolder() + "\\JPEG");
                foreach (string imagePath in files)
                {
                    Bitmap croppedImage;

                    // Here we capture the resource - image file.
                    using (var originalImage = new Bitmap(imagePath))
                    {
                        System.Drawing.Rectangle crop = new System.Drawing.Rectangle(15, 15, (originalImage.Width - 15), (originalImage.Height - 15));

                        // Here we capture another resource.
                        croppedImage = originalImage.Clone(crop, originalImage.PixelFormat);

                    } // Here we release the original resource - bitmap in memory and file on disk.

                    // At this point the file on disk already free - you can record to the same path.
                    croppedImage.Save(imagePath, ImageFormat.Jpeg);

                    // It is desirable release this resource too.
                    croppedImage.Dispose();
                    //Modified by Shilpa 14Sep17
                }
                return true;
            }
            catch (System.Exception ex)
            {
                logger.Info("Error while cropping files" + ex.Message);
                return false;
            }
        }

        public bool CompressJPEG()
        {
            try
            {
                string CompressJPEGFolder = ClsFolder.getTempFolder() + "\\CompressJPEG";
                if (!Directory.Exists(CompressJPEGFolder))
                    System.IO.Directory.CreateDirectory(CompressJPEGFolder);
                string[] pdfFiles = Directory.GetFiles(ClsFolder.getTempFolder() + "\\JPEG");
                var jpegEnc = new JpegEncoder.BaseJPEGEncoder();
                foreach (string file in pdfFiles)
                {
                    System.Drawing.Image img = System.Drawing.Image.FromFile(file);
                    jpegEnc.Save(img, CompressJPEGFolder + "//" + System.IO.Path.GetFileName(file), 300);   //200
                    img.Dispose();   //Modified by Shilpa 14Sep17
                    File.Delete(file);
                }
                if (Directory.GetFiles(ClsFolder.getTempFolder() + "\\JPEG").Length == 0)
                    Directory.Delete(ClsFolder.getTempFolder() + "\\JPEG");
                return true;
            }
            catch (Exception ex)
            {
                logger.Info("Error while compressing jpeg  files" + ex.Message);
                return false;
            }
        }

        public bool JPEGToPDF()
        {
            try
            {
                string CompressPDFFolder = ClsFolder.getTempFolder() + "\\PDF";
                if (!Directory.Exists(CompressPDFFolder))
                    System.IO.Directory.CreateDirectory(CompressPDFFolder);
                string[] files = Directory.GetFiles(ClsFolder.getTempFolder() + "\\CompressJPEG");
                foreach (string file in files)
                {
                    PdfSharp.Pdf.PdfDocument doc = new PdfSharp.Pdf.PdfDocument();

                    doc.Pages.Add(new PdfSharp.Pdf.PdfPage());
                    XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);
                    PdfSharp.Drawing.XImage img = PdfSharp.Drawing.XImage.FromFile(file);
                    xgr.DrawImage(img, 20, 0, doc.Pages[0].Width, doc.Pages[0].Height);
                    string filetoSave = System.IO.Path.ChangeExtension(System.IO.Path.GetFileName(file), ".pdf");
                    doc.Save(CompressPDFFolder + "//" + filetoSave);
                    xgr.Dispose();     //Modified by Shilpa 14Sep17
                    doc.Close();
                    img.Dispose();

                    File.Delete(file);
                }
                if (Directory.GetFiles(ClsFolder.getTempFolder() + "\\CompressJPEG").Length == 0)
                    Directory.Delete(ClsFolder.getTempFolder() + "\\CompressJPEG");
                return true;
            }
            catch (System.Exception ex)
            {
                logger.Info("Error while converting jpeg to pdf" + ex.Message);
                return false;

            }
        }

        public bool MergePDF(clsLogger ClsLogger)
        {
            try
            {
                string sourceDir = ClsFolder.getTempFolder() + "\\PDF";
                string targetPDF = ClsFolder.getDestFolder() + "\\" + fileName;
                using (FileStream stream = new FileStream(targetPDF, FileMode.Create))
                {
                    iTextSharp.text.Document pdfDoc = new iTextSharp.text.Document(iTextSharp.text.PageSize.A4);
                    PdfCopy pdf = new PdfCopy(pdfDoc, stream);
                    pdfDoc.Open();
                    var files = Directory.GetFiles(sourceDir);
                    int i = 1;
                    foreach (string file in files)
                    {
                        PdfReader reader = new PdfReader(file);
                        pdf.AddDocument(reader);
                        i++;
                        reader.Close();
                        reader.Dispose();
                    }
                    pdf.Close();
                    pdf.Dispose();
                    if (fileName.Contains("PHOTO"))
                    {
                        if ((new FileInfo(targetPDF).Length) / 1024 >= 49)
                        {
                            ClsLogger.FileStatus = false;
                        }
                        else
                        {
                            ClsLogger.FileStatus = true;
                        }
                    }
                    
                    if (pdfDoc != null)
                    {
                        pdfDoc.Close();
                        pdfDoc.Dispose();
                    }

                    stream.Close();
                    foreach (string file in files)
                    {
                        File.Delete(file);
                    }
                    if (Directory.GetFiles(sourceDir).Length == 0)
                        Directory.Delete(sourceDir);
                }
                return true;
            }
            catch (System.Exception ex)
            {
                logger.Info("Error while merging file" + ex.Message);
                return false;
            }
        }
    }
}
