﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using log4net;
namespace Image_Compression
{
   public class IniParser
    {



        private Hashtable keyPairs = new Hashtable();
        private String iniFilePath;
        public string ZippedPath;
        public string Outputpath;
        private struct SectionPair
        {
            public String Section;
            public String Key;
        }

        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// Opens the INI file at the given path and enumerates the values in the IniParser.
        /// </summary>
        /// <param name="iniPath">Full path to INI file.</param>
        public bool ParseIniFile()
        {
            TextReader iniFile = null;
            String strLine = null;
            String[] keyPair = null;
            bool status = false;
            logger.Info("Reading ini file from loc : " + AppDomain.CurrentDomain.BaseDirectory + "\\DataWriter_claim.ini");
            iniFilePath = AppDomain.CurrentDomain.BaseDirectory + "\\DataWriter_claim.ini";

            if (File.Exists(iniFilePath))
            {
                logger.Info("ini file found");
                try
                {
                    iniFile = new StreamReader(iniFilePath);
                    logger.Info("Reading file line by line");
                    strLine = iniFile.ReadLine();

                    while (strLine != null)
                    {
                        strLine = strLine.Trim().ToUpper();

                        if (strLine != "")
                        {
                          
                                keyPair = strLine.Split(new char[] { '=' }, 2);
                            if (keyPair[0].Trim().ToLower() == "zippedpath" && Convert.ToString(keyPair[1]) != "")
                            {
                                setZippepath(keyPair[1].Trim());
                                logger.Info("Zipped path : " + keyPair[1].Trim());
                            }
                               
                            if (keyPair[0].Trim().ToLower() == "outputpath" && Convert.ToString(keyPair[1]) != "")
                            {
                                setOutputpath(keyPair[1].Trim());
                                logger.Info("Output path : " + keyPair[1].Trim());
                            }
                               
                        }
                        

                        strLine = iniFile.ReadLine();
                       
                    }
                    if (getZippepath() == null || getZippepath() == "")
                    {
                        logger.Info("Zipped path not found in file");
                        status = false;
                    }
                    else if (getOutputpath() == null || getOutputpath() == "")
                    {
                        logger.Info("Output path not found in file");
                        status = false;
                    }
                    else
                        status = true;
                    return status;
                }
                catch (Exception ex)
                {
                    logger.Info("Error : " + ex.Message);
                    return false;
                }
                finally
                {
                    if (iniFile != null)
                        iniFile.Close();
                }
                
            }
            else
            {
                logger.Info("Unable to locate " + iniFilePath);
                return false;
            }

        }

        public string getZippepath()
        {
            return this.ZippedPath;
        }
        public void setZippepath(string zippedPath)
        {
            this.ZippedPath = zippedPath;
        }

        public string getOutputpath()
        {
            return this.Outputpath;
        }
        public void setOutputpath(string outputPath)
        {
            this.Outputpath = outputPath;
        }

    }
}
