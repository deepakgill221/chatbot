﻿using log4net;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Image_Compression
{
    class clsJPEGCompressor
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        clsFolders ClsFolder;
        public void CompressJPEG(string inputPath,clsFolders folderCls,clsLogger ClsLogger)
        {
            try
            {
                ClsFolder = folderCls;
                string fileName = Path.GetFileName(inputPath);
               Int64 fileLength = new FileInfo(inputPath).Length;
                if (fileName.Contains("PHOTO"))
                {
                    logger.Info(fileName + "is a PHOTO ");

                    if (fileLength / 1024 >= 49)
                    {
                        string source = ClsFolder.getTempFolder() + "\\0" + Path.GetFileNameWithoutExtension(inputPath) + ".jpeg";
                        ImageResizer resizer = new ImageResizer(45000, inputPath, source);   //20800
                        resizer.ScaleImage();
                        string destPath = ClsFolder.getDestFolder() + "\\" + fileName;
                        /*commented by Anuj 
                        var image = System.Drawing.Image.FromFile(source);
                        image.Save(destPath, ImageFormat.Jpeg);
                        image.Dispose();*/
                        File.Copy(source, destPath, true);
                        if (!((new FileInfo(destPath).Length) / 1024 >= 49))
                        {
                            ClsLogger.FileStatus = true;
                        }
                        else
                        {
                            ClsLogger.FileStatus = false;
                        }
                    }
                    else
                    {
                        logger.Info("file size less than 49 KB, hence copying");
                        //System.Drawing.Image myImage = System.Drawing.Image.FromFile(inputPath, true);
                        //myImage.Save(ClsFolder.getDestFolder() + "\\" + Path.GetFileName(inputPath));
                        File.Copy(inputPath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(inputPath));
                        logger.Info("file copied");
                   //     myImage.Dispose();
                        ClsLogger.FileStatus = true;
                        logger.Info("file status set to " + ClsLogger.FileStatus);

                    }

                }
                else if (fileName.Contains("POA") || fileName.Contains("POI"))
                {
                    logger.Info(fileName + "is not a PHOTO ");

                    if (fileLength / 1024 >= 149)
                    {
                        ImageResizer resizer = new ImageResizer(145000, inputPath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(inputPath));
                        resizer.ScaleImage();
                        //string destPath = ClsFolder.getDestFolder() + "\\" + fileName;
                        //var image = System.Drawing.Image.FromFile(source);
                        //image.Save(destPath, ImageFormat.Tiff);
                        //image.Dispose();
                    }
                    else
                    {
                        File.Copy(inputPath, ClsFolder.getDestFolder() + "\\" + Path.GetFileName(inputPath));
                    }
                }

            }
            catch (Exception ex)
            {
                logger.Info("Error : " + ex.Message);
            }
        }

    }
}
