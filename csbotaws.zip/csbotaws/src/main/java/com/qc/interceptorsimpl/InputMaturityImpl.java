package com.qc.interceptorsimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.qc.interceptors.InputMaturity;

@Service
public class InputMaturityImpl implements InputMaturity 
{

	String speech="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private Logger logger = LogManager.getLogger(InputReceiptImpl.class);
	@Override
	public String getInputMaturity(String sessionId, Map<String, Map> responsecacheOnSessionId) {
		String cashdata="";
		try
		{
			cashdata=((Map)responsecacheOnSessionId.get(sessionId).get("OverAllMaturityCashData")).get("maturityMessage")+"";
		}
		catch(Exception ex)
		{
			logger.info("Exception while extracting data from map :: "+ex);
		}
		if("".equalsIgnoreCase(cashdata))
		{
			cashdata=resProp.getString("validateOTP");
		}
		speech = cashdata;
		return speech;
	}
}
