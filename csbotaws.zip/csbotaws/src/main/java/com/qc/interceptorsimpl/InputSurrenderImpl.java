package com.qc.interceptorsimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.PolicyDetailHandlerService;
import com.qc.interceptors.InputSurrender;
@Service
public class InputSurrenderImpl implements InputSurrender 
{
	@Autowired
	PolicyDetailHandlerService policyDetailHandlerService;
	
	String speech="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private Logger logger = LogManager.getLogger(InputSurrenderImpl.class);
	@Override
	public String getInputSurrender(String sessionId, Map<String, Map> responsecacheOnSessionId) {
		logger.info("Action Invoded:- input.Surrender");
		String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
		String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
		Map data = (Map) responsecacheOnSessionId.get(sessionId).get("PolData");
		if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null) {
			speech = resProp.getString("validPolicyMessage");
		} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
			speech = resProp.getString("validateOTP").concat(cachePolicyNo);
		} else {
			if (data.get("CSV") == null) {
				speech = policyDetailHandlerService.getPolicyDetails(data, cachePolicyNo).get("Message").toString();
			} else {
				speech = ((Map) data.get("CSV")).get("Message").toString();
			}
		}
		return speech;
	}
}
