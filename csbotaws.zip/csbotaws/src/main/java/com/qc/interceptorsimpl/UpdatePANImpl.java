package com.qc.interceptorsimpl;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.UpdateAadhaarPanService;
import com.qc.interceptors.UpdatePAN;

@Service
public class UpdatePANImpl implements UpdatePAN{
	
	private static Logger logger = LogManager.getLogger(UpdatePANImpl.class);
	String speech="";
	
	@Autowired
	UpdateAadhaarPanService updateAadhaarPanService;

	@Override
	public String getUpdatePan(String sessionId, String pan, Map<String, Map> personal_detail) {
		Map resultMap=null;
		int panSize=pan.length();
		if(panSize==10)
		{
		String pan1=pan.substring(0, 4);
		String pan2=pan.substring(5, 8);
		String pan3=pan.substring(9);
		Boolean isnumeric_pan1 = StringUtils.isNumeric(pan1);
		Boolean isnumeric_pan2 = StringUtils.isNumeric(pan2);
		Boolean isnumeric_pan3 = StringUtils.isNumeric(pan3);
		if(isnumeric_pan1==false && isnumeric_pan2==true && isnumeric_pan3==false && panSize==10)
		{
			resultMap=updateAadhaarPanService.getPanDetails(sessionId);
			String result=resultMap.get("panNo")+"";
			String existing_Pan=updateAadhaarPanService.getPanNo(sessionId);
			if(pan.equalsIgnoreCase(existing_Pan))
			{
				speech="It seems your PAN already exists in our records. "
						+ "\n Is there anything else I can assist you with? ";
			}
			else
			{
				String status= updateAadhaarPanService.validatePAN(sessionId,pan, personal_detail);
				if("Matched".equalsIgnoreCase(status))
				{
					if("".equalsIgnoreCase(result))
					{
						speech="I'm now updating your PAN. Shall I go ahead & update the policy records?";
					}
					else
					{
						speech="The PAN you entered is different from that in our records. "
								+ "I'm now updating your PAN from "+result+" to "+pan+". "
										+ "Shall I go ahead & update the policy records?";
					}
				
				}
				else
				{
					speech="Sorry the PAN you entered is invalid. Please enter a valid PAN.";
				}
			}
		}
		else
		{
			speech="Sorry the PAN you entered is invalid. Please enter a valid PAN.";
		}
		}
		else
		{
			speech="Sorry the PAN you entered is invalid. Please enter a valid PAN.";
		}
		
		
		return speech;
	}

	@Override
	public String getUpdatePanYes(String sessionId, String policyNo, String pan) {
		
		String panStatus="";
			panStatus=updateAadhaarPanService.updatePan(sessionId, policyNo, pan);
			if("Success".equalsIgnoreCase(panStatus))
			{
				speech="Thank you for updating your PAN. It will get updated in our records within 10 calendar days. "
						+ "\n Is there anything else I can assist you with? ";
			}
			else
			{
				speech="Sorry, I am unable to process your request. Kindly try again after some time."
						+ "\n <a href='https://www.maxlifeinsurance.com/customer-service/ServiceRequest/pan-details.html' target='_blank'> Click here </a> if you wish to update the PAN number yourself. "
						+ "\n Is there anything else I can assist you with? ";
			}
		return speech;
	}
}
