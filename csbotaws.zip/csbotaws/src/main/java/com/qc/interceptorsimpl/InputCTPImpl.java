package com.qc.interceptorsimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.qc.interceptors.InputCTP;
@Service
public class InputCTPImpl implements InputCTP 
{
	
	String speech="";
	private static ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private static Logger logger = LogManager.getLogger(PremiumPaymentTermImpl.class);
	@Override
	public String getInputCTP(String sessionId, Map<String, Map> responsecacheOnSessionId) {
		logger.info("CASE :: input.CTP :: START");

		String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
		String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
		Map data = (Map) responsecacheOnSessionId.get(sessionId).get("PolData");
		if ("".equalsIgnoreCase(cachePolicyNo)) {
			speech = resProp.getString("validPolicyMessage");
		} else if ("".equalsIgnoreCase(cachevalidOTP)) {
			speech = resProp.getString("validateOTP").concat(cachePolicyNo);

		} else {
			if (data.get("CTP") == null) {
				speech = ((Map) data.get("ErrorMessage")).get("Message").toString();
			} else {

				Map ctp = (Map) data.get("CTP");
				speech = ctp.get("Message").toString();
			}
		}
		logger.info("CASE :: input.CTP :: END");
		return speech;
	}
}
