package com.qc.interceptorsimpl;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.CustomerInfoService;
import com.qc.api.service.MliDocHandlerService;
import com.qc.interceptors.InputReceipt;

@Service
public class InputReceiptImpl implements InputReceipt 
{
	@Autowired
	private MliDocHandlerService mliDocHandlerService;
	
	@Autowired
	private CustomerInfoService customerInfoService;
	
	String speech="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private Logger logger = LogManager.getLogger(InputReceiptImpl.class);
	@Override
	public String getInputReceipt(String sessionId, Map<String, Map> responsecacheOnSessionId) {
		logger.info("Action Invoded:- input.Receipt");
		String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
		String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
		String cashlastPremPmtDt = responsecacheOnSessionId.get(sessionId).get("lastPremPmtDt") + "";
		String emailIdAvailable = customerInfoService.customerInfo(cachePolicyNo,sessionId);
		String emailStatus="";
		
		try
		{
			JSONObject jsonobj= new JSONObject(emailIdAvailable);
			emailStatus = jsonobj.getJSONObject("response").getJSONObject("responseData").getString("soaMessage")+"";
		}catch(Exception e)
		{
			logger.error("Exception while getting status of email id for SessionId:: "+sessionId +" :: "+e);
		}
		
		if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null) {
			speech = resProp.getString("validPolicyMessage");
		} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
			speech = resProp.getString("validateOTP").concat(cachePolicyNo);
		} else if("Success".equalsIgnoreCase(emailStatus)){
			speech = mliDocHandlerService.getMliDocService(cachePolicyNo, cashlastPremPmtDt)
					.get("Message");
		}
		else {
			speech=resProp.getString("PolicyPackServiceEmailNotFound1")
					+ resProp.getString("PolicyPackServiceEmailNotFound2");
		}
		return speech;
	}
}
