package com.qc.interceptorsimpl;

import java.util.ResourceBundle;

import org.springframework.stereotype.Service;

import com.qc.interceptors.InputProposalStatus;

@Service
public class InputProposalStatusImpl implements InputProposalStatus{
	
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	String speech;
	public String getProposalStatus(String sessionId){
		
		speech=resProp.getString("proposal.status.response");
		return speech;
	}

}
