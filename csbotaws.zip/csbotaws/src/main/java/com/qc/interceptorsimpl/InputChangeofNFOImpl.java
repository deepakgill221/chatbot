package com.qc.interceptorsimpl;

import java.util.ResourceBundle;

import org.springframework.stereotype.Service;

import com.qc.interceptors.InputChangeofNFO;

@Service
public class InputChangeofNFOImpl implements InputChangeofNFO {
	
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");

	String speech;
	@Override
	public String getChangeOfNFO(String sessionId) {
		
		
		speech=resProp.getString("change.of.nfo.response");
		return speech;
	}

}
