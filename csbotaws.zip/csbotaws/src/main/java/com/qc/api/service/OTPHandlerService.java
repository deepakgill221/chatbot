package com.qc.api.service;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qc.api.dto.OTPService;
import com.qc.common.Commons;

@Component
public class OTPHandlerService 
{
	private static Logger logger = LogManager.getLogger(OTPHandlerService.class);
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");

	private static final String MESSAGE;
	private static final String RESPONSE;
	private static final String RESPONSE_DATA;
	private static final String PROPOSER_NAME;
	private static final String POLICY_NO;
	private static final String VALID_OTP;
	
	static{
		MESSAGE = "Message";	
		RESPONSE = "response";
		RESPONSE_DATA = "responseData";
		PROPOSER_NAME = "proposerName";
		POLICY_NO = "PolicyNo";
		VALID_OTP = "ValidOTP";
	}
	
	@Autowired
	OTPService otpService;
	
	public Map<String, String> getOtpMethod(String policyNo, String sessionId, int counter, String flag)
	{
		
		Map<String, String> otpDescMap = new HashMap<>();
		
		if("PROD".equalsIgnoreCase(flag)){
			otpDescMap = getPolicyOtpProd(policyNo, sessionId, counter);
		}
		
		else if ("UAT".equalsIgnoreCase(flag)){
			otpDescMap = getPolicyOtpUAT( policyNo,  counter) ;
		}
		
		return otpDescMap;
	}

	
	
	private Map<String, String> getPolicyOtpProd(String policyNo, String sessionId, int counter) {
		
		logger.info("CameInside getPolicyOtp :: Method :: START");
		String result="";
		String identity="OTP";
		String finaldate="";
		try
		{
			logger.info("START :: Calling OTPCallCashing Method");
			result = otpService.oTPCallCashing(policyNo, sessionId, identity, finaldate);
			logger.info("END :: OTPCallCashing Method :: Response :: "+ result);
		}catch(Exception e)
		{
			logger.info("Error Occoured while calling External webservice"+e);
		}
		Map<String, String> otpDescMap = new HashMap<>();
		String policyOtp = "";
		String proposerName = "";
		try
		{
			Map resultData = Commons.getGsonData(result);
			String soaStatusCode = ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSE_DATA))
					.get("soaStatusCode").toString();
			if (soaStatusCode != null && !soaStatusCode.equalsIgnoreCase("") && soaStatusCode.equalsIgnoreCase("999"))
			{
				String soaMessage = ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSE_DATA)).get("soaMessage")
						.toString();
				if ("Unable to fetch client Id from Policy Info backend service.".equals(soaMessage)) {
					otpDescMap.put(MESSAGE,
							resProp.getString("PolicyNumberNotFound") + " (" + policyNo + ") " +
							resProp.getString("PolicyNumberNotFound1"));
				} else if ("Unable to fetch Mobile number from Client Info backend service.".equals(soaMessage))
				{
					otpDescMap.put(MESSAGE, resProp.getString("MobileNumberRegardingPolicy"));
				}
			}
			else if (soaStatusCode != null && !soaStatusCode.equalsIgnoreCase("") && soaStatusCode.equalsIgnoreCase("200"))
			{
				logger.info("CameInside :: ! InvalidResponse");
				Map resultData2 = Commons.getGsonData(result);
				logger.info("ResultData :- "+resultData.toString());
				String soaStatusCode2 = ((Map) ((Map) resultData2.get(RESPONSE)).get(RESPONSE_DATA))
						.get("soaStatusCode").toString();
				if (soaStatusCode2 != null && !soaStatusCode2.equalsIgnoreCase("") && soaStatusCode2.equalsIgnoreCase("200")) 
				{
					try {
						policyOtp = ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSE_DATA)).get("otp").toString();

						proposerName = ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSE_DATA))
								.get(PROPOSER_NAME).toString();
					} catch (Exception ec) {
						logger.info("unable to get required data" + ec.getMessage());
					}
					otpDescMap.put("policyotp", policyOtp);
					otpDescMap.put(PROPOSER_NAME, proposerName);
					if (counter == 0)
					{
						otpDescMap.put(MESSAGE, resProp.getString("getOtpSuccessfully")/*.concat(policyOtp)*/);
						otpDescMap.put(POLICY_NO, policyNo);
						otpDescMap.put(VALID_OTP, "");
					}
					else
					{
						otpDescMap.put(MESSAGE, resProp.getString("getOtpRegenSuccessfully")/*.concat(policyOtp)*/);
						otpDescMap.put(POLICY_NO, policyNo);
						otpDescMap.put(VALID_OTP, "");
					}
				}
			}
			else {
				otpDescMap.put(MESSAGE, resProp.getString("GenericBackendErrorMessage"));
			}
		} catch (Exception e) {
			logger.info("We are in exception while calling API : " + e);
			otpDescMap.put(MESSAGE, "Production OTP service not working! Connect to conern team!");
		}
		logger.info("OutSide getPolicyOtp :: Method :: End :"+ otpDescMap);
		return otpDescMap;
	
	}
	
	private Map<String, String> getPolicyOtpUAT(String policyNo, int counter) 
	{
		logger.info("CameInside getPolicyOtp :: Method :: START");
		String result="";
		try
		{
			logger.info("START :: Calling OTPCallCashing Method");
			logger.info("END :: OTPCallCashing Method :: Response :: "+ result);
		}catch(Exception e)
		{
			logger.info("Error Occoured while calling External webservice"+e);
		}
		Map<String, String> otpDescMap = new HashMap<>();
		String policyOtp = "";
		String proposerName = "";
		try
		{
			if(true)
			{
				logger.info("CameInside :: ! InvalidResponse");
				String soaStatusCode2 = "200";
				if (!"".equalsIgnoreCase(soaStatusCode2) && "200".equalsIgnoreCase(soaStatusCode2)) 
				{
					
						policyOtp = "123456";
						proposerName = "UAT";
					otpDescMap.put("policyotp", policyOtp);
					otpDescMap.put("proposerName", proposerName);
					if (counter == 0)
					{
						otpDescMap.put(MESSAGE, resProp.getString("getOtpSuccessfully").concat(policyOtp));
						otpDescMap.put(POLICY_NO, policyNo);
						otpDescMap.put(VALID_OTP, "");
					}
					else
					{
						otpDescMap.put(MESSAGE, resProp.getString("getOtpRegenSuccessfully").concat(policyOtp));
						otpDescMap.put(POLICY_NO, policyNo);
						otpDescMap.put(VALID_OTP, "");
					}
				}
			}
		} catch (Exception e) {
			logger.info("We are in exception while calling API : " + e);
			otpDescMap.put(MESSAGE, "Production OTP service not working! Connect to conern team!");
		}
		logger.info("OutSide getPolicyOtp :: Method :: End :"+ otpDescMap);
		return otpDescMap;
	}
	
}



