package com.qc.api.dto;

public interface OTPService 
{
	public String oTPCallCashing(String policyNo,String sessionId, String identifier, String finalDate) throws Exception;

}

