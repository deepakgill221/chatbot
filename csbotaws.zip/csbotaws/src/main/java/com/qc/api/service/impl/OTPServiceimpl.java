package com.qc.api.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.qc.api.dto.OTPService;
import com.qc.common.Httpurl_Connection;

@Component
public class OTPServiceimpl implements OTPService
{
	private static Logger logger = LogManager.getLogger(OTPServiceimpl.class);
	public String oTPCallCashing(String policyNo, String sessionId, String identifier, String finaldate) throws  Exception
	{
		logger.info("CameInside Method :: OTPCallCashing ");
		Httpurl_Connection connection = new Httpurl_Connection();
		return  connection.httpConnection_response(policyNo, identifier, finaldate);
	}
	

}
