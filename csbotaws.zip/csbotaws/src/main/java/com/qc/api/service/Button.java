package com.qc.api.service;

import com.qc.api.hello.InnerData;

public interface Button 
{
	public InnerData getButtonsHI(String action);
	public InnerData getButtonsYesNo(String action);
	public InnerData getButtonsRenewalPaymentProcedure(String action);
	public InnerData getButtonsLoanInquiry(String action);
	public InnerData getButtonsUpdatePersonalDetails(String action);
	public InnerData getHelpfulSomeHelpful(String action);
	public InnerData getButtonFromDB(String result);
	public InnerData getButtonHello(String action);
	public InnerData getButtonBuyNow(String result, String url);
	public InnerData getButtonOnlineOffline(String result);
	public InnerData getButtonGoalDB(String result);
	
}
