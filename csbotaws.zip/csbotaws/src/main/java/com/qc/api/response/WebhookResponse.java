package com.qc.api.response;

import com.qc.api.hello.InnerData;

public class WebhookResponse {
    private String speech;
    private String displayText;
    
    //Button
    private InnerData data;

    private static final String SOURCE = "java-webhook";

    public WebhookResponse() {
		super();
	}

	public WebhookResponse(String speech, String displayText,InnerData data) {
		super();
		this.speech = speech;
		this.displayText = displayText;
		this.data=data;
	}

	public String getSpeech() {
		return speech;
	}

	public void setSpeech(String speech) {
		this.speech = speech;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public InnerData getData() {
		return data;
	}

	public void setData(InnerData data) {
		this.data = data;
	}

	public static String getSource() {
		return SOURCE;
	}

	@Override
	public String toString() {
		return "WebhookResponse [speech=" + speech + ", displayText=" + displayText + ", data=" + data + "]";
	}		

	
}
