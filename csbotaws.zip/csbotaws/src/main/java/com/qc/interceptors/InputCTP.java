package com.qc.interceptors;

import java.util.Map;

public interface InputCTP 
{
	public String getInputCTP(String sessionId, Map<String, Map> responsecacheOnSessionId);

}
