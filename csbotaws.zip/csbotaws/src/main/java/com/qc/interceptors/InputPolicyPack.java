package com.qc.interceptors;

import java.util.Map;

public interface InputPolicyPack {

	public String getInputPolicyPock(String sessionId, Map<String, Map> responsecacheOnSessionId);

}
