package com.qc.interceptors;

import java.util.Map;

public interface InputMaturity 
{

	public String getInputMaturity(String sessionId, Map<String, Map> responsecacheOnSessionId);

}
