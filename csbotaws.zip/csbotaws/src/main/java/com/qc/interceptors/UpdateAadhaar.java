package com.qc.interceptors;

import java.util.Map;

public interface UpdateAadhaar {
	
	public String getUpdateAadhaar(String sessionId, String aadhaar, String policyNo);
	public String getUpdateAadhaarYes(String sessionId, Map<String, Map> personalDetial);
	public String getLeadId(String sessionId);
	public String getTicketId(String sessionId);

}
