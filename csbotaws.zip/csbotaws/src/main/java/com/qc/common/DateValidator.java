package com.qc.common;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;


@Component
public class DateValidator 
{
	private static Logger logger = LogManager.getLogger(DateValidator.class);
	/*public static void main(String...ar)
	{
		boolean result = new DateValidator().isThisDateValid("01-jan-2012");
		System.out.println(result);
	}*/
	int result;
	String resultData="";
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	public boolean isThisDateValid(String dateToValidate)
	{
		try{
			if(dateToValidate == null)
			{
				return false;
			}
			else
			{
				DateTimeFormatter.ofPattern("dd-MM-yyyy").parse(dateToValidate);
			}
		}catch(Exception ex)
		{
			return false;
		}
		return true;
	}
	
	public String dateCheck1(String policyIssueDt)
	{
		try
		{
		LocalDate dateTime = LocalDate.parse(policyIssueDt, formatter);
	    dateTime = dateTime.plusYears(5);
	    LocalDate date=LocalDate.now();
	    result=date.compareTo(dateTime);
	    resultData=String.valueOf(result);
		}catch(Exception ex)
		{
			return "There is some communication glitch! Please try again after some time. Error Code -MAX00Surrender";
		}
		return resultData;
	}
	
	public String dateCheck2(String policyIssueDt,String policyPmtTerm)
	{
		try
		{
		int ppt=Integer.parseInt(policyPmtTerm);
		LocalDate dateTime = LocalDate.parse(policyIssueDt, formatter);
	    dateTime = dateTime.plusYears(ppt);
	    LocalDate date=LocalDate.now();
	    result=date.compareTo(dateTime);
	    resultData=String.valueOf(result);
		}catch(Exception ex)
		{
			return "There is some communication glitch! Please try again after some time. Error Code -MAX00Surrender";
		}
		return resultData;
	}
}