const app = angular.module("empappChatApp", ["kendo.directives"]);
app.controller("empappChatCtrl", function($scope, $http, $compile, $window) {
  const nodeServerUrl = "https://bot.maxlifeinsurance.com/postdata";
  const botTypingLoader = "img/chat_dots.gif";
  $scope.scrollArr = [];
  let refreshBtn = "";
  let autoFillContent = [];
  $scope.autoFillMis = false;
  $scope.autoFillRA = false;
  let intent = "";
  let botName = "EAPPBOT";
  $("#tableButtons").hide();
  let welcomeStringBot1;
  let botText = "";
  let tableCount = 1;
  let placeholder = "Write your text here...";
  $scope.placeholder = placeholder;
  let ssoid;
  //Generate here a random string
  let text = "";
  let botResponse = "";
  let tableShownData = [];
  let totalTables;
  let currentTableIndex;
  $scope.showMoreTableFlag = false;
  $scope.sampleText = "Write your text here....";
  let sessionGenerator = val => {
    return possible.charAt(Math.floor(val * possible.length));
  };

  let sendData = { query: "", randomString: "", botName: botName };
  const possible =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
  for (let i = 0; i < 9; i++) {
    text += sessionGenerator(Math.random());
  }
  sendData.randomString = text;
  console.log(sendData.randomString);
  let sendOnLoadText;
  let urlParams = window.location.search;
  if (urlParams) {
    let myArrayString = urlParams.split("?")[1];
    console.log(myArrayString);
    myArrayString = myArrayString.split("&");
    let key = [];
    for (let i = 0; i < myArrayString.length; i++) {
      key[i] = myArrayString[i];
    }
    console.log(key);
    if (
      key.length === 4 &&
      /authorize_eapp_001/i.test(key[0]) &&
      /ANDROID|IOS/i.test(key[2])
    ) {
      for (let i = 0; i < 4; i++) {
        key[i] = key[i].split("=")[1];
      }
      console.log(key);
      sendOnLoadText = `${
        key[1]
      } authorize_ecube_002_2017_BOT_certificate idiosyncratic_key ${key[2]} ${
        key[3]
      }`;
      $window.sessionStorage.setItem("ssoid", key[1]);
      ssoid = key[1];
      sendUserQuery();
    } else {
      sendOnLoadText = "unauthorized";
      sendUserQuery();
    }

    //On load display default msg**************************************************************************************Start
    function sendUserQuery() {
      sendData.query = sendOnLoadText;
      console.log(sendData);
      $http({
        method: "POST",
        url: nodeServerUrl,
        headers: {
          "Content-Type": "application/json"
        },
        data: sendData
      }).then(
        function successCallback(response) {
          console.log(response);
          if (
            response &&
            response.data &&
            response.data.result &&
            response.data.result.fulfillment &&
            response.data.result.fulfillment.data &&
            response.data.result.fulfillment.data.facebook &&
            response.data.result.fulfillment.data.facebook.buttons
          ) {
            let whichChatBot =
              response.data.result.fulfillment.data.facebook.buttons[0]
                .postback;
            let botResBtn =
              response.data.result.fulfillment.data.facebook.buttons;
            let btnLength = botResBtn.length;
            if (btnLength === 1 && botName === "EAPPBOT") {
              showChatBotButtons(whichChatBot);
              welcomeStringBot1 = response.data.result.fulfillment.speech.split(
                ","
              );
              botName = botResBtn[0].text;
              $window.sessionStorage.setItem("bot", botName);
              let postBack = `botSelector ${botResBtn[0].postback} ${ssoid}`;
              return $scope.sendChatData(
                botName,
                postBack,
                welcomeStringBot1[0]
              );
            } else {
              for (let i = 0; i < botResBtn.length; i++) {
                const buttonsElem = `<li>
                        <a ng-click="selectBot($event)" data-value="botSelector ${
                          botResBtn[i].postback
                        } ${ssoid}">
                        ${botResBtn[i].text}
                        </a>
                        </li>`;
                angular
                  .element(document.getElementsByClassName("otherTags"))
                  .append($compile(buttonsElem)($scope));
              }
            }
          }
          if (
            response &&
            response.data &&
            response.data.result &&
            response.data.result.fulfillment
          ) {
            botResponse = response.data.result.fulfillment.speech;
            let welcomeString = botResponse.split(",");
            var botElemeent = `<div class="msg cardbox welcomeMsg">
                    <p>${welcomeString[0]}</p>
                    </div>
                    <li class="other">
                    <div class="avatarbox">
                    <div class="avatar">
                    <img src="img/bot-icon-white.png" alt="bot-icon">
                    </div>
                    </div>
                    <div class="msg cardbox">
                    <p>${welcomeString[1]}</p>
                    </div>
                    </li>
                    </div>`;
            angular
              .element(document.getElementById("chatResponseBox"))
              .append($compile(botElemeent)($scope));
            $scope.scrollArr.push(botResponse);
          }
        },
        function errorCallback(response) {}
      );
    }
    //On load display default msg****************************************************************************************End

    //Send text msg****************************************************************************************************Start
    $scope.sendChatData = function(buttonText, postBack, welcomeMsgBot1) {
      if (!buttonText && !postBack && !welcomeMsgBot1 && !$scope.inputText) {
        return;
      }
      console.log(buttonText, postBack, welcomeMsgBot1);
      $("#autoWrapId").hide();

      let chatText = $scope.inputText;
      console.log($scope.inputText);
      let userText;
      if (!chatText) {
        userText = buttonText;
      } else {
        userText = chatText;
      }
      if (userText && !welcomeMsgBot1) {
        var userElemeent =
          '<li class="self">' +
          '<div class="msg">' +
          "<p>" +
          userText +
          "</p>" +
          "</div>" +
          "</li>";

        angular
          .element(document.getElementById("chatResponseBox"))
          .append($compile(userElemeent)($scope));
        $scope.inputText = "";
        $scope.scrollArr.push(userText);

        var botImage = document.getElementsByClassName("botTypingLoader");
        if (botImage.length > 0) {
          var botImageLen = botImage.length - 1;
          botImage[botImageLen].style.display = "none";
        }
        var botElemeent =
          '<li class="other botTypingLoader" style="display: inline-flex">' +
          '<div class="avatar">' +
          '<img src="img/bot-icon-white.png" alt="bot-icon">' +
          "</div>" +
          '<div class="msg bot botGif">' +
          '<img class="botTyping" src="img/chat_dots.gif" alt="user-icon">' +
          "</div>" +
          "</li>";
        angular
          .element(document.getElementById("chatResponseBox"))
          .append($compile(botElemeent)($scope));
        $scope.scrollArr.push(botTypingLoader);
      }
      if (/botSelector/i.test(postBack)) {
        console.log("in selector");
        postBack = postBack.replace(/botSelector/i, "");
        sendData.query = postBack;
        if (/misbot_validated_key_bot_2017/i.test(postBack)) {
          buttonText = "Business Numbers";
          console.log("bn");
          showChatBotButtons("misbot_validated_key_bot_2017");
        }
        if (/flsbot_validated_key_bot_2017/i.test(postBack)) {
          buttonText = "FLS";
          showChatBotButtons("flsbot_validated_key_bot_2017");
        }
        if (/hrbot_validated_key_bot_2017/i.test(postBack)) {
          buttonText = "HRPolicies";
        }
        botName = buttonText;
        $window.sessionStorage.setItem("bot", buttonText);
        console.log(postBack, buttonText);
        angular.element(document.getElementsByClassName("otherTags")).hide();
      } else {
        if (postBack) {
          sendData.query = postBack;
        } else {
          if (/apr|agentList/gi.test(intent)) {
            let elem = document.querySelectorAll("#tableButtons");
            $(elem[elem.length - 1]).remove();
            chatText = chatText.split("-");
            if (chatText.length >= 2) {
              chatText = "agentlist " + chatText[1] + "-" + chatText[2];
            } else {
              chatText = "agentlist " + chatText;
            }
          }
          sendData.query = chatText;
        }
      }
      sendData.botName = botName;
      console.log(sendData);
      sendData.query = sendData.query.trim();
      $http({
        method: "POST",
        url: nodeServerUrl,
        headers: {
          "Content-Type": "application/json"
        },
        data: sendData
      }).then(
        function successCallback(response) {
          console.log({ ...response });
          if (
            response &&
            response.data &&
            response.data.result &&
            response.data.result.fulfillment &&
            response.data.result.fulfillment.speech
          ) {
            let botResponse = response.data.result.fulfillment.speech;
            intent = response.data.result.metadata.intentName;
            console.log(intent);

            if (/email/gi.test(intent)) {
              $("#tags").kendoAutoComplete("destroy");
              $("#tags").bind("keyup", changeInput);
              $(".chatBox").css("height", "70vh");
              $scope.placeholder = placeholder;
              showChatBotButtons();
            }
            if (welcomeMsgBot1) {
              botText =
                '<div class="msg cardbox welcomeMsg">' +
                "<p>" +
                welcomeMsgBot1 +
                "</p>" +
                "</div>" +
                '<li class="other">' +
                '<div class="avatar">' +
                '<img src="img/bot-icon-white.png" alt="bot-icon">' +
                "</div>" +
                '<div class="msg bot" style="border-radius:1px 15px 15px 15px">' +
                '<p class="botResponse">' +
                botResponse +
                "</p>" +
                "</div>" +
                "</li>";
            } else {
              if (userText === "Achievement") {
                let hundredPercent1 = botResponse.indexOf("%");
                let hundredPercent2 = botResponse.lastIndexOf("%");
                let achievedTarget16 = botResponse.substr(
                  hundredPercent1 - 6,
                  3
                );
                let achievedTarget13 = botResponse.substr(
                  hundredPercent1 - 3,
                  3
                );
                let achievedTarget15 = botResponse.substr(
                  hundredPercent1 - 5,
                  3
                );

                let achievedTarget26 = botResponse.substr(
                  hundredPercent2 - 6,
                  3
                );
                let achievedTarget25 = botResponse.substr(
                  hundredPercent2 - 5,
                  3
                );
                let achievedTarget23 = botResponse.substr(
                  hundredPercent2 - 3,
                  3
                );

                if (
                  achievedTarget16 > 99.99 ||
                  achievedTarget13 > 99.99 ||
                  achievedTarget15 > 99.99 ||
                  achievedTarget26 > 99.99 ||
                  achievedTarget23 > 99.99 ||
                  achievedTarget25 > 99.99
                ) {
                  document.getElementById("emoIconSpan").style.display =
                    "inline-block";
                  document.getElementById("emoIcon").style.background =
                    "lightgreen";
                  botResponse =
                    botResponse +
                    '<img class="drumBeat" src="img/drum_player.gif" alt="drum_dancer">';
                  var audio = new Audio("img/sound.mp3");
                  audio.play();
                }
              }
              botText =
                '<li class="other">' +
                '<div class="avatar">' +
                '<img src="img/bot-icon-white.png" alt="bot-icon">' +
                "</div>" +
                '<div class="msg bot">' +
                '<p class="botResponse">' +
                botResponse +
                "</p>" +
                "</div>" +
                "</li>";
            }

            angular
              .element(document.getElementById("chatResponseBox"))
              .append($compile(botText)($scope));
            $scope.scrollArr.push(botResponse);
            let imageClass = document.getElementsByClassName("botTypingLoader");
            let imageClassLen = imageClass.length - 1;
            if (imageClassLen >= 0) {
              imageClass[imageClassLen].style.display = "none";
            }
          }

          if (
            response &&
            response.data &&
            response.data.result.fulfillment &&
            response.data.result.fulfillment.data &&
            response.data.result.fulfillment.data.facebook &&
            response.data.result.fulfillment.data.facebook.buttons
          ) {
            let buttons =
              response.data.result.fulfillment.data.facebook.buttons;
            if (/APR|AGENTLIST/gi.test(response.data.result.action)) {
              refreshBtn = `<button ng-click="refresh()">Home</button>`;
              console.log("in apr");
              $("#refreshBtn").html($compile(refreshBtn)($scope));

              let aprDiv = ` <div class="cstm-box" id="aprtable">
                    </div>
                    <div class="bottom-btns" id="tableButtons">
                        <button class="btn left" ng-click="showMoreTable($event)" ng-disabled="showMoreTableFlag" id="showMoreTables">Show More</button>
                        <button class="btn right" ng-click="clickThisBtn($event)" data-value="Email"><img src="img/excel-sheet-icn.jpg" alt="excel-sheet" />Send Mail </button>
                    </div>`;

              angular
                .element(document.getElementById("chatResponseBox"))
                .append($compile(aprDiv)($scope));
              if (response.data.result.action === "APR") {
                let filContent = buttons[buttons.length - 1].postback.split(
                  "|"
                );
                console.log("filContent: ", filContent);
                totalTables = buttons.slice(0, buttons.length - 2);
                if (filContent) {
                  $("#tags").unbind("keyup");
                  $("#tags").kendoAutoComplete({
                    autoWidth: true,
                    clearButton: false,
                    dataSource: filContent,
                    filter: "contains"
                  });
                  $scope.placeholder =
                    "Enter the Agent Id if you want to see your DRs data";
                }
              } else {
                totalTables = buttons.slice(0, buttons.length - 1);
              }
              tableShownData = buttons.slice(0, 3);
              $("#misBottomButn").hide();
              $("#raBottomButn").hide();
              $("#tableButtons").show();
              showTable(tableShownData);
              $(".chatBox").css("height", "88vh");
              currentTableIndex = 3;
              $scope.showMoreTableFlag = false;
            } else {
              let btn = "";
              for (let i = 0; i < buttons.length; i++) {
                btn += `${btn} <li class="ng-scope"><a ng-click="clickThisBtn($event)" data-value="${
                  buttons[i].postback
                }">${buttons[i].text}</a></li>`;
              }
              if ("raBotContent" === $scope.staticContent) {
                btn += `<li class="ng-scope"><a ng-click="clickThisBtn($event)" data-value="help" style="background: #003975; color:white" onMouseOut="this.style.background='#003975'" onMouseOver="this.style.background='#fa7623'">Help</a></li>`;
              }
              tableCount = 1;
              angular
                .element(document.getElementById("btnapr"))
                .append($compile(btn)($scope));
              angular
                .element(document.getElementById("btnflsapr"))
                .append($compile(btn)($scope));
            }
          } else {
            //  errorMsgDisplay();
          }
        },
        function errorCallback(response) {}
      );
    };
    //Send text msg******************************************************************************************************End
    //which bot buttons to show

    function showChatBotButtons(whichChatBot = sessionStorage.getItem("bot")) {
      if (
        /misbot_validated_key_bot_2017|Business Numbers/gi.test(whichChatBot)
      ) {
        $scope.staticContent = "misBotContent";
        $scope.autoFillMis = true;

        $("#misBottomButn").show();
        autoFillContent = [
          "Business",
          "Business Update",
          "Applied",
          "Applied MTD",
          "Applied YTD",
          "Applied FTD",
          "Paid",
          "Paid MTD",
          "Paid YTD",
          "Paid FTD",
          "Growth MTD",
          "Growth YTD",
          "Achievement",
          "Penetration",
          "Penetration MTD",
          "Protection",
          "ULIP",
          "TRAD",
          "WIP",
          "Applied AFYP",
          "Applied Adj. IFYP",
          "Applied Cases",
          "Growth Applied Cases",
          "Paid Cases",
          "Growth Paid Cases",
          "LPC Applied Cases MTD",
          "LPC Applied Cases YTD",
          "LPC Applied Adj. IFYP YTD",
          "LPC Applied AFYP MTD",
          "LPC Applied AFYP YTD",
          "LPC Paid Cases MTD",
          "LPC Paid Cases YTD",
          "LPC Paid Adj. MFYP YTD",
          "Case Size AFYP",
          "Case Size Achievement",
          "Growth Case Size",
          "Product Mix on Adj. MFYP",
          "Product Mix on Paid Cases",
          "Mode Mix Adj. MFYP",
          "Adj. MFYP",
          "Plan Achievement"
        ];
      } else if (/flsbot_validated_key_bot_2017|FLS/gi.test(whichChatBot)) {
        $scope.staticContent = "raBotContent";
        $scope.autoFillRA = true;
        $("#raBottomButn").show();
        autoFillContent = [
          "Applied",
          "Applied MTD",
          "Applied YTD",
          "Applied FTD",
          "Paid",
          "Paid MTD",
          "Paid YTD",
          "Paid FTD",
          "Applied Cases",
          "Paid Cases",
          "Recruitment MTD",
          "Recruitment YTD",
          "Adj. MFYP",
          "Wtg. MFYP",
          "Policy Status (Policy no.)",
          "Renewal Premium",
          "Premium Due",
          "Collection",
          "12 month rolling Collection",
          "No. of policies NTUed",
          "Nominee Details",
          "Policy Pack Delivery Status",
          "Medical Category for the policy",
          "Fund Value of the policy",
          "ECS date for the // policy",
          "Welcome Calling status",
          "13M Persistency",
          "Wip cases",
          "Applied FYP",
          "Activation",
          "Activation plan",
          "Promotion",
          "Performance",
          "GPA",
          "Recruitment",
          "Quality Recruitment",
          "Quality Recruitment Plan Achievement",
          "NAT Done"
        ];
      }
    }
    //Click channel btn************************************************************************************************Start
    $scope.clickThisBtn = function(event) {
      let buttonData = event.currentTarget;
      let postBack = buttonData.attributes["data-value"].value;
      let buttonText = angular.element(buttonData).text();
      return $scope.sendChatData(buttonText, postBack);
    };
    $scope.refresh = function() {
      $window.location.reload();
    };
    $scope.selectBot = function(event) {
      let buttonData = event.currentTarget;
      let postBack = buttonData.attributes["data-value"].value;
      let buttonText = angular.element(buttonData).text();
      return $scope.sendChatData(buttonText, postBack);
    };

    $scope.showMoreTable = event => {
      console.log("in show more");
      let finaLIndex = currentTableIndex + 3;
      if (finaLIndex >= totalTables.length) {
        $scope.showMoreTableFlag = true;
        let dataToDisplay = totalTables.slice(
          currentTableIndex,
          totalTables.length
        );
        showTable(dataToDisplay);
      } else {
        let dataToDisplay = totalTables.slice(currentTableIndex, finaLIndex);
        showTable(dataToDisplay);
      }
      currentTableIndex = finaLIndex;
    };
    //Click channel btn**************************************************************************************************End
    function showTable(data) {
      let tableData = '<div class="cstm-box">';
      for (let i = 0; i < data.length; i++) {
        tableData = `${tableData} <div class="cstm-sec">
    <h5>${data[i].text}</h5>
    <table class= "cstm-tbl ${
      tableCount % 2 === 0 ? "orange" : "blue"
    }" cellpadding="0" cellspacing="0"> 
    <thead>
    <tr>`;
        let tableRow = data[i].postback.split("|");
        let tableHeader = tableRow[0].split("#");
        for (let k = 0; k < tableHeader.length; k++) {
          tableData = `${tableData} <th>${tableHeader[k]}</th>`;
        }
        tableData = `${tableData} </tr></thead><tbody>`;

        for (let j = 1; j < tableRow.length; j++) {
          let tableCol = tableRow[j].split("#");
          tableData = `${tableData} <tr>`;
          for (let k = 0; k < tableCol.length; k++) {
            tableData = `${tableData} <td>${tableCol[k]}</td>`;
          }
          tableData = `${tableData} </tr>`;
        }
        tableData = `${tableData} </tbody>
                            </table>
                            </div>`;
        tableCount = tableCount + 1;
      }
      tableData = `${tableData} </div>`;
      console.log("in gg");
      let elem = document.querySelectorAll("#aprtable");
      console.log(elem);
      angular
        .element(document.querySelectorAll("#aprtable")[elem.length - 1])
        .append($compile(tableData)($scope));
    }
    // Auto Fill Start
    $scope.matchPeople = function(input) {
      input = $scope.inputText;
      if (!input || input == "null") {
        $("#autoWrapId").hide();
      } else {
        let reg = new RegExp(
          input
            .split("")
            .join("\\w*")
            .replace(/\W/, ""),
          "i"
        );
        return autoFillContent.filter(function(person) {
          if (person.match(reg)) {
            return person;
          }
        });
      }
    };

    let changeInput = function(val) {
      if (!/apr|agentList/i.test(intent)) {
        let autoCompleteResult = $scope.matchPeople(val);
        $scope.autoListItem = autoCompleteResult;
      }
      $("#autoWrapId").show();
    };

    $scope.changeInput = changeInput;

    $scope.autoFillSelect = function(index) {
      var selectText = document
        .getElementById("autoId" + index)
        .innerHTML.trim();
      $scope.inputText = selectText;
      $("#autoWrapId").hide();
    };
    // Auto Fill ends
  }
});

//Directive to keep scroll bar at bottom***************************************************************************Start
app.directive("schrollBottom", function() {
  return {
    scope: {
      schrollBottom: "="
    },
    link: function(scope, element) {
      scope.$watchCollection("schrollBottom", function(newValue) {
        if (newValue) {
          $(element).scrollTop($(element)[0].scrollHeight);
        }
      });
    }
  };
});
//Directive to keep scroll bar at bottom*****************************************************************************End
