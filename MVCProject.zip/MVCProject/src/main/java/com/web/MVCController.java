package com.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.web.pojo.UserPojo;
import com.web.service.LoginService;


@Controller
public class MVCController {

	@Autowired
	LoginService login;

	@RequestMapping(value="/home" , method = RequestMethod.GET )
	public String home() {
		System.out.println("inside controller");
		//ModelAndView view = new ModelAndView("login");
		return "home";
	}

	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String getLogin() {
		return "login";
		
	}
	
	@RequestMapping(value = "/register", method=RequestMethod.GET)
	public ModelAndView getRegister(HttpServletRequest request, HttpServletResponse response) {
		UserPojo userPojo = new UserPojo();
		ModelAndView model = new ModelAndView();
		model.addObject("user", userPojo);
		//model.addAttribute("edit", false);
		
		return model;
		
	}
	
	@RequestMapping(value="/login" , method = RequestMethod.POST)
	public ModelAndView welcome(@RequestParam String name , @RequestParam String password,  ModelAndView model) {
		model = new ModelAndView("login");
		if(!login.validateLogin(name, password)) {
			model.addObject("errorMessage", "Invalid Credentials");
			return model;
		}
		else {
		System.out.println(name);
		model = new ModelAndView("welcome");
		model.addObject("name", name);
		model.addObject("password", password);
		return model;
		}
	}

	
	@RequestMapping(value="/registerSuccess", method=RequestMethod.POST)
	public String getRegistration(@Valid UserPojo userPojo, BindingResult result, ModelMap model) {
		
		if(result.hasErrors()) {
			return "register";
		}
		
		return "viewuser";
		
	}
	
}
