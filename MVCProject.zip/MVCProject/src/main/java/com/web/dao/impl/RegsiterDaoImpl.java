package com.web.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.metamodel.Metadata;
import org.hibernate.metamodel.MetadataSources;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.web.dao.RegisterDao;
import com.web.pojo.UserPojo;


public class RegsiterDaoImpl implements RegisterDao{

	
	public String saveUser(UserPojo user) {   
        
		  
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();  
		Transaction transaction = session.beginTransaction();   
		
		UserPojo userPojo = new UserPojo();
		userPojo.setName(user.getName());    
		userPojo.setPassword(user.getPassword());
		userPojo.setProfession(user.getProfession());
		userPojo.setCountry(user.getCountry());
		
		
		session.save(userPojo);    
		  
		transaction.commit();    
	    
	    System.out.println("successfully saved");    
	    
	    session.close();   
	    factory.close();  
	    return "viewuser";
	        
	}

	
}

