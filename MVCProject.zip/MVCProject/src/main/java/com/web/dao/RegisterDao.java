package com.web.dao;

import com.web.pojo.UserPojo;

public interface RegisterDao {
	
	public String saveUser(UserPojo user);

}
