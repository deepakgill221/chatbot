package com.web.pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.stereotype.Repository;


public class UserPojo {
	private String name;
	private String password;
	private String profession;
	private String country;
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	
	

}
