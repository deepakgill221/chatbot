package com.web.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	
	public boolean validateLogin(String username, String password)
	{
		return username.equalsIgnoreCase("myname") && password.equals("mypass");
	}

}
