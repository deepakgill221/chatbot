package com.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.web.dao.RegisterDao;
import com.web.pojo.UserPojo;

@Service
public class RegistrationService {
	
	@Autowired 
	private RegisterDao registerDao;
	public String getRegister(UserPojo user) {
		
		return registerDao.saveUser(user);
	}

}
