﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFlowEmailWindowsService
{
    class CustomerResponse
    {
        private bool successFlag;
       // private ClientDVO cliDVO;
        private String errorDesc;
        private String agtEmaiId;
        private String custOwnerEmaiId;
        private String custAssgneEmaiId;
        private String errorDescEmail;

        public String getErrorDescEmail()
        {
            return errorDescEmail;
        }


        public void setErrorDescEmail(String errorDescEmail)
        {
            this.errorDescEmail = errorDescEmail;
        }

        public bool isSuccessFlag()
        {
            return successFlag;
        }


        public void setSuccessFlag(bool successFlag)
        {
            this.successFlag = successFlag;
        }


        //public ClientDVO getCliDVO()
        //{
        //    return cliDVO;
        //}
        //public void setCliDVO(ClientDVO cliDVO)
        //{
        //    this.cliDVO = cliDVO;
        //}
        public String getErrorDesc()
        {
            return errorDesc;
        }
        public void setErrorDesc(String errorDesc)
        {
            this.errorDesc = errorDesc;
        }
        public String getAgtEmaiId()
        {
            return agtEmaiId == null ? "" : agtEmaiId;
        }
        public void setAgtEmaiId(String agtEmaiId)
        {
            this.agtEmaiId = agtEmaiId;
        }
        public String getCustOwnerEmaiId()
        {
            return custOwnerEmaiId == null ? "" : custOwnerEmaiId;
        }
        public void setCustOwnerEmaiId(String custOwnerEmaiId)
        {
            this.custOwnerEmaiId = custOwnerEmaiId;
        }
        public String getCustAssgneEmaiId()
        {
            return custAssgneEmaiId == null ? "" : custAssgneEmaiId;
        }
        public void setCustAssgneEmaiId(String custAssgneEmaiId)
        {
            this.custAssgneEmaiId = custAssgneEmaiId;
        }

    }
}
