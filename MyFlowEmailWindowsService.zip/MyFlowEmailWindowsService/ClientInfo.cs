﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFlowEmailWindowsService
{
    public class ClientInfo
    {

        private String clientId;
        private String clientTitle;
        private String clientName;
        private String clientSirName;
        private String clientEmail;
        private String polId;
        private String hniFlag;
        private String axisFlag;

        private String agentId;


        public String getAgentId()
        {
            return agentId;
        }
        public void setAgentId(String agentId)
        {
            this.agentId = agentId;
        }
        public String getAxisFlag()
        {
            return axisFlag;
        }
        public void setAxisFlag(String axisFlag)
        {
            this.axisFlag = axisFlag;
        }
        public String getHniFlag()
        {
            return hniFlag == null || hniFlag == "" ? hniFlag = "N" : hniFlag;
        }
        public void setHniFlag(String hniFlag)
        {
            this.hniFlag = hniFlag;
        }
        public String getPolId()
        {
            return polId;
        }
        public void setPolId(String polId)
        {
            this.polId = polId;
        }
        public String getClientId()
        {
            return clientId;
        }
        public void setClientId(String clientId)
        {
            this.clientId = clientId;
        }
        public String getClientTitle()
        {
            return clientTitle;
        }
        public void setClientTitle(String clientTitle)
        {
            this.clientTitle = clientTitle;
        }
        public String getClientName()
        {
            return clientName;
        }
        public void setClientName(String clientName)
        {
            this.clientName = clientName;
        }
        public String getClientSirName()
        {
            return clientSirName;
        }
        public void setClientSirName(String clientSirName)
        {
            this.clientSirName = clientSirName;
        }
        public String getClientEmail()
        {
            return clientEmail == null ? "" : clientEmail;
        }
        public void setClientEmail(String clientEmail)
        {
            this.clientEmail = clientEmail;
        }

    }



}
