﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Configuration;
using System.Data;
//using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using log4net;

using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;


namespace MyFlowEmailWindowsService
{
    class EmailDelegator
    {

        EmailResponse _emailresponse = null;
        ClientInfo _clientinfo = null;
        ConnectToOracle _conntooracle = null;

        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public bool SendEmail(ClientInfo clientInfo, DataRow dr)
        {
            try
            {
                logger.Debug("Entered in Send Email function");
                SmtpClient objSMTPClient = new SmtpClient(ConfigurationManager.AppSettings["MailServer"].ToString(), 25);
                MailMessage objMail = new MailMessage();
                objMail.IsBodyHtml = true;
                objMail.Subject = ConfigurationManager.AppSettings["MailSubject"].ToString() + " " + dr["POL_NUM"];
                objMail.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString(), ConfigurationManager.AppSettings["MailFromName"].ToString());
                objMail.To.Clear();
                objMail.To.Add(clientInfo.getClientEmail());
                // objMail.To.Add("rishabh.dixit@maxlifeinsurance.com");
                objMail.Body = Createhtml(clientInfo, dr);
                //objMail.Body = "";
                //objSMTPClient.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["MailUserName"].ToString(), "RBDC()");
                logger.Debug("Mail sending to " + clientInfo.getClientEmail());
                objSMTPClient.Send(objMail);
                logger.Debug("Mail sent to " + clientInfo.getClientEmail());

                return true;
            }


            catch (Exception ex)
            {

                logger.Error("Error in sending Mails");
                logger.Error("Message -> " + ex.Message);
                logger.Error("StackTrace -> " + ex.StackTrace);
                return false;
            }


        }

        private string Createhtml(ClientInfo clientInfo, DataRow sqlclientInfodr)
        {
            StringBuilder sb = new StringBuilder();
            EmailHeaderFooter _emailhead = new EmailHeaderFooter();

            string content = sqlclientInfodr["XML_CONTENT"].ToString();

            content = content.Replace("<First Name>", clientInfo.getClientName()).Replace("<Last Name>", clientInfo.getClientSirName()).Replace("<?xml version=\"" + "1.0" + "\"?><EMAILTEXT>", " ").Replace("</EMAILTEXT>", "").Replace("<Title>", clientInfo.getClientTitle());

            if (clientInfo.getAxisFlag() != null && clientInfo.getAxisFlag().Equals("Y"))
            {
                content = content + "<br><br>" + _emailhead.getComment("AXIS_COMMENT");
            }
            else
            {
                if (clientInfo.getHniFlag() != null && clientInfo.getHniFlag().Equals("Y"))
                    content = content + "<br><br>" + _emailhead.getComment("HNI_COMMENT");
                else
                    content = content + "<br><br>" + _emailhead.getComment("NON_HNI_COMMENT");
            }
            if (Convert.ToString(sqlclientInfodr["email_type"]).ToUpper() == "ACRC" || Convert.ToString(sqlclientInfodr["email_type"]).ToUpper() == "DECLINE")
            {
                content = content + "<br><br>*Note-For Online Term Plan Please contact at toll free number or write us on the above mail id.";
            }


            //content = content + "<br><br><span style='font-family: Calibri; font-size: 10pt;'><b>IRDA recommends payout of all policy benefits through electronic mode from 1st April, 2014 onwards. Please update your bank details for your Max Life Insurance policy and get instant credit for all policy related benefits in your bank account.</b></span>";
         //   content = content + "<br><br><span style='font-family: Calibri; font-size: 10pt;'><b>IRDA recommends payout of all policy benefits through electronic mode from 1st April, 2014 onwards. Please update your bank details for your Max Life Insurance policy and get instant credit for all policy related benefits in your bank account.</b></span>";

            sb.Append("<HTML><HEAD></HEAD><BODY><table width='600'  align='center' style='border:2px solid black;' RULES='NONE' FRAME='BOX'  cellpadding='0' cellspacing='0' style='font-family:Arial, Helvetica'><tr border='0'><td colspan='0' align='center' valign='middle'>");
            sb.Append("<img src=\"");

            if (clientInfo.getAxisFlag() != null && clientInfo.getAxisFlag().Equals("Y"))
            {
                sb.Append(_emailhead.getLogo("LINK_LOGO_AXIS"));
            }
            else
            {
                if (clientInfo.getHniFlag() != null && clientInfo.getHniFlag().Equals("Y"))
                    sb.Append(_emailhead.getLogo("LINK_LOGO_HNI"));
                else
                    sb.Append(_emailhead.getLogo("LINK_LOGO_NONHNI"));
            }

            sb.Append("\" alt='mid' width='600' height='100' style='display:block;' border='0' /></td></tr>");
            sb.Append("<tr border='0'><td border='0'><table border='0px'><tr border='0'><td border='0'>");
            sb.Append(content);
            sb.Append("</td></tr></td></tr></table>");
            sb.Append("<tr border='0'><td border='0'>").Append("<img src=\"");

            if (clientInfo.getAxisFlag() != null && clientInfo.getAxisFlag().Equals("Y"))
            {
                sb.Append(_emailhead.getFooter("LINK_FOOTER_AXIS"));
            }
            else
            {
                if (clientInfo.getHniFlag() != null && clientInfo.getHniFlag().Equals("Y"))
                    sb.Append(_emailhead.getFooter("LINK_FOOTER_HNI"));
                else
                    sb.Append(_emailhead.getFooter("LINK_FOOTER_NONHNI"));
            }

            sb.Append("\" style='BORDER-TOP-WIDTH: 0px; DISPLAY: block; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px' height=230 alt=toll-free width=600 /> ");
            sb.Append("</td></tr>").Append("</table></body></HTML>");

            return sb.ToString();
        }

        // Agent  Related Info Start ////////////////////////////////////////////////////////////////////////

        public EmailResponse SendAgentMail(DataRow dr, SqlServerResource sqlServerResource)
        {
            _conntooracle = new ConnectToOracle();
            _emailresponse = new EmailResponse();
            //boolean errFlag = true;

            try
            {
                logger.Debug("Getting agent details");
              //  logger.Debug("Policy No." + getAgentDetails(dr["POL_NUM"].ToString().Trim()));
                _clientinfo = getAgentDetails(dr["POL_NUM"].ToString().Trim());

                logger.Debug("Policy Number :---" + Convert.ToString(dr["POL_NUM"]));
                // logger.Debug("SMS text:---" + _strSMSText);

                _emailresponse.setAgtEmaiId(_clientinfo.getClientEmail());

                if (_clientinfo != null)
                {
                    // for testing.....
                    //_clientinfo.setClientEmail("rishabh.dixit@maxlifeinsurance.com");
                    if (_clientinfo.getClientEmail() == null || _clientinfo.getClientEmail().Trim().Equals(""))
                    {
                        //mstDVO.setErrorDesc("Agent Email-Id not found");
                        _emailresponse.setErrorDescEmail("E-mail id not in My agent");
                        _emailresponse.setAgtEmaiId("");
                        _emailresponse.setSuccessFlag(false);
                    }

                    else if (_clientinfo.getClientName() == null || _clientinfo.getClientName().Trim().Equals(""))
                    {
                        logger.Debug("Agent Name not found");
                        _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                        _emailresponse.setSuccessFlag(false);
                    }

                    else if (_clientinfo.getHniFlag() == null || _clientinfo.getAxisFlag() == null)
                    {
                        logger.Debug("Agent Flagging not found");
                        _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                        _emailresponse.setSuccessFlag(false);
                    }

                    else
                    {
                        //mstDVO.setCliDVO(cliDVO);
                        //mstDVO.setErrorFlag(false);

                        String _strEmail = _clientinfo.getClientEmail();
                        Match match = Regex.Match(_strEmail, "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

                        //bool b = _strEmail.matches(EMAIL_REGEX);
                        if (match.Success)
                        {
                            logger.Debug("Sending mails to agent");
                            bool emailSentStatus = SendEmail(_clientinfo, dr);
                            logger.Debug("processed agent email record");
                            //EmailProcessor proc = new EmailProcessor();
                            //bool emailSentStatus = proc.sendEmailRequest(_clientinfo, dr);

                            _emailresponse.setSuccessFlag(emailSentStatus);
                        }
                        else
                        {
                            logger.Debug("Incomplete Email Id");
                            _emailresponse.setErrorDescEmail("Incomplete E-mail ID");
                            _emailresponse.setSuccessFlag(false);
                        }
                    }
                }
                else
                {
                    _emailresponse.setSuccessFlag(false);
                    _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                    //logger.debug("cliDVO is null ");
                }
            }
            catch (Exception e)
            {
                logger.Error("Message -> " + e.Message);
                logger.Error("StackTrace -> " + e.StackTrace);
                logger.Error("error in fetching agent details ", e);

                _emailresponse.setSuccessFlag(false);
                #region Changed By Ripon
                if (e.Message == "ORA-12570: Network Session: Unexpected packet read error")
                {
                    _emailresponse.setErrorDescEmail("Oracle Did'nt Respond");
                }
                else
                {
                    _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                }
                #endregion
            }

            return _emailresponse;


        }


        public ClientInfo getAgentDetails(String polNum)
        {

            logger.Debug("Fetching agent details for " + polNum);

            _conntooracle = new ConnectToOracle();
            _emailresponse = new EmailResponse();

            //ClientInfo dvo = new ClientDVO();
            String sql = "";

            OracleConnection oracleConnection = null;

            try
            {
                using (OracleConnection oraconn = new OracleConnection(_conntooracle.GetConnectionstring()))
                {

                    if (oraconn.State == ConnectionState.Closed)
                    {
                        logger.Debug("opening Oracle DB Connection");
                        oraconn.Open();
                        logger.Debug("Oracle DB Connection successfully opened");

                    }

                    logger.Debug("Source connection recieved, Preparing to fetch agent details");

                    using (OracleCommand oracom = new OracleCommand(string.Format("SELECT CLI_ID FROM TPOLC WHERE CO_ID='CP' AND TRIM(POL_ID)={0} AND POL_CLI_REL_TYP_CD='O'", polNum), oraconn))
                    {
                        logger.Debug("preparing to fetch agent details from ORACLE DB");
                        using (OracleDataReader rdr = oracom.ExecuteReader())
                        {
                            logger.Debug("got agent details from ORACLE DB ");
                            _clientinfo = new ClientInfo();
                            while (rdr.Read())
                            {
                                _clientinfo.setPolId(polNum);
                                _clientinfo.setClientId(rdr["CLI_ID"].ToString().Trim());
                            }

                            logger.Debug("cleint id fetched--> " + _clientinfo.getClientId());
                        }
                    }


                    if (_clientinfo.getClientId() != null && _clientinfo.getClientId().Length > 0)
                    {
                        logger.Debug("fetching other details for client id -->" + _clientinfo.getClientId());

                        using (OracleCommand oracom = new OracleCommand(string.Format("SELECT CLI_HNI_IND FROM TCLI WHERE CO_ID='CP'AND CLI_ID='{0}'", _clientinfo.getClientId()), oraconn))
                        {
                            logger.Debug("preparing to fetch agent details from ORACLE DB");
                            using (OracleDataReader rdr = oracom.ExecuteReader())
                            {
                                logger.Debug("got agent details from ORACLE DB ");
                                while (rdr.Read())
                                {
                                    _clientinfo.setHniFlag(rdr["CLI_HNI_IND"].ToString().Trim());
                                }

                            }

                            logger.Debug("client hni flag-->" + _clientinfo.getHniFlag());
                        }


                    }



                    // setting the axis flag....
                    using (OracleCommand oracom = new OracleCommand(string.Format("SELECT count(pol_id) as axiscount FROM tpol WHERE co_id = 'CP'  AND pol_id=rpad({0},10,' ')  AND serv_br_id LIKE 'X%'", polNum), oraconn))
                    {
                        logger.Debug("preparing to fetch agent details from ORACLE DB");
                        using (OracleDataReader rdr = oracom.ExecuteReader())
                        {
                            logger.Debug("got agent details from ORACLE DB ");
                            while (rdr.Read())
                            {
                                //_clientinfo.setAxisFlag(getAxisFlag(polNum));
                                if (rdr["axiscount"].ToString().Trim().Equals("0")) _clientinfo.setAxisFlag("N");

                                else _clientinfo.setAxisFlag("Y");
                            }
                        }
                    }




                    using (OracleCommand oracom = new OracleCommand(string.Format("select serv_agt_id from tpol where trim(pol_id)= {0}", polNum), oraconn))
                    {
                        logger.Debug("fetching the agent details based on agt id from ORACLE DB");

                        using (OracleDataReader rdr = oracom.ExecuteReader())
                        {
                            logger.Debug("got agent details from ORACLE DB ");
                            while (rdr.Read())
                            {
                                _clientinfo.setAgentId(rdr["serv_agt_id"].ToString().Trim());
                            }

                        }

                        logger.Debug("Agent ID fetched-->" + _clientinfo.getAgentId());
                    }


                    if (_clientinfo.getAgentId() != null && !_clientinfo.getAgentId().Equals(""))
                    {

                        using (OracleCommand oracom = new OracleCommand(string.Format("select strtitle, strfirstname, strlastname from chm_agent_m@dbmonul where stragentcd = '{0}'", _clientinfo.getAgentId().Trim()), oraconn))
                        {
                            logger.Debug("fetching the agent name,title etc based on agt id from ORACLE DB ");

                            using (OracleDataReader rdr = oracom.ExecuteReader())
                            {
                                logger.Debug("got agent details from ORACLE DB ");
                                while (rdr.Read())
                                {
                                    _clientinfo.setClientTitle(rdr["strtitle"].ToString().Trim());
                                    _clientinfo.setClientName(rdr["strfirstname"].ToString().Trim());
                                    _clientinfo.setClientSirName(rdr["strlastname"].ToString().Trim());


                                }

                            }

                            logger.Debug("agetnt name fetched--> " + _clientinfo.getClientTitle() + " " + _clientinfo.getClientName() + " " + _clientinfo.getClientSirName());
                        }

                        // now fetching agent email id....

                        using (OracleCommand oracom = new OracleCommand(string.Format("select stremailaddr from com_client_email@dbmonul where strclientcd in (select strclientcd from chm_agent_m@dbmonul where stragentcd = '{0}')", _clientinfo.getAgentId().Trim()), oraconn))
                        {
                            logger.Debug("fetching the agent name,title etc based on agt id from ORACLE DB");

                            using (OracleDataReader rdr = oracom.ExecuteReader())
                            {
                                logger.Debug("got agent details from ORACLE DB ");
                                while (rdr.Read())
                                {
                                    _clientinfo.setClientEmail(rdr["stremailaddr"].ToString().Trim());


                                }
                            }
                            if(_clientinfo.getClientEmail() != "")
                            logger.Debug("agent email id not found");
                            else
                                logger.Debug("agent email id fetched--> " + _clientinfo.getClientEmail());
                        }

                    }


                    else
                    {
                        logger.Debug("agent id not found for pol no::" + polNum);
                    }
                }  // End of connection String 


            }


            catch (SqlException e)
            {

                logger.Error("Error while getting client detail for " + polNum + ", " + e.Message);
                logger.Error("Message -> " + e.Message);
                logger.Error("StackTrace -> " + e.StackTrace);
                //throw new PortalException(e);
            }
            catch (Exception e)
            {

                logger.Error("Error while getting client detail for " + polNum + ", " + e.Message);
                logger.Error("Message -> " + e.Message);
                logger.Error("StackTrace -> " + e.StackTrace);
                //throw new PortalException(e);
            }
            finally
            {
                //closeObjects(rs, pstmt, con);
            }
            return _clientinfo;
        }

        // Agent  Related Info Ended //////////////////////////////////////////////////////////////////////// 

        public EmailResponse SendCustomerMail(DataRow dr, SqlServerResource sqlServerResource, string custype)
        {
            _conntooracle = new ConnectToOracle();
            _emailresponse = new EmailResponse();

            try
            {
                logger.Debug("opening oracle data source");
                using (OracleConnection oraconn = new OracleConnection(_conntooracle.GetConnectionstring()))
                {
                    if (oraconn.State == ConnectionState.Closed) oraconn.Open();
                    logger.Debug("oracle data source succesfully opened");
                    using (OracleCommand oracom = new OracleCommand(string.Format(sqlServerResource.getORACLESQLString("ORACLE_CLIENT_DETAILS"), dr["POL_NUM"].ToString(), custype), oraconn))
                    {
                        logger.Debug("Retrieving data from Oracle DB");
                        logger.Debug("Policy No." + dr["POL_NUM"].ToString());
                        using (OracleDataReader rdr = oracom.ExecuteReader())
                        {
                            logger.Debug("data from Oracle DB Retrieved");
                            _clientinfo = new ClientInfo();
                            while (rdr.Read())
                            {
                                _clientinfo.setClientName(rdr["ENTR_GIV_NM"].ToString().Trim());
                                _clientinfo.setClientSirName(rdr["ENTR_SUR_NM"].ToString().Trim());
                                _clientinfo.setClientTitle(rdr["CLI_INDV_TITL_TXT"].ToString().Trim());
                                _clientinfo.setClientId(rdr["CLI_ID"].ToString().Trim());
                                _clientinfo.setClientEmail(rdr["MAIL_ID"].ToString().Trim());
                                _clientinfo.setHniFlag(rdr["CLI_HNI_IND"].ToString().Trim());
                                _clientinfo.setPolId(dr["POL_NUM"].ToString().Trim());
                                //_clientinfo.setAgentId(dr[""].ToString());                   
                            }
                            logger.Debug("Client Info Class Initiliazed");
                        }
                    }

                    if (_clientinfo.getClientEmail().Trim() != null && _clientinfo.getClientEmail().Trim() != "")
                    {
                        logger.Debug("Initiliazing oracle command for Axis Customer");
                        using (OracleCommand oracom = new OracleCommand(string.Format(sqlServerResource.getORACLESQLString("ORACLE_AXIS_DETAILS"), dr["POL_NUM"].ToString()), oraconn))
                        {
                            logger.Debug("Initiliazed oracle command for Axis Customer");
                            logger.Debug("Retrieving data from Oracle DB");
                            using (OracleDataReader rdr = oracom.ExecuteReader())
                            {
                                logger.Debug("data from Oracle DB Retrieved");

                                while (rdr.Read())
                                {
                                    if (rdr["axiscount"].ToString().Trim().Equals("0")) { _clientinfo.setAxisFlag("N"); logger.Debug("Axis Flag :> N"); }

                                    else { _clientinfo.setAxisFlag("Y"); logger.Debug("Axis Flag :> Y"); }
                                }

                            }
                        }
                    }

                }


                if (custype.Equals("O"))
                    _emailresponse.setCustOwnerEmaiId(_clientinfo.getClientEmail());
                else if (custype.Equals("A"))
                    _emailresponse.setCustAssgneEmaiId(_clientinfo.getClientEmail());


                if (_clientinfo != null)
                {
                    if (_clientinfo.getClientId() != null && !_clientinfo.getClientId().Equals(""))
                    {

                        // for test purpose.....
                        //_clientinfo.setClientEmail("rishabh.dixit@maxlifeinsurance.com");
                        if (_clientinfo.getClientEmail() == null || _clientinfo.getClientEmail().Trim().Equals(""))
                        {
                            logger.Debug("Customer Email-Id not found for " + custype);

                            _emailresponse.setCustOwnerEmaiId("");
                            _emailresponse.setCustAssgneEmaiId("");
                            _emailresponse.setErrorDescEmail("E-mail id not in ingenium");
                            _emailresponse.setSuccessFlag(false);
                        }
                        else if (_clientinfo.getClientName() == null || _clientinfo.getClientName().Trim().Equals(""))
                        {
                            logger.Debug("Customer Name not found for " + custype);

                            _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                            _emailresponse.setSuccessFlag(false);
                        }
                        else if (_clientinfo.getHniFlag() == null || _clientinfo.getAxisFlag() == null)
                        {
                            logger.Debug("Customer Flagging not found for " + custype);

                            _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                            _emailresponse.setSuccessFlag(false);
                        }
                        else
                        {

                            String _strEmail = _clientinfo.getClientEmail();
                            Match match = Regex.Match(_strEmail, "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

                            //String _strEmail = _clientinfo.getClientEmail();
                            //String EMAIL_REGEX = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                            //bool b = _strEmail.match(EMAIL_REGEX);

                            if (match.Success)
                            {
                                logger.Debug("Sending Mail to client");
                                bool emailSentStatus = SendEmail(_clientinfo, dr);
                                logger.Debug("Mail processed with Status ::" + emailSentStatus);
                                //  EmailProcessor proc = new EmailProcessor();
                                //bool emailSentStatus = proc.sendEmailRequest(cliDVO, dataDVO);
                                _emailresponse.setSuccessFlag(emailSentStatus);
                            }
                            else
                            {
                                logger.Debug("Incomplete E-mail ID");
                                _emailresponse.setErrorDescEmail("Incomplete E-mail ID");
                                _emailresponse.setSuccessFlag(false);
                            }
                        }
                    }
                    else
                    {
                        logger.Debug(custype + " does not exists");
                        _emailresponse.setErrorDesc(custype + " not exists");
                        _emailresponse.setSuccessFlag(false);
                        _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                    }

                }
                else
                {
                    _emailresponse.setSuccessFlag(false);
                    _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                    logger.Info("CLIDVO is null: ");
                }

            }
            catch (Exception e)
            {

                logger.Error("error in fetching customer details for " + custype, e);
                logger.Error("Message -> " + e.Message);
                logger.Error("StackTrace -> " + e.StackTrace);
                _emailresponse.setSuccessFlag(false);
                #region Changed By Ripon
                if (e.Message == "ORA-12570: Network Session: Unexpected packet read error")
                {
                    _emailresponse.setErrorDescEmail("Oracle Did'nt Respond");
                }
                else
                {
                    _emailresponse.setErrorDescEmail("E-Mail Not Sent");
                }
                #endregion
            }

            return _emailresponse;
        }


        public int MarkRowExtracted(long seqNum, String errDesc, String myFlowType, String mobOrEmail)
        {
            int flag = 0;
            String strSearchSql = "";
            try
            {
                logger.Debug("Getting Sql Resouce File");
                SqlServerResource sqlServerResource = new SqlServerResource();

                strSearchSql = sqlServerResource.getSQLSERVERSQLString("SQLSERVER_MARK_PROCESSED_SQL");

                if (myFlowType.ToUpper().Equals("MYFLOWEMAIL"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, mobOrEmail, "", seqNum);

                }
                else if (myFlowType.ToUpper().Equals("MYFLOWSMS"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, "", mobOrEmail, seqNum);
                }

                flag = executeUpdate(strSearchSql);

            }
            catch (Exception ex)
            {
                logger.Error("Message -> " + ex.Message);
                logger.Error("StackTrace -> " + ex.StackTrace);
            }//ex.StackTrace; }
            return flag;
        }

        public int markRowError(long seqNum, String errDesc, String myFlowType, String mobOrEmail)
        {

            int flag = 0;
            String strSearchSql = "";
            try
            {

                SqlServerResource sqlServerResource = new SqlServerResource();
                strSearchSql = sqlServerResource.getSQLSERVERSQLString("SQLSERVER_MARK_ERROR_SQL");

                if (myFlowType.ToUpper().Equals("MYFLOWEMAIL"))
                {
                    strSearchSql = string.Format(strSearchSql, errDesc, mobOrEmail, "", seqNum);

                }
                else if (myFlowType.ToUpper().Equals("MYFLOWSMS"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, "", mobOrEmail, seqNum);
                }



                flag = executeUpdate(strSearchSql);

            }
            catch (Exception ex)
            {
                logger.Error("Message -> " + ex.Message);
                logger.Error("StackTrace -> " + ex.StackTrace);
            }//ex.printStackTrace();}
            return flag;
        }

        public int executeUpdate(string commandtext)
        {
            logger.Debug("Getting Sql Connection for updating record");
            using (SqlConnection sqlConnection = ConnectToSqlServer.GetConnection())
            {
                try
                {
                    if (sqlConnection.State == ConnectionState.Closed) sqlConnection.Open();

                    using (SqlCommand sqlCommand = new SqlCommand(commandtext, sqlConnection))
                    {
                        sqlCommand.CommandTimeout = 300;
                        sqlCommand.ExecuteNonQuery();
                        logger.Debug("Record Updated");
                        return 1;

                    }
                }

                catch (Exception ex)
                {
                    logger.Error("Error in Record Updation");
                    logger.Error("Message -> " + ex.Message);
                    logger.Error("StackTrace -> " + ex.StackTrace);
                    return 0;
                }
            }


        }
    }
}