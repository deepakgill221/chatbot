﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFlowEmailWindowsService
{
    class EmailHeaderFooter
    {

        // HNI Customer
        private string LINK_LOGO_HNI = "http://www.maxlifeinsurance.com/Customer_Comm1/Top_Band/T3-GC-Color.jpg";
        //private string LINK_FOOTER_HNI = "https://www.maxlifeinsurance.com/customer_comm1/gst17/I1-FIN_GC_CIN_Band-JV-line_MixedFont-01.jpg";
        private string LINK_FOOTER_HNI = "https://buyonline.maxlifeinsurance.com/customer_comm1/Contact_bands/B1-GC_CIN_Band%20&%20JV%20line_MixedFont-01-01.jpg";
        private string HNI_COMMENT = "Please write back to us in case you should require any further assistance or call us <br> toll free at 18601205577 or write us at goldcircle@maxlifeinsurance.com";

        // Non HNI Customer
        private string LINK_LOGO_NONHNI = "http://www.maxlifeinsurance.com/Customer_Comm1/Top_Band/T1-NGC-Color.jpg";
        //private string LINK_FOOTER_NONHNI = "https://www.maxlifeinsurance.com/customer_comm1/gst17/J1-Fin_NGC_Band-JV-line_MixedFont-01.jpg";
        private string LINK_FOOTER_NONHNI = "https://buyonline.maxlifeinsurance.com/customer_comm1/Contact_bands/A1-NGC_Band%20&%20JV%20line_MixedFont-01.jpg";
        private string NON_HNI_COMMENT = "Please write back to us in case you should require any further assistance or call us <br> toll free at 18601205577 or write us at service.helpdesk@maxlifeinsurance.com";

        // Axis Customer
        private string LINK_LOGO_AXIS = "http://www.maxlifeinsurance.com/Customer_Comm1/Bands/Color_Bands/AxisBand_h.jpg";
        //private string LINK_FOOTER_AXIS = "https://www.maxlifeinsurance.com/customer_comm1/gst17/C1-Axis-Band-JV-line_MixedFont-01.jpg ";
        private string LINK_FOOTER_AXIS = "https://buyonline.maxlifeinsurance.com/customer_comm1/Contact_bands/K1-Axis%20FIN%20Band%20&%20JV%20line_MixedFont-01-01.jpg";
        private string AXIS_COMMENT = "Please write back to us in case you should require any further assistance or call us <br> toll free at 18601205577 or write us at axis.helpdesk@maxlifeinsurance.com";



        public String getLogo(String a_strkeyString)
        {
            if (a_strkeyString.Equals("LINK_LOGO_HNI"))
            {             
                return LINK_LOGO_HNI;
            }

            if (a_strkeyString.Equals("LINK_LOGO_NONHNI"))
            {
                return LINK_LOGO_NONHNI;
            }

            if (a_strkeyString.Equals("LINK_LOGO_AXIS"))
            {
                return LINK_LOGO_AXIS;
            }

            return null;
        }

        public String getFooter(String a_strkeyString)
        {
            if (a_strkeyString.Equals("LINK_FOOTER_HNI"))
            {
                return LINK_FOOTER_HNI;
            }

            if (a_strkeyString.Equals("LINK_FOOTER_NONHNI"))
            {
                return LINK_FOOTER_NONHNI;
            }

            if (a_strkeyString.Equals("LINK_FOOTER_AXIS"))
            {
                return LINK_FOOTER_AXIS;
            }

            return null;
        }


        public String getComment(String a_strkeyString)
        {
            if (a_strkeyString.Equals("HNI_COMMENT"))
            {
                return HNI_COMMENT;
            }

            if (a_strkeyString.Equals("NON_HNI_COMMENT"))
            {
                return NON_HNI_COMMENT;
            }

            if (a_strkeyString.Equals("AXIS_COMMENT"))
            {
                return AXIS_COMMENT;
            }

            return null;
        }

    }
}
