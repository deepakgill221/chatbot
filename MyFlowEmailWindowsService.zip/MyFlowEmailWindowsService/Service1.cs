﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Timers;
using System.Threading;
using System.Data.SqlClient;
using log4net;
using System.Net;
using System.IO;

namespace MyFlowEmailWindowsService
{
    public partial class Service1 : ServiceBase
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static object _padlock = new object();
        System.Timers.Timer timer = new System.Timers.Timer();//Timer object
        //Int32 intInterval = 0;
        TimeSpan tsStartTime, tsEndTime, tsCurrent;
        TimeSpan start = new TimeSpan(08, 0, 0); //Morning  8  AM
        TimeSpan end = new TimeSpan(21, 02, 0);   //Evening  9  PM

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            logger.Debug("MyFlowSmsWindowsService has started successfully..");
            logger.Debug("Assigning Initial values...");
            SetInitialValue();
            logger.Debug("Initial values have assigned successfully.");
            // This will call in each miniute.            
            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);//This statement is used to set interval to 1 minute (= 60,000 milliseconds)
            //timer.AutoReset = true;
            timer.Interval = 60000;
            timer.Enabled = true;
        }

        protected override void OnStop()
        {
            TimeSpan now = DateTime.Now.TimeOfDay;
            if ((now > start) && (now < end))
            {
                string CurrentDirectory = string.Concat(System.AppDomain.CurrentDomain.BaseDirectory, @"LogFiles\");
                string FileName = "TLog.txt";
                if (File.Exists(string.Concat(CurrentDirectory, FileName)))
                {
                    logger.Debug("MyFlowSmsWindowsService has Stopped successfully..");
                    string today = DateTime.Now.ToString("dd_MM_yyyy_HH-mm");
                    string RenamedLog = string.Concat("TLog", "_", today, ".txt");
                    try
                    {
                        System.IO.File.Move(string.Concat(CurrentDirectory, FileName), string.Concat(CurrentDirectory, RenamedLog));
                    }
                    catch
                    {
                        logger.Debug("Rename Failed");
                    }
                }
            }
        }
        [STAThread]
        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {

            try
            {
                timer.Stop();

                lock (_padlock)
                {
                    // do some heavy processing... 
                    tsCurrent = TimeSpan.Parse(DateTime.Now.ToString("HH:mm"));

                    if (tsCurrent >= tsStartTime && tsCurrent <= tsEndTime)
                    {
                        #region Main Method for Sending MyFlowSms
                        try
                        {
                            logger.Info("Application Started");
                            logger.Info("Getting SQL Server Connection");

                            using (SqlConnection sqlConnection = ConnectToSqlServer.GetConnection())
                            {
                                try
                                {
                                    if (sqlConnection.State == ConnectionState.Closed) sqlConnection.Open();
                                    logger.Debug("SQL Server Connection Established");
                                    SqlServerResource sqlServerResource = new SqlServerResource();
                                    logger.Debug("SQL Server Resouce Object Created");

                                    // Starting Deletion of MyflowMqXML Table
                                    logger.Debug("Deleting Processed Data");
                                    using (SqlCommand sqlCommand = new SqlCommand(string.Format(sqlServerResource.getSQLSERVERSQLString("SQLSERVER_DELETE_PROCESSED_XML_SQL")), sqlConnection))
                                    {
                                        sqlCommand.CommandTimeout = 10000;
                                        sqlCommand.ExecuteNonQuery();
                                    }
                                    logger.Debug("Processed Data deleted");


                                    // Calling MYFLOW EMAIL Procedure
                                    logger.Debug("Calling Myflow Email Procedure");
                                    using (SqlCommand sqlCommand = new SqlCommand(string.Format(sqlServerResource.getSQLSERVERSQLString("SQLSERVER_CALL_PROCEDURE_SQL_EMAIL")), sqlConnection))
                                    {
                                        sqlCommand.CommandTimeout = 30000;
                                        sqlCommand.CommandType = CommandType.StoredProcedure;
                                        int _result = sqlCommand.ExecuteNonQuery();

                                    }
                                    logger.Debug("Procedure Executed Succesfully");

                                    // Updating the Email Records whose XML is NULL
                                    logger.Debug("Updating the Email Records whose XML is NULL");
                                    using (SqlCommand sqlCommand = new SqlCommand(string.Format(sqlServerResource.getSQLSERVERSQLString("SQL_UPDATE_NULL_XML_SQL_EMAIL")), sqlConnection))
                                    {
                                        sqlCommand.CommandTimeout = 10000;
                                        sqlCommand.ExecuteNonQuery();
                                    }
                                    logger.Debug("Email Records Updated whose XML is NULL");


                                    // Starting Deletion of MyflowMqXML Table
                                    logger.Debug("Starting Deletion of MyflowMqXML Table");
                                    using (SqlCommand sqlCommand = new SqlCommand(string.Format(sqlServerResource.getSQLSERVERSQLString("SQLSERVER_DELETE_PROCESSED_XML_SQL")), sqlConnection))
                                    {
                                        sqlCommand.CommandTimeout = 10000;
                                        sqlCommand.ExecuteNonQuery();

                                    }
                                    logger.Debug("MyflowMqXML Table deleted");

                                    //// Started Processing of Data
                                    //Started Processing of Data                        
                                    ProcessData processData = new ProcessData();
                                    logger.Debug("Process Data Object Created");
                                    logger.Debug("calling processxmldata");
                                    processData.processxmldata(sqlConnection, sqlServerResource);
                                    logger.Debug("processxmldata execution completed");


                                }

                                catch (Exception ex)
                                {
                                    logger.Error("Message -> " + ex.Message);
                                    logger.Error("StackTrace -> " + ex.StackTrace);
                                }

                            }

                        }

                        catch (Exception ex)
                        {
                            logger.Error("Message -> " + ex.Message);
                            logger.Error("StackTrace -> " + ex.StackTrace);
                        }

                        finally
                        {
                            logger.Debug("Ending  the Service Instance");
                            logger.Debug("                            ");
                            logger.Debug("                            ");
                            logger.Debug("                            ");
                            logger.Debug("                            ");
                            logger.Debug("                            ");
                            logger.Debug("                            ");
                        }
                        #endregion
                    }
                    else
                    {
                        OnStop();
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Debug("Error:" + ex.Message);

            }
            finally
            {
                timer.Start();
            }
        }

        private void SetInitialValue()
        {
            //Start Time of Day
            tsStartTime = TimeSpan.Parse(ConfigurationManager.AppSettings["StartTime"].ToString());
            //tsStartTime = TimeSpan.Parse("08:00");


            //End time of Day
            tsEndTime = TimeSpan.Parse(ConfigurationManager.AppSettings["EndTime"].ToString());
            //tsEndTime = TimeSpan.Parse("21:00");

        }
    }
}
