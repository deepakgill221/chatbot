﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace MyFlowEmailWindowsService
{
    static class ConnectToSqlServer
    {
        //public static SqlConnection _connection()
        //{
        //    SqlConnection sqlConnection = null;
        //    sqlConnection = new SqlConnection(@"Data Source=172.23.51.65\myflow,4967;Initial Catalog=MyFlow;User ID=jts_user;Password=sputuser");
        //    return sqlConnection;
        //}


        public static SqlConnection GetConnection()
        {
            string strConnString ="";
            try
            {
                string dbUserName = ConfigurationManager.AppSettings["SqlDBUserName"].ToString();
                string dbPassword = ConfigurationManager.AppSettings["SqlDBPassword"].ToString();
                string dbHost = ConfigurationManager.AppSettings["SqlServerIP"].ToString();
                string dbPort = ConfigurationManager.AppSettings["SqlServerPort"].ToString();
                string dbSID = ConfigurationManager.AppSettings["SqlDBName"].ToString();

                strConnString = @"Data Source="+dbHost+"\\myflow,"+dbPort+";Initial Catalog="+dbSID+";User ID="+dbUserName+";Password="+dbPassword;
            }

            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
            }
            return new SqlConnection(strConnString);
        }
    }
}
