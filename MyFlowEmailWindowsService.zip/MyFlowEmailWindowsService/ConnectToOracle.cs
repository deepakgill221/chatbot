﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
//using System.Data.OracleClient;

using Oracle.ManagedDataAccess.Client;
using System.Configuration;
using System.IO;
//using RSASecurity;

namespace MyFlowEmailWindowsService
{
    class ConnectToOracle
    {

        string dbUserName = "", dbPassword = "", dbHost = "", dbPort = "", dbSID = ""; OracleConnection oraconn = null;

        private OracleConnection GetConnection()
        {
            try
            {
               // string strConfigPath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "ManageConfig.ini";
               // string[] strValues = File.ReadAllLines(strConfigPath);
                dbUserName = ConfigurationManager.AppSettings["OraDBUserName"].ToString();
                dbPassword = ConfigurationManager.AppSettings["OraDBPassword"].ToString();
                dbHost = ConfigurationManager.AppSettings["OraHost"].ToString();
                dbPort = ConfigurationManager.AppSettings["OraPort"].ToString();
                dbSID = ConfigurationManager.AppSettings["OraSID"].ToString();
                //string strConnString = "SERVER=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.23.51.16)(PORT=1875))(CONNECT_DATA=(SERVICE_NAME=TB640IP5)));uid=SCOPPUT;pwd=feb#2014;";
                string strConnString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=" + dbHost + ")(PORT=" + dbPort + "))(CONNECT_DATA=(SERVICE_NAME=" + dbSID + ")));User Id=" + dbUserName + ";Password=" + dbPassword + ";";
                return new OracleConnection(strConnString);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public string GetConnectionstring()
        {
            try
            {
                // string strConfigPath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "ManageConfig.ini";
                // string[] strValues = File.ReadAllLines(strConfigPath);
                dbUserName = ConfigurationManager.AppSettings["OraDBUserName"].ToString();
                dbPassword = ConfigurationManager.AppSettings["OraDBPassword"].ToString();
                dbHost = ConfigurationManager.AppSettings["OraHost"].ToString();
                dbPort = ConfigurationManager.AppSettings["OraPort"].ToString();
                dbSID = ConfigurationManager.AppSettings["OraSID"].ToString();
                //string strConnString = "SERVER=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.23.51.16)(PORT=1875))(CONNECT_DATA=(SERVICE_NAME=TB640IP5)));uid=SCOPPUT;pwd=feb#2014;";
                string strConnString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=" + dbHost + ")(PORT=" + dbPort + "))(CONNECT_DATA=(SERVICE_NAME=" + dbSID + ")));User Id=" + dbUserName + ";Password=" + dbPassword + ";";
                return strConnString;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void ExecuteProcedure(string strProcName)
        {
            try
            {
                OracleConnection oConn = GetConnection();

                if (oConn != null)
                {
                    oConn.Open();
                    OracleCommand cmd = new OracleCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = strProcName;
                    cmd.Connection = oConn;
                    cmd.ExecuteNonQuery();

                    oConn.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

    }
}
