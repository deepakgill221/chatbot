﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace MyFlowEmailWindowsService
{
    class DataExtract
    {

    private long xmlSeqNum;
    private String xmlContent;
    private String sourceSystem;
    private String messageType;
    private DateTime recordCreatedDate;
    private String recordPolicyNumber;
    private String holderName;
    private String charType;
    
    public String getCharType() {
		return charType;
	}

	public void setCharType(String charType) {
		this.charType = charType;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	/* added by gopaln 29 nov 2012*/
    private String eMailType;
    
    /* addeb by mohit on 11June14*/
    private String phoneNum;
    
    public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	/**
     * @return type of Message - header field
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * @return date when record was created in database table - header field
     */
    public DateTime getRecordCreatedDate() {
    	DateTime date = recordCreatedDate;
        return date;
    }

    public String getRecordPolicyNumber() {
        return recordPolicyNumber;
    }

    /**
     * @return Originating System for current data - header field
     */
    public String getSourceSystem() {
        return sourceSystem;
    }

    /**
     * @return the actual content of the record in XML format 
     */
    public String getXmlContent() {
        return xmlContent;
    }

    /**
     * @param string type of Message - header field
     */
    public void setMessageType(String _string) {
        messageType = _string;
    }

    /**
     * @param date date when record was created in database table - header field
     */
    public void setRecordCreatedDate(DateTime date) {
    	DateTime myDate = date;
        recordCreatedDate = myDate;
    }

    public void setRecordPolicyNumber(String _string) {
    	recordPolicyNumber = _string;
    }

    /**
     * @param string Originating System for current data - header field
     */
    public void setSourceSystem(String _string) {
        sourceSystem = _string;
    }

    /**
     * @param string the actual content of the record in XML format 
     */
    public void setXmlContent(String _string) {
        xmlContent = _string;
    }

	public long getXmlSeqNum() {
		return xmlSeqNum;
	}

	public void setXmlSeqNum(long xmlSeqNum) {
		this.xmlSeqNum = xmlSeqNum;
	}
    
}
}
