package com.qc.api.request;

import java.io.Serializable;

public class WipApiRequest implements Serializable
{
	private static final long serialVersionUID = 1L;
	private ApiRequestHeader header;
	private WipReqestPayload payload;
	
	public WipApiRequest() {
		super();
	}
	
	public WipApiRequest(ApiRequestHeader header, WipReqestPayload payload) {
		super();
		this.header = header;
		this.payload= payload;
	}

	public ApiRequestHeader getHeader() {
		return header;
	}

	public void setHeader(ApiRequestHeader header) {
		this.header = header;
	}

	public WipReqestPayload getPayload() {
		return payload;
	}

	public void setPayload(WipReqestPayload payload) {
		this.payload = payload;
	}
	
}
