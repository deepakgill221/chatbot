package com.qc.api.dto;

public enum STATUSCODE {

	 OK(200),
    INVALID_REQUEST(400),
    SERVER_ERROR(500);
	
    private final int value;

    STATUSCODE(final int newValue) {
        value = newValue;
    }

    public int getValue() { return value; }
}
