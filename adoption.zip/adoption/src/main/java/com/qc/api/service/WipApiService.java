package com.qc.api.service;

import com.qc.api.request.WipApiRequest;
import com.qc.api.response.WipApiResponse;

public interface WipApiService 
{
	public WipApiResponse HibCrudOpt(WipApiRequest wipApiRequest);


}
