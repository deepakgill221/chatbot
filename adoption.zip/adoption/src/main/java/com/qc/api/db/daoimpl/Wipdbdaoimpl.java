package com.qc.api.db.daoimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.db.dao.Wipdbdao;
import com.qc.api.request.WipApiRequest;
import com.qc.api.response.WipApiResponse;
import com.qc.api.response.WipPayloadResponse;
import com.qc.api.sessionfactory.Sessionfactoryobject;
import com.qc.hibernateEntity.BeanEntity;

@Repository
@Transactional
public class Wipdbdaoimpl extends Sessionfactoryobject implements Wipdbdao 
{
	private static Logger logger = LogManager.getLogger(Wipdbdaoimpl.class);
	@Override
	public WipApiResponse InsertData(WipApiRequest wipApiRequest) 
	{
		logger.info("Inside Method :: InsertData");
		WipPayloadResponse wipResponse= new WipPayloadResponse();
		WipApiResponse response = new WipApiResponse();
		BeanEntity entity = new BeanEntity();
		entity.setSESSION_ID(wipApiRequest.getPayload().getTransaction().get(0).getSession_Id());
		entity.setSSO_ID(wipApiRequest.getPayload().getTransaction().get(0).getSsoId());
		entity.setKPI_ASKED(wipApiRequest.getPayload().getTransaction().get(0).getKpiAsked());
		entity.setINTENT_CALLED(wipApiRequest.getPayload().getTransaction().get(0).getIntentCalled());
		entity.setPLATFORM(wipApiRequest.getPayload().getTransaction().get(0).getPlatform());
		entity.setLOGIN_TIME(wipApiRequest.getPayload().getTransaction().get(0).getLoginTime());
		entity.setAPI_Response(wipApiRequest.getPayload().getTransaction().get(0).getApiResponse());
		try
		{
			logger.info("GetSession from Session Factory and Save Entity ::  START");
			getSession().save(entity);
			logger.info("GetSession from Session Factory and Save Entity ::  END");
		}
		catch(Exception ex)
		{
			logger.info("Exception occoured while getting session from database");
		}
		wipResponse.setMessage("DataInserted");
		response.setResponse(wipResponse);
		return response;
	}
}
