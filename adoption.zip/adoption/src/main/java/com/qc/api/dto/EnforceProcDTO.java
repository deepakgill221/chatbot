package com.qc.api.dto;

public class EnforceProcDTO 
{
	private String daily_inforced_afyp;
	private String daily_inforced_count;
	private String daily_adj_mfyp;
	private String mtd_inforced_afyp;
	private String mtd_inforced_count;
	private String mtd_adj_mfyp;
	
	public EnforceProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getDaily_inforced_afyp() {
		return daily_inforced_afyp;
	}

	public void setDaily_inforced_afyp(String daily_inforced_afyp) {
		this.daily_inforced_afyp = daily_inforced_afyp;
	}

	public String getDaily_inforced_count() {
		return daily_inforced_count;
	}

	public void setDaily_inforced_count(String daily_inforced_count) {
		this.daily_inforced_count = daily_inforced_count;
	}

	public String getDaily_adj_mfyp() {
		return daily_adj_mfyp;
	}

	public void setDaily_adj_mfyp(String daily_adj_mfyp) {
		this.daily_adj_mfyp = daily_adj_mfyp;
	}

	public String getMtd_inforced_afyp() {
		return mtd_inforced_afyp;
	}

	public void setMtd_inforced_afyp(String mtd_inforced_afyp) {
		this.mtd_inforced_afyp = mtd_inforced_afyp;
	}

	public String getMtd_inforced_count() {
		return mtd_inforced_count;
	}

	public void setMtd_inforced_count(String mtd_inforced_count) {
		this.mtd_inforced_count = mtd_inforced_count;
	}

	public String getMtd_adj_mfyp() {
		return mtd_adj_mfyp;
	}

	public void setMtd_adj_mfyp(String mtd_adj_mfyp) {
		this.mtd_adj_mfyp = mtd_adj_mfyp;
	}
	
}
