package com.qc.api.dto;

public enum ERRORSTATUS {

	SUCCESS,FAILURE;
}
