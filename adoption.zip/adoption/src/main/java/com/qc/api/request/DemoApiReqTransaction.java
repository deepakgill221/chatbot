package com.qc.api.request;


public class DemoApiReqTransaction  
{
	private String session_Id;
	private String ssoId;
	private String kpiAsked;
	private String intentCalled;
	private String platform;
	private String loginTime;
	private String apiResponse;
	
	public String getSession_Id() {
		return session_Id;
	}
	public void setSession_Id(String session_Id) {
		this.session_Id = session_Id;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getKpiAsked() {
		return kpiAsked;
	}
	public void setKpiAsked(String kpiAsked) {
		this.kpiAsked = kpiAsked;
	}
	public String getIntentCalled() {
		return intentCalled;
	}
	public void setIntentCalled(String intentCalled) {
		this.intentCalled = intentCalled;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}
	public String getApiResponse() {
		return apiResponse;
	}
	public void setApiResponse(String apiResponse) {
		this.apiResponse = apiResponse;
	}
	@Override
	public String toString() {
		return "DemoApiReqTransaction [session_Id=" + session_Id + ", ssoId=" + ssoId + ", kpiAsked=" + kpiAsked
				+ ", intentCalled=" + intentCalled + ", platform=" + platform + ", loginTime=" + loginTime
				+ ", apiResponse=" + apiResponse + "]";
	}
}
