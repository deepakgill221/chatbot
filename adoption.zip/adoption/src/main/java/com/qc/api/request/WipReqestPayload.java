package com.qc.api.request;

import java.io.Serializable;
import java.util.List;

public class WipReqestPayload implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<DemoApiReqTransaction> transaction;

	
	public List<DemoApiReqTransaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<DemoApiReqTransaction> transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "WipReqestPayload [transaction=" + transaction + "]";
	}
}
