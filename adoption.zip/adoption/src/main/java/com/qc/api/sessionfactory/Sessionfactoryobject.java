package com.qc.api.sessionfactory;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

public abstract class Sessionfactoryobject 
{
	@Autowired
	private LocalSessionFactoryBean sessionFactory;
	
	protected Session getSession() {
		Session  session=sessionFactory.getObject().getCurrentSession();
		if(session==null)
		{
			session=sessionFactory.getObject().openSession();
		}
		return session;
	}
	
/*	protected Session getSession() {
		return sessionFactory.getObject().getCurrentSession();
	}*/
	
	

}
