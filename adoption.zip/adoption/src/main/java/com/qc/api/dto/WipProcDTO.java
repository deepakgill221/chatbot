package com.qc.api.dto;

public class WipProcDTO 
{
	private String wip_afyp;
	private String ho_wip_afyp;
	private String go_wip_afyp;
	private String it_wip_afyp;
	private String fin_wip_afyp;
	private String misc_wip_afyp;
	private String welcome_wip_afyp;
	private String wip_count;
	private String ho_wip_count;
	private String go_wip_count;
	private String it_wip_count;
	private String fin_wip_count;
	private String misc_wip_count;
	private String welcome_wip_count;
	
	public WipProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getWip_afyp() {
		return wip_afyp;
	}

	public void setWip_afyp(String wip_afyp) {
		this.wip_afyp = wip_afyp;
	}

	public String getHo_wip_afyp() {
		return ho_wip_afyp;
	}

	public void setHo_wip_afyp(String ho_wip_afyp) {
		this.ho_wip_afyp = ho_wip_afyp;
	}

	public String getGo_wip_afyp() {
		return go_wip_afyp;
	}

	public void setGo_wip_afyp(String go_wip_afyp) {
		this.go_wip_afyp = go_wip_afyp;
	}

	public String getIt_wip_afyp() {
		return it_wip_afyp;
	}

	public void setIt_wip_afyp(String it_wip_afyp) {
		this.it_wip_afyp = it_wip_afyp;
	}

	public String getFin_wip_afyp() {
		return fin_wip_afyp;
	}

	public void setFin_wip_afyp(String fin_wip_afyp) {
		this.fin_wip_afyp = fin_wip_afyp;
	}

	public String getMisc_wip_afyp() {
		return misc_wip_afyp;
	}

	public void setMisc_wip_afyp(String misc_wip_afyp) {
		this.misc_wip_afyp = misc_wip_afyp;
	}

	public String getWelcome_wip_afyp() {
		return welcome_wip_afyp;
	}

	public void setWelcome_wip_afyp(String welcome_wip_afyp) {
		this.welcome_wip_afyp = welcome_wip_afyp;
	}

	public String getWip_count() {
		return wip_count;
	}

	public void setWip_count(String wip_count) {
		this.wip_count = wip_count;
	}

	public String getHo_wip_count() {
		return ho_wip_count;
	}

	public void setHo_wip_count(String ho_wip_count) {
		this.ho_wip_count = ho_wip_count;
	}

	public String getGo_wip_count() {
		return go_wip_count;
	}

	public void setGo_wip_count(String go_wip_count) {
		this.go_wip_count = go_wip_count;
	}

	public String getIt_wip_count() {
		return it_wip_count;
	}

	public void setIt_wip_count(String it_wip_count) {
		this.it_wip_count = it_wip_count;
	}

	public String getFin_wip_count() {
		return fin_wip_count;
	}

	public void setFin_wip_count(String fin_wip_count) {
		this.fin_wip_count = fin_wip_count;
	}

	public String getMisc_wip_count() {
		return misc_wip_count;
	}

	public void setMisc_wip_count(String misc_wip_count) {
		this.misc_wip_count = misc_wip_count;
	}

	public String getWelcome_wip_count() {
		return welcome_wip_count;
	}

	public void setWelcome_wip_count(String welcome_wip_count) {
		this.welcome_wip_count = welcome_wip_count;
	}
	
}
