package com.qc.api.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.db.dao.Wipdbdao;
import com.qc.api.dto.AppInfo;
import com.qc.api.dto.ERRORSTATUS;
import com.qc.api.request.WipApiRequest;
import com.qc.api.response.WipApiResponse;
import com.qc.api.service.WipApiService;

@Service
public class WipApiServiceImpl implements WipApiService
{
	private static Logger logger = LogManager.getLogger(WipApiServiceImpl.class);

	@Autowired
	Wipdbdao wipdbdao;
	public WipApiResponse HibCrudOpt(WipApiRequest wipApiRequest) 
	{
		{
			WipApiResponse wipapiresponse= new WipApiResponse();
			AppInfo info = new AppInfo();
			try
			{
				if(wipApiRequest.getPayload().getTransaction()!=null)
				{
					wipapiresponse=wipdbdao.InsertData(wipApiRequest);
					wipapiresponse.setHeader(wipApiRequest.getHeader());
					info.setCode("200");
					info.setDescription("DATA INSERTED USING HIBERNATE CRUD OPERATION USING SPRING BOOT !");
					info.setMessage("DATA INSERTED SUCCESSFULLY");
					info.setStatus(ERRORSTATUS.SUCCESS);
					wipapiresponse.setInfo(info);
				}
			}catch(Exception e)	
			{
				logger.error("Exception occcoured in logic");
			}
			return wipapiresponse;
		}
	}
}
