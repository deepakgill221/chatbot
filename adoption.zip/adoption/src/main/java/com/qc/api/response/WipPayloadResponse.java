package com.qc.api.response;



public class WipPayloadResponse 
{
	private String message;

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "WipPayloadResponse [message=" + message + "]";
	}
	
}
