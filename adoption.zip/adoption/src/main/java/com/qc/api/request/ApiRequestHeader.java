package com.qc.api.request;

public class ApiRequestHeader 
{
	String uniqueId = "";
	String creationTime="";
	String userId = "";
	String password = "";
	
	
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "ApiRequestHeader [uniqueId=" + uniqueId + ", creationTime=" + creationTime + ", userId=" + userId
				+ ", password=" + password + "]";
	}
}
