package com.qc.api.dto;

public class AppliedProcDTO 
{
	private String daily_applied_afyp;
	private String daily_applied_count;
	private String mtd_applied_afyp;
	private String mtd_applied_count;
	
	public AppliedProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getDaily_applied_afyp() {
		return daily_applied_afyp;
	}

	public void setDaily_applied_afyp(String daily_applied_afyp) {
		this.daily_applied_afyp = daily_applied_afyp;
	}

	public String getDaily_applied_count() {
		return daily_applied_count;
	}

	public void setDaily_applied_count(String daily_applied_count) {
		this.daily_applied_count = daily_applied_count;
	}

	public String getMtd_applied_afyp() {
		return mtd_applied_afyp;
	}

	public void setMtd_applied_afyp(String mtd_applied_afyp) {
		this.mtd_applied_afyp = mtd_applied_afyp;
	}

	public String getMtd_applied_count() {
		return mtd_applied_count;
	}

	public void setMtd_applied_count(String mtd_applied_count) {
		this.mtd_applied_count = mtd_applied_count;
	}
	
}
