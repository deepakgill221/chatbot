package com.qc.api.response;

import java.io.Serializable;

import com.qc.api.dto.AppInfo;
import com.qc.api.request.ApiRequestHeader;

public class WipApiResponse implements Serializable
{
	private static final long serialVersionUID = 1L;
	private ApiRequestHeader header;
	private AppInfo info;
	private WipPayloadResponse response;
	
	public WipApiResponse() {
		super();
	}
	
	public WipApiResponse(ApiRequestHeader header, AppInfo info, WipPayloadResponse response ) {
		super();
	    this.header=header;
	    this.info=info;
	    this.response=response;
	}

	public ApiRequestHeader getHeader() {
		return header;
	}

	public void setHeader(ApiRequestHeader header) {
		this.header = header;
	}

	public AppInfo getInfo() {
		return info;
	}

	public void setInfo(AppInfo info) {
		this.info = info;
	}

	public WipPayloadResponse getResponse() {
		return response;
	}

	public void setResponse(WipPayloadResponse response) {
		this.response = response;
	}

}
