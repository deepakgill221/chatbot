package com.qc.api.db.dao;

import com.qc.api.request.WipApiRequest;
import com.qc.api.response.WipApiResponse;

public interface Wipdbdao 
{
	public WipApiResponse InsertData(WipApiRequest wipApiRequest);
	
	

}
