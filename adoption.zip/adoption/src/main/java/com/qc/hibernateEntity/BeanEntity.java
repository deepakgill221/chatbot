package com.qc.hibernateEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ADOPTION_LOGS_UAT")
public class BeanEntity 
{
	private long HibAutoIncrement;
	private String SESSION_ID;
	private String SSO_ID;
	private String KPI_ASKED;
	private String INTENT_CALLED;
	private String PLATFORM;
	private String LOGIN_TIME;
	private String API_Response;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="HIB_AUTO_INCREMENT")
	public long getHibAutoIncrement() {
		return HibAutoIncrement;
	}
	public void setHibAutoIncrement(long hibAutoIncrement) {
		HibAutoIncrement = hibAutoIncrement;
	}
	public String getSESSION_ID() {
		return SESSION_ID;
	}
	public void setSESSION_ID(String sESSION_ID) {
		SESSION_ID = sESSION_ID;
	}
	public String getSSO_ID() {
		return SSO_ID;
	}
	public void setSSO_ID(String sSO_ID) {
		SSO_ID = sSO_ID;
	}
	public String getKPI_ASKED() {
		return KPI_ASKED;
	}
	public void setKPI_ASKED(String kPI_ASKED) {
		KPI_ASKED = kPI_ASKED;
	}
	public String getINTENT_CALLED() {
		return INTENT_CALLED;
	}
	public void setINTENT_CALLED(String iNTENT_CALLED) {
		INTENT_CALLED = iNTENT_CALLED;
	}
	public String getPLATFORM() {
		return PLATFORM;
	}
	public void setPLATFORM(String pLATFORM) {
		PLATFORM = pLATFORM;
	}
	public String getLOGIN_TIME() {
		return LOGIN_TIME;
	}
	public void setLOGIN_TIME(String lOGIN_TIME) {
		LOGIN_TIME = lOGIN_TIME;
	}
	public String getAPI_Response() {
		return API_Response;
	}
	public void setAPI_Response(String aPI_Response) {
		API_Response = aPI_Response;
	}
	@Override
	public String toString() {
		return "BeanEntity [HibAutoIncrement=" + HibAutoIncrement + ", SESSION_ID=" + SESSION_ID + ", SSO_ID=" + SSO_ID
				+ ", KPI_ASKED=" + KPI_ASKED + ", INTENT_CALLED=" + INTENT_CALLED + ", PLATFORM=" + PLATFORM
				+ ", LOGIN_TIME=" + LOGIN_TIME + ", API_Response=" + API_Response + "]";
	}
}
	
