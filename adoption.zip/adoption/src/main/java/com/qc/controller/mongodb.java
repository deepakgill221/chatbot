package com.qc.controller;

/*import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase; 
import java.util.Iterator; 
import com.mongodb.client.FindIterable;*/


/*import com.mongodb.client.FindIterable; 
import com.mongodb.client.MongoCollection; 
import com.mongodb.client.MongoDatabase;  
import com.mongodb.MongoClientURI;
import java.util.Iterator; 
import org.bson.Document; 
import com.mongodb.MongoClient; 
import com.mongodb.MongoCredential;*/ 

public class mongodb 
{
	/*Mongo DB connection strings and process.

	MongoClientURI connectionString = new MongoClientURI("mongodb://usename:pwd@ds139909.mlab.com:39909/dbname");
	MongoClient mongoClient = new MongoClient(connectionString);
	MongoDatabase database = mongoClient.getDatabase("sawa_app");
	MongoCollection<Document> collection = database.getCollection("logs");

	FindIterable<Document> iterDoc = collection.find(); 
	int i = 1; 
	// Getting the iterator 
	Iterator it = iterDoc.iterator();
		while (it.hasNext()) 
		{  
			System.out.println(it.next());  
			i++;
		}
			
}*/
/*{ */
	   
	  /* public static void main( String args[] ) {  
	      
	      // Creating a Mongo client 
		   MongoClientURI connectionString = new MongoClientURI("mongodb://usename:pwd@ds139909.mlab.com:39909/mlibot");
			MongoClient mongoClient = new MongoClient(connectionString);
	      
	      // Accessing the database 
	      MongoDatabase database = mongoClient.getDatabase("mlibot");  
	      
	      // Retrieving a collection 
	      MongoCollection<Document> collection = database.getCollection("logs");
	      System.out.println("Collection sampleCollection selected successfully"); 

	      // Getting the iterable object 
	      FindIterable<Document> iterDoc = collection.find(); 
	      int i = 1; 

	      // Getting the iterator 
	      Iterator it = iterDoc.iterator(); 
	    
	      while (it.hasNext()) {  
	         System.out.println(it.next());  
	      i++; 
	      }
	   } 
	}
*/
	}


