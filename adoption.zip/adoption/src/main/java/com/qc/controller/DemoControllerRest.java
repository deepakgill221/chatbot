package com.qc.controller;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.dto.ApiMsgInfo;
import com.qc.api.request.WipApiRequest;
import com.qc.api.response.WipApiResponse;
import com.qc.api.service.WipApiService;


@RestController
@RequestMapping(value = "/services/api/v1")
public class DemoControllerRest 
{
	@Autowired 
	Environment env;
	@Autowired	
	WipApiService wipApiService;
	
	private static Logger logger = LogManager.getLogger(DemoControllerRest.class);
	@RequestMapping(value="/logs" , method = RequestMethod.POST, 
			consumes = "application/json", produces="application/json")
	public WipApiResponse WipProcessRequestInsertData(@Valid @RequestBody WipApiRequest wipApiRequest)
	{
		logger.info("Inside Method : Adoption logs Request :: START");
		WipApiResponse response = null;
		try
		{
			ThreadContext.push("adoptionlogs"+System.currentTimeMillis());
			ObjectWriter objectWriter= new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info("Request In Json Format :- "+objectWriter.writeValueAsString(wipApiRequest));

		}catch(Exception ex)
		{
			logger.info("Error while converting request in to Json");
		}
		try
		{
			if(wipApiRequest!=null)
			{
				response=wipApiService.HibCrudOpt(wipApiRequest);
			}
		}catch(Exception e)
		{
			logger.info("Exception occoured while making response");
		}
		finally
		{
			ThreadContext.pop();
		}
		logger.info("Inside Method : Adoption logs Request :: END");
		return response;
	}
}
