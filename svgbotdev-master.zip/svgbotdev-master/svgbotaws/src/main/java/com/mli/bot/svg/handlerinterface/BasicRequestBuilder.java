package com.mli.bot.svg.handlerinterface;

import com.mli.bot.svg.exceptions.GenericCustomException;
import com.mli.bot.svg.request.InternalBasicRequest;
import com.mli.bot.svg.request.WebhookRequest;

public interface BasicRequestBuilder {

	public InternalBasicRequest getBasicRequest(WebhookRequest  webhookRequest) throws GenericCustomException;
	
}
