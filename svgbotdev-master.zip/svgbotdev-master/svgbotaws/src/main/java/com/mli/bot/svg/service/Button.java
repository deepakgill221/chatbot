package com.mli.bot.svg.service;

import com.mli.bot.svg.response.InnerData;

/**
 * @author sc05216
 *
 */
public interface Button 
{
	/**
	 * @return
	 */
	public InnerData getButtonsYesNo();
	/**
	 * @return
	 */
	public InnerData getButtonsGender();
	/**
	 * @return
	 */
	public InnerData resendOtp();
}
