package com.mli.bot.svg.handlerInterfaceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mli.bot.svg.handlerinterface.BasicRequestBuilder;
import com.mli.bot.svg.handlerinterface.HandlerFactoryPattern;
import com.mli.bot.svg.handlerinterface.RequestResponseHandler;
import com.mli.bot.svg.request.WebhookRequest;
import com.mli.bot.svg.service.SVGService;


@Component
public class HandlerFactoryPatternImpl implements HandlerFactoryPattern{

	@Autowired
	private SVGService svgBotService;
	
	@Autowired 
	BasicRequestBuilder basicRequestBuilder;  
	
	@Override
	public RequestResponseHandler getHandlerObject(WebhookRequest request) {
			return new WebHandler(request,svgBotService,basicRequestBuilder);	
	}

	
}
