package com.mli.bot.svg.response;

import java.io.Serializable;

public interface GenericResponse  extends Serializable{

	
}
