package com.mli.bot.svg.response;

import java.io.Serializable;

/**
 * @author ad01084
 *
 */
public class InnerContextData implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String givenPolicyNumber;


	public String getGivenPolicyNumber() {
		return givenPolicyNumber;
	}

	public void setGivenPolicyNumber(String givenPolicyNumber) {
		this.givenPolicyNumber = givenPolicyNumber;
	}

	@Override
	public String toString() {
		return "InnerContextData [givenPolicyNumber=" + givenPolicyNumber + "]";
	}
}
