 package com.mli.bot.svg.serviceimpl;


import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.bot.svg.service.DOBIntent;
import com.mli.bot.svg.utils.CalculateAge;
/**
 * @author sc05216
 *
 */
@Service
public class DOBIntentImpl implements DOBIntent 
{
	@Autowired
	private CalculateAge calculateAge;
	
	private static Logger logger = LogManager.getLogger(DOBIntentImpl.class);
	
	String speech="";
	/** 
	 * @Param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String customerDOBIntent(Map<String, Map<String, String>> map, String sessionId) {
		
		try{
		if(map.containsKey(sessionId))
		{
			int finalage=calculateAge.getAge(map,sessionId);

			if(finalage<=17)
			{
				speech = map.get(sessionId+"Msg").get("dobError");
				return speech;
			}
			else{
			speech=map.get(sessionId+"Msg").get("dob1") +" "+ map.get(sessionId).get("name") + map.get(sessionId+"Msg").get("dob2");
			}
		}
		else{
			speech=map.get(sessionId+"Msg").get("Error")+" : - DOB";
		}
		logger.info("Final speech DOB :: "+speech);
		}
		catch(Exception ex){
			logger.error("Exception in customerDOBIntent method for sessionId :: " + sessionId + " :: "+ ex);
		}
		return speech;
	}
}
