package com.mli.bot.svg.handlerInterfaceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.mli.bot.svg.controller.SvgController;
import com.mli.bot.svg.exceptions.GenericCustomException;
import com.mli.bot.svg.exceptions.WebCustomExceptionHandler;
import com.mli.bot.svg.handlerinterface.BasicRequestBuilder;
import com.mli.bot.svg.handlerinterface.RequestResponseHandler;
import com.mli.bot.svg.request.InternalBasicRequest;
import com.mli.bot.svg.request.WebhookRequest;
import com.mli.bot.svg.response.GenericResponse;
import com.mli.bot.svg.response.GenericResponseDTO;
import com.mli.bot.svg.response.WebhookResponse;
import com.mli.bot.svg.service.SVGService;

public class WebHandler implements RequestResponseHandler {

	private static Logger logger = LogManager.getLogger(SvgController.class);
	private WebhookRequest webReq;
	private GenericResponse webRes;
	private SVGService svgBotService;
	GenericResponseDTO genericResponseDto;
	private InternalBasicRequest basicReq;
	private BasicRequestBuilder basicRequestBuilder;

	public WebHandler(WebhookRequest webReq, SVGService svgBotService, BasicRequestBuilder basicRequestBuilder) {
		this.webReq = webReq;
		this.svgBotService = svgBotService;
		this.basicRequestBuilder = basicRequestBuilder;

		try 
		{
			logger.info("call request handler method start");
			requestHandler();
			logger.info("call request handler method ends");

			logger.info("call processRequest  method starts");
			processRequest();
			logger.info("call processRequest  method ends");

			logger.info("call responseHandler  method starts");
			responseHandler();
			logger.info("call responseHandler  method ends");

		} catch (GenericCustomException ex) {
		    this.webRes = new WebCustomExceptionHandler(ex).getFormattedExceptionResponse();
		}

	}

	
	@Override
	public void requestHandler() throws GenericCustomException {
		basicReq = basicRequestBuilder.getBasicRequest(webReq);
	}

	@Override
	public void responseHandler() throws GenericCustomException {
		this.webRes = new WebhookResponse(genericResponseDto.getSpeech(), genericResponseDto.getDisplayText(),
				genericResponseDto.getData());
	}

	@Override
	public GenericResponse getResponse() {

		return this.webRes;
	}

	@Override
	public void processRequest() throws GenericCustomException {
		genericResponseDto = svgBotService.svgBotProcess(basicReq);
	}

}
