package com.mli.bot.svg.serviceimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.mli.bot.svg.service.GenderIntent;



/**
 * @author sc05216
 *
 */
@Service
public class GenderIntentImpl implements GenderIntent {

	private static Logger logger = LogManager.getLogger(GenderIntentImpl.class);

	/**
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String genderResponse(Map<String, Map<String, String>> map, String sessionId) {

		String speech = "";

		try {
			speech = map.get(sessionId + "Msg").get("gender");
		} catch (Exception ex) {
			logger.error("Exception in GenderIntentImpl method for sessionId :: " + sessionId + " :: " + ex);
		}
		return speech;
	}
}
