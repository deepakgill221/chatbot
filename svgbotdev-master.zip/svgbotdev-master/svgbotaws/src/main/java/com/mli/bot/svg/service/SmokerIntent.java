package com.mli.bot.svg.service;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface SmokerIntent {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String customerSmokerIntent(Map<String,Map<String,String>> map, String sessionId);
}
