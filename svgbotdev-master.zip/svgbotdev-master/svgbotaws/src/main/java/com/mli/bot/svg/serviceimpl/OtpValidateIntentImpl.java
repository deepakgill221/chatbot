package com.mli.bot.svg.serviceimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.bot.svg.service.OtpValidateIntent;
import com.mli.bot.svg.service.OtpValidation;


/**
 * @author sc05216
 *
 */
@Service
public class OtpValidateIntentImpl implements OtpValidateIntent {

	private static Logger logger = LogManager.getLogger(OtpValidateIntentImpl.class);

	@Autowired
	private OtpValidation optValidation;

	/** 
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	
	@Override
	public String otpValidate(Map<String, Map<String, String>> map, String sessionId) {
		String speech = "";
		try {
			logger.info("Validating OTP api call :: sessionId :: " + sessionId);
			String response = optValidation.validateOtp(map, sessionId);
			JSONObject jsonObject = new JSONObject(response);
			String soaStatusCode = jsonObject.getJSONObject("response").getJSONObject("responseData")
					.get("soaStatusCode") + "";
			String soaMessage = jsonObject.getJSONObject("response").getJSONObject("responseData").get("soaMessage")+ "";
			System.out.println(" SOA Message status of validating otp api for sessionId :: " + sessionId + " soa status :: " +soaMessage);
			logger.info(" SOA Message status of validating otp api for sessionId :: " + sessionId + " soa status :: " +soaMessage );
			if ("Success".equalsIgnoreCase(soaMessage) && "200".equalsIgnoreCase(soaStatusCode)) {
				speech = map.get(sessionId + "Msg").get("email");
				speech = speech.replace("<br>", "\n");
			} else if("Invalid OTP".equalsIgnoreCase(soaMessage) && "500".equalsIgnoreCase(soaStatusCode)){
				speech="Incorrect OTP is entered, please enter the correct OTP";
				/*speech = map.get(sessionId+"Msg").get("wrongOTP");*/
			}
			else{
				speech=map.get(sessionId+"Msg").get("Error")+"mobile";
			}
		} catch (Exception ex) {
			logger.error("Exception in validating OTP for session Id :: " + sessionId + " :: " + ex);
		}
		return speech;
	}

}
