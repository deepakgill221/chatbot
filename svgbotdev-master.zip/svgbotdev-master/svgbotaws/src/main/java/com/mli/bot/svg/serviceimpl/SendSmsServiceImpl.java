package com.mli.bot.svg.serviceimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.bot.svg.service.SendSmsService;
import com.mli.bot.svg.utils.BeanProperty;
import com.mli.bot.svg.utils.CommonUtility;
import com.mli.bot.svg.utils.HttpCaller;

/**
 * @author sc05216
 *
 */
@Service
public class SendSmsServiceImpl implements SendSmsService {
	
	private static Logger logger = LogManager.getLogger(SendSmsServiceImpl.class);

	@Autowired
	private BeanProperty bean;
	@Autowired
	private HttpCaller httpCaller;
	@Autowired
	private CommonUtility commonUtility;

	/**
	 * (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	
	@Override
	public String sendSmsServiceCall(Map<String, Map<String, String>> map, String sessionId) {

		StringBuilder result = new StringBuilder();

		try {

			logger.info("SendSMSservicecall method start :: sessionId :: " + sessionId);
			String url = bean.getSendSmsApi();
			String customerId = bean.getSendSmsConsumerId();
			String appAccId = bean.getSendSmsAppAccId();
			String appAccPass = bean.getSendSmsAppAccPass();
			String appId = bean.getSendSmsAppId();
			String mobileNumber = map.get(sessionId).get("mobilenum");
			String otp = map.get(sessionId).get("systemOtp");
			String smsResponse1= map.get(sessionId + "Msg").get("smsResponse1");
			String smsResponse2= map.get(sessionId + "Msg").get("smsResponse2");
			int correlationId = commonUtility.getRandomNumber();
			logger.info("SessionId :: " + sessionId + " :: API :: " + "Generate OTP :: CorrelationId :: " +correlationId);
			StringBuilder requestData = new StringBuilder();
			
			requestData.append("	{	");
			requestData.append("		\"MliSmsService\": {");
			requestData.append("			\"requestHeader\": {");
			requestData.append("				\"generalConsumerInformation\": {");
			requestData.append("					\"messageVersion\": \"1.0\",");
			requestData.append("					\"consumerId\": \""+customerId+"\",");
			requestData.append("					\"correlationId\": \""+correlationId+"\"");
			requestData.append("				}");
			requestData.append("			},	");
			requestData.append("			\"requestBody\": {	");
			requestData.append("				\"appAccId\": \""+appAccId+"\",	");
			requestData.append("				\"appAccPass\": \""+appAccPass+"\",	");
			requestData.append("				\"appId\": \""+appId+"\",	");
			requestData.append("				\"msgTo\": \""+mobileNumber+"\",	");
			requestData.append("				\"msgText\": \""+smsResponse1 +" " + otp+ smsResponse2+"\"	");
			requestData.append("			}	");
			requestData.append("		}	");
			requestData.append("	}");

			httpCaller.callHttp(url, requestData, result);

		} catch (Exception ex) {

			logger.error("Exception in send SMS API :: sessionId :: " + sessionId + " :: " + ex);
		}

		logger.info("SendSMSservicecall method end :: sessionId :: " + sessionId);
		return result.toString();
	}

}
