package com.mli.bot.svg.serviceimpl;

import java.math.BigDecimal;
import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.bot.svg.service.CreateLeadService;
import com.mli.bot.svg.service.EmailIntent;
import com.mli.bot.svg.service.GetLeadService;
import com.mli.bot.svg.utils.BeanProperty;

/**
 * @author sc05216
 *
 */
@Service
public class EmailIntentImpl implements EmailIntent 
{
	private static Logger logger = LogManager.getLogger(EmailIntentImpl.class);
	
	@Autowired
	private CreateLeadService createLeadService;
	@Autowired
	private GetLeadService getLeadService;
	@Autowired
	private BeanProperty bean;
	String speech="";
	/** 
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String customerEmailIntent(Map<String, Map<String, String>> map, String sessionId) {
		
		try{
		if(map.containsKey(sessionId))
		{
			/**********************Create Lead API call start*********************************/
			
			String responseEquote = createLeadService.createLeadAPI(map, sessionId);

			JSONObject objectEquote = new JSONObject(responseEquote);
			JSONObject resEquote=(JSONObject)objectEquote.getJSONObject("response").getJSONObject("responseData").getJSONArray("createLeadWithRiderResponse").get(0);
			String leadStatus=resEquote.getString("leadStatus");
			
				if(leadStatus.contains("The reason for the Lead failure is LeadSource Id")){
					speech=map.get(sessionId+"Msg").get("smokerError");
				}
				else{	
				String leadId=resEquote.get("leadID")+"";
				map.get(sessionId).put("leadId", leadId);
				String responseleadAPI=getLeadService.getLeadAPI(map, sessionId);

				JSONObject objectlead = new JSONObject(responseleadAPI);
				JSONObject linkresponse=(JSONObject)objectlead.getJSONObject("response").getJSONObject("responseData").getJSONArray("leadData").get(0);
				String equoteNumber=linkresponse.getJSONObject("lead").get("equoteNumber")+"";
				map.get(sessionId).put("eQuote", equoteNumber);
				String link=bean.getReDirectURL()+equoteNumber;
				String totalPremiumWGST=map.get(sessionId).get("TotalPremiumWGST")+"";
				
				Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
				
				String totalPremiumWGSTFormat=format.format(new BigDecimal(totalPremiumWGST));

				String policyTerm=map.get(sessionId).get("PolicyTerm");
				
				speech=map.get(sessionId+"Msg").get("smoker1")+" "+map.get(sessionId).get("name")+map.get(sessionId+"Msg").get("smoker2")+policyTerm
						+map.get(sessionId+"Msg").get("smoker3")+totalPremiumWGSTFormat+map.get(sessionId+"Msg").get("smoker4")+" "+equoteNumber
						+map.get(sessionId+"Msg").get("smoker5")+link+map.get(sessionId+"Msg").get("smoker6")+" "+map.get(sessionId).get("leadId");
				speech=speech.replaceAll("<br>","\n");
			}
		}
		else{
			speech=map.get(sessionId+"Msg").get("Error")+": - Email";
		}
		}
		catch(Exception ex){
			
			logger.error("Exception in customerEmailIntent method for sessionId :: " + sessionId + " :: "+ ex);
		}
		return speech;
	}
}
