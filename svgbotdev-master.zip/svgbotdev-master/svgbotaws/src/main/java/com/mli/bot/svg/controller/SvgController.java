package com.mli.bot.svg.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mli.bot.svg.handlerinterface.HandlerFactoryPattern;
import com.mli.bot.svg.handlerinterface.RequestResponseHandler;
import com.mli.bot.svg.request.WebhookRequest;
import com.mli.bot.svg.response.GenericResponse;
import com.mli.bot.svg.service.SVGService;

/**
 * @author ad01084
 *
 */
@RestController

public class SvgController {
	private static Logger logger = LogManager.getLogger(SvgController.class);
	@Autowired
	private SVGService svgBotService;
	
	@Autowired
	private HandlerFactoryPattern factoryPattern;
	
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	@Scheduled(cron = "0 0/10 * * * ?")
	public void removeCashethirtyminute() 
	{
		logger.info("Cron job to remove un-used session from cache : Start");
		svgBotService.removeUnUsedSessionFromCache();
	}

	
	@PostMapping("/svg")
	public GenericResponse webhook(@RequestBody WebhookRequest webReq) 
	{
		
		logger.info("svg boat process starts");
		RequestResponseHandler   reqRpnsHandler = factoryPattern.getHandlerObject(webReq);
		logger.info("svg boat process Ends");
		return  reqRpnsHandler.getResponse();
		
	}
	
	

}
