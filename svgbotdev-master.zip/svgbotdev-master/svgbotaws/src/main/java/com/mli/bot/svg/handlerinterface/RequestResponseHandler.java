package com.mli.bot.svg.handlerinterface;

import com.mli.bot.svg.exceptions.GenericCustomException;
import com.mli.bot.svg.response.GenericResponse;

public interface RequestResponseHandler{
	
	
	public void requestHandler() throws GenericCustomException;
	
	public void responseHandler() throws GenericCustomException;
	
	public GenericResponse getResponse() ;
	
	public void processRequest() throws GenericCustomException;
	

}
