package com.mli.bot.svg.serviceimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mli.bot.svg.service.GetMessageService;
import com.mli.bot.svg.utils.BeanProperty;

/**
 * @author sc05216
 *
 */
@Service
public class GetMessageServiceImpl implements GetMessageService {
	
	private static Logger logger = LogManager.getLogger(GetMessageServiceImpl.class);
	
	@Autowired
	private BeanProperty bean;

	String textResponse;
	/** (non-Javadoc)
	 * @see com.mli.leadfirst.service.GetMessageService#getMessageAPI(java.lang.String)
	 */
	@Override
	public String getMessageAPI(String botName){
		
		try{
		String url = bean.getGetMessageAPI();
		
		ResponseEntity<String> response;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder sb=new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"type\":\""+botName+"\"	");
		sb.append("	}	");

		HttpEntity<String> entity=new HttpEntity<>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		
		response = restTemplate.exchange(url, HttpMethod.POST, entity,String.class);
		if(response.getStatusCodeValue() == 200)
		{
			textResponse = response.getBody();
			logger.info("Inside GetMessageServiceImpl:: getMessageAPI response form rule engine:: "+textResponse);
		}
		
		}
		catch( Exception ex){
			logger.error("Exception in message API for session Id :: " + botName + " :: " + ex);
		}
		return textResponse;
	}

}
