package com.mli.bot.svg.handlerInterfaceImpl;


import com.mli.bot.svg.handlerinterface.RequestResponseHandler;
import com.mli.bot.svg.response.GenericResponse;

public class TwitterHandler  implements RequestResponseHandler {

	

	@Override
	public void requestHandler() {
	}

	@Override
	public void responseHandler() {
		
	}

	@Override
	public GenericResponse getResponse() {
		return null;
	}

	@Override
	public void processRequest() {
		
	}

	
		

}
