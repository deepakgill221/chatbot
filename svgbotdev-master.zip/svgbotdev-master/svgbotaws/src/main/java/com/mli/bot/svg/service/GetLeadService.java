package com.mli.bot.svg.service;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface GetLeadService {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String getLeadAPI(Map<String, Map<String, String>> map, String sessionId);

}
