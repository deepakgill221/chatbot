package com.mli.bot.svg.service;

import com.mli.bot.svg.exceptions.GenericCustomException;
import com.mli.bot.svg.request.InternalBasicRequest;
import com.mli.bot.svg.response.GenericResponseDTO;


/**
 * @author sc05216
 *
 */

public interface SVGService {
	/**
	 * @param jsonStr : Request data in JSON Format
	 * @return
	 * @throws GenericCustomException 
	 */
	public GenericResponseDTO svgBotProcess(InternalBasicRequest basicRequest) throws GenericCustomException;
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	public void removeUnUsedSessionFromCache();
}
