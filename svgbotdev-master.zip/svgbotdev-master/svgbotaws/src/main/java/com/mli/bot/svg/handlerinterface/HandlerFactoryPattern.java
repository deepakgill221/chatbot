package com.mli.bot.svg.handlerinterface;

import com.mli.bot.svg.handlerinterface.RequestResponseHandler;
import com.mli.bot.svg.request.WebhookRequest;


public interface HandlerFactoryPattern {

	public RequestResponseHandler  getHandlerObject(WebhookRequest request);
	
}
