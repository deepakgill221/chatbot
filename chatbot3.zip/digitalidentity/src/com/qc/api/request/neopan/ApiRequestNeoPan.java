package com.qc.api.request.neopan;

import java.io.Serializable;

public class ApiRequestNeoPan implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestNeoPan request;
	public ApiRequestNeoPan() {
		super();
	}
	public ApiRequestNeoPan(RequestNeoPan request) {
		super();
		this.request = request;
	}
	public RequestNeoPan getRequest() {
		return request;
	}
	public void setRequest(RequestNeoPan request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestAgentDetails [request=" + request + "]";
	}
}
