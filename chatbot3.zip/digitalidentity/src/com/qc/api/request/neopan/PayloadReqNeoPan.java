package com.qc.api.request.neopan;

import java.io.Serializable;

public class PayloadReqNeoPan implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String UserName;
    private String CreationDate;
    private String CreationTime;
    private String SourceInfoName;
    private String RequestorToken;
    private String UserEmail;
    private String LastSyncDateTime;
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getCreationDate() {
		return CreationDate;
	}
	public void setCreationDate(String creationDate) {
		CreationDate = creationDate;
	}
	public String getCreationTime() {
		return CreationTime;
	}
	public void setCreationTime(String creationTime) {
		CreationTime = creationTime;
	}
	public String getSourceInfoName() {
		return SourceInfoName;
	}
	public void setSourceInfoName(String sourceInfoName) {
		SourceInfoName = sourceInfoName;
	}
	public String getRequestorToken() {
		return RequestorToken;
	}
	public void setRequestorToken(String requestorToken) {
		RequestorToken = requestorToken;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}
	public String getLastSyncDateTime() {
		return LastSyncDateTime;
	}
	public void setLastSyncDateTime(String lastSyncDateTime) {
		LastSyncDateTime = lastSyncDateTime;
	}
	@Override
	public String toString() {
		return "PayloadReqNeoPan [UserName=" + UserName + ", CreationDate=" + CreationDate + ", CreationTime="
				+ CreationTime + ", SourceInfoName=" + SourceInfoName + ", RequestorToken=" + RequestorToken
				+ ", UserEmail=" + UserEmail + ", LastSyncDateTime=" + LastSyncDateTime + "]";
	}
}
