package com.qc.api.request.neopan;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestNeoPan implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	
	private PayloadReqNeoPan requestData;
	

	
}
