package com.qc.api.request.otp;

import java.io.Serializable;

public class ApiRequestOtp implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestOtp request;
	public ApiRequestOtp() {
		super();
	}
	public ApiRequestOtp(RequestOtp request) {
		super();
		this.request = request;
	}
	public RequestOtp getRequest() {
		return request;
	}
	public void setRequest(RequestOtp request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestAgentDetails [request=" + request + "]";
	}
}
