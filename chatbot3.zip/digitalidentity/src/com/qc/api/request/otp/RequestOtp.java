package com.qc.api.request.otp;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestOtp implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqOtp requestData;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqOtp getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqOtp requestData) {
		this.requestData = requestData;
	}
	@Override
	public String toString() {
		return "RequestOtp [header=" + header + ", requestData=" + requestData + "]";
	}

	
}
