package com.qc.api.request.otp;

import java.io.Serializable;

public class PayloadReqOtp implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String no_of_chars;
	private String type;
	public String getNo_of_chars() {
		return no_of_chars;
	}
	public void setNo_of_chars(String no_of_chars) {
		this.no_of_chars = no_of_chars;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "PayloadReqOtp [no_of_chars=" + no_of_chars + ", type=" + type + "]";
	}

}
