package com.qc.api.request;

import com.qc.dto.Payload;

public class RequestApi {

ReqHeader header;
Payload payload;

public RequestApi(ReqHeader header, Payload payload) {
	super();
	this.header = header;
	this.payload = payload;
}

public ReqHeader getHeader() {
	return header;
}

public void setHeader(ReqHeader header) {
	this.header = header;
}

public Payload getPayload() {
	return payload;
}

public void setPayload(Payload payload) {
	this.payload = payload;
}

public RequestApi() {
	super();
	// TODO Auto-generated constructor stub
}



}
