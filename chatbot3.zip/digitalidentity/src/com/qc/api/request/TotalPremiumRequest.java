package com.qc.api.request;

import java.io.Serializable;

import com.qc.dto.DefaultRequestKeyDTO;

public class TotalPremiumRequest extends DefaultRequestKeyDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8995313179472323891L;
	String policyId;
	
	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	@Override
	public String toString() {
		return "TotalPremiumRequest [policyId=" + policyId + "]";
	}
}
