package com.qc.api.request;

import java.io.Serializable;

public class ReqHeader implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2504004817515934483L;
	String soaMsgVersion = "";
	String soaAppId = "";
	String soaCorrelationId = "";
	String soaUserId = "";
	String soaPassword ;
	
	public String getSoaMsgVersion() {
		return soaMsgVersion;
	}
	public void setSoaMsgVersion(String soaMsgVersion) {
		this.soaMsgVersion = soaMsgVersion;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	public String getSoaUserId() {
		return soaUserId;
	}
	public void setSoaUserId(String soaUserId) {
		this.soaUserId = soaUserId;
	}
	public String getSoaPassword() {
		return soaPassword;
	}
	public void setSoaPassword(String soaPassword) {
		this.soaPassword = soaPassword;
	}
	@Override
	public String toString() {
		return "ResponseHeader [soaMsgVersion=" + soaMsgVersion + ", soaAppId=" + soaAppId + ", soaCorrelationId="
				+ soaCorrelationId + ", soaUserId=" + soaUserId + ", soaPassword=" + soaPassword + "]";
	}
	

}
