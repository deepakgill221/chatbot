package com.qc.api.request.elasticsearch;

import java.io.Serializable;


public class ApiRequestElasticSearch implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestElasticSearch request;
	public ApiRequestElasticSearch() {
		super();
	}
	public ApiRequestElasticSearch( RequestElasticSearch request) {
		super();
		this.request = request;
	}
	public RequestElasticSearch getRequest() {
		return request;
	}
	public void setRequest(RequestElasticSearch request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestElasticSearch [ request=" + request + "]";
	}
}
