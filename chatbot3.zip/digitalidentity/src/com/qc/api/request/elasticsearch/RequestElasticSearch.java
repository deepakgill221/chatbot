package com.qc.api.request.elasticsearch;

import java.io.Serializable;

import com.qc.api.response.elasticsearch.HeaderElasticSearch;


public class RequestElasticSearch implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	
	private HeaderElasticSearch header;
	private PayloadReqElasticSearch requestData;
	public HeaderElasticSearch getHeader() {
		return header;
	}
	public void setHeader(HeaderElasticSearch header) {
		this.header = header;
	}
	
	public PayloadReqElasticSearch getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqElasticSearch requestData) {
		this.requestData = requestData;
	}
	@Override
	public String toString() {
		return "RequestElasticSearch [header=" + header + ", requestData=" + requestData + "]";
	}
	
}
