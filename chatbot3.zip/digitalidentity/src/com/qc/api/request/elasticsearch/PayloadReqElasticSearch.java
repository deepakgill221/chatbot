package com.qc.api.request.elasticsearch;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

public class PayloadReqElasticSearch implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String index;
	private String type;
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "PayloadReqElasticSearch [index=" + index + ", type=" + type + "]";
	}
	
	
	
	
}
