package com.qc.api.request.getdemoauthrequest;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonProperty;


public class ApiRequestGetDemoAuthRequest implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetDemoAuthRequest request;
	public ApiRequestGetDemoAuthRequest() {
		super();
	}
	public ApiRequestGetDemoAuthRequest( RequestGetDemoAuthRequest request) {
		super();
		this.request = request;
	}
	public RequestGetDemoAuthRequest getRequest() {
		return request;
	}
	public void setRequest(RequestGetDemoAuthRequest request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetDemoAuthRequest [ request=" + request + "]";
	}
}
