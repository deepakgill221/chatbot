package com.qc.api.request.getdemoauthrequest;

import java.io.Serializable;
import java.util.List;

import com.qc.api.common.Header;

public class PayloadReqGetDemoAuthRequest implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	private String aadhaarNumber;
	private String aadhaarName;
	private String strYear;
	private String strGender;
	private String strPiMatchStrategy;
	private String strPiMatchValue;
	private String strAddressValue;
	private String strPfaMatchStrategy;
	private String strPfaMatchValue;
	private String strCareOf;
	private String strBuilding;
	private String strLandmark;
	private String strStreet;
	private String strLocality;
	private String strPoName;
	private String strVillage;
	private String strSubdist;
	private String strDistrict;
	private String strState;
	private String strPincode;
	private String strCountry;
	private String type;
	public String getAadhaarNumber() {
		return aadhaarNumber;
	}
	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	public String getAadhaarName() {
		return aadhaarName;
	}
	public void setAadhaarName(String aadhaarName) {
		this.aadhaarName = aadhaarName;
	}
	public String getStrYear() {
		return strYear;
	}
	public void setStrYear(String strYear) {
		this.strYear = strYear;
	}
	public String getStrGender() {
		return strGender;
	}
	public void setStrGender(String strGender) {
		this.strGender = strGender;
	}
	public String getStrPiMatchStrategy() {
		return strPiMatchStrategy;
	}
	public void setStrPiMatchStrategy(String strPiMatchStrategy) {
		this.strPiMatchStrategy = strPiMatchStrategy;
	}
	public String getStrPiMatchValue() {
		return strPiMatchValue;
	}
	public void setStrPiMatchValue(String strPiMatchValue) {
		this.strPiMatchValue = strPiMatchValue;
	}
	public String getStrAddressValue() {
		return strAddressValue;
	}
	public void setStrAddressValue(String strAddressValue) {
		this.strAddressValue = strAddressValue;
	}
	public String getStrPfaMatchStrategy() {
		return strPfaMatchStrategy;
	}
	public void setStrPfaMatchStrategy(String strPfaMatchStrategy) {
		this.strPfaMatchStrategy = strPfaMatchStrategy;
	}
	public String getStrPfaMatchValue() {
		return strPfaMatchValue;
	}
	public void setStrPfaMatchValue(String strPfaMatchValue) {
		this.strPfaMatchValue = strPfaMatchValue;
	}
	public String getStrCareOf() {
		return strCareOf;
	}
	public void setStrCareOf(String strCareOf) {
		this.strCareOf = strCareOf;
	}
	public String getStrBuilding() {
		return strBuilding;
	}
	public void setStrBuilding(String strBuilding) {
		this.strBuilding = strBuilding;
	}
	public String getStrLandmark() {
		return strLandmark;
	}
	public void setStrLandmark(String strLandmark) {
		this.strLandmark = strLandmark;
	}
	public String getStrStreet() {
		return strStreet;
	}
	public void setStrStreet(String strStreet) {
		this.strStreet = strStreet;
	}
	public String getStrLocality() {
		return strLocality;
	}
	public void setStrLocality(String strLocality) {
		this.strLocality = strLocality;
	}
	public String getStrPoName() {
		return strPoName;
	}
	public void setStrPoName(String strPoName) {
		this.strPoName = strPoName;
	}
	public String getStrVillage() {
		return strVillage;
	}
	public void setStrVillage(String strVillage) {
		this.strVillage = strVillage;
	}
	public String getStrSubdist() {
		return strSubdist;
	}
	public void setStrSubdist(String strSubdist) {
		this.strSubdist = strSubdist;
	}
	public String getStrDistrict() {
		return strDistrict;
	}
	public void setStrDistrict(String strDistrict) {
		this.strDistrict = strDistrict;
	}
	public String getStrState() {
		return strState;
	}
	public void setStrState(String strState) {
		this.strState = strState;
	}
	public String getStrPincode() {
		return strPincode;
	}
	public void setStrPincode(String strPincode) {
		this.strPincode = strPincode;
	}
	public String getStrCountry() {
		return strCountry;
	}
	public void setStrCountry(String strCountry) {
		this.strCountry = strCountry;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "PayloadReqGetDemoAuthRequest [aadhaarNumber=" + aadhaarNumber + ", aadhaarName=" + aadhaarName
				+ ", strYear=" + strYear + ", strGender=" + strGender + ", strPiMatchStrategy=" + strPiMatchStrategy
				+ ", strPiMatchValue=" + strPiMatchValue + ", strAddressValue=" + strAddressValue
				+ ", strPfaMatchStrategy=" + strPfaMatchStrategy + ", strPfaMatchValue=" + strPfaMatchValue
				+ ", strCareOf=" + strCareOf + ", strBuilding=" + strBuilding + ", strLandmark=" + strLandmark
				+ ", strStreet=" + strStreet + ", strLocality=" + strLocality + ", strPoName=" + strPoName
				+ ", strVillage=" + strVillage + ", strSubdist=" + strSubdist + ", strDistrict=" + strDistrict
				+ ", strState=" + strState + ", strPincode=" + strPincode + ", strCountry=" + strCountry + ", type="
				+ type + "]";
	}
	
}
