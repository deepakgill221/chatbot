package com.qc.api.request.getdemoauthrequest;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.Header1;

public class RequestGetDemoAuthRequest implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	
	private Header1 header;
	private PayloadReqGetDemoAuthRequest payload;
	public Header1 getHeader() {
		return header;
	}
	public void setHeader(Header1 header) {
		this.header = header;
	}
	public PayloadReqGetDemoAuthRequest getPayload() {
		return payload;
	}
	public void setPayload(PayloadReqGetDemoAuthRequest payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestGetDemoAuthRequest [header=" + header + ", payload=" + payload + "]";
	}
	
}
