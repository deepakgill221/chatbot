package com.qc.api.response;

import java.io.Serializable;

public class PanResultV1 implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2300182101823546154L;
	private String pan;
	private String dob;
	private String name;
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "PanResultV1 [pan=" + pan + ", dob=" + dob + ", name=" + name + "]";
	}
	
}
