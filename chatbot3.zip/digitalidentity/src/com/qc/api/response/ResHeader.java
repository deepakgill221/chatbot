package com.qc.api.response;

import java.io.Serializable;

public class ResHeader implements Serializable{

	private static final long serialVersionUID = -2137932908128704919L;
	String soaMsgVersion = "";
	String soaAppId = "";
	String soaCorrelationId = "";
	
	
	public String getSoaMsgVersion() {
		return soaMsgVersion;
	}
	public void setSoaMsgVersion(String soaMsgVersion) {
		this.soaMsgVersion = soaMsgVersion;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	@Override
	public String toString() {
		return "ResponseHeader [soaMsgVersion=" + soaMsgVersion + ", soaAppId=" + soaAppId + ", soaCorrelationId="
				+ soaCorrelationId + "]";
	}
	
	
}
