package com.qc.api.response;

import java.io.Serializable;

public class PanResponseV1 implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7980512121674825996L;
	String status;
	PanResultV1 response;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public PanResultV1 getResponse() {
		return response;
	}

	public void setResponse(PanResultV1 response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "PanResponseV1 [status=" + status + ", response=" + response + "]";
	}

}
