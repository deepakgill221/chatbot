package com.qc.api.response;

import com.qc.dto.Payload;

public class ResponseApi {
 
	ResHeader header;
	ErrorInfo errorInfo;
	Payload payload;
	
	
	public ResponseApi() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResponseApi(ResHeader header, ErrorInfo errorInfo, Payload payload) {
		super();
		this.header = header;
		this.errorInfo = errorInfo;
		this.payload = payload;
	}

	public ResHeader getHeader() {
		return header;
	}

	public void setHeader(ResHeader header) {
		this.header = header;
	}

	public ErrorInfo getErrorInfo() {
		return errorInfo;
	}

	public void setErrorInfo(ErrorInfo errorInfo) {
		this.errorInfo = errorInfo;
	}

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}
    
	
}
