package com.qc.api.response;

public class StringConstants 
{
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	
	public static final String C200 = "200";
	public static final String C200DESC = "Response Generated Successfully";
	public static final String C201DESC = "Updated Successfuly";
	public static final String C202DESC = "Updated Successfuly";
	
	
	public static final String C500 = "500";
	public static final String C500DESC = "There seems to be something wrong. Please try after sometime.";
	
	
	public static final String C600 = "600";
	public static final String C600DESC = "Validation check fail! Please verify your request json mendatory fields could not be empty and invalid key!!";
	
	public static final String C601 = "601";
	public static final String C601DESC = "aadhar service unavailable";
	
	
	
	
//	public static final String C602 = "602";
//	public static final String C602DESC = "Generate OTP service Response Validation fail";
//	
//	public static final String C603 = "603";
//	public static final String C603DESC = "Unable to save generated otp data on DB";
	
	//////////////DB related Error code/////////////
	public static final String C700 = "700";
	public static final String C700DESC = "Data not found from backend";
	
	public static final String C701 = "701";
	public static final String C701DESC = "There seems to be something wrong at backend.";
	public static final String C702DESC = "There seems to be something wrong";
}
