package com.qc.api.response;

import java.io.Serializable;

public class PlanDetailV2Response implements Serializable{

	private static final long serialVersionUID = -3879025252614705745L;
	private	String	planId	;
	private	String	rhId	;
	private	String	rtblID	;
	private	String	rhBandAmt	;
	private	String	rtblSexCd	;
	private	String	rtblStblCd1	;
	private	String	rtblStblCd2	;
	private	String	rtblMatXpryDur	;
	private	String	rtblAgeDur	;
	private	String	rtbl1Rt	;
	private	String	rtbl2Rt	;
	private	String	rtbl3Rt	;
	private	String	rtbl4Rt	;
	private	String	rtbl5Rt	;
	private	String	rtbl6Rt	;
	private	String	rtbl7Rt	;
	private	String	rtbl8Rt	;
	private	String	rtblAge	;
	private	String	variantId1	;
	private	String	rate1	;
	private	String	variantId2	;
	private	String	rate2	;
	private	String	variantId3	;
	private	String	rate3	;
	
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getRhId() {
		return rhId;
	}
	public void setRhId(String rhId) {
		this.rhId = rhId;
	}
	public String getRtblID() {
		return rtblID;
	}
	public void setRtblID(String rtblID) {
		this.rtblID = rtblID;
	}
	public String getRhBandAmt() {
		return rhBandAmt;
	}
	public void setRhBandAmt(String rhBandAmt) {
		this.rhBandAmt = rhBandAmt;
	}
	public String getRtblSexCd() {
		return rtblSexCd;
	}
	public void setRtblSexCd(String rtblSexCd) {
		this.rtblSexCd = rtblSexCd;
	}
	public String getRtblStblCd1() {
		return rtblStblCd1;
	}
	public void setRtblStblCd1(String rtblStblCd1) {
		this.rtblStblCd1 = rtblStblCd1;
	}
	public String getRtblStblCd2() {
		return rtblStblCd2;
	}
	public void setRtblStblCd2(String rtblStblCd2) {
		this.rtblStblCd2 = rtblStblCd2;
	}
	public String getRtblMatXpryDur() {
		return rtblMatXpryDur;
	}
	public void setRtblMatXpryDur(String rtblMatXpryDur) {
		this.rtblMatXpryDur = rtblMatXpryDur;
	}
	public String getRtblAgeDur() {
		return rtblAgeDur;
	}
	public void setRtblAgeDur(String rtblAgeDur) {
		this.rtblAgeDur = rtblAgeDur;
	}
	public String getRtbl1Rt() {
		return rtbl1Rt;
	}
	public void setRtbl1Rt(String rtbl1Rt) {
		this.rtbl1Rt = rtbl1Rt;
	}
	public String getRtbl2Rt() {
		return rtbl2Rt;
	}
	public void setRtbl2Rt(String rtbl2Rt) {
		this.rtbl2Rt = rtbl2Rt;
	}
	public String getRtbl3Rt() {
		return rtbl3Rt;
	}
	public void setRtbl3Rt(String rtbl3Rt) {
		this.rtbl3Rt = rtbl3Rt;
	}
	public String getRtbl4Rt() {
		return rtbl4Rt;
	}
	public void setRtbl4Rt(String rtbl4Rt) {
		this.rtbl4Rt = rtbl4Rt;
	}
	public String getRtbl5Rt() {
		return rtbl5Rt;
	}
	public void setRtbl5Rt(String rtbl5Rt) {
		this.rtbl5Rt = rtbl5Rt;
	}
	public String getRtbl6Rt() {
		return rtbl6Rt;
	}
	public void setRtbl6Rt(String rtbl6Rt) {
		this.rtbl6Rt = rtbl6Rt;
	}
	public String getRtbl7Rt() {
		return rtbl7Rt;
	}
	public void setRtbl7Rt(String rtbl7Rt) {
		this.rtbl7Rt = rtbl7Rt;
	}
	public String getRtbl8Rt() {
		return rtbl8Rt;
	}
	public void setRtbl8Rt(String rtbl8Rt) {
		this.rtbl8Rt = rtbl8Rt;
	}
	public String getRtblAge() {
		return rtblAge;
	}
	public void setRtblAge(String rtblAge) {
		this.rtblAge = rtblAge;
	}
	public String getVariantId1() {
		return variantId1;
	}
	public void setVariantId1(String variantId1) {
		this.variantId1 = variantId1;
	}
	public String getRate1() {
		return rate1;
	}
	public void setRate1(String rate1) {
		this.rate1 = rate1;
	}
	public String getVariantId2() {
		return variantId2;
	}
	public void setVariantId2(String variantId2) {
		this.variantId2 = variantId2;
	}
	public String getRate2() {
		return rate2;
	}
	public void setRate2(String rate2) {
		this.rate2 = rate2;
	}
	public String getVariantId3() {
		return variantId3;
	}
	public void setVariantId3(String variantId3) {
		this.variantId3 = variantId3;
	}
	public String getRate3() {
		return rate3;
	}
	public void setRate3(String rate3) {
		this.rate3 = rate3;
	}

	
}
