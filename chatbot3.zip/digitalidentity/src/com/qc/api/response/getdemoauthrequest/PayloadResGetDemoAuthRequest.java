package com.qc.api.response.getdemoauthrequest;

import java.io.Serializable;
import java.util.List;

public class PayloadResGetDemoAuthRequest implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private String AuthenticateStatus;
	public String getAuthenticateStatus() {
		return AuthenticateStatus;
	}
	public void setAuthenticateStatus(String authenticateStatus) {
		AuthenticateStatus = authenticateStatus;
	}
	@Override
	public String toString() {
		return "PayloadResGetDemoAuthRequest [AuthenticateStatus=" + AuthenticateStatus + "]";
	}
	
}
