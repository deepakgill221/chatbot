package com.qc.api.response.getdemoauthrequest;

import java.io.Serializable;

public class ApiResponseGetDemoAuthRequest implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetDemoAuthRequest response;

	public ApiResponseGetDemoAuthRequest() {
		super();
	}
	public ApiResponseGetDemoAuthRequest(ResponseGetDemoAuthRequest response) {
		super();
		this.response = response;
	}
	public ResponseGetDemoAuthRequest getResponse() {
		return response;
	}
	public void setResponse(ResponseGetDemoAuthRequest response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetDemoAuthRequest [response=" + response + "]";
	}
}
