package com.qc.api.response.getdemoauthrequest;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.Header1;
import com.qc.api.common.MsgInfo;

public class ResponseGetDemoAuthRequest implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header1 header;
	private MsgInfo msgInfo;
	private PayloadResGetDemoAuthRequest payload;
	
	public ResponseGetDemoAuthRequest() {
		super();
	}
	public ResponseGetDemoAuthRequest(Header1 header, MsgInfo msgInfo, PayloadResGetDemoAuthRequest payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	public Header1 getHeader() {
		return header;
	}
	public void setHeader(Header1 header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadResGetDemoAuthRequest getPayload() {
		return payload;
	}
	public void setPayload(PayloadResGetDemoAuthRequest payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponseGetDemoAuthRequest [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload
				+ "]";
	}
}
