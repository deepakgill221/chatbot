package com.qc.api.response.otp;

import java.io.Serializable;

public class ApiResponseOtpDetails implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseOtpDetails response;

	public ApiResponseOtpDetails() {
		super();
	}
	public ApiResponseOtpDetails(ResponseOtpDetails response) {
		super();
		this.response = response;
	}
	public ResponseOtpDetails getResponse() {
		return response;
	}
	public void setResponse(ResponseOtpDetails response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseAgentDetails [response=" + response + "]";
	}
}
