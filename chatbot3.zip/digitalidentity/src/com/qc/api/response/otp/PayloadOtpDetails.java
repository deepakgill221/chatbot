package com.qc.api.response.otp;

import java.io.Serializable;
import java.util.List;

public class PayloadOtpDetails implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private String msg;
	private String status;
	private String otp;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getStatus() {
		return status;
	}
	@Override
	public String toString() {
		return "PayloadOtpDetails [msg=" + msg + ", status=" + status + ", otp=" + otp + "]";
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
}
