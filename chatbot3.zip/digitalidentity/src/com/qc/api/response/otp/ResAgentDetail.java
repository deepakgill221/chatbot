package com.qc.api.response.otp;

import java.io.Serializable;

public class ResAgentDetail implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;
	private String tppLoginDate;
	private String tppWorkItemId;
	private String tppStatusCode;
	private String tppProposalNumber;
	private String tppPlanName;
	private String customerName;
	public String getTppLoginDate() {
		return tppLoginDate;
	}
	public void setTppLoginDate(String tppLoginDate) {
		this.tppLoginDate = tppLoginDate;
	}
	public String getTppWorkItemId() {
		return tppWorkItemId;
	}
	public void setTppWorkItemId(String tppWorkItemId) {
		this.tppWorkItemId = tppWorkItemId;
	}
	public String getTppStatusCode() {
		return tppStatusCode;
	}
	public void setTppStatusCode(String tppStatusCode) {
		this.tppStatusCode = tppStatusCode;
	}
	public String getTppProposalNumber() {
		return tppProposalNumber;
	}
	public void setTppProposalNumber(String tppProposalNumber) {
		this.tppProposalNumber = tppProposalNumber;
	}
	public String getTppPlanName() {
		return tppPlanName;
	}
	public void setTppPlanName(String tppPlanName) {
		this.tppPlanName = tppPlanName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	@Override
	public String toString() {
		return "ResAgentDetail [tppLoginDate=" + tppLoginDate + ", tppWorkItemId=" + tppWorkItemId + ", tppStatusCode="
				+ tppStatusCode + ", tppProposalNumber=" + tppProposalNumber + ", tppPlanName=" + tppPlanName
				+ ", customerName=" + customerName + "]";
	}
}
