package com.qc.api.response.otp;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class ResponseOtpDetails implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private MsgInfo msginfo;
	private PayloadOtpDetails payload;
	
	public ResponseOtpDetails() {
		super();
	}
	public ResponseOtpDetails(Header header, MsgInfo msginfo, PayloadOtpDetails payload) {
		super();
		this.header = header;
		this.msginfo = msginfo;
		this.payload = payload;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsginfo() {
		return msginfo;
	}
	public void setMsginfo(MsgInfo msginfo) {
		this.msginfo = msginfo;
	}
	public PayloadOtpDetails getPayload() {
		return payload;
	}
	public void setPayload(PayloadOtpDetails payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponseAgentDetails [header=" + header + ", msginfo=" + msginfo + ", payload=" + payload + "]";
	}
}
