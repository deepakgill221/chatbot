package com.qc.api.response;

import java.io.Serializable;

public class PartialWithDrawalResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2570769758269578628L;
	String comment;
	String amount;

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "PartialWithDrawalResponse [comment=" + comment + ", amount=" + amount + "]";
	}

}
