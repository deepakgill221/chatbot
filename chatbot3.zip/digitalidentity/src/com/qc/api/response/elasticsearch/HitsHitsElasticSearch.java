package com.qc.api.response.elasticsearch;

import java.io.Serializable;
import java.util.List;

public class HitsHitsElasticSearch implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private String _index;
	private String _type;
	private String _id;
	private String _score;
	private String _source;
	
	public static long getSerialversionuid() {
		return serialVersionUID;}
	
	public String get_index() {
		return _index;
	}

	public void set_index(String _index) {
		this._index = _index;
	}

	public String get_type() {
		return _type;
	}

	public void set_type(String _type) {
		this._type = _type;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String get_score() {
		return _score;
	}

	public void set_score(String _score) {
		this._score = _score;
	}

	public String get_source() {
		return _source;
	}

	public void set_source(String _source) {
		this._source = _source;
	}

	@Override
	public String toString() {
		return "PayloadResElasticSearch [_index=" + _index +  ", _type=" + _type +  ",_id=" + _id +  ",_score=" + _score +",_source=" + _source +  ",getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
