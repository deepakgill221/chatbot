package com.qc.api.response.elasticsearch;

import java.io.Serializable;
import java.util.Map;

import org.json.JSONObject;


public class ResponseElasticSearch implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private HeaderElasticSearch header;
	private MsgInfo msgInfo;
	//	private JSONObject responseData;
	private Map<String,Object> responseData;

	public ResponseElasticSearch() {
		super();
	}
	public ResponseElasticSearch(HeaderElasticSearch header, MsgInfo msgInfo, Map<String,Object> responseData) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.responseData = responseData;
	}
	public HeaderElasticSearch getHeader() {
		return header;
	}
	public void setHeader(HeaderElasticSearch header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

	public Map<String, Object> getResponseData() {
		return responseData;
	}
	public void setResponseData(Map<String, Object> responseData) {
		this.responseData = responseData;
	}
	//	public JSONObject getResponseData() {
	//		return responseData;
	//	}
	//	public void setResponseData(JSONObject responseData) {
	//		this.responseData = responseData;
	//	}
	@Override
	public String toString() {
		return "ResponseElasticSearch [header=" + header + ", msgInfo=" + msgInfo + ", responseData=" + responseData
				+ "]";
	}
}
