package com.qc.api.response.elasticsearch;

import java.io.Serializable;
import java.util.List;

public class ShredsElasticSearch implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private String total;
	private String successful;
	private String skipped;
	private String failed;
	
	public static long getSerialversionuid() {
		return serialVersionUID;}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getSuccessful() {
		return successful;
	}
	public void setSuccessful(String successful) {
		this.successful = successful;
	}
	public String getSkipped() {
		return skipped;
	}
	public void setSkipped(String skipped) {
		this.skipped = skipped;
	}
	public String getFailed() {
		return failed;
	}
	public void setFailed(String failed) {
		this.failed = failed;
	}
	@Override
	public String toString() {
		return "PayloadResElasticSearch [total=" + total +  ", successful=" + successful +  ",skipped=" + skipped +  ",failed=" + failed +  ",getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
