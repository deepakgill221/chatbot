package com.qc.api.response.elasticsearch;

import java.io.Serializable;
/**
 * 
 */
public class HeaderElasticSearch implements Serializable 
{
	private static final long serialVersionUID = 2504004817515934483L;
	private String soaAppId = "";
	private String soaCorrelationId = "";
	private String searchVar = "";
	
	public String getSearchVar() {
		return searchVar;
	}
	public void setSearchVar(String searchVar) {
		this.searchVar = searchVar;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	@Override
	public String toString() {
		return "HeaderElasticSearch [soaAppId=" + soaAppId + ", soaCorrelationId=" + soaCorrelationId + ", searchVar="
				+ searchVar + "]";
	}
	
	
}
