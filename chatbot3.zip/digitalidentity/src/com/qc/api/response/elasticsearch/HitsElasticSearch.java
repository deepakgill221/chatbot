package com.qc.api.response.elasticsearch;

import java.io.Serializable;
import java.util.List;

public class HitsElasticSearch implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private String total;
	private String max_score;
	private HitsHitsElasticSearch hits;
	
	public static long getSerialversionuid() {
		return serialVersionUID;}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	
	public String getMax_score() {
		return max_score;
	}
	public void setMax_score(String max_score) {
		this.max_score = max_score;
	}
	public HitsHitsElasticSearch getHits() {
		return hits;
	}
	public void setHits(HitsHitsElasticSearch hits) {
		this.hits = hits;
	}
	@Override
	public String toString() {
		return "PayloadResElasticSearch [total=" + total +  ", max_score=" + max_score +  ",hits=" + hits +    ",getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
