package com.qc.api.common;

import java.io.Serializable;

public class MsgInfo implements Serializable
{
	private static final long serialVersionUID = 8152531142041540859L;
	private String msgCode;
	private String msg;
	private String msgDescription;
	
	public String getMsgCode() {
		return msgCode;
	}
	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getMsgDescription() {
		return msgDescription;
	}
	public void setMsgDescription(String msgDescription) {
		this.msgDescription = msgDescription;
	}
	@Override
	public String toString() {
		return "MsgInfo [msgCode=" + msgCode + ", msg=" + msg + ", msgDescription=" + msgDescription + "]";
	}
}
