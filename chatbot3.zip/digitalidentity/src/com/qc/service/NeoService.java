package com.qc.service;

import java.util.Map;



public interface NeoService 
{
	public String processDFSRequest(Map requestData, String requestJson);

}
