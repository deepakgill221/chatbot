package com.qc.service;

import com.qc.api.request.otp.ApiRequestOtp;
import com.qc.api.response.otp.ApiResponseOtpDetails;

public interface OtpService 
{
	public ApiResponseOtpDetails generateOTPProcess(ApiRequestOtp apiRequest);
}
