package com.qc.service;

import java.util.List;
import java.util.Map;

import org.springframework.core.env.Environment;

import com.qc.dto.CreditBureauTrackerDTO;
import com.qc.dto.CrifRequestResponseTrackerDTO;

public interface ExternalServices {
	
	public Map<String,String> callService(Map<String,Object> requestParams,Environment env,CreditBureauTrackerDTO cbTrackerDTO);

	public Map<String, String> callNeoService(Map<String,Object> requestParams,Environment env,
			CreditBureauTrackerDTO cbTrackerDTO,List<CrifRequestResponseTrackerDTO> crifEqifaxInnerData);
	Map<String, String> callNeoServiceV3(Map<String, Object> requestParams, Environment env,
			CreditBureauTrackerDTO cbTrackerDTO, List<CrifRequestResponseTrackerDTO> crifEqifaxInnerData);
	
}
