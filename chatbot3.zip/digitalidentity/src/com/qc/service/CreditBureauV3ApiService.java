package com.qc.service;

import java.util.Map;

import org.springframework.core.env.Environment;

public interface CreditBureauV3ApiService {

	public String getCbV3ActionRequest(final String requestJson, Environment env,Map requestData);
}
