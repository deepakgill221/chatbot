package com.qc.service;

import com.qc.api.request.getdemoauthrequest.ApiRequestGetDemoAuthRequest;
import com.qc.api.response.getdemoauthrequest.ApiResponseGetDemoAuthRequest;

public interface GetDemoAuthRequestService {
	public ApiResponseGetDemoAuthRequest getDemoAuthRequestService(ApiRequestGetDemoAuthRequest apiRequest);
}
