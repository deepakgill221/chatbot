package com.qc.service;

import com.qc.api.request.elasticsearch.ApiRequestElasticSearch;
import com.qc.api.response.elasticsearch.ApiResponseElasticSearch;

public interface ElasticSearchService {
	public ApiResponseElasticSearch generateSearch(ApiRequestElasticSearch apiRequest);
}
