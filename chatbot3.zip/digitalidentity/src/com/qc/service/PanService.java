package com.qc.service;

import org.springframework.core.env.Environment;


public interface PanService {
	public String processPANRequest(final String requestJson , Environment env);
}
