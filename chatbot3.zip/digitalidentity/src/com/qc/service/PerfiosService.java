package com.qc.service;

import com.qc.entity.PerfiosEntity;
import com.qc.entity.PerfiosReportEntity;

public interface PerfiosService 
{
	public PerfiosEntity getStartProcessData(PerfiosEntity perfiosEntity);
	
	public PerfiosEntity getTransactionStatus(PerfiosEntity perfiosEntity,PerfiosReportEntity perfiosReportEntity);
	
	public PerfiosEntity getRetrieveReport(PerfiosEntity perfiosEntity,PerfiosReportEntity perfiosReportEntity);
	
	public PerfiosEntity getTransactionReview(PerfiosEntity perfiosEntity,PerfiosReportEntity perfiosReportEntity);
	
	public PerfiosEntity getSupportedInstitutions(PerfiosEntity perfiosEntity,PerfiosReportEntity perfiosReportEntity);
	
	public PerfiosEntity getDeleteData(PerfiosEntity perfiosEntity,PerfiosReportEntity perfiosReportEntity);
}
