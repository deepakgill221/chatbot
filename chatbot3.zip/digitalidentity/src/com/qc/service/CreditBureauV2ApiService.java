package com.qc.service;

import java.util.Map;

import org.springframework.core.env.Environment;

public interface CreditBureauV2ApiService {

	public String getCbV2ActionRequest(final String requestJson, Environment env,Map requestData);
}
