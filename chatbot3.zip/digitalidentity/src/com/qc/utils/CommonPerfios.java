package com.qc.utils;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.security.Key;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.util.ResourceBundle;

import javax.crypto.Cipher;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.openssl.PEMReader;
import org.bouncycastle.util.encoders.Hex;
import com.qc.entity.PerfiosEntity;
import com.sun.research.ws.wadl.Resource;

public class CommonPerfios 
{

	private static ResourceBundle res = ResourceBundle.getBundle("application");
	private static Logger logger = LogManager.getLogger(CommonPerfios.class);
	static String email =res.getString("perfios.email.id");
	static String server =res.getString("perfios.server.url");
	public static  String vendor = res.getString("perfios.mli.vendor");//"maxlifeInsurance";
	//public static  String returnURL = "https://mliutilityuat.maxlifeinsurance.com/AadhaarBiometricKUAWebServiceClient/%s";

	static String privateKey = "-----BEGIN RSA PRIVATE KEY-----\r\n" + 
			"MIIBPAIBAAJBAL7tRrW9KHOrfjkXmOpF5XTHMghQNyPPxqPyupN0H68+aHDjqmdt\r\n" + 
			"btWuDOWssUTw2ruD6iKS2FMxzBF0Sw+2/8ECAwEAAQJBAKOY9Sns96iFnhaVnbXA\r\n" + 
			"RqkVtk1hTp4k/3SkHDMVIcEqISOC0SHG0geXDhkB1uqUtckP9V7hFb3pFgVlAlbW\r\n" + 
			"AAECIQDpy1PbM95kVrUOLvXfZCsZS1yZydYpGHo4A90AMw0kwQIhANEPomye6G3w\r\n" + 
			"MDPeRBYJyNXtErKCrzTAAF9XxmmkqZsBAiEAijQExR6bR2suKk0+USjwhUpUWiDD\r\n" + 
			"NZXfob8+5EBJc8ECIQC3whtNiHvarmVgIf0Mtfr+9owZtj7UifOJ2ng/QYoHAQIg\r\n" + 
			"O7Al4/FQ4HGX+bCuWd5Ndkowq8SVLWDu+wPWuI5jngM=\r\n" + 
			"-----END RSA PRIVATE KEY-----";
	static final String DIGEST_ALGO = "SHA-1";
	static final String ENCRYPTION_ALGO = "RSA/ECB/PKCS1Padding";
	//static String perfiosTransactionId = "UPDATE ME PLEASE";
	//static String format = "pdf";//pdf,xml

	public static String getTxnStatusPayload(String applicationId , String vendor){
		return "<payload>\n" +
				"<apiVersion>" +"2.0"+ "</apiVersion>\n"+
				"<vendorId>" + vendor + "</vendorId>\n" +
				"<txnId>" + applicationId + "</txnId>\n" +
				"</payload>";
	}

	public static String getRetrievePayload(String applicationId, String vendor, String perfiosTransactionId, String format ){
		return "<payload>\n" +
				"<apiVersion>" +"2.0"+ "</apiVersion>\n"+
				"<vendorId>" + vendor + "</vendorId>\n" +
				"<txnId>" + applicationId + "</txnId>\n" +
				"<perfiosTransactionId>"+ perfiosTransactionId +"</perfiosTransactionId>\n" +
				"<reportType>"+format+"</reportType>\n" +
				"</payload>";
	}
	public static String getDeleteTransactionPayload(String vendorId, String perfiosTransactionId ) {
		return "<payload>\n" +
				"<apiVersion>" +"2.0"+ "</apiVersion>\n"+
				"<vendorId>" + vendorId + "</vendorId>\n" +
				"<perfiosTransactionId>"+perfiosTransactionId+"</perfiosTransactionId>\n" +
				"</payload>";
	}

	public static String getRequestReviewTransactionPayload(String vendorId, String perfiosTransactionId ) {
		return "<payload>\n" +
		    "<apiVersion>" +"2.0"+ "</apiVersion>\n"+
            "<vendorId>" + vendorId + "</vendorId>\n" +
            "<perfiosTransactionId>"+perfiosTransactionId+"</perfiosTransactionId>\n" +
            "</payload>";
	}
	
	public static String InstitutionsTransactionPayloadNetbanking(String vendorId, String destinationId ) {
		return "<payload>\n" +
		    "<apiVersion>" +"2.0"+ "</apiVersion>\n"+
            "<vendorId>" + vendorId + "</vendorId>\n" +
            "<destination>"+destinationId+"</destination>\n" +
            "</payload>";
	}
	
	public static String InstitutionsTransactionstatement(String vendorId, String destinationId ) {
		return "<payload>\n" +
		    "<apiVersion>" +"2.0"+ "</apiVersion>\n"+
            "<vendorId>" + vendorId + "</vendorId>\n" +
            "<destination>"+destinationId+"</destination>\n" +
            "</payload>";
	}
	
	public static String InstitutionsTransactionbankAccountDetail(String vendorId, String destinationId ) {
		return "<payload>\n" +
		    "<apiVersion>" +"2.0"+ "</apiVersion>\n"+
            "<vendorId>" + vendorId + "</vendorId>\n" +
            "<destination>"+destinationId+"</destination>\n" +
            "</payload>";
	}
	
	public static String perfiosTransactionData(PerfiosEntity perfiosEntity) throws Exception 
	{
		logger.debug("perfiosTransactionData : Start ");
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		String transactionStatusUrl = genericCreateHTML(getTxnStatusPayload(perfiosEntity.gettId(),vendor), "txnstatus");
		logger.debug("perfiosTransactionData : End : "+transactionStatusUrl);
		return transactionStatusUrl;
	}
	
	public static String perfiosDataRetrieveStatement(PerfiosEntity perfiosEntity) throws Exception 
	{
		String myHTML="";
		String format="statements";
		//String format="xml";
		//String format="pdf";
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		myHTML = genericCreateHTML(getRetrievePayload(perfiosEntity.gettId(), vendor, perfiosEntity.getPerfiosTransId(), format), "retrieve");
		logger.debug("Perfios HTML CREATED:--"+myHTML);
		return myHTML;
	}

	public static String perfiosTransactionReview(PerfiosEntity perfiosEntity) throws Exception
	{
		String myHTML="";
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		myHTML = genericCreateHTML(getRequestReviewTransactionPayload(vendor, perfiosEntity.getPerfiosTransId()), "review");
		logger.debug("Perfios HTML CREATED:--"+myHTML);
		return myHTML;
	}
	
	public static String perfiosSupportedInstitutions(PerfiosEntity perfiosEntity) throws Exception
	{
		String myHTML="";
		String destinationId = perfiosEntity.getDestination();
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		if(destinationId!=null && destinationId.equalsIgnoreCase("netbankingFetch"))
			myHTML = genericCreateHTML(InstitutionsTransactionPayloadNetbanking(vendor, destinationId), "institutions");
		else if(destinationId!=null && destinationId.equalsIgnoreCase("statement"))
			myHTML = genericCreateHTML(InstitutionsTransactionstatement(vendor, destinationId), "institutions");
		else if(destinationId!=null && destinationId.equalsIgnoreCase("bankAccountDetailsFetch"))
			myHTML = genericCreateHTML(InstitutionsTransactionbankAccountDetail(vendor, destinationId), "institutions");
		else
		{
			logger.info("NO DETAIL FOUND IN DESTINATION---"+destinationId);
			return myHTML="";
		}
		logger.debug("Perfios HTML CREATED:--"+myHTML);
		return myHTML;
	}
	
	
	public static String perfiosDataDeleteStatement(PerfiosEntity perfiosEntity) throws Exception 
	{
		String myHTML="";
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		myHTML = genericCreateHTML(getDeleteTransactionPayload(vendor, perfiosEntity.getPerfiosTransId()), "retrieve");
		logger.debug("Perfios HTML CREATED:--"+myHTML);
		return myHTML;
	}

	private static void createFile(String classification, String myHTML) {
		String filename = vendor +"/" + classification + "_" + server + ".html";

		try {
			PrintWriter out = new PrintWriter(filename);
			out.print(myHTML);
			out.close();
			logger.info("Successfully created file " + filename);
		}catch (Exception e){
			logger.error("ErrorInfo while creating file " + filename);
		}
	}

	private static String genericCreateHTML(String payload){
		return genericCreateHTML(payload, null);
	}

	private static String genericCreateHTML(String payload, String operation) 
	{
		String emailEncrypted = encrypt(email, ENCRYPTION_ALGO, buildPublicKey(privateKey));
		payload = payload.replaceAll("\n", "");
		payload = payload.replaceAll("#email#", emailEncrypted);

		String payloadSign=payload;
		String signaturePayload = getSignature(ENCRYPTION_ALGO, DIGEST_ALGO, buildPrivateKey(privateKey),payloadSign);
		logger.info("Signature :: "+signaturePayload);
		
		if (operation == null) operation = "start";
		
		String myHTML =
				"<html>\n" +
						"	<body onload='document.autoform.submit();'>\n" +
						"		<form name='autoform' method='post' action='https://" + server +"/KuberaVault/insights/" +operation + "'>\n" +
						"			<input type='hidden' name='payload' value='"+ payloadSign + "'>\n" +
						"			<input type='hidden' name='signature' value='" + signaturePayload + "'>\n" +
						"		</form>\n" +
						"	</body>\n" +
						"</html>\n";

		String xml = "payload="+payloadSign+"&signature="+signaturePayload;
		return xml;
	}


	public static String getSignature(String encryptAlgo, String digestAlgo, Key k, String xml) {
		String dig = makeDigest(xml, digestAlgo);
		return encrypt(dig, encryptAlgo, k);
	}

	private static PrivateKey buildPrivateKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PrivateKey pKey = null;
		try {
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPrivate();
			pemReader.close();
		}
		catch (IOException i) {
			i.printStackTrace();
		}
		return pKey;
	}

	private static PublicKey buildPublicKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PublicKey pKey = null;
		try {
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPublic();
			pemReader.close();
		}
		catch (IOException i) {
			i.printStackTrace();
		}
		return pKey;
	}

	public static String makeDigest(String payload, String digestAlgo) {
		String strDigest = "";
		try {
			MessageDigest md = MessageDigest.getInstance(digestAlgo);
			md.update(payload.getBytes("UTF-8"));
			byte[] digest = md.digest();
			byte[] encoded = Hex.encode(digest);
			strDigest = new String(encoded);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return strDigest;
	}

	public static String encrypt(String raw, String encryptAlgo, Key k) {
		String strEncrypted = "";
		try {
			Cipher cipher = Cipher.getInstance(encryptAlgo);
			cipher.init(Cipher.ENCRYPT_MODE, k);
			byte[] encrypted = cipher.doFinal(raw.getBytes("UTF-8"));
			byte[] encoded = Hex.encode(encrypted);
			strEncrypted = new String(encoded);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return strEncrypted;
	}





	public static String perfiosDataStartProcess(PerfiosEntity perfiosEntity, int requestCall) throws Exception 
	{
		String myHTML="";
		String vendorId=perfiosEntity.getVenderId();
		String txnId=perfiosEntity.gettId();
		String emailID=perfiosEntity.getEmailId();
		String destination=perfiosEntity.getDestination();
		String returnurl=perfiosEntity.getReturnUrl();
		
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

		switch(requestCall)
		{
		case 1:
			if(destination!=null && destination.equalsIgnoreCase("payloadNetbanking"))
			{
				String payloadNetbanking = "<payload>\n" +
						"<vendorId>"+vendorId+"</vendorId>\n" +
						"<txnId>"+txnId+"</txnId>\n" +
						"<emailId>" +"#email#"+ "</emailId>\n" +
						"<destination>"+destination+"</destination>\n" +
						"<returnUrl>"+returnurl+"</returnUrl>\n" +
						"</payload>";
				myHTML = genericCreateHTMLStartProcess(payloadNetbanking,emailID);
			}
			else if(destination!=null && destination.equalsIgnoreCase("payloadStatement"))
			{
				String payloadStatement = "<payload>\n" +
						"<vendorId>" + vendorId + "</vendorId>\n" +
						"<txnId>" + txnId +"</txnId>\n" +
						"<emailId>" +"#email#"+"</emailId>\n" +
						"<destination>" +destination+ "</destination>\n" +
						"<returnUrl>" +returnurl + "</returnUrl>\n" +
						"</payload>";
				myHTML = genericCreateHTMLStartProcess(payloadStatement,emailID);
			}
			else if(destination!=null && destination.equalsIgnoreCase("netbankingFetch"))
			{
				String netbankingFetch = "<payload>\n" +
						"<vendorId>"+vendorId+"</vendorId>\n" +
						"<txnId>"+txnId+"</txnId>\n" +
						"<emailId>" +"#email#"+ "</emailId>\n" +
						"<destination>"+destination+"</destination>\n" +
						"<returnUrl>"+returnurl+"</returnUrl>\n" +
						"</payload>";
				myHTML = genericCreateHTMLStartProcess(netbankingFetch,emailID);
			}
			else if(destination!=null && destination.equalsIgnoreCase("bankAccountDetailsFetch"))
			{
				String bankAccountDetailsFetch = "<payload>\n" +
						"<vendorId>" + vendorId + "</vendorId>\n" +
						"<txnId>" + txnId +"</txnId>\n" +
						"<emailId>" +"#email#"+"</emailId>\n" +
						"<destination>" +destination+ "</destination>\n" +
						"<returnUrl>" +returnurl + "</returnUrl>\n" +
						"</payload>";
				myHTML = genericCreateHTMLStartProcess(bankAccountDetailsFetch,emailID);
			}
			else if(destination!=null && destination.equalsIgnoreCase("statement"))
			{
				String statement = "<payload>\n" +
						"<vendorId>"+vendorId+"</vendorId>\n" +
						"<txnId>"+txnId+"</txnId>\n" +
						"<emailId>" +"#email#"+ "</emailId>\n" +
						"<destination>"+destination+"</destination>\n" +
						"<returnUrl>"+returnurl+"</returnUrl>\n" +
						"</payload>";
				myHTML = genericCreateHTMLStartProcess(statement,emailID);
			}

			break;
		case 2:
			System.out.println("Need to Implement");
			break;
		case 3:
			System.out.println("Need to Implement");
			break;
		case 4:
			System.out.println("Need to Implement");
			break;
		default:
			myHTML="";
			break;
		}
		return myHTML;

	}
	private static String genericCreateHTMLStartProcess(String payload, String emailID){
		return genericCreateHTMLStartProcess(payload,emailID, null);
	}
	private static String genericCreateHTMLStartProcess(String payload,String emailID, String operation) {

		String emailEncrypted = encrypt(emailID, ENCRYPTION_ALGO, buildPublicKey(privateKey));
		payload = payload.replaceAll("\n", "");
		payload = payload.replaceAll("#email#", emailEncrypted);

		String signaturePayload = getSignature(ENCRYPTION_ALGO, DIGEST_ALGO, buildPrivateKey(privateKey),payload);
		logger.info("Signature :: "+signaturePayload);

		if (operation == null) operation = "start";
		String myHTML =
				"<html>\n" +
						"	<body onload='document.autoform.submit();'>\n" +
						"		<form name='autoform' method='post' action='https://" + server +"/KuberaVault/insights/" +operation + "'>\n" +
						"			<input type='hidden' name='payload' value='"+ payload + "'>\n" +
						"			<input type='hidden' name='signature' value='" + signaturePayload + "'>\n" +
						"		</form>\n" +
						"	</body>\n" +
						"</html>\n";

		return myHTML;
	}
}



//
//String message ="\n\nnetbanking and statement APIs are the APIs to start the transaction. \n" +
//"Only integration supported to start the transaction is through autopost form as in the netbanking and statement htmls.\n" +
//"All other APIs are xml over HTTP and do not need browser to be present.\n" +
//"You can directly invoke those APIs using other mechanisms.\n\n" +
//"Trying this program:\n" +
//"\t(1)First run the program and it will generate the netbanking and statement upload files.\n" +
//"\t(2)Depending upon whether you have requested these features to be available, you should be able to start the transactions.\n" +
//"\t(3)netbanking and statment HTML start the perfios transaction using browser to browser integration.\n" +
//"\t\t(3.1)To start netbanking transaction, open netbanking_* file in your browser..\n" +
//"\t\t(3.2)To start statement upload transaction, open statement_* file in your browser..\n" +
//"\t(4)You can then check the status of all transactions using txnstatus API.\n" +
//"\t\t(4.1)To check the status of transaction, open txnstatus_* file in your browser. \n" +
//"\t\t\tThis API could also be accessed without a browser. Without autoform load request\n" +
//"\t(5)To retrieve a report, you will need to re-run the program. Change the value of perfiosTransactionId variable in your program.\n" +
//"\t\t Compile and run the java program. open retrieve_* file in your browser. This API could also be accessed without a browser.\n" +
//"\t\t Without autoform load request\n" +
//"\t(5)To delete the transaction related artifacts, you will need to re-run the program. \n" +
//"\t\tChange the value of perfiosTransactionId variable in your program. Compile and run the java program. open delete_* \n" +
//"\t\tfile in your browser. This API could also be accessed without a browser. Without autoform load request\n" +
//"You can pass applicationId and perfiosTransactionId through command line by providing system properties too. " +
//"For e.g. java -DperfiosTransactionId=HDJDJ com.perfios.sample.OnlineSampleMaxLifeInsurance\n" +
//"\t(6)For more details please refer the API guide.\n";
//System.out.println(message);
