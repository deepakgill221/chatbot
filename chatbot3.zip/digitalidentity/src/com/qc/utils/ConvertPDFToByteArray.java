package com.qc.utils;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ResourceBundle;

import org.apache.axis.encoding.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
public class ConvertPDFToByteArray {
	private static Logger logger = LoggerFactory.getLogger(ConvertPDFToByteArray.class.getClass());
	ResourceBundle resProp = ResourceBundle.getBundle("application");
	//	public  String pdfByteCaller(String fileLocation) throws IOException
	//	{
	//		logger.info("Came Inside pdfByteCaller with FileLocation : "+fileLocation);
	//		byte data[] = convertPDFToByteArray(fileLocation);
	//		String filedata=Base64.encode(data);
	//		return filedata;
	//	}

	public  String pdfByteCaller(String aadhaarno) throws IOException
	{
		logger.info("Came Inside pdfByteCaller with Aadhar& policy no--"+aadhaarno);
		byte data[] = convertPDFToByteArray(aadhaarno);
		String filedata=Base64.encode(data);
		System.out.println(filedata);
		/*//		    -----------For decode------------------
		 * 
	        Base64 b = new Base64();
	        byte[] bytes = b.decode(filedata); 
	        FileOutputStream fos = new FileOutputStream("D:\\AadharWebService\\AadhaarKycFiles\\New\\999929989823.pdf");
	        fos.write(bytes);
	        fos.close();
		 */
		return filedata;
	}
	public  byte[] convertPDFToByteArray(String newpdfpath)
	{

		logger.info("Came Inside convertPDFToByteArray with Aadhar& policy no-"+newpdfpath);
		InputStream inputStream = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			String pdfpath=resProp.getString("aadhaar.template.pdfpath");
			File pdffile= new File(newpdfpath);
			if(pdffile.exists())
			{
				logger.info("Pdf found at Location"+pdfpath);		
				inputStream = new FileInputStream(newpdfpath);
				byte[] buffer = new byte[1024];
				baos = new ByteArrayOutputStream();

				int bytesRead;
				while ((bytesRead = inputStream.read(buffer)) != -1) {
					baos.write(buffer, 0, bytesRead);
				}
			}
			else
			{
				logger.info("Pdf not saved at Location"+pdfpath);

			}

		} catch (FileNotFoundException e)
		{
			logger.info("File not found--"+e);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("IO exception --"+e);
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		logger.info("Pdf byte array--"+ baos.toByteArray());
		return baos.toByteArray();
	}
	public String newPdfByteArray(Object addressjson,String custName,String gender,String dob,String phone,String email,String aadhaarNo,String imgbytearray,String policyno) throws IOException
	{
//		initializing();
		String totalPrem= "";
		String serviceTax="";
		String sumAssured="";
		String addr="";
		String compAddr="";
		String filePath0="";

		try
		{
			JSONObject addressJson=(JSONObject)addressjson;
			String filePath = resProp.getString("aadhaar.template.NEW_PDF_PATH") ;
			//filePath  = (new StringBuilder(workDir)).append(File.separator).append("COI").append(File.separator).toString();
			//this loop is used for First_Medical_Letter pdf creation
			String	blank_ekyc_file = (new StringBuilder(resProp.getString("aadhaar.template.pdfpath"))).append("Aadhaar_EKYC.PDF").toString();
			PdfReader pdfReader  = new PdfReader(blank_ekyc_file);
			filePath0  = filePath+aadhaarNo+".pdf"; 
			PdfStamper pdfStamper = new PdfStamper(pdfReader, new FileOutputStream(filePath0));
			for(int i=1; i<= pdfReader.getNumberOfPages(); i++)
			{
				PdfContentByte cb = pdfStamper.getUnderContent(i);
				cb.setRGBColorFill(0x00, 0x00, 0x00);

				if(i==1)
				{
					printWord(policyno, cb, 146, 604);
					printWord(custName, cb, 144, 580);
					if(addr.length()<=30){
						printWord(addr.substring(0, addr.length()), cb, 138, 675);
					}else if(addr.length()>30 && addr.length()<=60){
						printWord(addr.substring(0, 30), cb, 138, 675);
						printWord(addr.substring(30, addr.length()>60?60:addr.length()), cb, 138, 665);
					}else if(addr.length()>60){
						printWord(addr.substring(0, 30), cb, 138, 675);
						printWord(addr.substring(30, 60), cb, 138, 665);
						printWord(addr.substring(60, addr.length()>90?90:addr.length()), cb, 138, 655);
					}
					printWord(addressJson.getString("LOCATION"), cb, 190, 434);
					printWord(dob, cb, 144, 556);
					printWord(gender, cb, 144, 529);
//					printWord(addressJson.getString("STATE"), cb, 142, 475);
					printWord("INDIA", cb, 142, 475);
					printWord(addressJson.getString("PIN"), cb, 147, 462);
					printWord(addressJson.getString("HOUSE")+" "+addressJson.getString("STREET"), cb, 245, 448);
					printWord(addressJson.getString("LANDMARK"), cb, 180, 420);
					printWord(addressJson.getString("VILL/CITY"), cb, 180, 405);
					printWord(addressJson.getString("DIST"), cb, 180, 390);

					printWord(email, cb, 147, 366);
					printWord(phone, cb, 160, 341);
					printWord(aadhaarNo, cb, 165, 315);

					Base64 b = new Base64();
					// byte[] bytes = b.decode(filedata);
					byte[] imgByte = b.decode(imgbytearray); 
					// byte[] imgByte = b.decode("/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADIAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDd4peKbupM/hWNih3frmlHSmZ96cDigQ4U8dKZS/wn3oAkQfLTsU2PhBT+tAAMVIBTMU4UWAcKdSAc070oFcUCn44pop2OaYC44pw60gFOHakMU9R/OnUfWjtQAY4p2O9NpenegDHMKUhUKw2oCuOcmpW6U09CT0rv5F2MbsZAA7BWHH0qZo0B4QfnUdv98GpieTgd6fKuwrjBEp/hH504QjptH504HGc9qPN+UlVLew7/AJ0ckewXYLCAMYx+NOEI9aj+1bTh42X64/pSfbYCpO9eOvNHs49hczJ/IHrzTlg968+1/wCI/wDZ0xS0jjlYHjccg/lWGnxhvgT5mn27c/wuwxUONNdClzbnr7LDAu+WVUX1dgBVhREU3CLf7Kf8a8xsvi9p8hRbmymjJHzMhDAf1rttF8R6Vq4Bs76GRj/BnDfkeauMYbJCbktzeSCF1zsI9s0nkRn+Fvzp8Dh0JBBGPWpBjim6cexKkyAW6ngE4pfsoyMbhVggHFOHbFL2Uew+dlb7KegJ/Kl+zE/xfpVtee9KOO1L2MOwc7Kf2V/VaX7K/qv51cxS7aXsIjVRnBPqiFT2NQPqny47Vkbj60mT0qrlWNuDVQvLDjFWo9UgbHz4rm9x20m7aM5oTFY6oX0DdZBtrJ1nxVZaZExaZAcdzXBeKPER01Vt4XHntyRnoPevP7q7nvZTLPIznpyaTqJAoXOw1j4g3t1IRayMoB4YDH5d6y7TxvrFtMXe5ebcMMJTnj69a5s88gU3j8axcmXZEs87TStI3Vjnio9x7UnakqW7jsPVyO+KtwzOACrkN7VSFSA4xgfpTTBndaB8RNZ0WRVaQXUQG0pMTyPY/wD669k8MeMdL8RxBbaUrcgfNDLgP7/X8K+aVbcBVuzu5rO4Se2meKZTlJEOCprWMmjNxTPrFaeBXEfD/wAajxHZNb3jKuowAeYOm8f3gPyz/wDXrtDKokWMnlhkCt009UZNNbkoFOAoAFOA7VQCY4pe9OxRikCPHsigc0jECkBNYm4rHHFVNTu0sbGW5boik9etWXxu59K5nxnLt0N1Unllzz70PRAee3V1LdXMk8x3O5JJNRoQepx71GevNLWBY8BmPFWbezaTkioYXwce9b1rGBAGPeom0kXTjdlC40tlgDqoBHJxWb5bdMV3EYUxhXTgjHSs290XDma3wVPJFYxq9GazpdUcxtKthhUoCY75rS+wPKSEwHH8JqpJayxE7kIPfjFdEZIwcWRKGUgjnPWnFgv1NL0HAK49qikcEjA/GrvYixo6dqUlhdxXNvK6TRtkMjbSPX9K9z8FeJ28SahaBlcfZbRhIxOdzkoOSAByAcD6189xnBGa9i+DWrW6XF5pcwXzJwHjOBzjORnr6cfWrpvWxM1oe0LyKeBTY12gAEkCpK6dzATHFGKeBxSgUAjxRjubFOAIPekUZPNO7msDoGy9c+1cX43dvsigE4L8/lXaydR9K4vxqpNqOOAQaUtgW5wROTQKOtaEcMcUYd+D6msG7FoLCzLuHk4A6Cujgt96ACucW9ffiJCR/OrceqXkI3eUyj1KmsZxcjaMlE7i1slZBmp20kn7nH4VyVn4pullAIG3uMV2VjrIuI+B+BFc8qTidEKiaMi40R2fzEGGU5yO9XYtJiuYf30YDgYOR1qe91RraLKrya5y58UXyt5cUYwepAyaqMXIUpRiXJvDdmSQV49qzrrwtahcwuw9QTmnJqes3Cf6gkHuRikXULuCTbcwHB7itOWa2Zk5RfQ5+7077LcbGbI7ECrug6nLpGr213buVeJwwI9O9WNZUT2guI+qmsiAjzFIHU8V0UpNx13OecbPQ+udMuxf6fBdKCFkQMMjHUVcAzWV4ajEXh6wQHOIV59eBzWsBgc13J6HG9xRTgKBilxTGeKbcUd6eRTO/WsTca55rmPFsJexc+xrpzzWN4jjB0uRvQUmtATPK4l3Sqvqa2ntlcDcMgdqzLNCbxQe3Nb69Mdq5Jt9Dogr6GYLgwMFSPB6cCraahcLP5EoijBGR5obn8qkktFdtwqZI1iId8MQOA3NRzRL5WN1DTng8l2VUaSMSFVOduexHUVoaBOfN2t0rOk3SnPAz7Vf0tdkmQOKio01oXTi0zodTCyBRHjJHWudmtZ9k0sTJ+7BYLnlvoK3ZPnQBgeO9V2tG3biMr64zWNOdtzScL7GRpmo394xiQIxVSx25XGPUnirVrM9+5SRd3PII6VpC3h8sruUZ64GKWCNIGzEvPrWk5xe25EYPqVrzTl/s6dAuMqTz61yel2TXuqWlmvDTSrGPqxx/Wu+kzJGVbuK5zw7Zyx63HdRrlrS4V/yORWuHlo2zOrC7SR9NWURhtIYj/AgXpjoKtUyFTsXcMHHIqXFeotjzBAOOKcOlA4FKOKBnirVGTk8Cnk+9IoBOayNxjAisfxDIBY7M8Ma2ZPvEVja/AZLHcP4eaJ6xCLs7nnqx7dVfjAxmtRFHGaryoFuBIB1FTo3OO1cMvhR1q3MaUEQbtn8KV7MNIPk4p9pjIrdiSFoTv8AlI7iuVvU6ktDmbi2ZGCD7xGT7Cr+kxRNMqFwMHBqC/iZ5SyOPTn0qtZ2M4uBLCNpHJwx5/Or0aJvZnb3NrbxoqJMrlvSnWNqrxsjj51NYU1u8pjkm8zcPu7ZCoB/CtnTWdYx5sm9iBzWTSNE7sfJpYLZEYz64pGtQgxtAFbMTArnrVS5ZFBap2LZkTRgDgDpVfwtpzy39zj5fOuFjX3Of/rirM7gBgPwrpvAenC51WN8ZSEGU/U9P8+1dVJOWi6nJOSi3J9D1NBx707FKopwxkcV6x5F9RuBSY6U/oetBHNFxo8QanLxTDThwKhG7B1y1Vr+AS2Ui+qmreMnpUdyrPAyr1I4qugjzS8RYyMt8wOMU2NsEZq/qGl3MDvJInGetZisd3PFcU46HRGVzbtHGMip7i8ZVIHQd6y7STDDmrszK6FVAya42veOtP3dCk16m8GST8B3q7a6ogOApCnqc1RGl7iWRfyq7D51soHko/1rRcgRv1L39pxrjKOw9c//AFqt22rWww8b455VutV7fzbgbDAq59K0INLhjGWUc9eKiXIN67GrZ3olXI6HpTbqTPGfwqvAscAKr93t7VBNMGY561i1d6F3shCHnkVIwSzHAA7mvS/AGn3Vml3LPBJEj7AnmLgtjP6ciuM8JaW+ratuUfu4BuYkcZ7D+Z/CvX7ZTFCqAE4GK9TDUtFI83EVN4otjrTl6VGAT2p4FdbOKwtLkAc0hNMUb2JPSgpHiLKVIPUUK2Wxnn0pwal27+vX1qEzewv8XFO7c1W2DcRuf8GIocRRoXkdlRRksZSAP1p3EVdYthNaOBjOK83uswzH24NbmueL4hvg0ze56GZ3Yj8AT+tcY80txcb5XLMx5JrCpJM0imtTWiudjBs1ehuwx6mueWRkba9TrK2MoTXM4Jm6m0dbbz7VHI5rVtYoXXfIciuJi1AhQrAqRWhb6w6psUHP0NZey1uaqrodxbrb7d6HC/lSz3Ee3Ct71x66zLt2hWWni+nl42kD1NJ0w9qbb3q7iM1Wlu9oJ3YFZrXAQfN1NQxs1xJnkKOlEadtSXNs9m+GmraKNONkt5ENUdi0sLcMfTGeox6Z/CvRkzjgV8fXbkahKwz98/hXp3gr4qTWBjsteZrm2Jwtzt3SRj37sP1+vAr0qdVWszlqYdv3ke7jpRuAFUrO/tb+0jubSaOeCQZSSMgqwqypH91cfStrHLYUnI71InC5pu4ddqj6CglT1B/M0ageHg1IGHSoS2KhuLuO0t5J5WwiDJrM6Au7yCxhe4uJAiL1J/l9a848QeIbnV5Si5jtVPyxg9fc+po1jWX1acM8irGD8kYb7v8A9esyQfw9vXFYznfRHRTpK12VKaTyKlMZI4pEiLZ46Vkmtxyi1oWWiEyA98VX2vGe+Pardtyq1pRW6Sj5sc1DlYfKzJiuVBwy5zWlBc2/p+NTSaQh5AOKamkgHoKnniw5GTC7iwcAf4Uhu2bARTj2qxDpS8DH61pW+nRr1UH6VLnFFcrZlw2skp3SdPSr4i8pD2xWiIlTOMfhVS7+WFjkAfyrOU3IqMLanIyMxvZ1P98n86mTK84xUE7h752UfK3Q1PGMtjriuuLNKa0Oq8LeMNT8NXO+0lDwMf3lvIfkf/A+4/UcV7t4b8Xad4ktd9pIFmUAyW7n50P9R7j9DxXzQh6e9TxaxNo91FPbyTQzoco8XUVrCo4mNehGWuzPrAPxjilBBNeZeDfitputItrqskdnegf6xvlST3/2T+n06V6HBd29zH5lvPHMn96Ngw/MV1ppq6POlBx3PF92a5DxZrVs8P2KGTe4bLbeQODx+dZmreKrm9DRW4MMB4OPvN9fSufLbVZjyzDArllPSyOuNO2rIXbn3q9EweJWX5towQeoqhjpmhWaM7lODWViozady7sG7gHB/StCGyDW6nHLc5rOimWQdlk9OxrX0y+A/wBHuMDH3X/pWdRO2h0JqSIY7VkbGKtIu3pWo0SHt+NQtACflrncrhy2JrVgwAq/HGP7oqlbxMrDuK144S4BxWUmXYagGOAPypwUt0qzHak9aspbADpS1KsZhj5Oa5zXbwMfs8Z4z83vXUapILW2ZhjcRgVwcjiWcs5yo6D1rWjC8rktEezJ3HgDj605JADtIx/WldyzfN+AA6VIsQONw/Gu1ajemxPBggY6d6ZehJIsF1LA8DOaaIsfLzjHQ1BNhQABimkZzloCQCQjBIYdCDirtrd3tq6vFO4YdGBwfzFQ2qHAf8uKtkccU72IjHQxGh4ULgAD8zUT2/ORzn1q1746UnGakLmeY9h5FMxk+1XJ1PAHSljhGKA5LlTb7VKsjjAPzY796n2KM8c+lJ5S89s0mNRsbelanEyCCdsdlb/Gt6O2BAI5B9K4ZUAcZ/OtGz1W/wBP/wBWwmi/utyRWM6N9UaKXc7KO2A7Vdg+TjFYun+IbW+UKWEUvdWOPyrTEpJPPBrkcXHc1TT2NJZFHOBSTXYWMkkAVmGYrnnisq5vGlc8nb6UlqDZFrt7uiZtx5+VRXMxq0jjaM9hir2oyNdXQiUkqg5+tTWsAQA4wa7qcbR1M99SFYAqZPWpQmQF+oqbaMkds1A9ysfU5rXUTElCpHksM4qkAZpu+Kd+8unAAIXsa0IbVY1xznOKdyWriIhWML6VL5XHXmpdgAzTCSAM80my1Ewgc4BpjJ8wI/KiimjJjCxXIYZz3qVJEA4oopLVlJaDtoY8dKBGecUUUgT1GmPnpzQGeM8DpRRTLHMkN16JL/eA/nVuy1i80xxFcAyxdgT/ACNFFTKKa1E1bVG6uqw3kANu3Xqp6iqV5cC1gJHLtwo96KK51BKVgbKdvGIk3ORvzk881JJcBRgdc0UV1IJaFfdM549KmgsN3zycjrRRQJK5dSFYiAqjrUnAJ/pRRSNUhSMkrSbBjFFFA7H/2Q==");
					Image image = Image.getInstance(imgByte);
					image.scaleToFit(80, 110);
					image.setAbsolutePosition(280, 65);
					cb.addImage(image);

				}

			}
			pdfStamper.close();
			pdfReader.close();

		}catch (Exception e)
		{
			e.printStackTrace();
		}
		return filePath0;
	}

	private void printWord(String word, PdfContentByte cb, int x, int y) {
		if (word == null)
			word = "";
		cb.beginText();
		cb.setFontAndSize(FontFactory.getFont("TIMES").getBaseFont(), 9.0F);
		cb.showTextAligned(PdfContentByte.ALIGN_LEFT, word, x, y, 0);
		cb.endText();
	}
}
