package com.qc.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.axis.encoding.Base64;

public class Test 
{
	public static void main(String[] args) 
	{
		/*BigDecimal a = new BigDecimal("2.71828183");
        BigDecimal b = new BigDecimal("-4.0656");
        MathContext mc = new MathContext(4);
        System.out.println();
        System.out.println();
        double d = a.doubleValue();
        double c = b.doubleValue();
		Math.pow(d,c);
		System.out.println(Math.pow(d,c));*/
			/*String aadhaarno="";
			//byte data[] = convertPDFToByteArray(aadhaarno);
			String filedata=Base64.encode(data);
			System.out.println(filedata);*/
			/*//		    -----------For decode------------------
			 * 
		        Base64 b = new Base64();
		        byte[] bytes = b.decode(filedata); 
		        FileOutputStream fos = new FileOutputStream("D:\\AadharWebService\\AadhaarKycFiles\\New\\999929989823.pdf");
		        fos.write(bytes);
		        fos.close();
			 */
		
		
		
		 try {
             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
             sdf.setLenient(false);
             
             int year = Calendar.getInstance().get(Calendar.YEAR);

 		    int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
 		    System.out.println("Financial month : " + month);
 		    if (month < 3) {
 		        System.out.println("Financial Year : " + (year - 1) + "-" + year);
 		    } else {
 		        System.out.println("Financial Year : " + year + "-" + (year + 1));
 		    }

             Date d1 = sdf.parse("2015-12-2015");
             Date d2 = sdf.parse("15-12-2015");
             Date d3 = sdf.parse("18-12-2015");

             if (d2.compareTo(d1) >= 0) {
                   if (d2.compareTo(d3) <= 0) {
                          System.out.println("d2 is in between d1 and d2");
                   } else {
                          System.out.println("d2 is NOT in between d1 and d2");
                   }
             } else {
                   System.out.println("d2 is NOT in between d1 and d2");
             }

      } catch (Exception pe) {
             pe.printStackTrace();
      }
		 
		    
		   /* Date d= 1-1-2018;
		    d.after(min) && d.before(max);
		*/
		
		
		
		
//		String request = Test.getStringdata();
//		System.out.println(request);
//		request = request.replaceAll(Pattern.quote("\\b"), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		request = request.replaceAll(Pattern.quote("\\f"), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		request = request.replaceAll(Pattern.quote("\\n"), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		request = request.replaceAll(Pattern.quote("\\r"), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		request = request.replaceAll(Pattern.quote("\\t"), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		request = request.replaceAll(Pattern.quote("\\v"), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		request = request.replaceAll(Pattern.quote("\""), Matcher.quoteReplacement(" "));
//		System.out.println(request);
//		
//		
//		String convertedData1 = request.replaceAll(Pattern.quote("\\"), Matcher.quoteReplacement("\\\\"));
//		System.out.println(convertedData1);
		
	}
	
	

	
	public static String getStringdata()
	{
		
		return "a\\b sdfghjkl a\\f sdfghjkl a\\n sdfghjkl a\\r sdfghjkl a\\t  sdfghjkl a\\v  sdfghjkl a\" sdfghjkl a\\ sdfghjkl";
		
//		return "a\\b sdfghjkl";
//		return "a\\f sdfghjkl";
//		return "a\\n sdfghjkl";
//		return "a\\r sdfghjkl";
//		return "a\\t  sdfghjkl";
//		return "a\\v  sdfghjkl";
//		return "a\" sdfghjkl";
//		return "a\\ sdfghjkl";
	}
	
}
