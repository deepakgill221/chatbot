package com.qc.utils;

import java.io.File;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class DomParser2 {

	 public static void main(String[] args){

	      try {	

	    	  String xmlRecords = "<?xml version=\"1.0\" encoding=\"utf-8\"?><FUSION-REPORT-FILE>  <INQUIRY-STATUS>    <INQUIRY>      <INQUIRY-UNIQUE-REF-NO>15072016163000INS000123</INQUIRY-UNIQUE-REF-NO>      <REQUEST-DT-TM>15-07-2016 16:30:10</REQUEST-DT-TM>      <RESPONSE-DT-TM>15-07-2016 16:30:15</RESPONSE-DT-TM>      <RESPONSE-TYPE>ACKNOWLEDGEMENT</RESPONSE-TYPE>      <ERRORS>        <ERROR>          <CODE></CODE>          <DESCRIPTION></DESCRIPTION>        </ERROR>      </ERRORS>    </INQUIRY>  </INQUIRY-STATUS>  <REPORT-FILE>    <HEADER>      <DATE-OF-REQUEST>15-07-2016</DATE-OF-REQUEST>      <DATE-OF-ISSUE>15-07-2016</DATE-OF-ISSUE>      <PREPARED-FOR>MAX LIFE INSURANCE</PREPARED-FOR>      <PREPARED-FOR-ID>INS000123</PREPARED-FOR-ID>      <REPORT-ID>TEST1234</REPORT-ID>    </HEADER>    <REQUEST>      <NAME>TEST NAME</NAME>      <DOB-DATE>15-07-1975</DOB-DATE>      <PAN>ABVDV1234D</PAN>      <UID>123456789101</UID>      <ADDRESS>Flat no 1 street no1 locality 1</ADDRESS>      <STATE>MH</STATE>      <PIN>411017</PIN>      <PHONE>9898989898</PHONE>      <EMAIL>testemail@test.com</EMAIL>      <CREDT-RPT-ID>CRDRQINQR</CREDT-RPT-ID>      <CREDT-REQ-TYP>INDV</CREDT-REQ-TYP>      <CREDT-INQ-PURPS-TYP>CP07</CREDT-INQ-PURPS-TYP>      <CREDT-INQ-PURPS-TYP-DESC>InsuranceRequest</CREDT-INQ-PURPS-TYP-DESC>      <CLIENT-CUSTOMER-ID>ML000123</CLIENT-CUSTOMER-ID>      <BRANCH-ID>TESTBRSNCH01</BRANCH-ID>      <APP-ID>TESTAPP01</APP-ID>      <AMOUNT>3000000</AMOUNT>    </REQUEST>    <REQ-SERVICES>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>PAN</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired entity PAN exist in NSDL</DESCRIPTION>        <SCORE>          <SCORE-NAME>PAN SCORE</SCORE-NAME>          <SCORE-VALUE>80</SCORE-VALUE>          <SCORE-DESCRIPTION>Yes-PAN exist for Entity being verified</SCORE-DESCRIPTION>        </SCORE>        <REMARKS>ABVDV1234D, RANJEET DILIP SINGH</REMARKS>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>UID</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>UID SCORE</SCORE-NAME>          <SCORE-VALUE>100</SCORE-VALUE>          <SCORE-DESCRIPTION>Enquired Entity exists in bureau</SCORE-DESCRIPTION>        </SCORE>        <REMARKS>123456789101</REMARKS>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>DOB</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired element details exist in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>DOB SCORE</SCORE-NAME>          <SCORE-VALUE>95</SCORE-VALUE>          <SCORE-DESCRIPTION>Enquired element details exist in bureau</SCORE-DESCRIPTION>        </SCORE>        <REMARKS>15-07-1975</REMARKS>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>ADDRESS</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>ADDRESS SCORE</SCORE-NAME>          <SCORE-VALUE>80</SCORE-VALUE>          <SCORE-DESCRIPTION>Enquired Entity exists in bureau</SCORE-DESCRIPTION>        </SCORE>        <REMARKS>Flat no 1 street no1 locality 1 city 1 MH 411017</REMARKS>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>BUREAU</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>BUREAU SCORE</SCORE-NAME>          <SCORE-VALUE>100</SCORE-VALUE>          <SCORE-DESCRIPTION>Enquired Entity exists in bureau</SCORE-DESCRIPTION>        </SCORE>        <REMARKS>Yes-Phone-100%-9898989898-from Bureau</REMARKS>        <REMARKS>Yes-Email-100%-testemail@test.com-from Bureau</REMARKS>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>CB SCORE</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>PERFORM-CONSUMER SCORE</SCORE-NAME>          <SCORE-VALUE>826</SCORE-VALUE>          <SCORE-DESCRIPTION>A-Very Low Risk</SCORE-DESCRIPTION>        </SCORE>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>OCCUPATION CLASS</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>OCCUPATION CLASS</SCORE-NAME>          <SCORE-VALUE>A</SCORE-VALUE>          <SCORE-DESCRIPTION>SALARIED</SCORE-DESCRIPTION>        </SCORE>      </REQ-SERVICE>      <REQ-SERVICE>        <REQ-SERVICE-TYPE>INCOME SEGMENT</REQ-SERVICE-TYPE>        <STATUS>YES</STATUS>        <DESCRIPTION>Enquired Entity exists in bureau</DESCRIPTION>        <SCORE>          <SCORE-NAME>INCOME SEGMENT</SCORE-NAME>          <SCORE-VALUE>F</SCORE-VALUE>          <SCORE-DESCRIPTION>Super Affluent (1000000-1500000)</SCORE-DESCRIPTION>        </SCORE>      </REQ-SERVICE>    </REQ-SERVICES>  </REPORT-FILE></FUSION-REPORT-FILE>";

			    DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			    InputSource is = new InputSource();
			    is.setCharacterStream(new StringReader(xmlRecords));
			    Map<String, String> resMap = new HashMap<String,String>();
			    Document doc = db.parse(is);
	    	  
	         System.out.println("Root element :" 
	            + doc.getDocumentElement().getNodeName());
	         NodeList nList = doc.getElementsByTagName("REQ-SERVICE");
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) 
	         {
	            Node nNode = nList.item(temp);
//	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               
	               System.out.println("REQ-SERVICE-TYPE : " + eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent());
//	               System.out.println("SCORE-NAME : " + eElement.getElementsByTagName("SCORE-NAME").item(0).getTextContent());
	               System.out.println("SCORE-VALUE : " + eElement.getElementsByTagName("SCORE-VALUE").item(0).getTextContent());
	               if(temp<5)
	               {
	            	   if(temp==4)
	            	   {
	            		   System.out.println("REMARKS : " + eElement.getElementsByTagName("REMARKS").item(0).getTextContent());
	            		   System.out.println("REMARKS : " + eElement.getElementsByTagName("REMARKS").item(0).getTextContent());
	            	   }
	            	   else
	            	   {
	    	               System.out.println("REMARKS : " + eElement.getElementsByTagName("REMARKS").item(0).getTextContent());
	            	   }
	               }
	               else
	               {
	            	   System.out.println("SCORE-DESCRIPTION : " + eElement.getElementsByTagName("SCORE-DESCRIPTION").item(0).getTextContent()); 
	               }
//	        Storing data in a map
	               
	               resMap.put("REQ-SERVICE-TYPE-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent());
	               resMap.put("STATUS-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("STATUS").item(0).getTextContent());
//	               resMap.put("SCORE-NAME-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-NAME").item(0).getTextContent());
	               resMap.put("SCORE-VALUE-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-VALUE").item(0).getTextContent());
	               if(temp<5)
	               {
	               resMap.put("REMARKS-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("REMARKS").item(0).getTextContent());
	               }
	               else
	               {
	            	   resMap.put("SCORE-DESCRIPTION-"+eElement.getElementsByTagName("REQ-SERVICE-TYPE").item(0).getTextContent()+"",eElement.getElementsByTagName("SCORE-DESCRIPTION").item(0).getTextContent());
	               }
	            }
	            System.out.println("-------------");
	         }
	         System.out.println(resMap);
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }
	
}
