package com.qc.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class FlatFileMaker
{
	private static Logger logger = LogManager.getLogger(FlatFileMaker.class);
	public static void main(String[] args) 
	{

		String request = "{\"fname\": \"Rishabh\",\"mname\": \"\",\"lname\": \"Sharma\",\"dob\": \"26-06-1993\",\"gender\": \"male\",\"email\": \"rishabh.sharma9818@gmail.com\",\"address\": \"ghaziabad\",\"mobileno\": \"9818411217\",\"pan\": \"DYQPS2000P\",\"validationType\": \"PAN\",  \"app_name\": \"TPP\" }";
		String response = "{\"Response\": {\"ResponseInfo\": {\"UserName\": \"\",\"CreationDate\": \"\",\"CreationTime\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"PAN\",\"TransTrackingID\": \"\",\"TransactionData\": {\"status\":\"200\",\"statusDesc\":\"Success\",\"message\":\"Success\",\"pan\":\"AFUPJ7365N\",\"pan_status\":\"Not Matched\",\"dob\":\"16-06-1967\",\"dob_status\":\"Matched\",\"name\":\"NITIN JAIN\",\"name_status\":\"Not Matched\",\"address\":\"B TYPE B 14/7 RAJSARTHI SOCITY INDIRA NAGAR NASHIK NAGPUR MH 422009\",\"address_status\":\"Matched\",\"pinCode\":\"422009\",\"pinCode_status\":\"Matched\",\"mobile\":\"9860685829\",\"mobile_status\":\"Matched\",\"emailID\":\"SHUBHAGIDHANANJAY.JOSHI@GMAIL.COM\",\"emailID_status\":\"Matched\",\"occptnCls\":\"SALARIED\",\"credtScr\":\"600\",\"estmtdIncm\":\"400000-600000\" }";
	}
	public static void generateFlatFile(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
	{

		FileWriter writer = null;
		try 
		{
			sFileName+="panFile_"+new SimpleDateFormat("dd_MM_yyyy").format(Calendar.getInstance().getTime())+".txt";
			File f = new File(sFileName);

			if(f.exists()){
				writer = new FileWriter(sFileName, true);
			}else{
				writer = new FileWriter(sFileName, false);
			}

			String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());

			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write("DATE  : "+timeStamp);
			bufferedWriter.newLine();
			bufferedWriter.write("APP_NAME  : "+appName.toUpperCase());
			bufferedWriter.newLine();
			bufferedWriter.write("SERVICE_PROVIDER : "+serviceName);
			bufferedWriter.newLine();
			bufferedWriter.write("REQUEST--->>>>>>>>>> "+requestJSON);
			bufferedWriter.newLine();
			bufferedWriter.write("RESPONSE--->>>>>>>>> "+responseJSON);
			bufferedWriter.newLine();
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (IOException e) 
		{
			logger.error("We are in Exception : "+e);
		}
		finally
		{
			try
			{
				if(writer!=null)
				{
					writer.close();
				}
				
			}
			catch(Exception ex)
			{
				logger.error("We are in Exception : "+ex);
			}
		}
	}

	
	public static void generateNeoFlatFile(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
	{

		FileWriter writer = null;
		try 
		{
			String requestServiceName= "";
			
			sFileName+="panFile_"+new SimpleDateFormat("dd_MM_yyyy").format(Calendar.getInstance().getTime())+".txt";
			File f = new File(sFileName);

			if(f.exists())
			{
				writer = new FileWriter(sFileName, true);
			}
			else
			{
				writer = new FileWriter(sFileName, false);
			}
			
			String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());

			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write("Credit bureau 2.0 -----");
			bufferedWriter.newLine();
			bufferedWriter.write("DATE  : "+timeStamp);
			bufferedWriter.newLine();
			bufferedWriter.write("Requested Service : "+requestServiceName);
			bufferedWriter.newLine();
			bufferedWriter.write("APP_NAME  : "+appName.toUpperCase());
			bufferedWriter.newLine();
			bufferedWriter.write("SERVICE_PROVIDER : "+serviceName);
			bufferedWriter.newLine();
			bufferedWriter.write("REQUEST -:- "+requestJSON);
			bufferedWriter.newLine();
			bufferedWriter.write("RESPONSE -:- "+responseJSON);
			bufferedWriter.newLine();
			bufferedWriter.newLine();
			bufferedWriter.close();

		} 
		catch (IOException e) 
		{
			logger.error("We are in exception !",e);
		}
		finally
		{
			try
			{
				if(writer!=null)
				{
					writer.close();
				}
				
			}
			catch(Exception ex)
			{
				logger.error("We are in Exception : "+ex);
			}
		}
	}
}
