package com.qc.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MultiFormatDate 
{
	private static final Logger logger = LogManager.getLogger(MultiFormatDate.class);
	public static String getFormattedDate(String dateAsString,String ipFormat,String opFormat) throws ParseException{
		String formattedDate = "";
		SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);//("dd/MM/yyyy hh:mm:ss a");
		Date date = sdf.parse(dateAsString);
		sdf = new SimpleDateFormat(opFormat);//(dd-MMM-yy hh:mm:ss a)
		formattedDate = sdf.format(date);
		return formattedDate;
	}
	
	public static String getSoaFormattedDate(String dateAsString)
	{
		try 
		{
			//String dateAsString="2010-03-16 00:00:00.0";
			String ipFormat="yyyy-MM-dd HH:mm:ss.S";
			String opFormat="yyyy-MM-dd";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(date);
			return formattedDate;
		} 
		catch (ParseException e) 
		{
			logger.info(e);
			return dateAsString;
		}
	}
	
	public static String getSoaMoDobFormattedDate(String dateAsString)
	{
		try 
		{
			//String dateAsString="2010-03-16 00:00:00.0";
			String ipFormat="yyyy-MM-dd HH:mm:ss.S";
			String opFormat="dd-MM-yyyy";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(date);
			return formattedDate;
		} 
		catch (ParseException e) 
		{
			logger.info(e);
			return dateAsString;
		}
	}
	
	public static String getSoaInMiliSecDate(String dateAsString)
	{
		try 
		{
			//String dateAsString="2010-03-16";
			String ipFormat="dd-MMM-yy";
			String opFormat="yyyy-MM-dd HH:mm:ss.S";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(date);
			return formattedDate;
		} 
		catch (ParseException e) 
		{
			logger.info(e);
			return dateAsString;
		}
	}
	
	public static java.sql.Date getSQLDate(String dateAsString)
	{
		try 
		{
			//String dateAsString="30-12-2017";
			String opFormat="dd-MMM-yyyy";
			String ipFormat="dd-MM-yyyy";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			//sdf = new SimpleDateFormat(opFormat);
			//formattedDate = sdf.format(date);
			//System.out.println(formattedDate);
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			
			//sdf = new SimpleDateFormat(opFormat);
			//formattedDate = sdf.format(sqlDate);
			//System.out.println(formattedDate);
			return sqlDate;
		} 
		catch (ParseException e) 
		{
			logger.error("Error While Parsing date so returning null(Required formate is like dd-mm-yyyy i.e. 19-05-2017) : comming date is : "+dateAsString+" Error : "+e);
			return null;
		}
	}
	
	public static void main(String... arr)
	{
		try 
		{
			String dateAsString="30-12-2017";
			String opFormat="dd-MMM-yyyy";
			String ipFormat="dd-MM-yyyy";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(date);
			System.out.println(formattedDate);
			
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(sqlDate);
			System.out.println(formattedDate);
		} 
		catch (ParseException e) 
		{
			e.printStackTrace();
		}
	}
}
