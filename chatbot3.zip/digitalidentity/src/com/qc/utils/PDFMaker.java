package com.qc.utils;


import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFMaker {

	private static Logger logger = LogManager.getLogger(PDFMaker.class);
	public static void main(String[] args) {

		String request = "{\"fname\": \"Rishabh\",\"mname\": \"\",\"lname\": \"Sharma\",\"dob\": \"26-06-1993\",\"gender\": \"male\",\"email\": \"rishabh.sharma9818@gmail.com\",\"address\": \"ghaziabad\",\"mobileno\": \"9818411217\",\"pan\": \"DYQPS2000P\",\"validationType\": \"PAN\",  \"app_name\": \"TPP\" }";
		String response = "{\"Response\": {\"ResponseInfo\": {\"UserName\": \"\",\"CreationDate\": \"\",\"CreationTime\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"ALL\",\"TransTrackingID\": \"\",\"TransactionData\": {\"status\":\"200\",\"statusDesc\":\"Success\",\"message\":\"Success\",\"policyNo\":\"1111111\",\"pan\":\"AFUPJ7365N\",\"pan_status\":\"Not Matched\",\"dob\":\"16-06-1967\",\"dob_status\":\"Matched\",\"name\":\"NITIN JAIN\",\"name_status\":\"Not Matched\",\"address\":\"B TYPE B 14/7 RAJSARTHI SOCITY INDIRA NAGAR NASHIK NAGPUR MH 422009\",\"address_status\":\"Matched\",\"pinCode\":\"422009\",\"pinCode_status\":\"Matched\",\"mobile\":\"9860685829\",\"mobile_status\":\"Matched\",\"emailID\":\"SHUBHAGIDHANANJAY.JOSHI@GMAIL.COM\",\"emailID_status\":\"Matched\",\"occptnCls\":\"SALARIED\",\"credtScr\":\"600\",\"estmtdIncm\":\"400000-600000\" }";
		//		generateFlatFile("C:\\LOGS\\PAN\\", request, response, "TPP");
		//		generateNeoPDF("C:\\LOGS\\PAN\\", request, response, "TPP", "CRIF");
		generateNeoPDF("C:\\LOGS\\PAN\\", request, response, "TPP", "CRIF");

	}

	public static String generateNeoPDF(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
	{
		try 
		{
			responseJSON+=" } }  ]  }  }  }";
			Map responseData=null;
			Map requestData=null;
			responseData=Commons.getGsonData(responseJSON); 
			requestData=Commons.getGsonData(requestJSON); 

			String validationType=(((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
			String policyNo=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("policyNo").toString();
			String name=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("name").toString();
			String name_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("name_status").toString();
			String Dob=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("dob").toString();
			String Dob_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("dob_status").toString();
			String pan=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("pan").toString();
			String pan_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("pan_status").toString();

			//requestJSON
			String requestPostal = (((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("postalCode")).toString().trim();
			String requestMobileno = (((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("mobileno")).toString().trim();
			String requestEmail = (((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("email")).toString().trim();
			String houseNo=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("houseNo")).toString().trim();
			String location=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("street")).toString().trim();
			String street=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("location")).toString().trim();
			String subDistrict=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("subDistrict")).toString().trim();

			String requestAddress = new String();
			requestAddress += (houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			requestAddress += (location.equals("")?"":location+" ");
			requestAddress += (subDistrict.equals("")?"":subDistrict+" ");

			File destDir = new File(sFileName);
			if (!destDir.exists())
	        {
	            destDir.mkdirs();
	        }
			sFileName+="panPDF_"+new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(Calendar.getInstance().getTime())+".pdf";
			
	        
			OutputStream file = new FileOutputStream(new File(sFileName));
			Document document = new Document();
			PdfWriter.getInstance(document, file);

			PdfPTable table=new PdfPTable(3);

			table.addCell(customizedFont("Details"));
			table.addCell(customizedFont("Match (Y/N)"));
			table.addCell(customizedFont("Details as per CB"));
			table.addCell("Proposal Number");
			table.addCell("");
			table.addCell(policyNo);
			table.addCell("Name");
			table.addCell(matchingParser(name_status));
			table.addCell(name);
			table.addCell("DOB");
			table.addCell(matchingParser(Dob_status));
			table.addCell(Dob);
			table.addCell("PAN");
			table.addCell(matchingParser(pan_status));
			table.addCell(pan);
			if(validationType.equalsIgnoreCase("ALL"))
			{
				String address=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("address").toString();
				String address_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("address_status").toString();
				String pincode=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("pinCode").toString();
				String pincode_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("pinCode_status").toString();
				String mobile=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("mobile").toString();
				String mobile_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("mobile_status").toString();
				String emailID=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("emailID").toString();
				String emailID_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("emailID_status").toString();
				String occptnCls=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("occptnCls").toString();
				String credtScr=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("credtScr").toString();
				String estmtdIncm=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("Response")).get("ResponsePayload")).get("Transactions")).get(0)).get("TransactionData")).get("estmtdIncm").toString();

				table.addCell("Address");
				table.addCell(requestAddress);
				table.addCell(address);
				table.addCell("Pincode");
				table.addCell(requestPostal);
				table.addCell(pincode);
				table.addCell("Mobile");
				table.addCell(requestMobileno);
				table.addCell(mobile);
				table.addCell("Email id");
				table.addCell(requestEmail);
				table.addCell(emailID);
				table.addCell("Occupation Class");
				table.addCell("");
				table.addCell(occptnCls);
				table.addCell("Credit Score");
				table.addCell("");
				table.addCell(credtScr);
				table.addCell("Estimated Income");
				table.addCell("");
				table.addCell(estmtdIncm);
			}

			document.open();//PDF document opened........			       

			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("Document Generated On - "+new Date().toString()));
			document.add(new Paragraph("-  CREDIT BUREAU 2.0  -"));
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("APP NAME : "+appName));
			document.add(new Paragraph("Response From : "+serviceName));
			document.add(Chunk.NEWLINE);
			document.add(table);
			document.add(Chunk.NEWLINE);   			    

			document.close();

			file.close();

		} 
		catch (Exception e)
		{
			logger.error("We are in exception while making PDF : "+e);
		}
		return sFileName;
	}


	public static String generateNeoPDFV3(String sFileName, String requestJSON, String responseJSON, String appName, String serviceName)
	{
		try 
		{
			responseJSON+="    } ]  }  }  }";
			Map responseData=null;
			Map requestData=null;
			responseData=Commons.getGsonData(responseJSON); 
			requestData=Commons.getGsonData(requestJSON); 
			List<Map> policyDetails = new ArrayList<Map>();
			List<String> policyNo = new ArrayList<>();
			policyDetails = ((List)((Map) ((List) ((Map) ((Map) responseData.get("response")).get("payload"))
					.get("transactions")).get(0)).get("policyDetails"));
			for(Map policyno : policyDetails)
			{
				if(policyno!=null && policyno.containsKey("policyNo"))
				{
					policyNo.add(policyno.get("policyNo").toString());
				}
			}
			

			String validationType=(((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("validationType")).toString();
			
			/*String policyNo=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("policyNo").toString();*/
			
			String name=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("name").toString();
			String name_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("name_status").toString();
			String Dob=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("dob").toString();
			String Dob_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("dob_status").toString();
			String pan=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("pan").toString();
			String pan_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("pan_status").toString();

			//requestJSON
			String requestPostal = (((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("postalCode")).toString().trim();
			String requestMobileno = (((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("mobileNo")).toString().trim();
			String requestEmail = (((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("email")).toString().trim();
			String houseNo=(((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("houseNo")).toString().trim();
			String location=(((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("street")).toString().trim();
			String street=(((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("location")).toString().trim();
			String subDistrict=(((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("subDistrict")).toString().trim();

			String requestAddress = new String();
			requestAddress += (houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			requestAddress += (location.equals("")?"":location+" ");
			requestAddress += (subDistrict.equals("")?"":subDistrict+" ");

			File destDir = new File(sFileName);
			if (!destDir.exists())
	        {
	            destDir.mkdirs();
	        }
			sFileName+="panPDF_"+new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(Calendar.getInstance().getTime())+".pdf";
			
	        
			OutputStream file = new FileOutputStream(new File(sFileName));
			Document document = new Document();
			PdfWriter.getInstance(document, file);

			PdfPTable table=new PdfPTable(3);

			table.addCell(customizedFont("Details"));
			table.addCell(customizedFont("Match (Y/N)"));
			table.addCell(customizedFont("Details as per CB"));
			table.addCell("Proposal Number");
			table.addCell("");
			table.addCell(policyNo.get(0));
			table.addCell("Name");
			table.addCell(matchingParser(name_status));
			table.addCell(name);
			table.addCell("DOB");
			table.addCell(matchingParser(Dob_status));
			table.addCell(Dob);
			table.addCell("PAN");
			table.addCell(matchingParser(pan_status));
			table.addCell(pan);
			if(validationType.equalsIgnoreCase("ALL"))
			{
				/*String address=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("address").toString();
				String address_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("address_status").toString();
				String pincode=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("pinCode").toString();
				String pincode_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("pinCode_status").toString();
				String mobile=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("mobile").toString();
				String mobile_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("mobile_status").toString();
				String emailID=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("emailID").toString();
				String emailID_status=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("emailID_status").toString();
				String occptnCls=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("occptnCls").toString();
				String credtScr=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("credtScr").toString();
				String estmtdIncm=((Map)(Map)((Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("transactionData ")).get("estmtdIncm").toString();*/

				String address=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("address").toString();
				String address_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("address_status").toString();
				String pincode=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("pinCode").toString();
				String pincode_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("pinCode_status").toString();
				String mobile=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("mobile").toString();
				String mobile_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("mobile_status").toString();
				String emailID=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("emailID").toString();
				String emailID_status=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("emailID_status").toString();
				String occptnCls=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("occptnCls").toString();
				String credtScr=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("credtScr").toString();
				String estmtdIncm=((Map)(Map)((List)((Map)((Map)responseData.get("response")).get("payload")).get("transactions")).get(0)).get("estmtdIncm").toString();
				
				table.addCell("Address");
				table.addCell(requestAddress);
				table.addCell(address);
				table.addCell("Pincode");
				table.addCell(requestPostal);
				table.addCell(pincode);
				table.addCell("Mobile");
				table.addCell(requestMobileno);
				table.addCell(mobile);
				table.addCell("Email id");
				table.addCell(requestEmail);
				table.addCell(emailID);
				table.addCell("Occupation Class");
				table.addCell("");
				table.addCell(occptnCls);
				table.addCell("Credit Score");
				table.addCell("");
				table.addCell(credtScr);
				table.addCell("Estimated Income");
				table.addCell("");
				table.addCell(estmtdIncm);
			}

			document.open();//PDF document opened........			       

			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("Document Generated On - "+new Date().toString()));
			document.add(new Paragraph("-  CREDIT BUREAU 2.0  -"));
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("APP NAME : "+appName));
			document.add(new Paragraph("Response From : "+serviceName));
			document.add(Chunk.NEWLINE);
			document.add(table);
			document.add(Chunk.NEWLINE);   			    

			document.close();

			file.close();

		} 
		catch (Exception e)
		{
			logger.error("We are in exception while making PDF : "+e);
		}
		return sFileName;
	}
	
	public static String matchingParser(String status)
	{
		String matcher ="";
		if(status.equalsIgnoreCase("Matched"))
		{
			matcher="Y";
		}
		else
		{
			matcher="N";
		}
		return matcher;
	}

	public static PdfPCell customizedFont(String rawData)
	{
		Paragraph para = new Paragraph(rawData);
		PdfPCell cell = new PdfPCell ();
		Font font = new Font(FontFamily.TIMES_ROMAN, 14, Font.BOLD);
		para.setFont(font);
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.addElement(para);

		return cell;
	}


}
