package com.qc.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {

	public Date getStringToDate(String date)
	{
		Date curDate=null;
		SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		try{
			
			
			curDate = df.parse(date);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return curDate;
	}
	
	public Date getSqlDateFromString(String stringDate){
		        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
		        Date parsed = null;
				try {
					parsed = format.parse(stringDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        java.sql.Date sqlDate = new java.sql.Date(parsed.getTime());
		    return sqlDate;	   
	}
	
	public static void main(String[] args) {
		String startDate="12-OCT-2014";
		Date dated=new Utility().getSqlDateFromString(startDate);
		   SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
		   java.util.Date date = null;
		try {
			date = sdf1.parse(startDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   java.sql.Date sqlStartDate = (java.sql.Date) new Date(date.getTime()); 
	}
}
