package com.qc.serviceImpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.qc.api.request.elasticsearch.ApiRequestElasticSearch;
import com.qc.api.response.StringConstants;
import com.qc.api.response.elasticsearch.ApiResponseElasticSearch;
import com.qc.api.response.elasticsearch.MsgInfo;
import com.qc.api.response.elasticsearch.ResponseElasticSearch;
import com.qc.service.ElasticSearchService;
import com.qc.utils.Commons;
import com.qc.utils.XTrustProvider;

@Service
public class ElasticSearchServiceImpl implements ElasticSearchService
{
	private static Logger logger = LogManager.getLogger(ElasticSearchServiceImpl.class);
	
	@Override
	public ApiResponseElasticSearch generateSearch(ApiRequestElasticSearch apiRequest) {
		logger.info("generateSearch service : Start");
		
		String output = new String();
		StringBuilder result = new StringBuilder();
		StringBuilder resultURL = new StringBuilder();
		
		String index=apiRequest.getRequest().getRequestData().getIndex();
		String type=apiRequest.getRequest().getRequestData().getType();
		String headerSearch=apiRequest.getRequest().getHeader().getSearchVar();
		headerSearch=headerSearch.replaceAll(" ", "%20");
		
		MsgInfo msginfo = new MsgInfo();
		ResponseElasticSearch response = new ResponseElasticSearch();
		ApiResponseElasticSearch apiResponse =new ApiResponseElasticSearch();
		
		ResourceBundle res = ResourceBundle.getBundle("application");
		
		HttpURLConnection conn = null;
		String DevMode = "N";
		JSONObject object=null;
		Map<String, Object> transData=null;
		try 
		{
		XTrustProvider trustProvider = new XTrustProvider();
		trustProvider.install();
		String serviceurl = res.getString("elasticService");
		if(null!=type && !(type.isEmpty())){
		result.append("/"+index+"/"+type+"/"+headerSearch);
		}
		else{
			result.append("/"+index+"/"+headerSearch);
		}
		String urll=serviceurl.concat(result.toString());

		URL url = new URL(urll);
		if (DevMode != null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode)) {
			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			conn = (HttpURLConnection) url.openConnection(proxy);
		} else {
			conn = (HttpURLConnection) url.openConnection();
		}
		conn.setDoInput(true);
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setUseCaches(false);
		conn.setAllowUserInteraction(true);
		conn.connect();
		
		int apiResponseCode = conn.getResponseCode();
		
		if (apiResponseCode == 200) 
		{
			try{
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			while ((output = br.readLine()) != null) {
				resultURL.append(output);
			}
			conn.disconnect();
			br.close();
			object = new JSONObject(resultURL.toString());
			transData=Commons.getGsonData(object.toString());
			if(object != null){
				response.setResponseData(transData);
				msginfo.setMsgCode(StringConstants.C200);
				msginfo.setMsg(StringConstants.SUCCESS);
				msginfo.setMsgDescription(StringConstants.C200DESC);
				logger.info(StringConstants.C200DESC);
			}
			}
			catch (Exception e) {
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C601DESC);
				logger.info(StringConstants.C601DESC);
				logger.error("json conversion have some error : "+e);
			}	
		}else
		{
			msginfo.setMsgCode(StringConstants.C601);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C601DESC);
			logger.info(StringConstants.C601DESC);
		}
		
		}
		catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		
		response.setMsgInfo(msginfo);
		response.setResponseData(transData);
		
		apiResponse.setResponse(response);
		logger.info("generateSearch  service : End");
		return apiResponse;
	}

}
