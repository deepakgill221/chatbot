package com.qc.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.qc.service.ObjectToPojoService;

@Service
public class ObjectToPojoServiceImpl implements ObjectToPojoService
{
	@Override
	public List<Map<String , String>> getCustomClass(List<Object[]> objectList) 
	{
		List<Map<String , String>> pojoList = new ArrayList<>();
		if(objectList != null && objectList.size()>0)
		{
			try
			{

				for( Object[] obj : objectList)
				{
					int key = 0;	
					Map<String , String> hashMap = new HashMap<>();
					for(Object oo : obj)
					{
						hashMap.put("key"+key, (oo == null || oo == "")?"":oo.toString().trim());
						key++;
					}
					pojoList.add(hashMap);	
				}
			}
			catch(ClassCastException ce)
			{
				int key = 0;	
				Map<String , String> hashMap = new HashMap<>();
				for(Object oo : objectList)
				{
					hashMap.put("key"+key, (oo == null || oo == "")?"":oo.toString().trim());
					key++;
				}
				pojoList.add(hashMap);	
			}
		}
		return pojoList;
	}
}
