package com.qc.serviceImpl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.db.dao.CreditBureauReportDBDao;
import com.qc.dto.CreditBureauTrackerDTO;
import com.qc.dto.CrifRequestResponseTrackerDTO;
import com.qc.entity.CreditBureauReportEntity;
import com.qc.service.CreditBureauV2ApiService;
import com.qc.service.ExternalServices;
import com.qc.utils.Base64ArrayUtility;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;
import com.qc.utils.ObjectFactory;
import com.qc.utils.PDFMaker;

@Service
public class CreditBureauV2ApiServiceImpl implements CreditBureauV2ApiService{

	private static Logger logger = LogManager.getLogger(CreditBureauV2ApiServiceImpl.class);
	@Autowired
	CreditBureauReportDBDao creditBureauReportDBDao; 

	@Override
	public String getCbV2ActionRequest(final String requestJson, Environment env,Map requestData) 
	{
		String PRIORITY=env.getProperty("com.qualtech.pan2.resource.priority");
		String CRIF_STATUS=env.getProperty("com.qualtech.pan2.resource.CRIF.status");
		String EQUIFAX_STATUS=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.status");
		String FLAT_FILE_PATH=env.getProperty("flatFilePath");
		String flatFileMessage="";
		String methodName = null;
		String serviceName = null;
		String app_name = "";
		String responseString = "";
		methodName = Commons.getMethodName();
		ObjectFactory of = new ObjectFactory();
		Map<String, String> responseMap = null;
		CreditBureauTrackerDTO cbTrackerDTO = new CreditBureauTrackerDTO();
		List<CrifRequestResponseTrackerDTO> crifEqifaxInnerData = new ArrayList<CrifRequestResponseTrackerDTO>();
		String correlationId = new String();
		final String outerTrackingId = ""+System.currentTimeMillis();
		String ValidationType="";
		String policyNo="";
		try 
		{
			if (requestData != null) 
			{
				try
				{
					correlationId = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
							.get("Transactions")).get(0)).get("TransTrackingID")).toString();
				}
				catch(Exception e)
				{
					logger.error("Exception occured in getting Correlation Id",e);
				}
				ValidationType = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("ValidationType")).toString();
				String fname = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("fname")).toString();
				String dob = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("dob")).toString();
				String pan = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("pan")).toString();
				app_name = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("app_name")).toString();
				policyNo = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("RequestPayload"))
						.get("Transactions")).get(0)).get("policyNo")).toString();

				responseString += "{\"Response\": {";
				responseString += "\"ResponseInfo\": {";
				responseString += "\"UserName\": \"\",";
				responseString += "\"CreationDate\": \"\",";
				responseString += "\"CreationTime\": \"\",";
				responseString += "\"SourceInfoName\":\"\",";
				responseString += "\"RequestorToken\": \"\",";
				responseString += "\"UserEmail\": \"\",";
				responseString += "\"LastSyncDateTime\": \"\"";
				responseString += "},";
				responseString += "\"ResponsePayload\": {";
				responseString += "\"Transactions\": [";
				responseString += "{";
				responseString += "\"Key1\":\"\",";
				responseString += "\"Key2\": \"\",";
				responseString += "\"Key3\": \"\",";
				responseString += "\"Key4\": \"\",";
				responseString += "\"Key5\": \"\",";
				responseString += "\"ValidationType\": \"" + ValidationType + "\",";
				responseString += "\"TransTrackingID\": \"\",";
				responseString += "\"TransactionData\": ";

				if (ValidationType != null && !ValidationType.equalsIgnoreCase("")	
						&& ( ValidationType.equalsIgnoreCase("ALL")	|| ValidationType.equalsIgnoreCase("PANDOB") )
						&& fname != null 	&& !fname.equalsIgnoreCase("") 
						&& dob != null 		&& !dob.equalsIgnoreCase("") 
						&& pan != null 		&& !pan.equalsIgnoreCase("") 
						&& app_name != null	&& !app_name.equalsIgnoreCase("") 
					)
				{
					logger.debug("All validation Passed");
					try
					{
						String priority = PRIORITY; 
						String[] Arr = priority.split(",");
						logger.info("Calling Webservice Start");
						for (String itr : Arr)
						{
							String serviceStatus = "";
							if (itr != null && itr.equalsIgnoreCase("CRIF")) 
							{
								logger.info("Calling : "+itr+" : Status : "+CRIF_STATUS);
								serviceStatus = CRIF_STATUS;
							} 
							else if (itr != null && itr.equalsIgnoreCase("EQUIFAX_2.0")) 
							{
								logger.info("Calling : "+itr+" : Status : "+EQUIFAX_STATUS);
								serviceStatus = EQUIFAX_STATUS;
							}
							serviceName = itr;
							logger.info("Calling Webservice Of : " + itr);
							if (serviceStatus.equalsIgnoreCase("TRUE"))
							{
								ExternalServices extServices = of.getService(itr);
								responseMap = extServices.callNeoService(requestData,env,cbTrackerDTO,crifEqifaxInnerData);
								logger.info("FULLY CALCULATED Response From ITR SERVICE " + itr + " (ALL SERVICE) ::: "+ responseMap);
								if (responseMap != null)
								{
									logger.info(" Calling Webservice Of : " + itr+ " Completed Successfully with Response");
									break;
								} 
								else 
								{
									if (itr.equalsIgnoreCase("CRIF"))
									{
										try 
										{
											flatFileMessage="ResponseMap is NULL From Criff -:- Incomplete Data found or Error while parsing error code from CB Service -:- ";
											logger.info(flatFileMessage);
										}
										catch (Exception e) 
										{
											logger.error("ErrorInfo while Creating Flat File inside " + methodName + "()" + e);
										}
									}
								}
							}
						}
						logger.info("Calling Webservice End");
						if (responseMap != null)
						{
							if (ValidationType.equalsIgnoreCase("ALL")) 
							{
								logger.info("Response generation Start : ALL");
								responseString += "{\"status\":\"200\",";
								responseString += "\"statusDesc\":\"Success\",";
								responseString += "\"message\":\"Success\",";
								responseString += "\"policyNo\":\"" + policyNo + "\",";
								responseString += "\"pan\":\"" + responseMap.get("PAN") + "\",";
								responseString += "\"pan_status\":\"" + responseMap.get("PAN_STATUS") + "\",";
								responseString += "\"dob\":\"" + responseMap.get("DOB") + "\",";
								responseString += "\"dob_status\":\"" + responseMap.get("DOB_STATUS") + "\",";
								responseString += "\"name\":\"" + responseMap.get("NAME") + "\",";
								responseString += "\"name_status\":\"" + responseMap.get("NAME_STATUS") + "\",";
								responseString += "\"address\":\"" + responseMap.get("ADDRESS") + "\",";
								responseString += "\"address_status\":\"" + responseMap.get("ADDRESS_STATUS") + "\",";
								responseString += "\"pinCode\":\"" + responseMap.get("PINCODE") + "\",";
								responseString += "\"pinCode_status\":\"" + responseMap.get("PINCODE_STATUS") + "\",";
								responseString += "\"mobile\":\"" + responseMap.get("MOBILE") + "\",";
								responseString += "\"mobile_status\":\"" + responseMap.get("MOBILE_STATUS") + "\",";
								responseString += "\"emailID\":\"" + responseMap.get("EMAIL") + "\",";
								responseString += "\"emailID_status\":\"" + responseMap.get("EMAIL_STATUS") + "\",";
								responseString += "\"occptnCls\":\"" + responseMap.get("OCCPTNCLS") + "\",";
								responseString += "\"credtScr\":\"" + responseMap.get("CREDITSCR") + "\",";
								responseString += "\"estmtdIncm\":\"" + responseMap.get("ESTMTDINCM") + "\"";
								responseString += ",\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, app_name, serviceName,cbTrackerDTO) + "\"";
								responseString += " }";
								logger.info("Response generation End : ALL");
							}
							else if (ValidationType.equalsIgnoreCase("PANDOB"))
							{
								logger.info("Response generation Start : PANDOB");
								responseString += "{\"status\":\"200\",";
								responseString += "\"statusDesc\":\"Success\",";
								responseString += "\"message\":\"Success\",";
								responseString += "\"policyNo\":\"" + policyNo + "\",";
								responseString += "\"pan\":\"" + responseMap.get("PAN") + "\",";
								responseString += "\"pan_status\":\"" + responseMap.get("PAN_STATUS") + "\",";
								responseString += "\"dob\":\"" + responseMap.get("DOB") + "\",";
								responseString += "\"dob_status\":\"" + responseMap.get("DOB_STATUS") + "\",";
								responseString += "\"name\":\"" + responseMap.get("NAME") + "\",";
								responseString += "\"name_status\":\"" + responseMap.get("NAME_STATUS") + "\"";
								responseString += ",\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, app_name, serviceName,cbTrackerDTO) + "\"";
								responseString += " }";
								logger.info("Response generation End : PANDOB");
							}
						} 
						else 
						{
							responseString += "{\"status\":\"101\", \"statusDesc\":\"Failure\", \"message\":\"There is some error in calling webservice.\"}";
							logger.info(flatFileMessage+"something happens wrong while getting data from CB Service");
						}
					}
					catch (Exception e) 
					{
						responseString += "{\"status\":\"101\",\"statusDesc\":\"Failure\",\"message\":\"There is some error in calling webservice\"}";
						logger.error("There is some Exception while processing CB Calling Process : "+e);
					}
				}
				else 
				{
					// Invalid Request Json
					responseString += "{\"status\":\"102\",\"statusDesc\":\"Failure\",\"message\":\"Invalid Request Json\"}";
					logger.info("Validation Check fail : no need to call CB service");
				}
			}
			else 
			{
				// Invalid Request Json
				responseString += "{\"status\":\"102\",\"statusDesc\":\"Failure\",\"message\":\"Invalid Request Json\"}";
				logger.info("Request Json is null : Unable to process CB service calling");
			}
		} 
		catch (Exception e)
		{
			responseString += "{\"Response\": {\"ResponseInfo\": {\"UserName\": \"\",\"CreationDate\": \"\",\"CreationTime\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"\",\"TransTrackingID\": \"\",\"TransactionData\": ";
			responseString += "{\"status\":\"102\",\"statusDesc\":\"Failure\",\"message\":\"Invalid Request Json\"}";
			logger.error("Request Json contains invalid key : We are in exception while fetching value from request Json : " + e);
		}
		try 
		{
			logger.info("Flat file Creation : Start");
			String sFileName = FLAT_FILE_PATH;
			FlatFileMaker.generateNeoFlatFile(sFileName, requestJson, flatFileMessage+responseString, app_name, serviceName);
			logger.info("Flat file Creation : End");
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo while Creating Flat File inside " + methodName + "()" + e);
		}
		responseString += " }  ]  }  }  }";
		logger.info("Response Json generation completed");
		
		/*
		 * Inserting all api request,response and credit bureau 2.0 (CRIF AND EQUIFAX) api request and response in DB
		 */
		try 
		{
			final String crifResponseJson = responseString;
			final String correlationIdNew = correlationId;
			final String policyNoNew = policyNo;
			final String serviceTypeNew = ValidationType;
			new Thread(new Runnable() 
			{
			    public void run() 
			    {
			    	runningBackgroundProcess(requestJson,crifResponseJson,correlationIdNew,outerTrackingId,cbTrackerDTO,policyNoNew,serviceTypeNew);
			    }
			}).start();
		} 
		catch (Exception e) 
		{
			logger.error("We get exception while setting data in DB : "+e);
		}
		
		logger.info(" Going outside " + methodName + "().");
		return responseString;
	}

	public void runningBackgroundProcess(String requestJson,String crifResponseJson,
			String correlationId,String outerTrackingId,CreditBureauTrackerDTO cbTrackerDTO,String policyNoNew,String serviceTypeNew)
	{
		logger.info("Running background process to save crif data!!");
		InetAddress ip = null;
        String hostname = null;
        try
        {
            ip = InetAddress.getLocalHost();
            hostname = ip.getHostName();
        }
        catch (UnknownHostException e)
        {
        	logger.error("We are in exception : "+e);
        }
		try
		{
			int pdfGenerated=0;
			for(CrifRequestResponseTrackerDTO crifData : cbTrackerDTO.getCrifv2RetryData())
			{
				CreditBureauReportEntity entity = new CreditBureauReportEntity();
				Long sequenceId = creditBureauReportDBDao.getSequenceValue();
				entity.setId(Long.parseLong(""+sequenceId));
				entity.setCorrelationId(correlationId);
				entity.setApiRequestJson((requestJson != null && !requestJson.isEmpty()) ? requestJson : "");
				entity.setApiResponseJson((crifResponseJson != null && !crifResponseJson.isEmpty())? crifResponseJson : "");
				entity.setRemark("credit bureau service");
				entity.setServerIpAddress(""+ip);
				entity.setServerHostName(hostname);
				entity.setOuterTrackerId(outerTrackingId);
				entity.setPolicyNo(policyNoNew);
				entity.setServiceType(serviceTypeNew);
				if(cbTrackerDTO != null)
				{
					entity.setCbVersion(cbTrackerDTO.getCbVersion());
					entity.setCbServiceProvider(cbTrackerDTO.getCbServiceProvider());
					if(pdfGenerated == (cbTrackerDTO.getCrifv2RetryData().size()-1))
					{
						entity.setPdfByteArray((cbTrackerDTO.getPdfByte() != null && !cbTrackerDTO.getPdfByte().isEmpty()) ? cbTrackerDTO.getPdfByte() : "");
						entity.setIsPdfGenerated((cbTrackerDTO.isPdfGenerated()==true)?"Y":"N");
					}
					pdfGenerated++;
				}
				if(crifData != null)
				{
					entity.setProviderApiRequest((crifData.getCrifRequestXml() != null && !crifData.getCrifRequestXml().isEmpty()) ? crifData.getCrifRequestXml() : "");
					entity.setProviderApiResponse((crifData.getCrifResponseXml() != null && !crifData.getCrifResponseXml().isEmpty()) ? crifData.getCrifResponseXml() : "");
					entity.setInnerTrackerId(crifData.getInnerTrackId());
					entity.setCreatedTime(crifData.getStartDate());
					entity.setUpdatedTime(crifData.getEndDate());
					entity.setProviderStatusCode(crifData.getProviderStatusCode());
				}
				try
				{
					creditBureauReportDBDao.saveCreditBureauReport(entity);
				}
				catch(Exception e)
				{
					logger.info("Exception occured while crif/equfax api data saving for tracking !!",e);
					logger.info("Now attempting to insert data in Catch Block!! !!",e);
					try
					{
						if(crifData != null)
						{
							entity.setProviderApiRequest("No Data Found ");
							entity.setProviderApiResponse("No Data Found ");
							entity.setInnerTrackerId(crifData.getInnerTrackId());
							entity.setCreatedTime(crifData.getStartDate());
							entity.setUpdatedTime(crifData.getEndDate());
						}
						creditBureauReportDBDao.saveCreditBureauReport(entity);
					}
					catch (Exception e2) 
					{
						logger.info("Exception occured again while crif/equfax api data saving for tracking !!",e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception occured while saving crif data to DB!! "+e);
		}
	}


	private String getPdfByteArrayString(String responseString, String FLAT_FILE_PATH,
			String requestJson, String app_name, String serviceName ,CreditBureauTrackerDTO cbTrackerDTO)
	{
		try
		{
			if (responseString.contains("200")) 
			{
				String sFileName = FLAT_FILE_PATH;
				String path = PDFMaker.generateNeoPDF(sFileName, requestJson, responseString, app_name, serviceName);
				String bFile = new Base64ArrayUtility().encodeToString(path, false);
				/*
				 * Updating crif request response to credit bureau tracker
				 * Starts
				 */
				cbTrackerDTO.setPdfByte(""+bFile.toString().trim());
				cbTrackerDTO.setPdfGenerated(true);
				/*
				 * Updating crif request response to credit bureau tracker
				 * Ends
				 */				
				return bFile.toString().trim();
			}
		}
		catch(Exception ex)
		{
			logger.error("We are in Exception "+ex);
		}
		return "";
	}

}
