package com.qc.serviceImpl;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.qc.entity.PerfiosEntity;
import com.qc.entity.PerfiosReportEntity;
import com.qc.utils.CommonPerfios;
import com.qc.utils.ConvertPDFToByteArray;
import com.qc.utils.UnzipUtility;
import com.qc.utils.XTrustProvider;

@Service
@PropertySource({ "classpath:application.properties" })
public class PerfiosServiceImpl implements com.qc.service.PerfiosService 
{
	private static Logger logger = LogManager.getLogger(PerfiosServiceImpl.class);

	private static final int BUFFER_SIZE = 9999999;

	@Autowired
	Environment env;
	//	@Value("${com.perfios.merged.filelocation}")
	//	String perfiosMergedFileLocation;
	//	@Value("$(com.perfios.zipfile.downloadlocation)")
	//	String perfiosZipDownloadLocation;
	final long TIME_IN_MILLI_SEC = System.currentTimeMillis();


	@Override
	public PerfiosEntity getStartProcessData(PerfiosEntity perfiosEntity) 
	{
		try 
		{
			logger.info("Getting HTML Content Process : Start");
			String htmlContent = CommonPerfios.perfiosDataStartProcess(perfiosEntity,1);
			perfiosEntity.setStartProcessHtml(htmlContent);
			logger.info("Getting HTML Content Process : End : "+htmlContent);
		} 
		catch (Exception e) 
		{
			logger.error("We are in Exception : "+e);
		}
		return perfiosEntity;
	}

	@Override
	public PerfiosEntity getTransactionStatus(PerfiosEntity perfiosEntity,
			PerfiosReportEntity perfiosReportEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting TransactionStatus Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosTransactionData(perfiosEntity);
			String pUrl = perfiosEntity.getTxnStatusUrl();
			logger.info("URL : "+pUrl);
			logger.debug("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			perfiosReportEntity.setProviderApiRequest(perfiosRequest);
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			//For perfios tracking Starts
			perfiosReportEntity.setProviderStatusCode(""+apiResponseCode);
			//For perfios tracking Ends
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Starts
				 */
				perfiosReportEntity.setProviderApiResponse(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Ends
				 */
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling START_PERFIOS_SERVICE_REQUEST_ACTION ::",e);
		}
		return perfiosEntity;
	}

	@Override
	public PerfiosEntity getRetrieveReport(PerfiosEntity perfiosEntity,
			PerfiosReportEntity perfiosReportEntity) 
	{
		final long TIME_IN_MILLI_SEC = System.currentTimeMillis();
		//String tempFileName = perfiosMergedFileLocation+"_"+TIME_IN_MILLI_SEC+".pdf";
//		String originalFileToBeSend = env.getProperty("com.perfios.temp.filelocation")+"_"+TIME_IN_MILLI_SEC+".pdf";

		String output = new String();
		String mergedPdfByteArray = new String();
		StringBuilder result = new StringBuilder();
		ConvertPDFToByteArray convertPDFToByteArray = new ConvertPDFToByteArray();
		StringBuilder xmlByte = new StringBuilder();
		try 
		{
			logger.info("Getting RetrieveReport Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosDataRetrieveStatement(perfiosEntity);
			String pUrl = perfiosEntity.getRetriveUrl();
			logger.info("URL : "+pUrl);
			logger.debug("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			perfiosReportEntity.setProviderApiRequest(perfiosRequest);
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			//For perfios tracking Starts
			perfiosReportEntity.setProviderStatusCode(""+apiResponseCode);
			//For perfios tracking Ends
			if(apiResponseCode == 200)
			{
				String fileName = "";
				String disposition = conn.getHeaderField("Content-Disposition");
				String contentType = conn.getContentType();
				int contentLength = conn.getContentLength();
				if (disposition != null) {
					int index = disposition.indexOf("filename=");
					if (index > 0) {
						fileName = disposition.substring(index + 9,disposition.length());
					}
				} 
				logger.info("Perfios zip File Name : " + fileName);
				// opens input stream from the HTTP connection
				InputStream inputStream = conn.getInputStream();
				
				String zipFilePath = env.getProperty("com.perfios.temp.filelocation") + fileName;
				logger.info("Perfios Zip File downloaded : File Location : "+zipFilePath);

				String unZipLocation = zipFilePath.substring(0,zipFilePath.length()-4) + File.separator+TIME_IN_MILLI_SEC;
				logger.info("Perfios UnZip File : unZipLocation : "+unZipLocation);
				
				// opens an output stream to save into file
				FileOutputStream outputStream = new FileOutputStream(zipFilePath);
				int bytesRead = -1;
				byte[] buffer = new byte[BUFFER_SIZE];
				while ((bytesRead = inputStream.read(buffer)) != -1)
				{
					outputStream.write(buffer, 0, bytesRead);
				}
				
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Starts
				 */
				try
				{
					perfiosReportEntity.setProviderApiResponse(new String(buffer));
					perfiosReportEntity.setIsPdfGenerated("N");//Initial Set to NOT Generated
					
				}catch(Exception e){
					logger.error("Exception while traversing for perfios traking  ");
				}
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Ends
				 */	
				
				outputStream.close();
				inputStream.close();
				conn.disconnect();
				try
				{
					UnzipUtility unzipper = new UnzipUtility();
					try 
					{
						unzipper.unzip(zipFilePath, unZipLocation);
					} 
					catch (Exception ex) 
					{
						logger.error(ex);
					}

					List<String> listString = new ArrayList<>();
					try(Stream<Path> paths = Files.walk(Paths.get(unZipLocation))) 
					{
						paths.forEach(filePath -> {
							if (Files.isRegularFile(filePath))
							{
								//logger.info("filePath : "+filePath);
								listString.add(filePath.toString());
							}
						});
					}
					//List<InputStream> list = new ArrayList<InputStream>();
					try
					{
						xmlByte.append("<byteArrays>");
						for(String path : listString)
						{
							//list.add(new FileInputStream(new File(path)));
							xmlByte.append("<byteArray>"+ convertPDFToByteArray.pdfByteCaller(path)+"</byteArray>");
							//listOfFileWithByteArray.add(convertPDFToByteArray.pdfByteCaller(path));
							perfiosReportEntity.setIsPdfGenerated("Y");
						}
						xmlByte.append("</byteArrays>");
						//OutputStream out = new FileOutputStream(new File(originalFileToBeSend));
						//doMerge(list, out);
						logger.debug("ByteArray Xml :"+xmlByte.toString());
					}
					catch (FileNotFoundException e)
					{
						logger.error("Exception occured while processing files ! "+e);
					}
					catch (IOException e) 
					{
						logger.error("Exception occured while processing files ! "+e);
					}
					catch (Exception e)
					{
						logger.error("Exception occured while processing files ! "+e);
					}
				}
				catch (Exception e) 
				{
					logger.error("Exception"+e);
				}
				//logger.info("perfiosMergedFileLocation :"+originalFileToBeSend);
				//mergedPdfByteArray = convertPDFToByteArray.pdfByteCaller(originalFileToBeSend);
				//setting in response xml
			//	perfiosEntity.setResponseXML("<response><status>Success</status><statusCode>200</statusCode><byteArray>"+mergedPdfByteArray+"</byteArray></response>");
				perfiosEntity.setResponseXML("<response><status>Success</status><statusCode>200</statusCode>"+xmlByte.toString()+"</response>");
				logger.debug("PerfiosAPI MergedPdfByteArray :: "+mergedPdfByteArray); 
				
				if(env.getProperty("com.perfios.temp.filelocation.data.delete").equalsIgnoreCase("Y"))
				{
					try
					{
						//File file = new File(unZipLocation);
						//file.delete();
						FileUtils.deleteDirectory(new File(unZipLocation.substring(0, unZipLocation.lastIndexOf(File.separator))));
					}
					catch(Exception ex)
					{
						logger.error("ErrorInfo while trying to delete ZIP Extracted Folder : "+ex);
					}
					
					try
					{
						File file = new File(zipFilePath);
						file.delete();
					}
					catch(Exception ex)
					{
						logger.error("ErrorInfo while trying to delete ZIP Extracted Folder : "+ex);
					}
					
//					try
//					{
//						//Code for deleting file
//						File file = new File(originalFileToBeSend);
//						file.delete();
//					}
//					catch (Exception e) 
//					{
//						logger.error("ErrorInfo While Deleting Temp File ::",e);
//					}
				}
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling RetrieveReport Perfios ::",e);
		}
		finally
		{

		}
		logger.info("Getting RetrieveReport Process : END");
		return perfiosEntity;
	}

	public static void doMerge(List<InputStream> list, OutputStream outputStream)
	{
		try
		{
			Document document = new Document();
			PdfWriter writer = PdfWriter.getInstance(document, outputStream);
			document.open();
			PdfContentByte cb = writer.getDirectContent();

			for (InputStream in : list) 
			{
				PdfReader reader = new PdfReader(in);
				//reader.unethicalreading = true;
				//reader.isEncrypted();

				reader = unlockPdf(reader);

				for (int i = 1; i <= reader.getNumberOfPages(); i++)
				{
					document.newPage();
					//import the page from source pdf
					PdfImportedPage page = writer.getImportedPage(reader, i);
					//add the page to the destination pdf
					cb.addTemplate(page, 0, 0);
				}
			}
			outputStream.flush();
			document.close();
			outputStream.close();
		}
		catch(DocumentException e)
		{
			System.out.println("e :"+e);
		}
		catch(IOException e1)
		{
			System.out.println("e :"+e1);
		}	
	}
	public static PdfReader unlockPdf(PdfReader reader)
	{
		if (reader == null)
		{
			return reader;
		}
		try
		{
			Field f = reader.getClass().getDeclaredField("encrypted");
			f.setAccessible(true);
			f.set(reader, false);
		} 
		catch (Exception e)
		{ 
			// ignore
		}
		return reader;
	}

	public byte[] compressByteArray(byte[] bytes){

		ByteArrayOutputStream baos = null;
		Deflater dfl = new Deflater();
		dfl.setLevel(Deflater.BEST_COMPRESSION);
		dfl.setInput(bytes);
		dfl.finish();
		baos = new ByteArrayOutputStream();
		byte[] tmp = new byte[4*1024];
		try{
			while(!dfl.finished()){
				int size = dfl.deflate(tmp);
				baos.write(tmp, 0, size);
			}
		} catch (Exception ex){

		} finally {
			try{
				if(baos != null) baos.close();
			} catch(Exception ex){}
		}

		return baos.toByteArray();
	}


	public byte[] decompressByteArray(byte[] bytes){

		ByteArrayOutputStream baos = null;
		Inflater iflr = new Inflater();
		iflr.setInput(bytes);
		baos = new ByteArrayOutputStream();
		byte[] tmp = new byte[4*1024];
		try{
			while(!iflr.finished()){
				int size = iflr.inflate(tmp);
				baos.write(tmp, 0, size);
			}
		} catch (Exception ex){

		} finally {
			try{
				if(baos != null) baos.close();
			} catch(Exception ex){}
		}

		return baos.toByteArray();
	}

	@Override
	public PerfiosEntity getTransactionReview(PerfiosEntity perfiosEntity,
			PerfiosReportEntity perfiosReportEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting TransactionReview Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosTransactionReview(perfiosEntity);
			String pUrl = perfiosEntity.getTransactionReviewUrl();
			logger.info("URL : "+pUrl);
			logger.debug("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//conn.setRequestProperty("Content-Type", "application/xml");
			//OutputStream os = conn.getOutputStream();
			//os.write(perfiosTransactionUrl.)
			//os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			perfiosReportEntity.setProviderApiRequest(perfiosRequest);
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			//For perfios tracking Starts
			perfiosReportEntity.setProviderStatusCode(""+apiResponseCode);
			//For perfios tracking Ends
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Starts
				 */
				perfiosReportEntity.setProviderApiResponse(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Ends
				 */
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling RetrieveReport Perfios ::",e);
			
		}
		logger.info("Getting TransactionReview Process : END");
		return perfiosEntity;
	}
	
	
	@Override
	public PerfiosEntity getSupportedInstitutions(PerfiosEntity perfiosEntity,
			PerfiosReportEntity perfiosReportEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting SupportedInstitutions Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosSupportedInstitutions(perfiosEntity);
			String pUrl = perfiosEntity.getSupportedInstUrl();
			logger.info("URL : "+pUrl);
			logger.debug("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//conn.setRequestProperty("Content-Type", "application/xml");
			//OutputStream os = conn.getOutputStream();
			//os.write(perfiosTransactionUrl.)
			//os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			perfiosReportEntity.setProviderApiRequest(perfiosRequest);
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			//For perfios tracking Starts
			perfiosReportEntity.setProviderStatusCode(""+apiResponseCode);
			//For perfios tracking Ends
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Starts
				 */
				perfiosReportEntity.setProviderApiResponse(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Ends
				 */
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling RetrieveReport Perfios ::",e);
		}
		logger.info("Getting SupportedInstitutions Process : END");
		return perfiosEntity;
	}

	
	@Override
	public PerfiosEntity getDeleteData(PerfiosEntity perfiosEntity,
			PerfiosReportEntity perfiosReportEntity) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Getting DeleteData Process : Start");

			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String perfiosRequest=CommonPerfios.perfiosDataDeleteStatement(perfiosEntity);
			String pUrl = perfiosEntity.getDeleteDataUrl();
			logger.info("URL : "+pUrl);
			logger.debug("Payload and Signature : "+perfiosRequest);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//conn.setRequestProperty("Content-Type", "application/xml");
			//OutputStream os = conn.getOutputStream();
			//os.write(perfiosTransactionUrl.)
			//os.flush();

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(perfiosRequest);
			writer.flush();
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			perfiosReportEntity.setProviderApiRequest(perfiosRequest);
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			perfiosEntity.setApiResponseCode(""+apiResponseCode);
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			//For perfios tracking Starts
			perfiosReportEntity.setProviderStatusCode(""+apiResponseCode);
			//For perfios tracking Ends
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				perfiosEntity.setResponseXML(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Starts
				 */
				perfiosReportEntity.setProviderApiResponse(result.toString());
				/*
				 * Updating Perfios request response to credit bureau tracker
				 * Ends
				 */
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling RetrieveReport Perfios ::",e);
			
		}
		logger.info("Getting DeleteData Process : END");
		return perfiosEntity;
	}

}

