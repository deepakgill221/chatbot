package com.qc.serviceImpl;

import java.util.Date;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.db.dao.CreditBureauReportDBDao;
import com.qc.db.dao.PanDao;
import com.qc.dto.CBSERVICEPROVIDER;
import com.qc.dto.CBVERSION;
import com.qc.dto.CreditBureauTrackerDTO;
import com.qc.entity.CreditBureauReportEntity;
import com.qc.service.ExternalServices;
import com.qc.service.PanService;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;
import com.qc.utils.ObjectFactory;

@Service
public class PanServiceImpl implements PanService {

	private static final Logger logger = LogManager.getLogger(PanServiceImpl.class);
	
	@Autowired
	CreditBureauReportDBDao creditBureauReportDBDao;
	
	@Autowired
	PanDao panDao;
	
	@Override
	public String processPANRequest(String requestJson, Environment env) {


		String PRIORITY = env.getProperty("com.qualtech.pan.resource.priority");
		String FLAT_FILE_PATH=env.getProperty("flatFilePath");
		String CRIF_STATUS=env.getProperty("com.qualtech.pan.resource.CRIF.status");
		String EQUIFAX_STATUS=env.getProperty("com.qualtech.pan.resource.EQUIFAX.status");
		String flatFileMessage="";
		String methodName=null;
		//added
		String status = null;
		String pan ="";
		String fname="";
		String dob="";
		Map requestData=null;
		String serviceName =null;
		methodName=Commons.getMethodName();
		ObjectFactory of = new ObjectFactory();
		logger.info(" Came inside "+methodName+"().");
		Map<String, String> responseMap = null;
		String responseString = new String();
		//for cb tracking
		CreditBureauTrackerDTO cbTrackerDTO = new CreditBureauTrackerDTO();
		boolean pdfGenerated=false;
		String pdfByte=new String();
		try
		{
			requestData=Commons.getGsonData(requestJson);
			if(requestData!=null && requestData.containsKey("fname") && requestData.containsKey("mname")
					&& requestData.containsKey("lname") && requestData.containsKey("dob")
					&& requestData.containsKey("pan") && requestData.containsKey("gender")
					&& requestData.containsKey("email") && requestData.containsKey("careOf")
					&& requestData.containsKey("houseNo") && requestData.containsKey("street")
					&& requestData.containsKey("landmark") && requestData.containsKey("location")
					&& requestData.containsKey("postOffice") && requestData.containsKey("vill_city")
					&& requestData.containsKey("subDistrict") && requestData.containsKey("district")
					&& requestData.containsKey("state") && requestData.containsKey("stateCode")
					&& requestData.containsKey("postalCode") && requestData.containsKey("mobileno")
					&& requestData.containsKey("validationType") && requestData.containsKey("app_name") 
					&&(requestData.get("pan")!=null && !requestData.get("pan").equals(""))
					&&(requestData.get("fname")!=null && !requestData.get("fname").equals(""))
					&&(requestData.get("dob")!=null && !requestData.get("dob").equals(""))
					&&(requestData.get("validationType")!=null && !requestData.get("validationType").equals(""))
					&&(requestData.get("app_name")!=null && !requestData.get("app_name").equals(""))
					&& (requestData.get("app_name").toString().equalsIgnoreCase("TPP")	|| requestData.get("app_name").toString().equalsIgnoreCase("MSALES"))
					&& requestData.size()<23 )
			{
				try
				{
					String priority = PRIORITY; //VALUE FROM PROPERTY FILE
					String[] Arr = priority.split(",");
					logger.info("Calling Webservice Start");
					for (String itr : Arr)
					{
						logger.debug(" Calling Webservice Of : "+itr);
						String serviceStatus="";
						if(itr != null && itr.equalsIgnoreCase("CRIF"))
						{
							serviceStatus = CRIF_STATUS;
							/*
							 * Setting CRIF provider and version to Tracker DTO
							 * Starts
							 */
							cbTrackerDTO.setCbServiceProvider(CBSERVICEPROVIDER.CRIF);
							cbTrackerDTO.setCbVersion(CBVERSION.CREDIT_BUREAU_V1);
							/*
							 * Setting CRIF provider and version to Tracker DTO
							 * Ends
							 */
						}
						/*else if(itr != null && itr.equalsIgnoreCase("EQUIFAX"))
						{
							serviceStatus = EQUIFAX_STATUS;
							
							 * Setting CRIF provider and version to Tracker DTO
							 * Starts
							 
							cbTrackerDTO.setCbServiceProvider(CBSERVICEPROVIDER.EQUIFAX);
							cbTrackerDTO.setCbVersion(CBVERSION.CREDIT_BUREAU_V1);
							
							 * Setting CRIF provider and version to Tracker DTO
							 * Ends
							 
						}*/
						
						if(serviceStatus.equalsIgnoreCase("TRUE"))
						{
							
							///added on 13 may 2018 via MJ~
							logger.debug("Object convert into String");
							status = panDao.getStatusThroughProcedures(requestJson);
							logger.info("status after calling getStatusByCallProcedures----> "+status);
							if(status!=null){
								if(!status.isEmpty()){
									if(status.equalsIgnoreCase("Y"))
									{
										ExternalServices extServices = of.getService(itr);
										responseMap = extServices.callService(requestData,env,cbTrackerDTO);
										
										if(responseMap!=null && responseMap.get("RESPONSE_STATUS").equalsIgnoreCase("200"))
										{
											responseString+="{\"status\":\""+responseMap.get("RESPONSE_STATUS")+"\", \"response\": { ";
											responseString+="\"pan\":\""+responseMap.get("PAN_STATUS")+"\",";
											responseString+="\"dob\":\""+responseMap.get("DOB_STATUS")+"\",";
											responseString+="\"name\":\""+responseMap.get("NAME_STATUS")+"\"";
											responseString+=" }}";
										}
										else
										{
											responseString="{\"status\":\"500\",\"message\":\"There is some error in calling webservice\"}";
											logger.info(flatFileMessage+"something happens wrong while getting data from CB Service");
										}
										
										if(responseMap!=null && responseMap.containsKey("RESPONSE_STATUS"))
										{
											serviceName = itr;
											logger.debug(" Calling Webservice Of : "+itr +" Completed Successfully with Response");
											break;
										}
										else
										{
											if(itr.equalsIgnoreCase("CRIF"))
											{
												try
												{
													flatFileMessage="ResponseMap is NULL From Criff -:- Incomplete Data found or Error while parsing error code from CB Service -:- ";
													logger.info(flatFileMessage);
												}
												catch(Exception e)
												{
													logger.error("ErrorInfo while Creating Flat File inside "+methodName+"()"+e,new Throwable());
												} 
											}
										}
										
									}
									else{
										responseString="{\"status\":\"500\",\"message\":\"Request has been came under 30 Second\"}";
										logger.info("Request has been came under 30 Second"+status);
									}
								
								}
								else{
									responseString="{\"status\":\"500\",\"message\":\"Request has been came under 20Second\"}";
									logger.info("Status is coming blank from proc :: status: "+status);
								}
							}
							else{ 
								responseString="{\"status\":\"500\",\"message\":\"Procedures was not run properly\"}";
								logger.info("Status is coming null from proc :: status: "+status);
							}
						}
							
						}
					logger.info(" Calling Webservice End");
				}
			catch(Exception e)
			{
//				if(responseString.length()==0 ){
//					responseString="{\"status\":\"500\",\"message\":\"There is some error in calling webservice\"}";
				logger.error("There is some Exception while processing CB Calling Process : "+e);
//				}
			}
			}
			
			else
			{
//				responseString="{\"status\":\"500\",\"message\":\"Invalid Request Json\"}";
				logger.info("Validation Check fail : no need to call CB service");
			}
		}
		catch(Exception e)
		{
			
//			responseString="{\"status\":\"500\",\"message\":\"There is some Technical Issue\"}";
			logger.info("Request Json is Invalid : Unable to parse : "+e);
		}
					
		try
		{
    		//String sFileName = resProp.getString("flatFilePath");
    		String sFileName = FLAT_FILE_PATH;//FROM PROPERTY FILE
    		FlatFileMaker.generateFlatFile(sFileName, requestJson, responseString, requestData.get("app_name").toString(), serviceName);
		}
		catch(Exception e)
		{
			logger.error("ErrorInfo while Creating Flat File inside "+methodName+"()"+e,new Throwable());
		} 
		logger.debug(" ResponseJSON:"+responseString);
		
		/*
		 * Inserting all api request,response and credit bureau 1.0 api request and response in DB
		 */
		final String crifResponseJson = responseString;
		new Thread(new Runnable() 
		{
		    public void run() 
		    {
		    	runningBackgroundProcess(requestJson,crifResponseJson,cbTrackerDTO);
		    }
		}).start();
		logger.info(" Going outside "+methodName+"().");
		return responseString;
		
	}
	
	public void runningBackgroundProcess(String requestJson,String crifResponseJson,CreditBureauTrackerDTO cbTrackerDTO){
		logger.info("Running background process to save crif data!!");
		try
		{
			CreditBureauReportEntity entity = new CreditBureauReportEntity();
			//Gson gson = new Gson();
			//CBV1RequestDTO dto = gson.fromJson(requestJson,CBV1RequestDTO.class);
			Long sequenceId = creditBureauReportDBDao.getSequenceValue();
			entity.setId(sequenceId);
			entity.setApiRequestJson(requestJson);
			entity.setApiResponseJson(crifResponseJson == null ? "" : crifResponseJson);
			entity.setCreatedTime(new Date());
			entity.setUpdatedTime(new Date());
			entity.setRemark("service");
			if(cbTrackerDTO != null)
			{
				entity.setCbVersion(cbTrackerDTO.getCbVersion());
				entity.setCbServiceProvider(cbTrackerDTO.getCbServiceProvider());
				//entity.setProviderApiRequest(cbTrackerDTO.getRequestXml() == null ? " ".getBytes(): cbTrackerDTO.getRequestXml().getBytes());
				//entity.setProviderApiResponse(cbTrackerDTO.getResponseXml() == null ? " ".getBytes(): cbTrackerDTO.getResponseXml().getBytes());	
			}
			creditBureauReportDBDao.saveCreditBureauReport(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception occured while saving crif data to DB!! "+e);
		}
		
	}

}
