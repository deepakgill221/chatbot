package com.qc.serviceImpl;

import java.net.InetAddress;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.apache.commons.codec.binary.Base64;
import com.qc.db.dao.CreditBureauReportDBDao;
import com.qc.dto.CreditBureauTrackerDTO;
import com.qc.dto.CrifRequestResponseTrackerDTO;
import com.qc.entity.CreditBureauReportEntity;
import com.qc.service.CreditBureauV3ApiService;
import com.qc.service.ExternalServices;
import com.qc.utils.Base64ArrayUtility;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;
import com.qc.utils.ObjectFactory;
import com.qc.utils.PDFMaker;

@Service
public class CreditBureauV3ApiServiceImpl implements CreditBureauV3ApiService{

	private static Logger logger = LogManager.getLogger(CreditBureauV3ApiServiceImpl.class);
	@Autowired
	CreditBureauReportDBDao creditBureauReportDBDao; 

	@Override
	public String getCbV3ActionRequest(final String requestJson, Environment env,Map requestData) 
	{
		String PRIORITY=env.getProperty("com.qualtech.pan2.resource.priority");
		String CRIF_STATUS=env.getProperty("com.qualtech.pan2.resource.CRIF.status");
		String EQUIFAX_STATUS=env.getProperty("com.qualtech.pan2.resource.EQUIFAX_2.0.status");
		String FLAT_FILE_PATH=env.getProperty("flatFilePath");
		String flatFileMessage="";
		String methodName = null;
		String serviceName = null;
		String app_name = "";
		String responseString = "";
		methodName = Commons.getMethodName();
		ObjectFactory of = new ObjectFactory();
		Map<String, String> responseMap = null;
		CreditBureauTrackerDTO cbTrackerDTO = new CreditBureauTrackerDTO();
		List<CrifRequestResponseTrackerDTO> crifEqifaxInnerData = new ArrayList<CrifRequestResponseTrackerDTO>();
		String correlationId = new String();
		final String outerTrackingId = ""+System.currentTimeMillis();
		String ValidationType="";
		List<Map> policyDetails = new ArrayList<Map>();
		List<String> policyNo = new ArrayList<>();
		String soacorellationId="";
		String soaAppId ="";
		try 
		{
			if (requestData != null) 
			{
				try
				{
					//correlationId = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("Payload"))
						//	.get("Transactions")).get(0)).get("TransTrackingID")).toString();
				}
				catch(Exception e)
				{
					logger.error("Exception occured in getting Correlation Id",e);
				}
				ValidationType = (((Map) ((List) ((Map) ((Map) requestData.get("request")).get("payload"))
						.get("transactions")).get(0)).get("validationType")).toString();
				String fname = (((Map) ((List) ((Map) ((Map) requestData.get("request")).get("payload"))
						.get("transactions")).get(0)).get("firstName")).toString();
				String dob = (((Map) ((List) ((Map) ((Map) requestData.get("request")).get("payload"))
						.get("transactions")).get(0)).get("dob")).toString();
				String pan = (((Map) ((List) ((Map) ((Map) requestData.get("request")).get("payload"))
						.get("transactions")).get(0)).get("pan")).toString();
//				app_name = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("payload"))
//						.get("Transactions")).get(0)).get("app_name")).toString();
//				policyNo = (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("payload"))
//						.get("Transactions")).get(0)).get("policyNo")).toString();
				
				policyDetails = ((List)((Map) ((List) ((Map) ((Map) requestData.get("request")).get("payload"))
						.get("transactions")).get(0)).get("policyDetails"));
				
				String transTrackingID = (((Map) ((List) ((Map) ((Map) requestData.get("request")).get("payload"))
						.get("transactions")).get(0)).get("transTrackingID")).toString();
				 soacorellationId=(((Map)(Map) ((Map) requestData.get("request")).get("header"))
						.get("soaCorrelationId").toString());
				 soaAppId=(((Map)(Map) ((Map) requestData.get("request")).get("header"))
						.get("soaAppId").toString());
			/*	policyDetails =(List<Map<String, String>) (((Map) ((List) ((Map) ((Map) requestData.get("Request")).get("payload"))
						.get("Transactions")).get(0)).get("policyDetails"));
				*/
				for(Map policyno : policyDetails)
				{
					if(policyno!=null && policyno.containsKey("policyNo"))
					{
						policyNo.add(policyno.get("policyNo").toString());
					}
				}
				
				/*responseString += "{\"response\": {";
				responseString += "\"header\": {";
				responseString += "\"soaCorrelationId\": \"12345\",";
				responseString += "\"soaAppId\": \"NEO";
				responseString += "\"}";
				responseString += "\"payload\": \"\",";
				responseString += "\"SourceInfoName\":\"\",";
				responseString += "\"RequestorToken\": \"\",";
				responseString += "\"UserEmail\": \"\",";
				responseString += "\"LastSyncDateTime\": \"\"";
				responseString += "},";
				responseString += "\"payload\": {";
				responseString += "\"Transactions\": [";
				responseString += "{";
//				responseString += "\"Key1\":\"\",";
//				responseString += "\"Key2\": \"\",";
//				responseString += "\"Key3\": \"\",";
//				responseString += "\"Key4\": \"\",";
//				responseString += "\"Key5\": \"\",";
				responseString += "\"ValidationType\": \"" + ValidationType + "\",";
				responseString += "\"TransTrackingID\": \"\",";
				responseString += "\"TransactionData\": \"\",";
				responseString += "\"};
*/				

				if (ValidationType != null && !ValidationType.equalsIgnoreCase("")	
						&& ( ValidationType.equalsIgnoreCase("ALL")	|| ValidationType.equalsIgnoreCase("PANDOB") )
						&& fname != null 	&& !fname.equalsIgnoreCase("") 
						&& dob != null 		&& !dob.equalsIgnoreCase("") 
						&& pan != null 		&& !pan.equalsIgnoreCase("") 
						//&& app_name != null	&& !app_name.equalsIgnoreCase("") 
					)
				{
					logger.debug("All validation Passed");
					try
					{
						String priority = PRIORITY; 
						String[] Arr = priority.split(",");
						logger.info("Calling Webservice Start");
						for (String itr : Arr)
						{
							String serviceStatus = "";
							if (itr != null && itr.equalsIgnoreCase("CRIF")) 
							{
								logger.info("Calling : "+itr+" : Status : "+CRIF_STATUS);
								serviceStatus = CRIF_STATUS;
							} 
							else if (itr != null && itr.equalsIgnoreCase("EQUIFAX_2.0")) 
							{
								logger.info("Calling : "+itr+" : Status : "+EQUIFAX_STATUS);
								serviceStatus = EQUIFAX_STATUS;
							}
							serviceName = itr;
							logger.info("Calling Webservice Of : " + itr);
							if (serviceStatus.equalsIgnoreCase("TRUE"))
							{
								ExternalServices extServices = of.getService(itr);
								responseMap = extServices.callNeoServiceV3(requestData,env,cbTrackerDTO,crifEqifaxInnerData);
								logger.info("FULLY CALCULATED Response From ITR SERVICE " + itr + " (ALL SERVICE) ::: "+ responseMap);
								if (responseMap != null)
								{
									logger.info(" Calling Webservice Of : " + itr+ " Completed Successfully with Response");
									break;
								} 
								else 
								{
									if (itr.equalsIgnoreCase("CRIF"))
									{
										try 
										{
											flatFileMessage="ResponseMap is NULL From Criff -:- Incomplete Data found or Error while parsing error code from CB Service -:- ";
											logger.info(flatFileMessage);
										}
										catch (Exception e) 
										{
											logger.error("ErrorInfo while Creating Flat File inside " + methodName + "()" + e);
										}
									}
								}
							}
						}
						
						logger.info("Calling Webservice End");
						if (responseMap != null)
						{
							StringBuilder sb = new StringBuilder();
							
							if (ValidationType.equalsIgnoreCase("ALL")) 
							{
								sb.append("<![CDATA[<data><creditBureau><name><detailsAsPerCB>"+ responseMap.get("NAME") +"</detailsAsPerCB><matchStatus>" 
														+ responseMap.get("NAME_STATUS") + "</matchStatus></name><dob><detailsAsPerCB>" + responseMap.get("DOB") +
														"</detailsAsPerCB><matchStatus>" + responseMap.get("DOB_STATUS") + "</matchStatus></dob><panNumber><detailsAsPerCB>"
														+ responseMap.get("PAN") + "</detailsAsPerCB><matchStatus>" + responseMap.get("PAN_STATUS") + 
														"</matchStatus></panNumber><address><detailsAsPerCB>" + responseMap.get("ADDRESS") + "</detailsAsPerCB><matchStatus>" 
														+ responseMap.get("ADDRESS_STATUS") + "</matchStatus></address><pinCode><detailsAsPerCB>" + responseMap.get("PINCODE") +
														"</detailsAsPerCB><matchStatus>" + responseMap.get("PINCODE_STATUS") +"</matchStatus></pinCode><mobile><detailsAsPerCB>"+ 
														responseMap.get("MOBILE") +"</detailsAsPerCB><matchStatus>"+ responseMap.get("MOBILE_STATUS") 
														+"</matchStatus></mobile><email><detailsAsPerCB>"+ responseMap.get("EMAIL") +"</detailsAsPerCB><matchStatus>"
														+ responseMap.get("EMAIL_STATUS") +"</matchStatus></email><occupationType><detailsAsPerCB>"+ responseMap.get("OCCPTNCLS") 
														+"</detailsAsPerCB><matchStatus>"+1+"</matchStatus></occupationType><creditScore><detailsAsPerCB>"+ responseMap.get("CREDITSCR")
														+"</detailsAsPerCB><matchStatus>"+ responseMap.get("EMAIL_STATUS") +"</matchStatus></creditScore><estimated><detailsAsPerCB>"
														+ responseMap.get("ESTMTDINCM") +"</detailsAsPerCB><matchStatus>"+ responseMap.get("ESTMTDINCM")+
																		"</matchStatus></estimated></creditBureau></data>]]>");
																
								logger.info("Response generation Start : ALL");
								/*responseString += "\"msgInfo\":{";*/
								responseString += "{\"response\":";
								responseString += "{\"header\":{";
								responseString += "\"soaCorrelationId\":\""+soacorellationId+"\",";
								responseString += "\"soaAppId\":\""+soaAppId+"";
								responseString += "\"},";
								responseString += "\"msgInfo\":{";
								responseString += "\"msgCode\": \"200\",";
								responseString += "\"msg\": \"Success\",";
								responseString += "\"msgDescription\":\"Response Generated Successfully";
								responseString += "\"},";
								responseString += "\"payload\": {";
								responseString += "\"transactions\":[{";
								responseString += "\"validationType\": \"" + ValidationType + "\",";
								responseString += "\"transTrackingID\": \"" + transTrackingID + "\",";
								//responseString += "\"transactionData\": {";
								
								/*responseString += "{\"status\":\"200\",";
								responseString += "\"statusDesc\":\"Success\",";
								responseString += "\"message\":\"Success\",";*/
//								responseString += "\"policyNo\":\"" + policyNo + "\",";
								/*int i=1;
								responseString += "\"policyDetails\": [";
								for(String str : policyNo){
								responseString += "{";
								responseString += "\"policyNo\":\"" + str + "\"";
								if(i==1){
									responseString += "},";
									i++;
								}
								else{
									responseString += "}";
								}
								}*/
								int i=policyNo.size();
								responseString += "\"policyDetails\": [";
								for(String str : policyNo){
								responseString += "{";
								responseString += "\"policyNo\":\"" + str + "\"";
								if(i>1){
									responseString += "},";
									i--;
								}
								else{
									responseString += "}";
								}
								}
								responseString += "],";
								responseString += "\"pan\":\"" + responseMap.get("PAN") + "\",";
								responseString += "\"pan_status\":\"" + responseMap.get("PAN_STATUS") + "\",";
								responseString += "\"dob\":\"" + responseMap.get("DOB") + "\",";
								responseString += "\"dob_status\":\"" + responseMap.get("DOB_STATUS") + "\",";
								responseString += "\"name\":\"" + responseMap.get("NAME") + "\",";
								responseString += "\"name_status\":\"" + responseMap.get("NAME_STATUS") + "\",";
								responseString += "\"address\":\"" + responseMap.get("ADDRESS") + "\",";
								responseString += "\"address_status\":\"" + responseMap.get("ADDRESS_STATUS") + "\",";
								responseString += "\"pinCode\":\"" + responseMap.get("PINCODE") + "\",";
								responseString += "\"pinCode_status\":\"" + responseMap.get("PINCODE_STATUS") + "\",";
								responseString += "\"mobile\":\"" + responseMap.get("MOBILE") + "\",";
								responseString += "\"mobile_status\":\"" + responseMap.get("MOBILE_STATUS") + "\",";
								responseString += "\"emailID\":\"" + responseMap.get("EMAIL") + "\",";
								responseString += "\"emailID_status\":\"" + responseMap.get("EMAIL_STATUS") + "\",";
								responseString += "\"occptnCls\":\"" + responseMap.get("OCCPTNCLS") + "\",";
								responseString += "\"credtScr\":\"" + responseMap.get("CREDITSCR") + "\",";
								/*responseString += "\"estmtdIncm\":\"fafa\"" ;*/
								responseString += "\"estmtdIncm\":\"" + responseMap.get("ESTMTDINCM") + "\"";
								//responseString += "\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, "NEO", serviceName,cbTrackerDTO) + "\"";
								responseString += ",\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, app_name, serviceName,cbTrackerDTO) + "\"";
								responseString += ",\"xml\":\""+new String(Base64.encodeBase64(sb.toString().getBytes(),false))+"\"";
								responseString += " }  ]    }  } }";

								
								logger.info("Response generation End : ALL");
							}
							else if (ValidationType.equalsIgnoreCase("PANDOB"))
							{
								sb.append("<![CDATA[<data><creditBureau><name><detailsAsPerCB>"+ responseMap.get("NAME") +"</detailsAsPerCB><matchStatus>" 
										+ responseMap.get("NAME_STATUS") + "</matchStatus></name><dob><detailsAsPerCB>" + responseMap.get("DOB") +
										"</detailsAsPerCB><matchStatus>" + responseMap.get("DOB_STATUS") + "</matchStatus></dob><panNumber><detailsAsPerCB>"
										+ responseMap.get("PAN") + "</detailsAsPerCB><matchStatus>" + responseMap.get("PAN_STATUS") + 
										"</matchStatus></panNumber></creditBureau></data>]]>");
																
								logger.info("Response generation Start : PANDOB");
								responseString += "{\"response\":";
								responseString += "{\"header\":{";
								responseString += "\"soaCorrelationId\":\""+soacorellationId+"\",";
								responseString += "\"soaAppId\":\""+soaAppId+"";
								responseString += "\"},";
								responseString += "\"msgInfo\":{";
								responseString += "\"msgCode\": \"200\",";
								responseString += "\"msg\": \"Success\",";
								responseString += "\"msgDescription\":\"Response Generated Successfully";
								responseString += "\"},";
								responseString += "\"payload\": {";
								responseString += "\"transactions\":[{";
								responseString += "\"validationType\": \"" + ValidationType + "\",";
								responseString += "\"transTrackingID\": \"" + transTrackingID + "\",";
								//responseString += "\"transactionData\":\"{";
								
								/*int i=1;
								responseString += "\"policyDetails\": [";
								for(String str : policyNo){
								responseString += "{";
								responseString += "\"policyNo\":\"" + str + "\"";
								if(i==1){
									responseString += "},";
									i++;
								}
								else{
									responseString += "}";
								}
								}*/
								int i=policyNo.size();
								responseString += "\"policyDetails\": [";
								for(String str : policyNo){
								responseString += "{";
								responseString += "\"policyNo\":\"" + str + "\"";
								if(i>1){
									responseString += "},";
									i--;
								}
								else{
									responseString += "}";
								}
								}
								responseString += "],";
								responseString += "\"pan\":\"" + responseMap.get("PAN") + "\",";
								responseString += "\"pan_status\":\"" + responseMap.get("PAN_STATUS") + "\",";
								responseString += "\"dob\":\"" + responseMap.get("DOB") + "\",";
								responseString += "\"dob_status\":\"" + responseMap.get("DOB_STATUS") + "\",";
								responseString += "\"name\":\"" + responseMap.get("NAME") + "\",";
								responseString += "\"name_status\":\"" + responseMap.get("NAME_STATUS") + "\"";
								responseString += ",\"byteArr\":\"" + this.getPdfByteArrayString(responseString, FLAT_FILE_PATH, requestJson, app_name, serviceName,cbTrackerDTO) + "\"";
								responseString += ",\"xml\":\""+new String(Base64.encodeBase64(sb.toString().getBytes(),false))+"\"";
								responseString += " }  ]    }  } }";
								logger.info("Response generation End : PANDOB");
							}
						} 
						else 
						{
							responseString = "{\"response\": {\"header\":{ \"soaCorrelationId\":\""+soacorellationId+"\","+ "\"soaAppId\":\""+soaAppId+"\"}, \"msgInfo\":{ \"msgCode\": \"101\", \"msg\": \"Failure\", \"msgDescription\":\"There is some error in calling webservice. \" }, \"payload\" : \"null\" } } " ;
							//responseString += "{\"msgCode\":\"101\", \"msg\":\"Failure\", \"msgDescription\":\"There is some error in calling webservice.\"}";
							logger.info(flatFileMessage+"something happens wrong while getting data from CB Service");
						}
					}
					catch (Exception e) 
					{
						responseString = "{\"response\": {\"header\":{ \"soaCorrelationId\":\""+soacorellationId+"\","+ "\"soaAppId\":\""+soaAppId+"}, \"msgInfo\":{ \"msgCode\": \"101\", \"msg\": \"Failure\", \"msgDescription\":\"There is some error in calling webservice. \" }, \"payload\" : \"null\"} } " ;
						//responseString += "{\"msgCode\":\"101\",\"msg\":\"Failure\",\"msgDescription\":\"There is some error in calling webservice\"}";
						logger.error("There is some Exception while processing CB Calling Process : "+e);
					}
				}
				else 
				{
					// Invalid Request Json
					responseString = "{\"response\": {\"header\":{ \"soaCorrelationId\":\""+soacorellationId+"\","+ "\"soaAppId\":\""+soaAppId+"}, \"msgInfo\":{ \"msgCode\": \"102\", \"msg\": \"Failure\", \"msgDescription\":\"There is some error in calling webserviceInvalid Request Json. \" }, \"payload\" : \"null\"} } " ;
					//responseString += "{\"msgCode\":\"102\",\"msg\":\"Failure\",\"msgDescription\":\"Invalid Request Json\"}";
					logger.info("Validation Check fail : no need to call CB service");
				}
			}
			else 
			{
				// Invalid Request Json
				//responseString += "{\"msgCode\":\"102\",\"msg\":\"Failure\",\"msgDescription\":\"Invalid Request Json\"}";
				responseString = "{\"response\": {\"header\":{ \"soaCorrelationId\":\""+soacorellationId+"\","+ "\"soaAppId\":\""+soaAppId+"}, \"msgInfo\":{ \"msgCode\": \"102\", \"msg\": \"Failure\", \"msgDescription\":\"There is some error in calling webserviceInvalid Request Json. \" }, \"payload\" : \"null\"} } " ;
				logger.info("Request Json is null : Unable to process CB service calling");
			}
		} 
		catch (Exception e)
		{
			/*responseString += "{\"Response\": {\"ResponseInfo\": {\"UserName\": \"\",\"CreationDate\": \"\",\"CreationTime\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"\",\"TransTrackingID\": \"\",\"TransactionData\": ";
			responseString += "{\"msgCode\":\"102\",\"msg\":\"Failure\",\"msgDescription\":\"Invalid Request Json\"}";
			logger.error("Request Json contains invalid key : We are in exception while fetching value from request Json : " + e);*/
			
			//responseString += "{\"Response\": {\"header\": {\"soaMsgVersion\": \"\",\"soaAppId\": \"\",\"soaCorrelationId\": \"\"";
			/*responseString += "{\"Response\": {\"header\": {\"soaMsgVersion\": \"\",\"soaAppId\": \"\",\"soaCorrelationId\": \"\",\"SourceInfoName\":\"\",\"RequestorToken\": \"\",\"UserEmail\": \"\",\"LastSyncDateTime\": \"\"},\"ResponsePayload\": {\"Transactions\": [{\"Key1\":\"\",\"Key2\": \"\",\"Key3\": \"\",\"Key4\": \"\",\"Key5\": \"\",\"ValidationType\": \"\",\"TransTrackingID\": \"\",\"TransactionData\": ";*/
			responseString = "{\"response\": {\"header\":{ \"soaCorrelationId\":\""+soacorellationId+"\","+ "\"soaAppId\":\""+soaAppId+"}, \"msgInfo\":{ \"msgCode\": \"102\", \"msg\": \"Failure\", \"msgDescription\":\"There is some error in calling webserviceInvalid Request Json. \" }, \"payload\" : \"null\"} } " ;
			logger.error("Request Json contains invalid key : We are in exception while fetching value from request Json : " + e);
		}
		try 
		{
			logger.info("Flat file Creation : Start");
			String sFileName = FLAT_FILE_PATH;
			FlatFileMaker.generateNeoFlatFile(sFileName, requestJson, flatFileMessage+responseString, app_name, serviceName);
			logger.info("Flat file Creation : End");
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo while Creating Flat File inside " + methodName + "()" + e);
		}
		/*responseString += " }  ]    }  } }";*/
		logger.info("Response Json generation completed");
		
		/*
		 * Inserting all api request,response and credit bureau 2.0 (CRIF AND EQUIFAX) api request and response in DB
		 */
		try 
		{
			final String crifResponseJson = responseString;
			final String correlationIdNew = correlationId;
			final List<String> policyNoNew = policyNo;
			final String serviceTypeNew = ValidationType;
			new Thread(new Runnable() 
			{
			    public void run() 
			    {
			    	runningBackgroundProcess(requestJson,crifResponseJson,correlationIdNew,outerTrackingId,cbTrackerDTO,policyNoNew,serviceTypeNew);
			    }
			}).start();
		} 
		catch (Exception e) 
		{
			logger.error("We get exception while setting data in DB : "+e);
		}
		
		logger.info(" Going outside " + methodName + "().");
		return responseString;
	}

	public void runningBackgroundProcess(String requestJson,String crifResponseJson,
			String correlationId,String outerTrackingId,CreditBureauTrackerDTO cbTrackerDTO,List<String> policyNoNew ,String serviceTypeNew)
	{
		logger.info("Running background process to save crif data!!");
		InetAddress ip = null;
        String hostname = null;
        try
        {
            ip = InetAddress.getLocalHost();
            hostname = ip.getHostName();
        }
        catch (UnknownHostException e)
        {
        	logger.error("We are in exception : "+e);
        }
		try
		{
			int pdfGenerated=0;
			for(CrifRequestResponseTrackerDTO crifData : cbTrackerDTO.getCrifv2RetryData())
			{
				CreditBureauReportEntity entity = new CreditBureauReportEntity();
				for(String s : policyNoNew ){
				Long sequenceId = creditBureauReportDBDao.getSequenceValue();
				entity.setId(Long.parseLong(""+sequenceId));
				entity.setCorrelationId(correlationId);
				entity.setApiRequestJson((requestJson != null && !requestJson.isEmpty()) ? requestJson : "");
				entity.setApiResponseJson((crifResponseJson != null && !crifResponseJson.isEmpty())? crifResponseJson : "");
				entity.setRemark("credit bureau service");
				entity.setServerIpAddress(""+ip);
				entity.setServerHostName(hostname);
				entity.setOuterTrackerId(outerTrackingId);
				entity.setPolicyNo(s);
				entity.setServiceType(serviceTypeNew);
				if(cbTrackerDTO != null)
				{
					entity.setCbVersion(cbTrackerDTO.getCbVersion());
					entity.setCbServiceProvider(cbTrackerDTO.getCbServiceProvider());
					if(pdfGenerated == (cbTrackerDTO.getCrifv2RetryData().size()-1))
					{
						entity.setPdfByteArray((cbTrackerDTO.getPdfByte() != null && !cbTrackerDTO.getPdfByte().isEmpty()) ? cbTrackerDTO.getPdfByte() : "");
						entity.setIsPdfGenerated((cbTrackerDTO.isPdfGenerated()==true)?"Y":"N");
					}
					pdfGenerated++;
				}
				if(crifData != null)
				{
					entity.setProviderApiRequest((crifData.getCrifRequestXml() != null && !crifData.getCrifRequestXml().isEmpty()) ? crifData.getCrifRequestXml() : "");
					entity.setProviderApiResponse((crifData.getCrifResponseXml() != null && !crifData.getCrifResponseXml().isEmpty()) ? crifData.getCrifResponseXml() : "");
					entity.setInnerTrackerId(crifData.getInnerTrackId());
					entity.setCreatedTime(crifData.getStartDate());
					entity.setUpdatedTime(crifData.getEndDate());
					entity.setProviderStatusCode(crifData.getProviderStatusCode());
				}
				try
				{
					creditBureauReportDBDao.saveCreditBureauReport(entity);
				}
				catch(Exception e)
				{
					logger.info("Exception occured while crif/equfax api data saving for tracking !!",e);
					logger.info("Now attempting to insert data in Catch Block!! !!",e);
					try
					{
						if(crifData != null)
						{
							entity.setProviderApiRequest("No Data Found ");
							entity.setProviderApiResponse("No Data Found ");
							entity.setInnerTrackerId(crifData.getInnerTrackId());
							entity.setCreatedTime(crifData.getStartDate());
							entity.setUpdatedTime(crifData.getEndDate());
						}
						creditBureauReportDBDao.saveCreditBureauReport(entity);
					}
					catch (Exception e2) 
					{
						logger.info("Exception occured again while crif/equfax api data saving for tracking !!",e);
					}
				}
			}
		}
		}
		catch(Exception e)
		{
			logger.error("Exception occured while saving crif data to DB!! "+e);
		}
	}


	private String getPdfByteArrayString(String responseString, String FLAT_FILE_PATH,
			String requestJson, String app_name, String serviceName ,CreditBureauTrackerDTO cbTrackerDTO)
	{
		try
		{
			if (responseString.contains("200")) 
			{
				String sFileName = FLAT_FILE_PATH;
				String path = PDFMaker.generateNeoPDFV3(sFileName, requestJson, responseString, app_name, serviceName);
				String bFile = new Base64ArrayUtility().encodeToString(path, false);
				/*
				 * Updating crif request response to credit bureau tracker
				 * Starts
				 */
				cbTrackerDTO.setPdfByte(""+bFile.toString().trim());
				cbTrackerDTO.setPdfGenerated(true);
				/*
				 * Updating crif request response to credit bureau tracker
				 * Ends
				 */				
				return bFile.toString().trim();
			}
		}
		catch(Exception ex)
		{
			logger.error("We are in Exception "+ex);
		}
		return "";
	}

}
