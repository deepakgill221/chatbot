package com.qc.serviceImpl;

import java.net.URL;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.equifax.services.eport.servicedefs._1_0.CreditReportWSInquiryPortTypeProxy;
import com.equifax.services.eport.servicedefs._1_0.V10;
import com.equifax.services.eport.servicedefs._1_0.V10Locator;
import com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions;
import com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType;
import com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType;
import com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions;
import com.equifax.services.eport.ws.schemas._1_0.RequestBodyType;
import com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType;
import com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions;
import com.qc.dto.CreditBureauTrackerDTO;
import com.qc.dto.CrifRequestResponseTrackerDTO;
import com.qc.service.ExternalServices;
import com.qc.utils.Match;
import com.qc.utils.XTrustProvider;

@Service//("equifaxService")
public class EquifaxService implements ExternalServices
{
	private static Logger logger = LogManager.getLogger(EquifaxService.class);
	
	public Map<String,String> callService(Map<String,Object> requestParams,Environment env,CreditBureauTrackerDTO cbTrackerDTO)
	{
		Match nm = new Match();
		Map<String, String> responseParams =  null;
		Map<String,String> response = new HashMap<String,String>();
		
		if(requestParams.get("validationType").toString().equalsIgnoreCase("PAN"))
		{
			//Call logic to Equifax VID - Used For PAN
			try
			{
				logger.info("EQUIFAX service for PAN :  START");
				responseParams = getPanDetail(requestParams,env);
				
				if((responseParams.containsKey("ERRORCODE") && responseParams.get("ERRORCODE").contains("E")))
				{
					response.put("RESPONSE_STATUS", "1");
					response.put("PAN_STATUS", "Not Matched");
					response.put("DOB_STATUS", "");
					response.put("NAME_STATUS", "Not Matched");
					logger.info("EQUIFAX service for PAN :  END");
					return response; 
				}
				else{
					
				
				if(responseParams!=null && responseParams.containsKey("PANNO") )
				{
					if(responseParams.get("PANCODE").equalsIgnoreCase("E"))
					{
						boolean panFlag = nm.matchPAN(requestParams, responseParams);
						boolean nameFlag = nm.matchName(requestParams, responseParams);

						if(panFlag && nameFlag)
						{	//if pan and name are matched then pan matched.
							response.put("PAN_STATUS", "Matched");
						}
						else
						{
							response.put("PAN_STATUS", "Not Matched");
						}

						if(nameFlag)
						{
							response.put("NAME_STATUS", "Matched");
						}
						else
						{
							response.put("NAME_STATUS", "Not Matched");
						}
					
						response.put("DOB_STATUS", "");
						response.put("RESPONSE_STATUS", "1");
					}
					else
					{
//						When PAN no is not matched or wrong PAN number.
						response.put("RESPONSE_STATUS", "1");//	rishabh
						response.put("PAN_STATUS", "Not Matched");
						response.put("DOB_STATUS", "");
						response.put("NAME_STATUS", "Not Matched");
					}
					
				}
				else
				{
			
					response.put("RESPONSE_STATUS", "0");
					response.put("PAN_STATUS", "Not Matched");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
				}
				}	
				
				logger.info("EQUIFAX service for PAN :  END");
				return response;
				
			}
			catch(Exception e)
			{
				logger.error("Inside catch: "+e.getMessage());
				e.printStackTrace();
			}

		}
		else if(requestParams.get("validationType").toString().equalsIgnoreCase("DOB"))
		{
			//Call logic to Equifax EVDR - Used for DOB
			try
			{
				logger.info("EQUIFAX service for DOB :  START");

				responseParams = getDobDetail(requestParams,env);
				// RISHABH 28 MAR ;
				if((responseParams.containsKey("ERRORCODE") && responseParams.get("ERRORCODE").contains("E")))
				{
					response.put("RESPONSE_STATUS", "1");
					response.put("PAN_STATUS", "");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
					logger.info("EQUIFAX service for DOB :  END");
					return response; 
				}
				else{
				if(responseParams!=null && (responseParams.containsKey("DOB")|| responseParams.containsKey("DOBCODE")))
				{
					
					boolean nameFlag = nm.matchName(requestParams, responseParams);
					boolean dobFlag = nm.matchDOB(requestParams, responseParams);

						response.put("PAN_STATUS", "");

					if(nameFlag)
					{
						response.put("NAME_STATUS", "Matched");
					}
					else
					{
						response.put("NAME_STATUS", "Not Matched");
					}

					if(dobFlag && nameFlag)
					{	//for Dob both name and DOB need to matched
						response.put("DOB_STATUS", "Matched");
					}
					else
					{
						response.put("DOB_STATUS", "Not Matched");
					}
					response.put("RESPONSE_STATUS", "1");
				}
				
				else
				{
					response.put("RESPONSE_STATUS", "0");
					response.put("PAN_STATUS", "");
					response.put("DOB_STATUS", "Not Matched");
					response.put("NAME_STATUS", "Not Matched");
				}
				logger.info("EQUIFAX service for DOB :  END");
				return response;
			}
			}
			catch(Exception e)
			{
				logger.error("Inside catch: "+e.getMessage());
				e.printStackTrace();
			}
		}
		return null;
	}

	private Map<String,String> getPanDetail(Map<String,Object> requestParams,Environment env)
	{
		Map<String,String> panMap = new HashMap<String,String>();
		try 
		{
			
			String CUSTOMERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.CustomerId");
			String USERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.UserId");
			String PASSWORD=env.getProperty("com.qualtech.pan.resource.EQUIFAX.Password");
			String MEMBER_NUMBER=env.getProperty("com.qualtech.pan.resource.EQUIFAX.MemberNumber");
			String PRODUCT_CODE_PAN=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodePAN");
			String PRODUCT_CODE_DOB=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodeDOB");
			String SECURITY_CODE=env.getProperty("com.qualtech.pan.resource.EQUIFAX.SecurityCode");
			String PRODUCT_VERSION=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductVersion");
			String URL=env.getProperty("com.qualtech.pan.resource.EQUIFAX.url");
			
			logger.info(" PAN : Calling EQUIFAX Service : Start");
			URL url=new URL(URL);
			logger.info(" PAN : url:"+url);

			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(Integer.parseInt(CUSTOMERID));
			requestHeaderType.setUserId(USERID);
			requestHeaderType.setPassword(PASSWORD);
			requestHeaderType.setMemberNumber(MEMBER_NUMBER);
			requestHeaderType.setProductCode(PRODUCT_CODE_PAN);//For PAN
			requestHeaderType.setSecurityCode(SECURITY_CODE);
			requestHeaderType.setProductVersion(PRODUCT_VERSION);
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value31);
			requestBodyType.setFirstName(requestParams.get("fname").toString());//First Name
			requestBodyType.setMiddleName(requestParams.get("mname").toString());//M Name
			requestBodyType.setLastName(requestParams.get("lname").toString());//L Name

			String dateInString = getDateInAnyFormat(requestParams.get("dob").toString(),"yyyy-mm-dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId(requestParams.get("pan").toString());

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);


			V10 locator = new V10Locator();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			//CreditReportWSInquiryBindingStub stub = new CreditReportWSInquiryBindingStub(url,locator);
			//InquiryResponseType response = stub.getConsumerCreditReport(inquiryRequest);

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			//For Dev we need to enable this
//			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
//			System.setProperty("http.proxyPort", "3128");

//			logger.info(" PAN : Proxy Set Going to call service for Response XML : Start");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
//			logger.info(" PAN : Proxy Set Going to call service for Response XML : End");

			try
			{
			panMap.put("PANCODE", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getReturnCode());
			panMap.put("PANNO", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getPAN());
			panMap.put("FNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getFirstName());
			panMap.put("MNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getMiddleName());
			panMap.put("LNAME", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getLastName());
			}
			catch(NullPointerException ne)
			{
				logger.error(" PAN : EQUIFAX Service : in Exception: Invalid Entries" +ne.getMessage());
				panMap.put("ERRORCODE",response.getReportData().getError()[0].getErrorCode());
				logger.error(" PAN : EQUIFAX Service : in Exception: ErrorInfo code"+response.getReportData().getError()[0].getErrorCode());
				logger.error(" PAN : EQUIFAX Service : in Exception: ErrorInfo Message"+response.getReportData().getError()[0].getErrorMsg());
			}
			
			logger.info(" PAN : Calling EQUIFAX Service : End");
		} 
		catch (Exception e)
		{
			logger.error(" PAN : Calling EQUIFAX Service : in Exception" +e.getMessage());
			e.printStackTrace();
		}
		return panMap;
	}
	private Map<String,String> getDobDetail(Map<String,Object> requestParams,Environment env)
	{
		Map<String,String> dobMap = new HashMap<String,String>();
		try 
		{
			String CUSTOMERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.CustomerId");
			String USERID=env.getProperty("com.qualtech.pan.resource.EQUIFAX.UserId");
			String PASSWORD=env.getProperty("com.qualtech.pan.resource.EQUIFAX.Password");
			String MEMBER_NUMBER=env.getProperty("com.qualtech.pan.resource.EQUIFAX.MemberNumber");
			String PRODUCT_CODE_PAN=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodePAN");
			String PRODUCT_CODE_DOB=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductCodeDOB");
			String SECURITY_CODE=env.getProperty("com.qualtech.pan.resource.EQUIFAX.SecurityCode");
			String PRODUCT_VERSION=env.getProperty("com.qualtech.pan.resource.EQUIFAX.ProductVersion");
			String URL=env.getProperty("com.qualtech.pan.resource.EQUIFAX.url");
			
			logger.info(" DOB : Calling EQUIFAX Service : Start");
			URL url=new URL(URL);
			logger.info(" DOB : url:"+url);
			
			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(Integer.parseInt(CUSTOMERID));
			requestHeaderType.setUserId(USERID);
			requestHeaderType.setPassword(PASSWORD);
			requestHeaderType.setMemberNumber(MEMBER_NUMBER);
			requestHeaderType.setProductCode(PRODUCT_CODE_DOB);//For DOB
			requestHeaderType.setSecurityCode(SECURITY_CODE);
			requestHeaderType.setProductVersion(PRODUCT_VERSION);
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value1);
			requestBodyType.setFirstName(requestParams.get("fname").toString());
			requestBodyType.setMiddleName(requestParams.get("mname").toString());
			requestBodyType.setLastName(requestParams.get("lname").toString());

			String dateInString = getDateInAnyFormat(requestParams.get("dob").toString(),"yyyy-mm-dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId(requestParams.get("pan").toString());
			requestBodyType.setAddrLine1(getAddress(requestParams));
			requestBodyType.setState(new StateCodeOptions(requestParams.get("stateCode").toString().toUpperCase()));
			requestBodyType.setPostal(requestParams.get("postalCode").toString());

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);

			InquiryResponseType inquiryResponse = new InquiryResponseType();
			inquiryResponse.setInquiryRequestInfo(requestBodyType);


			V10 locator = new V10Locator();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();

			//CreditReportWSInquiryBindingStub stub = new CreditReportWSInquiryBindingStub(url,locator);
			//InquiryResponseType response = stub.getConsumerCreditReport(inquiryRequest);

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			//For Dev we need to enable this
//			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
//			System.setProperty("http.proxyPort", "3128");
			

			logger.info(" PAN : Proxy Set Going to call service for Response XML : Start");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);
			logger.info(" PAN : Proxy Set Going to call service for Response XML : End");
			
			try{
			int a = response.getReportData().getVerifyIDResponse().getVidNsdlResponses().length;
			dobMap.put("PANCODE", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[a-1].getNsdlResponse().getReturnCode());
			dobMap.put("PANNO", response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[a-1].getNsdlResponse().getPAN());
			
				try
				{
					dobMap.put("DOBCODE", response.getReportData().getError()[a-1].getErrorCode());
				}
				catch(NullPointerException ne)
				{
					logger.error(" DOB : EQUIFAX Service : in Exception: DOB found" +ne.getMessage());
					dobMap.put("DOB",""+new SimpleDateFormat("dd-MM-yyyy").format(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth()));
					dobMap.put("FNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getFirstName());
					dobMap.put("MNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getMiddleName());
					dobMap.put("LNAME",response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getLastName());
				
				}
			
			}
			catch(NullPointerException ne){
				logger.error(" DOB : EQUIFAX Service : in Exception: Invalid Entries"+ne.getMessage());
				dobMap.put("ERRORCODE",response.getReportData().getError()[0].getErrorCode());
//				logger.info(" DOB : Calling EQUIFAX Service : End");
//				return dobMap;
			}
			
			logger.info(" DOB : Calling EQUIFAX Service : End");
		}
		catch(Exception e)
		{
			logger.error(" DOB : Calling EQUIFAX Service : in Exception"+e.getMessage());
			e.printStackTrace();
		}
		return dobMap;
	}


	private String getAddress(Map<String,Object> requestData)
	{
		String address="";
		try
		{
			String careOf = requestData.get("careOf")!=null?requestData.get("careOf").toString():"";
			String houseNo = requestData.get("houseNo")!=null?requestData.get("houseNo").toString():"";
			String street = requestData.get("street")!=null?requestData.get("street").toString():"";
			String landmark = requestData.get("landmark")!=null?requestData.get("landmark").toString():"";
			String location = requestData.get("location")!=null?requestData.get("location").toString():"";
			String postOffice = requestData.get("postOffice")!=null?requestData.get("postOffice").toString():"";
			String vill_city = requestData.get("vill_city")!=null?requestData.get("vill_city").toString():"";
			String subDistrict = requestData.get("subDistrict")!=null?requestData.get("subDistrict").toString():"";
			String district = requestData.get("district")!=null?requestData.get("district").toString():"";

			address += (careOf.equals("")?"":careOf+" ")+(houseNo.equals("")?"":houseNo+" ")+(street.equals("")?"":street+" "); 
			address += (vill_city.equals("")?"":vill_city+" ")+(location.equals("")?"":location+" ")+(landmark.equals("")?"":landmark+" ");
			address += (postOffice.equals("")?"":postOffice+" ")+(subDistrict.equals("")?"":subDistrict+" ")+(district.equals("")?"":district+" ");
		}
		catch(Exception ex)
		{
			logger.error("ErrorInfo Whill Trying to Create Address" +ex.getMessage());
			address="False";
			ex.printStackTrace();
		}

		return address;
	}


	public String getDateInAnyFormat(String inputDate , String dateFormat)
	{
		String outputDate="";
		Format requiredFormatter = new SimpleDateFormat(dateFormat);
		logger.info("Input Date is : "+inputDate+" And Requested Format is : "+dateFormat);
		try
		{
			DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			Date date = formatter.parse(inputDate);
			outputDate = requiredFormatter.format(date);
			return outputDate;
		}
		catch(Exception ex)
		{
			try
			{
				DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
				Date date = formatter.parse(inputDate);
				outputDate = requiredFormatter.format(date);
				return outputDate;
			}
			catch(Exception ex1)
			{
				try
				{
					DateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
					Date date = formatter.parse(inputDate);
					outputDate = requiredFormatter.format(date);
					return outputDate;
				}
				catch(Exception ex2)
				{
					try
					{
						DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						Date date = formatter.parse(inputDate);
						outputDate = requiredFormatter.format(date);
						return outputDate;
					}
					catch(Exception ex3)
					{
						try
						{
							DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
							Date date = formatter.parse(inputDate);
							outputDate = requiredFormatter.format(date);
							return outputDate;
						}
						catch(Exception ex4)
						{
							try
							{
								DateFormat formatter = new SimpleDateFormat("yyyyddMM");
								Date date = formatter.parse(inputDate);
								outputDate = requiredFormatter.format(date);
								return outputDate;
							}
							catch(Exception ex5)
							{
								try
								{
									DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
									Date date = formatter.parse(inputDate);
									outputDate = requiredFormatter.format(date);
									return outputDate;
								}
								catch(Exception ex6)
								{
									logger.info("Input Date is : "+inputDate);
									ex.printStackTrace();
								}
							}
						}
					}
				}
			}
		}
		return outputDate;
	}
//################## NOT IN USE (Please refer EquifaxServceHelper for equifax 2.0) ##########	
//###########################################################################################	
//########################	CREDIT BUREAU 2.0  ##############################################
	
	@Override
	public Map<String, String> callNeoService(Map<String, Object> requestParams,Environment env,
			CreditBureauTrackerDTO cbTrackerDTO,List<CrifRequestResponseTrackerDTO> crifEqifaxInnerData) {
		return null;
	}

	@Override
	public Map<String, String> callNeoServiceV3(Map<String, Object> requestParams, Environment env,
			CreditBureauTrackerDTO cbTrackerDTO, List<CrifRequestResponseTrackerDTO> crifEqifaxInnerData) {
		// TODO Auto-generated method stub
		return null;
	}
}
