package com.qc.serviceImpl;

import java.io.File;


import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.controller.NeoControllerRest;
import com.qc.service.NeoService;
import com.qc.utils.Base64ArrayUtility;
import com.qc.utils.Commons;

@Service
@Transactional
public class NeoServiceImpl implements NeoService 
{
	private static Logger logger = LogManager.getLogger(NeoControllerRest.class);
	@Autowired Environment env;

	@Override
	public String processDFSRequest(Map requestData, String requestJson) 
	{

		int i=0;
		String methodName=null;
		methodName=Commons.getMethodName();
		logger.info("Came inside "+methodName+"().");
		String leadId="";
		String docType="";
		String fileFormat="";
		String atchmnt="";
		String date="";
		//String gender="";
		String Key1="";
		String ValidationType="";
		boolean X = false;
		StringBuilder responseJson = new StringBuilder();
		try
		{
			if(requestData!=null)
			{
				leadId=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("leadId")).toString().toUpperCase();
				docType=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("docType")).toString().toUpperCase();
				fileFormat=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("fileFormat")).toString().toUpperCase();
				atchmnt=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("atchmnt")).toString().trim();
				date=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("date")).toString().toUpperCase();
				ValidationType=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("ValidationType")).toString();
				Key1=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("Key1")).toString();

				logger.info("leadId is : "+leadId+" and ValidationType is : " + ValidationType);

				String reponseString=requestJson.replaceAll("Request","Response");
				reponseString = reponseString.replace(atchmnt, "12345");
				responseJson.append(reponseString.substring(0,reponseString.indexOf("TransTrackingID")-1));
				responseJson.append("\"TransTrackingID\":\"\",\"TransactionData\": ");

				String path=env.getProperty("com.qualtech.DFS.Path");

				if(leadId!=null && !leadId.equalsIgnoreCase("")
						&& docType!=null && !docType.equalsIgnoreCase("")
						&& fileFormat!=null && !fileFormat.equalsIgnoreCase("")
						&& atchmnt!=null && !atchmnt.equalsIgnoreCase("")
						&& date!=null && !date.equalsIgnoreCase("")
						)
				{
					if(ValidationType!=null && ValidationType.equalsIgnoreCase("DFS"))
					{
						boolean docTypeFlag = false;
						try
						{
							int docId = Integer.parseInt(docType);
							if(docId>0 && docId<178)
							{
								docType=getDocTypeName(docId);
								docTypeFlag=true;
								logger.info("Valid DocType Recived");
							}

						}
						catch(Exception ex)
						{
							logger.info("We are in Exception : Invalid DocType Recived");
						}

						if(docTypeFlag)
						{
							logger.info("All validation passed.");
							String filePath = path+File.separator+leadId;
							String docName = "";

							File dir = new File(filePath);
							dir.mkdirs();
							logger.debug("File path :" +dir);

							if (dir.exists())
							{
								logger.debug("Exists Path is :"+path);
								if (dir.canWrite() )
								{
									//For Development Check
									//String aa = new Base64ArrayUtility().encodeToString("D:/abc.pdf", true);
									//logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
									//logger.info(aa);
									//byte[] bFile = 	new Base64ArrayUtility().decodeToByteArray(aa);

									byte[] bFile = 	new Base64ArrayUtility().decodeToByteArray(atchmnt);
									if(bFile!=null)
									{
										if(fileFormat.equalsIgnoreCase("pdf") || fileFormat.equalsIgnoreCase("tif")
												|| fileFormat.equalsIgnoreCase("jpg") || fileFormat.equalsIgnoreCase("jpeg")
												|| fileFormat.equalsIgnoreCase("bmp") || fileFormat.equalsIgnoreCase("gif")
												|| fileFormat.equalsIgnoreCase("tiff") || fileFormat.equalsIgnoreCase("doc")
												||fileFormat.equalsIgnoreCase("docx") || fileFormat.equalsIgnoreCase("tif")	)
										{
											logger.info("Request for :  "+fileFormat+"  : Start");
											try 
											{
												docName=docType+"_"+leadId+"_"+date+"."+fileFormat;
												FileOutputStream fileOuputStream = new FileOutputStream(""+dir+File.separator+docName);
												fileOuputStream.write(bFile);
												fileOuputStream.close();
												logger.info("File Saving on common Location : Done");
											}
											catch(Exception e)
											{
												logger.error("ErrorInfo occured while converting into PDF"+e.getMessage());
											}    
											responseJson.append("    {	 ");
											responseJson.append("    \"status\": \"200\",	 ");
											responseJson.append("    \"statusDesc\": \"Success\",	 ");

											responseJson.append("    \"filePath\": \""+env.getProperty("com.qualtech.DFS.Path.forResponse")+leadId+"\\\\"+docName+"\",	 ");
											responseJson.append("    \"docName\": \""+docName+"\",	 ");

											responseJson.append(" 	 \"message\": \"Response Successfully Generated\"	 ");
											responseJson.append(" 	 }	 ");
											logger.info("Request for :  PDF  : End");
										}
										else
										{
											logger.info("Failure due to invalid file format");

											responseJson.append("    {	 ");
											responseJson.append("    \"status\": \"102\",	 ");
											responseJson.append("    \"statusDesc\": \"Failure\",	 ");
											responseJson.append(" 	 \"message\": \"Invalid File Format\"	 ");
											responseJson.append(" 	 }	 ");
										}

									}
									else
									{
										logger.info("Failure due to invalid Attachment i.e invalid Base64String");

										responseJson.append("    {	 ");
										responseJson.append("    \"status\": \"102\",	 ");
										responseJson.append("    \"statusDesc\": \"Failure\",	 ");
										responseJson.append(" 	 \"message\": \"Invalid Attachment\"	 ");
										responseJson.append(" 	 }	 ");
									}
								}
								else
								{
									// The directory is not writable
									responseJson.append("    {	 ");
									responseJson.append("    \"status\": \"102\",	 ");
									responseJson.append("    \"statusDesc\": \"Failure\",	 ");
									responseJson.append(" 	 \"message\": \"WebService Not Able to Write Data\"	 ");
									responseJson.append(" 	 }	 ");
									logger.error("Path is not Writable :"+path);
								}
							}
							else
							{
								// The directory is not exists
								responseJson.append("    {	 ");
								responseJson.append("    \"status\": \"102\",	 ");
								responseJson.append("    \"statusDesc\": \"Failure\",	 ");
								responseJson.append(" 	 \"message\": \"WebService Not Able to Access Path\"	 ");
								responseJson.append(" 	 }	 ");
								logger.error("Path is not exists :"+path);
							}
						}
						else
						{
							logger.info("Failure due to the Invalid Documet Type.");

							responseJson.append("    {	 ");
							responseJson.append("    \"status\": \"102\",	 ");
							responseJson.append("    \"statusDesc\": \"Failure\",	 ");
							responseJson.append(" 	 \"message\": \"Invalid Documet Type\"	 ");
							responseJson.append(" 	 }	 ");
						}

					}
					else
					{
						logger.info("Failure due to the invalid request.");

						responseJson.append("    {	 ");
						responseJson.append("    \"status\": \"103\",	 ");
						responseJson.append("    \"statusDesc\": \"Failure\",	 ");
						responseJson.append(" 	 \"message\": \"Invalid request\"	 ");
						responseJson.append(" 	 }	 ");
					}

				}	
				else
				{
					logger.info("Failure due to the invalid request.");

					responseJson.append("    {	 ");
					responseJson.append("    \"status\": \"103\",	 ");
					responseJson.append("    \"statusDesc\": \"Failure\",	 ");
					responseJson.append(" 	 \"message\": \"Invalid request\"	 ");
					responseJson.append(" 	 }	 ");
				}
			}
			else
			{
				logger.info("Failure due to the some internal error.");
				responseJson.append("    {	 ");
				responseJson.append("    \"status\": \"105\",	 ");
				responseJson.append("    \"statusDesc\": \"Failure\",	 ");
				responseJson.append(" 	 \"message\": \"Request JSON is Null/ Invalid\"	 ");
				responseJson.append(" 	 }	 ");
			}
			responseJson.append(" 	 }  ]  }  }  }");
		}
		catch(Exception e)
		{
			responseJson.append(" { \"status\": \"500\", \"statusDesc\":\"Failure\", \"message\":\"ErrorInfo while designing Reponse String\",\"leadId\":\""+leadId+"\" } ");
			logger.error("ErrorInfo while designing Response String:-"+e,new Throwable());
		}
		logger.debug("ReponseString : "+responseJson.toString());
		logger.info("Going outside "+methodName+"().");
		return responseJson.toString();

	}
	private String getDocTypeName(int docId)
	{
		String docName="";
		//Document Type  (AADHAR-01, CREDIT BUREAU-02, PERFIOS-03, TPA-04, Illustration-05, Dob-06,Address-07,
		//Income-08,Photo-09,Bank Statement-10, Income Proof-11, Passport-12, Medical TPA-13, PAN Card-14, Voter ID Card-15, Driving Licence -16
		switch(docId)
		{
		case 1:
			docName="AADHAR";
			break;
		case 2:
			docName="CREDIT BUREAU";
			break;
		case 3:
			docName="PERFIOS";
			break;
		case 4:
			docName="TPA";
			break;
		case 5:
			docName="Illustration";
			break;
		case 6:
			docName="Dob";
			break;
		case 7:
			docName="Address";
			break;
		case 8:
			docName="Income";
			break;
		case 9:
			docName="Photo";
			break;
		case 10:
			docName="Bank Statement";
			break;
		case 11:
			docName="Income Proof";
			break;
		case 12:
			docName="Passport";
			break;
		case 13:
			docName="Medical TPA";
			break;
		case 14:
			docName="PAN Card";
			break;
		case 15:
			docName="Voter ID Card";
			break;
		case 16:
			docName="Driving Licence";
			break;
		case 17:
			docName="Election Commission ID Card";
			break;
		case 18:
			docName="Bank Statement";
			break;
		case 19:
			docName="Telephone_Mobile Bill";
			break;
		case 20:
			docName="Electricity Bill";
			break;
		case 21:
			docName="ESI ID Card";
			break;
		case 22:
			docName="Ex service Man Card";
			break;
		case 23:
			docName="Gas Bill";
			break;
		case 24:
			docName="Lease Agreement  with Rent Receipt";
			break;
		case 25:
			docName="Post Office Savings Account Statement";
			break;
		case 26:
			docName="Ration Card";
			break;
		case 27:
			docName="Senior Citizen Membership Card";
			break;
		case 28:
			docName="Income Tax Return";
			break;
		case 29:
			docName="Salary Slips";
			break;
		case 30:
			docName="Bank Statement";
			break;
		case 31:
			docName="Appointment letter";
			break;
		case 32:
			docName="Audited P&L Acc and Bal Sheets";
			break;
		case 33:
			docName="Computation of Income";
			break;
		case 34:
			docName="Form 16 A";
			break;
		case 35:
			docName="Form 16";
			break;
		case 36:
			docName="School Leaving Certificate or College ID Card";
			break;
		case 37:
			docName="Copy of Credit Card";
			break;
		case 38:
			docName="Credit Card Statement";
			break;
		case 39:
			docName="CreditCard Mandate";
			break;
		case 40:
			docName="Customer Letters";
			break;
		case 41:
			docName="CV of Key Person";
			break;
		case 42:
			docName="Deed of Variation";
			break;
		case 43:
			docName="Diabetes Questionnaire";
			break;
		case 44:
			docName="DigestiveDisorder Questionnaire";
			break;
		case 45:
			docName="DirectDebit Mandate";
			break;
		case 46:
			docName="Diving Questionnaire";
			break;
		case 47:
			docName="Epilepsy Questionnaire";
			break;
		case 48:
			docName="F2F Report";
			break;
		case 49:
			docName="Gynaecological Disorder questionnaire";
			break;
		case 50:
			docName="Housewife Questionnaire";
			break;
		case 51:
			docName="HUF Addennum";
			break;
		case 52:
			docName="Hypertension Questionnaire";
			break;
		case 53:
			docName="Juvenile Questionnaire";
			break;
		case 54:
			docName="Kidney Urinary Disorder Questionnaire";
			break;
		case 55:
			docName="Managing Partner Report";
			break;
		case 56:
			docName="Medical Documents";
			break;
		case 57:
			docName="MedicalRequisiton Form";
			break;
		case 58:
			docName="Merchant Navy Questionnaire";
			break;
		case 59:
			docName="Mining Questionnaire";
			break;
		case 60:
			docName="Miscellaneous Questionnaire";
			break;
		case 61:
			docName="MOA";
			break;
		case 62:
			docName="Mountaineering Questionnaire";
			break;
		case 63:
			docName="Musculoskeletal Questionnaire";
			break;
		case 64:
			docName="MWPA Addennum";
			break;
		case 65:
			docName="Name Change Declaration";
			break;
		case 66:
			docName="Nervous Disorder questionnaire";
			break;
		case 67:
			docName="NRI Questionnaire";
			break;
		case 68:
			docName="Oil and Gas Questionnaire";
			break;
		case 69:
			docName="Others";
			break;
		case 70:
			docName="Parachuting Questionnaire";
			break;
		case 71:
			docName="Partnership Deed";
			break;
		case 72:
			docName="Partnership Questionnaire";
			break;
		case 73:
			docName="Proposal Form";
			break;
		case 74:
			docName="Respiratory Questionnaire";
			break;
		case 75:
			docName="Sales Manager Report";
			break;
		case 76:
			docName="TeleCalling";
			break;
		case 77:
			docName="Tubercolosis Questionnaire";
			break;
		case 78:
			docName="Tumor Questionnaire";
			break;
		case 79:
			docName="Vernacular Declaration";
			break;
		case 80:
			docName="Add docs Employer Employee cases";
			break;
		case 81:
			docName="Adoption Related Documents";
			break;
		case 82:
			docName="Affidavits";
			break;
		case 83:
			docName="Armed Forces Questionnaire";
			break;
		case 84:
			docName="Aviation Questionnaire";
			break;
		case 85:
			docName="Board Resolution";
			break;
		case 86:
			docName="Chest Pain Questionnaire";
			break;
		case 87:
			docName="CO Acceptance";
			break;
		case 88:
			docName="Combo addendum";
			break;
		case 89:
			docName="Company Annual Report";
			break;
		case 90:
			docName="Pan Acknowledgement 1";
			break;
		case 91:
			docName="Premium Receipt";
			break;
		case 92:
			docName="Counter Offer Acceptance";
			break;
		case 93:
			docName="MER";
			break;
		case 94:
			docName="Blood_Urine Test";
			break;
		case 95:
			docName="ECG_TMT";
			break;
		case 96:
			docName="CXR";
			break;
		case 97:
			docName="Additional test";
			break;
		case 98:
			docName="Finacle Print Out";
			break;
		case 99:
			docName="Counter offer rescan";
			break;
		case 100:
			docName="Direct Debit Mandate";
			break;
		case 101:
			docName="DOBProof";
			break;	
		case 102:
			docName="Investor Risk profile";
			break;
		case 103:
			docName="KYC Company Documents";
			break;
		case 104:
			docName="Medical report rescan";
			break;
		case 105:
			docName="NB 10";
			break;
		case 106:
			docName="NB 10A";
			break;
		case 107:
			docName="NB 11";
			break;
		case 108:
			docName="NB09C";
			break;
		case 109:
			docName="NPW 04";
			break;
		case 110:
			docName="NPW 05";
			break;
		case 111:
			docName="NPW4A";
			break;
		case 112:
			docName="NPW5A";
			break;
		case 113:
			docName="PAN document";
			break;
		case 114:
			docName="PEP Questionnaire";
			break;
		case 115:
			docName="Private Tution Questionnaire";
			break;
		case 116:
			docName="Proposal form rescan";
			break;
		case 117:
			docName="Proposal Form_Page1";
			break;
		case 118:
			docName="Proposal Form_Page2";
			break;
		case 119:
			docName="Proposal Form_Page3";
			break;
		case 120:
			docName="Proposal Form_Page4";
			break;
		case 121:
			docName="Proposal Form_Page5";
			break;
		case 122:
			docName="Proposal Form_Page6";
			break;
		case 123:
			docName="Proposal Form_Page7";
			break;
		case 124:
			docName="Regular Income Proofs";
			break;
		case 125:
			docName="Rescan others";
			break;
		case 126:
			docName="UW 01";
			break;
		case 127:
			docName="UW 02";
			break;
		case 128:
			docName="Additional medical test";
			break;
		case 129:
			docName="Blood Urine test";
			break;
		case 130:
			docName="Cancelled Cheque";
			break;
		case 131:
			docName="Car Insurance Papers";
			break;
		case 132:
			docName="ECG TMT";
			break;
		case 133:
			docName="IT Return";
			break;
		case 134:
			docName="Medical Reports";
			break;
		case 135:
			docName="Salary Slip";
			break;
		case 136:
			docName="UW 04";
			break;
		case 137:
			docName="Company Profit Loss Account";
			break;
		case 138:
			docName="Spouse Rider Questionnaire";
			break;
		case 139:
			docName="Underwriting Worksheet";
			break;
		case 140:
			docName="Proposal Form_Page8";
			break;
		case 141:
			docName="Copy of Bank Book Statement";
			break;
		case 142:
			docName="Marriage Card";
			break;
		case 143:
			docName="Payor Rider Questionnaire";
			break;
		case 144:
			docName="Policy Pack Acknowledgement";
			break;
		case 145:
			docName="Relationship Proof";
			break;
		case 146:
			docName="Company AML Documents";
			break;
		case 147:
			docName="Key Person A and B Questionnaire";
			break;
		case 148:
			docName="AML Document";
			break;
		case 149:
			docName="Customer Letter";
			break;
		case 150:
			docName="Fact Finder";
			break;
		case 151:
			docName="Policy Reissue Letter";
			break;
		case 152:
			docName="Financial and Company Documents";
			break;
		case 153:
			docName="Financial Documents";
			break;
		case 154:
			docName="Max Life communication";
			break;
		case 155:
			docName="Reinsurance Decision";
			break;
		case 156:
			docName="Welcome Calling Sheet";
			break;
		case 157:
			docName="Email Communication";
			break;
		case 158:
			docName="Payment Acknowledgement";
			break;
		case 159:
			docName="Communication Address Proof";
			break;
		case 160:
			docName="ID Proof";
			break;
		case 161:
			docName="Permanent Address Proof";
			break;
		case 162:
			docName="BI Document";
			break;
		case 163:
			docName="Signed ECS Form";
			break;
		case 164:
			docName="PayorPhoto";
			break;
		case 165:
			docName="PayorPAN";
			break;
		case 166:
			docName="Counter Offer Rescan";
			break;
		case 167:
			docName="Medical Report Rescan";
			break;
		case 168:
			docName="Proposal Form Rescan";
			break;
		case 169:
			docName="Rescan Others";
			break;
		case 170:
			docName="Resume";
			break;
		case 171:
			docName="Office Head Report";
			break;
		case 172:
			docName="Internal Agent Checklist";
			break;
		case 173:
			docName="LA Photo with Agent";
			break;
		case 174:
			docName="Payor Adhaar";
			break;
		case 175:
			docName="Payor Enrolment";
			break;
		case 176:
			docName="Proposer Adhaar";
			break;
		case 177:
			docName="Proposer Enrolment";
			break;
		default :
			docName="Invalid";
		}
		return docName;
	}
}
