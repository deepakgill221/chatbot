package com.qc.serviceImpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.qc.api.request.getdemoauthrequest.ApiRequestGetDemoAuthRequest;
import com.qc.api.response.StringConstants;
import com.qc.api.common.MsgInfo;
import com.qc.api.response.getdemoauthrequest.ApiResponseGetDemoAuthRequest;
import com.qc.api.response.getdemoauthrequest.PayloadResGetDemoAuthRequest;
import com.qc.api.response.getdemoauthrequest.ResponseGetDemoAuthRequest;
import com.qc.service.GetDemoAuthRequestService;
import com.qc.utils.XTrustProvider;

@Service
public class GetDemoAuthRequestServiceImpl implements GetDemoAuthRequestService
{
	private static Logger logger = LogManager.getLogger(GetDemoAuthRequestServiceImpl.class);
	
	@Override
	public ApiResponseGetDemoAuthRequest getDemoAuthRequestService(ApiRequestGetDemoAuthRequest apiRequest) {

		logger.info("getDemoAuthRequestService service : Start");
		
		String output = new String();
		StringBuilder request = new StringBuilder();
		StringBuilder result = new StringBuilder();
		URL url = null;
		MsgInfo msginfo = new MsgInfo();
		
		ResourceBundle res = ResourceBundle.getBundle("application");
		String serviceurl = res.getString("GetDemoAuthRequest.url");
		
		HttpURLConnection conn = null;
		String DevMode = "N";
		JSONObject object=null;
		
		ResponseGetDemoAuthRequest response = new ResponseGetDemoAuthRequest();
		ApiResponseGetDemoAuthRequest apiResponse =new ApiResponseGetDemoAuthRequest();
		PayloadResGetDemoAuthRequest payloadResGetDemoAuthRequest = new PayloadResGetDemoAuthRequest();
		
		request.append("            {   ");
		request.append("	        \"request\": {  ");
		request.append("		    \"header\": {   ");   
		request.append("			\"soaCorrelationIdd\": \" " +apiRequest.getRequest().getHeader().getSoaCorrelationId()  +"    \", ");
		request.append("			\"soaMsgVersion\": \"" +apiRequest.getRequest().getHeader().getSoaMsgVersion()  +"\",  ");
		request.append("			\"soaAppId\": \"" +apiRequest.getRequest().getHeader().getSoaAppId()  +"\" ");
		request.append("		    },  ");
		request.append("	     	\"requestData\": {  ");
		request.append("			\"requestPayload\": { ");
		request.append("			\"transactions\": [{  ");
		request.append("			\"aadhaarNumber\": \"" +apiRequest.getRequest().getPayload().getAadhaarNumber()  +"\",  ");
		request.append("			\"AadhaarName\": \"" +apiRequest.getRequest().getPayload().getAadhaarName()  +"\",  ");
		request.append("			\"strYear\": \"" +apiRequest.getRequest().getPayload().getStrYear()  +"\",  ");
		request.append("			\"strGender\": \"" +apiRequest.getRequest().getPayload().getStrGender()  +"\",  ");
		request.append("			\"strPiMatchStrategy\": \"" +apiRequest.getRequest().getPayload().getStrPiMatchStrategy()  +"\",  ");
		request.append("			\"strPiMatchValue\": \"" +apiRequest.getRequest().getPayload().getStrPiMatchValue()  +"\", ");
		request.append("			\"strAddressValue\": \"" +apiRequest.getRequest().getPayload().getStrAddressValue()  +"\",  ");
		request.append("			\"strPfaMatchStrategy\": \"" +apiRequest.getRequest().getPayload().getStrPfaMatchStrategy()  +"\",  ");
		request.append("			\"strPfaMatchValue\": \"" +apiRequest.getRequest().getPayload().getStrPfaMatchValue()  +"\",  ");
		request.append("			\"strCareOf\": \"" +apiRequest.getRequest().getPayload().getStrCareOf()  +"\",  ");
		request.append("			\"strBuilding\": \"" +apiRequest.getRequest().getPayload().getStrBuilding()  +"\",   ");
		request.append("			\"strLandmark\": \"" +apiRequest.getRequest().getPayload().getStrLandmark()  +"\",   ");
		request.append("			\"strStreet\": \"" +apiRequest.getRequest().getPayload().getStrStreet()  +"\",   ");
		request.append("			\"strLocality\": \"" +apiRequest.getRequest().getPayload().getStrLocality()  +"\", ");
		request.append("			\"strPoName\": \"" +apiRequest.getRequest().getPayload().getStrPoName()  +"\",   ");
		request.append("			\"strVillage\": \"" +apiRequest.getRequest().getPayload().getStrVillage()  +"\",   ");
		request.append("			\"strSubdist\": \"" +apiRequest.getRequest().getPayload().getStrSubdist()  +"\",   ");
		request.append("			\"strDistrict\": \"" +apiRequest.getRequest().getPayload().getStrDistrict()  +"\",   ");
		request.append("			\"strState\": \"" +apiRequest.getRequest().getPayload().getStrState()  +"\",   ");
		request.append("			\"strPincode\": \"" +apiRequest.getRequest().getPayload().getStrPincode()  +"\",  ");
		request.append("			\"strCountry\": \"" +apiRequest.getRequest().getPayload().getStrCountry()  +"\",    ");
		request.append("			\"type\": \"" +apiRequest.getRequest().getPayload().getType()  +"\"   ");
		request.append("			}]   ");
		request.append("			}    ");
		request.append("			}    ");
		request.append("			}    ");
		request.append("			}    ");
				
		
		try 
		{
			
			XTrustProvider xTrustProvider =new XTrustProvider();
			xTrustProvider.install();
			url = new URL(serviceurl);
			Proxy proxy;
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(request.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}

			int apiResponseCode = conn.getResponseCode();
			logger.info("content type -->"+ conn.getContentType());
			logger.info("http status code "+ conn.getResponseCode());
		
		if (apiResponseCode == 200) 
		{
			try{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
			object = new JSONObject(result.toString());
			if(object != null){
				
				payloadResGetDemoAuthRequest.setAuthenticateStatus((object.getJSONObject("Response").getJSONObject("responseData").getJSONObject("ResponsePayload").getJSONArray("Transactions").getJSONObject(0).getJSONObject("transactionData").get("AuthenticateStatus")).toString());
				msginfo.setMsgCode(StringConstants.C200);
				msginfo.setMsg(StringConstants.SUCCESS);
				msginfo.setMsgDescription(StringConstants.C200DESC);
				logger.info(StringConstants.C200DESC);
			}
			}
			catch (Exception e) {
				msginfo.setMsgCode(StringConstants.C200);
				msginfo.setMsg(StringConstants.SUCCESS);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C200DESC);
				logger.error("json conversion have some error : "+e);
			}	
		}else
		{
			msginfo.setMsgCode(StringConstants.C601);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C601DESC);
			logger.info(StringConstants.C601DESC);
		}
		
		}
		catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		
		response.setMsgInfo(msginfo);
		response.setPayload(payloadResGetDemoAuthRequest);
		
		apiResponse.setResponse(response);
		logger.info("getDemoAuthRequestService  service : End");
		return apiResponse;
	
	}

}
