package com.qc.serviceImpl;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.otp.ApiRequestOtp;
import com.qc.api.response.StringConstants;
import com.qc.api.response.otp.ApiResponseOtpDetails;
import com.qc.api.response.otp.PayloadOtpDetails;
import com.qc.api.response.otp.ResponseOtpDetails;
import com.qc.db.dao.OtpDao;
import com.qc.service.OtpService;


@Service
public class OtpServiceImpl implements OtpService
{
	private static Logger logger = LogManager.getLogger(OtpServiceImpl.class);

	@Autowired OtpDao otpDao;
	private final String FAILURE="FAILURE";
	private final String OTP="OTP";
	private final String STATUS="STATUS";
	private final String MSG="MSG";
	private final String N="N";
	private final String AN="AN";
	private final String A="A";
	private final String ANS="ANS";

	private ArrayList<String> strArr=null;

	//	***************************SINGLETON******************************************
	private OtpServiceImpl()
	{
		strArr=new ArrayList<String>();
		strArr.add(N);
		strArr.add(AN);
		strArr.add(A);
		strArr.add(ANS);
	}
	/*private static class OTPServiceImplHelper
	{
		private static final OTPServiceImpl INSTANCE=new OTPServiceImpl();
	}

	public static OTPServiceImpl getInstance()
	{
		return OTPServiceImplHelper.INSTANCE;
	}
*/	@Override
	public ApiResponseOtpDetails generateOTPProcess(ApiRequestOtp apiRequest)
	{
		logger.info("generateOTPProcess service : Start");
		ApiResponseOtpDetails response = new ApiResponseOtpDetails();
		MsgInfo msginfo = new MsgInfo();
		PayloadOtpDetails resPayload= new PayloadOtpDetails();
		ResponseOtpDetails responseAgentDetails = new ResponseOtpDetails();
		logger.info("OTPServiceImpl -->  Starts...");
		try
		{
			int noOfchars=0;	
			//			****************COMMON*************************

			resPayload.setStatus("FAILURE");
			resPayload.setOtp("");
			//			*****************************************

			String no_of_charsStr=apiRequest.getRequest().getRequestData().getNo_of_chars();
			String type=apiRequest.getRequest().getRequestData().getType();
			no_of_charsStr=isNullThanBlank(no_of_charsStr);

			if("".equals(no_of_charsStr))
			{
				resPayload.setMsg("Please enter Number of Characters you need.");
			}
			else
			{
				try
				{
					noOfchars=Integer.parseInt(no_of_charsStr);
					if(noOfchars<4)
					{
						resPayload.setMsg("Please enter Number of Characters more than 3.");
					}
				}
				catch(NumberFormatException ne)
				{
					resPayload.setMsg("Please enter only numeric Number of Characters.");
				}
			}

			type=isNullThanBlank(type);
			type=type.toUpperCase();

			if("".equals(no_of_charsStr))
			{
				resPayload.setMsg("Please enter Type.");
			}
			else
			{
				if(!strArr.contains(type))
				{
					resPayload.setMsg("Please enter valid Type.");
				}
			}
			if(noOfchars>3)
			{
				if(N.equals(type))
				{
					resPayload=otpDao.call_Numeric(noOfchars);
				}
				else if(AN.equals(type))
				{
					resPayload=otpDao.call_AlphaNumeric(noOfchars);
				}
				else if(ANS.equals(type))
				{
					resPayload=otpDao.call_AlphaNumericSpecial(noOfchars);
				}
				else if(A.equals(type))
				{
					resPayload=otpDao.call_Alpha(noOfchars);
				}
			}

			if(resPayload!=null && !resPayload.equals(""))
			{
				//=new PayloadOtpDetails();

				msginfo.setMsgCode(StringConstants.C200);
				msginfo.setMsg(StringConstants.SUCCESS);
				msginfo.setMsgDescription(StringConstants.C200DESC);
				logger.info(StringConstants.C200DESC);
			}
			else
			{
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C601DESC);
				logger.info(StringConstants.C601DESC);
			}
		}
		catch(Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseAgentDetails.setMsginfo(msginfo);
		responseAgentDetails.setPayload(resPayload);
		response.setResponse(responseAgentDetails);
		logger.info("OtpGeneration service : End");
		return response;
	}

	private String isNullThanBlank(String str)
	{
		String temp = str;
		temp = (temp == null) ? "" : temp.trim();
		return temp;
	}


}
