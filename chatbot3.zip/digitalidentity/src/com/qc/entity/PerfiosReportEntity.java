package com.qc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.qc.dto.PERFIOSSERVICENAME;
import com.qc.dto.PERFIOSVERSION;

@Entity
@Table(name = "PERFIOS_REPORT_TRACKING")
public class PerfiosReportEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2501248017120078532L;
	private Long id;
	private PERFIOSSERVICENAME perfiosServiceName;
	private PERFIOSVERSION perfiosVersion;
	private String apiRequestJson;
	private String apiResponseJson;
	private String providerApiRequest;
	private String providerApiResponse;
	private String pdfByteArray;
	private Date createdTime;
	private Date updatedTime;
	private String correlationId;
	private String remark;
	private String isPdfGenerated;
	private String serverIpAddress;
	private String serverHostName;
	private String outerTrackerId;
	private String providerStatusCode;
	private String transactionNo;
	private String clientId;

	@Id
	@Column(name = "PS_ID",unique=true,nullable=false)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "PS_API_NAME")
	@Enumerated(EnumType.STRING)
	public PERFIOSSERVICENAME getPerfiosServiceName() {
		return perfiosServiceName;
	}

	public void setPerfiosServiceName(PERFIOSSERVICENAME perfiosServiceName) {
		this.perfiosServiceName = perfiosServiceName;
	}

	@Column(name = "PS_VERSION")
	@Enumerated(EnumType.STRING)
	public PERFIOSVERSION getPerfiosVersion() {
		return perfiosVersion;
	}

	public void setPerfiosVersion(PERFIOSVERSION perfiosVersion) {
		this.perfiosVersion = perfiosVersion;
	}

	@Column(name = "PS_API_REQUEST_JSON")
	public String getApiRequestJson() {
		return apiRequestJson;
	}

	public void setApiRequestJson(String apiRequestJson) {
		this.apiRequestJson = apiRequestJson;
	}

	@Column(name = "PS_API_RESPONSE_JSON")
	public String getApiResponseJson() {
		return apiResponseJson;
	}

	public void setApiResponseJson(String apiResponseJson) {
		this.apiResponseJson = apiResponseJson;
	}

	@Column(name = "PS_PROVIDER_API_REQUEST")
	public String getProviderApiRequest() {
		return providerApiRequest;
	}

	public void setProviderApiRequest(String providerApiRequest) {
		this.providerApiRequest = providerApiRequest;
	}

	@Column(name = "PS_PROVIDER_API_RESPONSE")
	public String getProviderApiResponse() {
		return providerApiResponse;
	}

	public void setProviderApiResponse(String providerApiResponse) {
		this.providerApiResponse = providerApiResponse;
	}

	@Column(name = "PS_PDF_BYTE_ARRAY")
	public String getPdfByteArray() {
		return pdfByteArray;
	}

	public void setPdfByteArray(String pdfByteArray) {
		this.pdfByteArray = pdfByteArray;
	}

	@Column(name = "CREATED_TIME")
	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@Column(name = "UPDATED_TIME")
	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	@Column(name = "CORRELATION_ID")
	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	@Column(name = "REMARK")
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "IS_PDF_GENERATED")
	public String getIsPdfGenerated() {
		return isPdfGenerated;
	}

	public void setIsPdfGenerated(String isPdfGenerated) {
		this.isPdfGenerated = isPdfGenerated;
	}

	@Column(name = "SERVER_IP_ADDRESS")
	public String getServerIpAddress() {
		return serverIpAddress;
	}

	public void setServerIpAddress(String serverIpAddress) {
		this.serverIpAddress = serverIpAddress;
	}

	@Column(name = "SERVER_HOST_NAME")
	public String getServerHostName() {
		return serverHostName;
	}

	public void setServerHostName(String serverHostName) {
		this.serverHostName = serverHostName;
	}

	@Column(name = "OUTER_TRACKER_ID")
	public String getOuterTrackerId() {
		return outerTrackerId;
	}

	public void setOuterTrackerId(String outerTrackerId) {
		this.outerTrackerId = outerTrackerId;
	}

	@Column(name = "PROVIDER_STATUS_CODE")
	public String getProviderStatusCode() {
		return providerStatusCode;
	}

	public void setProviderStatusCode(String providerStatusCode) {
		this.providerStatusCode = providerStatusCode;
	}

	@Column(name = "TRANSACTION_NO")
	public String getTransactionNo() {
		return transactionNo;
	}

	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}

	@Column(name = "CLIENT_ID")
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	

}
