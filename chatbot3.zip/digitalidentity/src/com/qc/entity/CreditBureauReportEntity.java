package com.qc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.qc.dto.CBSERVICEPROVIDER;
import com.qc.dto.CBVERSION;

@Entity
@Table(name = "CB_REPORT_TRACKING")
public class CreditBureauReportEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6247137439185816659L;
	private Long id;
	private CBSERVICEPROVIDER cbServiceProvider;
	private CBVERSION cbVersion;
	private String apiRequestJson;
	private String apiResponseJson;
	private String providerApiRequest;
	private String providerApiResponse;
	private String pdfByteArray;
	private Date createdTime;
	private Date updatedTime;
	private String correlationId;
	private String remark;
	private String isPdfGenerated;
	private String serverIpAddress;
	private String serverHostName;
	private String outerTrackerId;
	private String innerTrackerId;
	private String providerStatusCode;
	private String policyNo;
	private String serviceType;
	//private CreditBureauApiParameterEntity cbApiParameter;

	@Id
	@Column(name = "CB_ID",unique=true,nullable=false)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "CB_SERVICE_PROVIDER")
	@Enumerated(EnumType.STRING)
	public CBSERVICEPROVIDER getCbServiceProvider() {
		return cbServiceProvider;
	}

	public void setCbServiceProvider(CBSERVICEPROVIDER cbServiceProvider) {
		this.cbServiceProvider = cbServiceProvider;
	}

	@Column(name = "CB_VERSION")
	@Enumerated(EnumType.STRING)
	public CBVERSION getCbVersion() {
		return cbVersion;
	}

	public void setCbVersion(CBVERSION cbVersion) {
		this.cbVersion = cbVersion;
	}

	@Column(name = "CB_API_REQUEST_JSON")
	public String  getApiRequestJson() {
		return apiRequestJson;
	}

	public void setApiRequestJson(String  apiRequestJson) {
		this.apiRequestJson = apiRequestJson;
	}

	@Column(name = "CB_API_RESPONSE_JSON")
	public String  getApiResponseJson() {
		return apiResponseJson;
	}

	public void setApiResponseJson(String  apiResponseJson) {
		this.apiResponseJson = apiResponseJson;
	}

	@Column(name = "CB_PROVIDER_API_REQUEST")
	public String  getProviderApiRequest() {
		return providerApiRequest;
	}

	public void setProviderApiRequest(String  providerApiRequest) {
		this.providerApiRequest = providerApiRequest;
	}

	@Column(name = "CB_PROVIDER_API_RESPONSE")
	public String  getProviderApiResponse() {
		return providerApiResponse;
	}

	public void setProviderApiResponse(String  providerApiResponse) {
		this.providerApiResponse = providerApiResponse;
	}

	@Column(name = "CREATED_TIME")
	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@Column(name = "UPDATED_TIME")
	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	@Column(name = "REMARK")
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "PDF_BYTE_ARRAY")
	public String  getPdfByteArray() {
		return pdfByteArray;
	}

	public void setPdfByteArray(String  pdfByteArray) {
		this.pdfByteArray = pdfByteArray;
	}

	@Column(name = "IS_PDF_GENERATED")
	public String getIsPdfGenerated() {
		return isPdfGenerated;
	}

	public void setIsPdfGenerated(String isPdfGenerated) {
		this.isPdfGenerated = isPdfGenerated;
	}

	@Column(name = "CORRELATION_ID")
	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	@Column(name = "SERVER_IP_ADDRESS")
	public String getServerIpAddress() {
		return serverIpAddress;
	}

	public void setServerIpAddress(String serverIpAddress) {
		this.serverIpAddress = serverIpAddress;
	}

	@Column(name = "SERVER_HOST_NAME")
	public String getServerHostName() {
		return serverHostName;
	}

	public void setServerHostName(String serverHostName) {
		this.serverHostName = serverHostName;
	}

	@Column(name = "OUTER_TRACKER_ID")
	public String getOuterTrackerId() {
		return outerTrackerId;
	}

	public void setOuterTrackerId(String outerTrackerId) {
		this.outerTrackerId = outerTrackerId;
	}

	@Column(name = "INNER_TRACKER_ID")
	public String getInnerTrackerId() {
		return innerTrackerId;
	}

	public void setInnerTrackerId(String innerTrackerId) {
		this.innerTrackerId = innerTrackerId;
	}

	@Column(name = "PROVIDER_STATUS_CODE")
	public String getProviderStatusCode() {
		return providerStatusCode;
	}

	public void setProviderStatusCode(String providerStatusCode) {
		this.providerStatusCode = providerStatusCode;
	}

	@Column(name = "POLICY_NO")
	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Column(name = "SERVICE_TYPE")
	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	
/*
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "cbReport")
	@Cascade({ CascadeType.ALL, CascadeType.SAVE_UPDATE })
	@NotFound(action = NotFoundAction.IGNORE)
	@OnDelete(action = OnDeleteAction.CASCADE)
	public CreditBureauApiParameterEntity getCbApiParameter() {
		return cbApiParameter;
	}

	public void setCbApiParameter(CreditBureauApiParameterEntity cbApiParameter) {
		this.cbApiParameter = cbApiParameter;
	}*/

	
}
