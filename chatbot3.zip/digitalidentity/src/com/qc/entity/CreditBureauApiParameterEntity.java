/*package com.qc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name="CREDIT_BUREAU_API_PARAMETER")
public class CreditBureauApiParameterEntity implements Serializable
{
	*//**
	 * 
	 *//*
	private static final long serialVersionUID = 4337088963738409793L;
	private Long id;
	private CreditBureauReportEntity cbReport;
	private String fName;
	private String mName;
	private String lName;
	// private String ;
	
	@Id
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CB_ID", nullable = true)
	@ForeignKey(name = "FK_ID")
	public CreditBureauReportEntity getCbReport() {
		return cbReport;
	}

	public void setCbReport(CreditBureauReportEntity cbReport) {
		this.cbReport = cbReport;
	}

	@Column(name = "F_NAME")
	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	@Column(name = "M_NAME")
	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	@Column(name = "L_NAME")
	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

}
*/