package com.qc.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.otp.ApiRequestOtp;
import com.qc.api.response.StringConstants;
import com.qc.api.response.otp.ApiResponseOtpDetails;
import com.qc.api.response.otp.ResponseOtpDetails;
import com.qc.service.NeoService;
import com.qc.service.OtpService;
import com.qc.utils.Commons;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping(value = "/services")
@Api(value="NEO", description="NEO service for maxlifeinsurance.com",tags = {"NEO"})
public class PanValidationRestController {
	
	private static Logger logger = LogManager.getLogger(PanValidationRestController.class);

	@Autowired OtpService otpService;
	@ApiOperation(notes = "OtpGeneration service", value = "OtpGeneration service!", nickname = "")
	@RequestMapping(value = "/WebService/GetNeoPANRequest", method = RequestMethod.POST , consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseOtpDetails GetNeoPANRequest(@Valid @RequestBody ApiRequestOtp apiRequest) 
	{
		logger.info("ControllerRest :: otpGenerateAction :: Start");
		ApiResponseOtpDetails apiResponse = new ApiResponseOtpDetails();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try 
		{
			ThreadContext.push("OtpGeneration : "+UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info("RequestJson :: "+ow.writeValueAsString(apiRequest));
		}
		catch (JsonProcessingException e1) 
		{
			logger.info("Error While converting request data to json : "+e1);
		}
		catch(Exception ex)
		{
			logger.info("Error While mapping response header : "+ex);
		}
		try
		{
			/**Requirement - 12 June 2017 : get data from Proc shared by DB dteam (Vidya Shanker pandey)
			 * on behalf of agent id and online channel as request parameter
			**/
			if(apiRequest != null 
					&&  apiRequest.getRequest().getRequestData() != null  
					&& apiRequest.getRequest().getRequestData().getNo_of_chars() != null 
					&& !apiRequest.getRequest().getRequestData().getNo_of_chars().isEmpty()
					&& apiRequest.getRequest().getRequestData().getType() != null 
					&& !apiRequest.getRequest().getRequestData().getType().isEmpty()
					)
			{
				logger.debug("Controller to service call : Start");
				apiResponse = otpService.generateOTPProcess(apiRequest);
				logger.debug("Controller to service call : End");
				apiResponse.getResponse().setHeader(header);
			}
			else
			{
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseOtpDetails(new ResponseOtpDetails(header, msgInfo, null));
			}
		}
		catch (Exception e) 
		{
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC+" : "+e);
			apiResponse = new ApiResponseOtpDetails(new ResponseOtpDetails(header, msgInfo, null));
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
//		try 
//		{
//			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//			logger.debug("ResponseJson :: "+ow.writeValueAsString(apiResponse));
//		}
//		catch (Exception ex) 
//		{
//			logger.info("Error While converting response data to json : "+ex);
//		}
		logger.info("ControllerRest :: otpGenerateAction :: End");
		return apiResponse;
	}
	

	
}
