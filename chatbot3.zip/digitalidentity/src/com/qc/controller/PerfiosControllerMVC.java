package com.qc.controller;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.qc.entity.PerfiosEntity;
import com.qc.service.PerfiosService;

@Controller
public class PerfiosControllerMVC {
	private static Logger logger = LogManager.getLogger(PerfiosControllerMVC.class);
	
	@Autowired HttpSession session;
	@Autowired PerfiosService perfiosService;
	
	@Autowired Environment env;
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = { "/perfios/api/v1/StartProcess" })
	public String perfiosStartProcess(@ModelAttribute PerfiosEntity perfiosEntity)
	{
		logger.info("PerfiosSprBootRest | perfiosStartProcess() | :- START");
		try
		{
			perfiosEntity.setVenderId("maxlifeInsurance");
			perfiosEntity.setEmailId((!perfiosEntity.getEmailId().equalsIgnoreCase(""))?perfiosEntity.getEmailId():"maxLifeInsuranceSample@perfios.com");
			perfiosEntity.setDestination((!perfiosEntity.getDestination().equalsIgnoreCase(""))?perfiosEntity.getDestination():"netbankingFetch");
			perfiosEntity.setReturnUrl(env.getProperty("perfios.start.process.return.url")+"/perfios/api/v1/StartProcessResponse?perfiosTransId=%s");
			perfiosEntity = perfiosService.getStartProcessData(perfiosEntity);
			session.setAttribute("PerfiosEntity", perfiosEntity);
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		logger.info("PerfiosSprBootRest | perfiosStartProcess() | :- END");
		return "perfiosStartProcess";
	}
	
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = { "/perfios/api/v1/StartProcessResponse" })
	public String perfiosStartProcessResponse(@ModelAttribute PerfiosEntity perfiosEntity)
	{
		logger.info("PerfiosSprBootRest | perfiosStartProcessResponse() | :- START");
		try
		{
			session.setAttribute("PerfiosEntity", perfiosEntity);
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		logger.info("PerfiosSprBootRest | perfiosStartProcessResponse() | :- END");
		return "perfiosStartProcessResponse";
	}
}
