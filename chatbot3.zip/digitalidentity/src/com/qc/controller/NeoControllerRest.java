package com.qc.controller;

import java.util.List;



import java.util.Map;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.service.NeoService;
import com.qc.utils.Commons;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/neo/api")
@Api(value="NEO", description="NEO service for maxlifeinsurance.com",tags = {"NEO"})
public class NeoControllerRest 
{
	private static Logger logger = LogManager.getLogger(NeoControllerRest.class);

	@Autowired NeoService neoService;
	@ApiOperation(notes = "This service will return DFS response for success and will return failure response for invalid request!!", value = "Get DFS with given request!", nickname = "")
	@RequestMapping(value = "/v1/dfsrequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getDFSRequestData(@RequestBody String requestJSON) 
	{
		logger.debug("NeoControllerRest:: getDFSRequestData :: Start");
		Map requestData = null;
		String returnOutput="";  
		try
		{
			ThreadContext.push("DFSRequest : "+UniqueId.getUniqueId());
			String methodName=Commons.getMethodName();  
			logger.debug(">>>>>>>>>>>>>>>>>>>>>Came inside>>>>>>>>>>>>>>>>>>>>> "+methodName); 
			try
			{
				logger.debug("Request Json : "+requestJSON);
				try 
				{
					logger.info(requestJSON.substring(0,requestJSON.indexOf("atchmnt")) +" -- "+requestJSON.substring(requestJSON.indexOf("date")),requestJSON.length() );
				} catch (Exception e) {
				}
				logger.debug("Request Json going to parse : Start");
				requestData=Commons.getGsonData(requestJSON);
				String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				ThreadContext.push(TransTrackingID);
				logger.debug("Request Json going to parse : End");
			} 
			catch (Exception e)
			{
				logger.error("We are in Exception while converting request json to Map : "+e);
			}
			try
			{  
				logger.debug("call service : Start"); 
				returnOutput=neoService.processDFSRequest(requestData,requestJSON);
				logger.debug("call service : End"); 
			}
			catch(Exception e)
			{
				returnOutput="{\"status\":\"FAIL\",\"message\":\"ErrorInfo While Reponse\"}";
				logger.error("ErrorInfo while generating response from Database inside "+methodName+"():-"+e);
			}
			logger.debug("Response Json : "+returnOutput);
			logger.info(">>>>>>>>>>>>>>>>>>>>>Going outside>>>>>>>>>>>>>>>>>>>>> "+methodName+"().");
		}
		catch(Exception ex)
		{
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.debug("NeoControllerRest:: getDFSRequestData :: End");
		return returnOutput;
	}

}
