package com.qc.controller;

import java.io.IOException;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.db.dao.PerfiosReportDBDao;
import com.qc.dto.PERFIOSSERVICENAME;
import com.qc.dto.PERFIOSVERSION;
import com.qc.entity.PerfiosEntity;
import com.qc.entity.PerfiosReportEntity;
import com.qc.entity.PerfiosXMLEntity;
import com.qc.service.PerfiosService;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/perfios/api/v1")
@Api(value="Perfios", description="Perfios service for maxlifeinsurance.com",tags = {"Perfios"})
public class PerfiosControllerRest 
{
	 private static Logger logger = LogManager.getLogger(PerfiosControllerRest.class);
	
	@Autowired 
	PerfiosService perfiosService;
	@Autowired
	PerfiosReportDBDao perfiosReportDBDao; 
	@Autowired
	Environment env;
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/txnstatusrequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosTransactionStatus(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		logger.info("PerfiosControllerRest | perfiosTransactionStatus() | :- START");
		ThreadContext.push("TxnStatusRequest : "+UniqueId.getUniqueId());
		logger.info("PerfiosSprBootRest | perfiosTransactionStatus() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		final PerfiosReportEntity perfiosReportEntity = new PerfiosReportEntity();
		try
		{
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			try
			{
				perfiosReportEntity.setApiRequestJson(convertPojoToXml(perfiosXMLEntity));
				perfiosReportEntity.setCorrelationId(""+perfiosXMLEntity.getTrackerId());
				perfiosReportEntity.setCreatedTime(new Date());
				perfiosReportEntity.setOuterTrackerId(""+UniqueId.getUniqueId());
				perfiosReportEntity.setPerfiosServiceName(PERFIOSSERVICENAME.TRANSACTION_STATUS);
				perfiosReportEntity.setPerfiosVersion(PERFIOSVERSION.PERFIOS_V1);
				perfiosReportEntity.setTransactionNo(perfiosXMLEntity.getPerfiosTransId());
				perfiosReportEntity.setClientId(perfiosXMLEntity.gettId());
			}
			catch(Exception e)
			{
				logger.error("Exception while setting request data for perfios tracker!!",e);
			}
			/*
			 * Updating Perfios request response to  tracker
			 * Ends
			 */
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setTxnStatusUrl(env.getProperty("perfios.transaction.status.url"));
			
			perfiosEntity = perfiosService.getTransactionStatus(perfiosEntity,perfiosReportEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}
		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Starts
		 */
		perfiosReportEntity.setUpdatedTime(new Date());
		perfiosReportEntity.setApiResponseJson(perfiosEntity.getResponseXML());
		new Thread(new Runnable() 
		{
		    public void run() 
		    {
		    	runningBackgroundProcess(perfiosReportEntity);
		    }
		}).start();
		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Ends
		 */
		logger.info("PerfiosControllerRest | perfiosTransactionStatus() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/retrievereportrequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosRetrieveReportRequest(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("RetrieveReportRequest : "+UniqueId.getUniqueId());
		logger.info("PerfiosControllerRest | perfiosRetrieveReportRequest() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		final PerfiosReportEntity perfiosReportEntity = new PerfiosReportEntity();
		try
		{
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			try
			{
				perfiosReportEntity.setApiRequestJson(convertPojoToXml(perfiosXMLEntity));
				perfiosReportEntity.setCorrelationId(""+perfiosXMLEntity.getTrackerId());
				perfiosReportEntity.setCreatedTime(new Date());
				perfiosReportEntity.setOuterTrackerId(""+UniqueId.getUniqueId());
				perfiosReportEntity.setPerfiosServiceName(PERFIOSSERVICENAME.RETRIVAL_REPORT);
				perfiosReportEntity.setPerfiosVersion(PERFIOSVERSION.PERFIOS_V1);
				perfiosReportEntity.setTransactionNo(perfiosXMLEntity.getPerfiosTransId());
				perfiosReportEntity.setClientId(perfiosXMLEntity.gettId());
			}
			catch(Exception e)
			{
				logger.error("Exception while setting request data for perfios tracker!!",e);
			}
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setRetriveUrl(env.getProperty("perfios.retrive.statement.url"));
			
			perfiosEntity = perfiosService.getRetrieveReport(perfiosEntity,perfiosReportEntity);
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
			
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
			String returnXml = "<response><status>Failure</status><statusCode>500</statusCode></response>";
			perfiosEntity.setResponseXML(returnXml);
		}

		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Starts
		 */
		perfiosReportEntity.setUpdatedTime(new Date());
		perfiosReportEntity.setApiResponseJson(perfiosEntity.getResponseXML());
		new Thread(new Runnable() 
		{
		    public void run() 
		    {
		    	runningBackgroundProcess(perfiosReportEntity);
		    }
		}).start();
		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Ends
		 */
		logger.info("PerfiosControllerRest | perfiosRetrieveReportRequest() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	public String convertPojoToXml(PerfiosXMLEntity perfiosXMLEntity) throws JAXBException
	{
		String resultXml = "";
		try 
		{
			OutputStream output = new OutputStream()
		    {
		        private StringBuilder string = new StringBuilder();
		        @Override
		        public void write(int b) throws IOException {
		            this.string.append((char) b );
		        }

		        public String toString(){
		            return this.string.toString();
		        }
		    };
			JAXBContext jaxbContext = JAXBContext.newInstance(PerfiosXMLEntity.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			jaxbMarshaller.marshal(perfiosXMLEntity, (OutputStream) output);
			resultXml = output.toString();
		} 
		catch (Exception e) {
			logger.error("Exception in xml parsing!! ",e);
		}
		return resultXml;
	}
	public void runningBackgroundProcess(PerfiosReportEntity perfiosReportEntity)
	{
		logger.info("Running background process to save perfios data!!");
		if(perfiosReportEntity != null)
		{
			InetAddress ip = null;
	        try
	        {
	            ip = InetAddress.getLocalHost();
	            perfiosReportEntity.setServerIpAddress(""+ip);
	            perfiosReportEntity.setServerHostName(ip.getHostName());
	        }
	        catch (UnknownHostException e)
	        {
	            logger.error("Exception while saving perfios tracking :: UNKNOW HOST EXCEPTION : !!",e);
	        }
	        try
	        {
	        	Long sequenceId = perfiosReportDBDao.getSequenceValue();
	        	perfiosReportEntity.setId(sequenceId);
	        	perfiosReportDBDao.savePerfiosReport(perfiosReportEntity);
	        }
	        catch(Exception e)
	        {
	        logger.error("Exception while saving perfios tracking data!!",e);	
	        }
		}
	}
	
	
	/*Added via MJ~ on 14th APril*/
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/TransactionReviewRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosTransactionReview(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("TransactionReviewRequest : "+UniqueId.getUniqueId());
		logger.info("PerfiosSprBootRest | perfiosTransactionReview() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		final PerfiosReportEntity perfiosReportEntity = new PerfiosReportEntity();
		try
		{
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			try
			{
				perfiosReportEntity.setApiRequestJson(convertPojoToXml(perfiosXMLEntity));
				perfiosReportEntity.setCorrelationId(""+perfiosXMLEntity.getTrackerId());
				perfiosReportEntity.setCreatedTime(new Date());
				perfiosReportEntity.setOuterTrackerId(""+UniqueId.getUniqueId());
				perfiosReportEntity.setPerfiosServiceName(PERFIOSSERVICENAME.TRANSACTION_REVIEW);
				perfiosReportEntity.setPerfiosVersion(PERFIOSVERSION.PERFIOS_V1);
				perfiosReportEntity.setTransactionNo(perfiosXMLEntity.getPerfiosTransId());
				perfiosReportEntity.setClientId(perfiosXMLEntity.gettId());
			}
			catch(Exception e)
			{
				logger.error("Exception while setting request data for perfios tracker!!",e);
			}
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setTransactionReviewUrl(env.getProperty("perfios.review.url"));
			
			perfiosEntity = perfiosService.getTransactionReview(perfiosEntity,perfiosReportEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}

		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Starts
		 */
		perfiosReportEntity.setUpdatedTime(new Date());
		perfiosReportEntity.setApiResponseJson(perfiosEntity.getResponseXML());
		new Thread(new Runnable() 
		{
		    public void run() 
		    {
		    	runningBackgroundProcess(perfiosReportEntity);
		    }
		}).start();
		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Ends
		 */
		logger.info("PerfiosSprBootRest | perfiosTransactionReview() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}

	/*Added Via MJ~ on 14th April*/
	
	@ApiOperation(notes = "This service will return perfios transaction response for success and will return failure response for invalid request!!", value = "Get perfios transaction with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/SupportedInstitutionsRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosSupportedInstitutions(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("SupportedInstitutionsRequest : "+UniqueId.getUniqueId());
		logger.info("PerfiosSprBootRest | perfiosSupportedInstitutions() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		final PerfiosReportEntity perfiosReportEntity = new PerfiosReportEntity();
		try
		{
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			try
			{
				perfiosReportEntity.setApiRequestJson(convertPojoToXml(perfiosXMLEntity));
				perfiosReportEntity.setCorrelationId(""+perfiosXMLEntity.getTrackerId());
				perfiosReportEntity.setCreatedTime(new Date());
				perfiosReportEntity.setOuterTrackerId(""+UniqueId.getUniqueId());
				perfiosReportEntity.setPerfiosServiceName(PERFIOSSERVICENAME.SUPPORTED_INSTITUTE);
				perfiosReportEntity.setPerfiosVersion(PERFIOSVERSION.PERFIOS_V1);
				perfiosReportEntity.setTransactionNo(perfiosXMLEntity.getPerfiosTransId());
				perfiosReportEntity.setClientId(perfiosXMLEntity.gettId());
			}
			catch(Exception e)
			{
				logger.error("Exception while setting request data for perfios tracker!!",e);
			}
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setSupportedInstUrl(env.getProperty("perfios.institutions.url"));
			
			perfiosEntity = perfiosService.getSupportedInstitutions(perfiosEntity,perfiosReportEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}

		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Starts
		 */
		perfiosReportEntity.setUpdatedTime(new Date());
		perfiosReportEntity.setApiResponseJson(perfiosEntity.getResponseXML());
		new Thread(new Runnable() 
		{
		    public void run() 
		    {
		    	runningBackgroundProcess(perfiosReportEntity);
		    }
		}).start();
		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Ends
		 */
		logger.info("PerfiosSprBootRest | perfiosSupportedInstitutions() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	/*Added Via MJ~ on 14th April*/
	
	@ApiOperation(notes = "This service will return perfios delete response for success and will return failure response for invalid request!!", value = "Get perfios delete data with given request!", nickname = "")
	@RequestMapping(method = {RequestMethod.POST}, value = { "/DeleteDataRequest" }, consumes = { "application/xml" }, produces = { "application/xml" })
	public String perfiosDeleteData(@RequestBody PerfiosXMLEntity perfiosXMLEntity)
	{
		ThreadContext.push("DeleteDataRequest : "+UniqueId.getUniqueId());
		logger.info("PerfiosSprBootRest | perfiosDeleteData() | :- START");
		PerfiosEntity perfiosEntity = new PerfiosEntity();
		final PerfiosReportEntity perfiosReportEntity = new PerfiosReportEntity();
		try
		{
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Starts
			 */
			try
			{
				perfiosReportEntity.setApiRequestJson(convertPojoToXml(perfiosXMLEntity));
				perfiosReportEntity.setCorrelationId(""+perfiosXMLEntity.getTrackerId());
				perfiosReportEntity.setCreatedTime(new Date());
				perfiosReportEntity.setOuterTrackerId(""+UniqueId.getUniqueId());
				perfiosReportEntity.setPerfiosServiceName(PERFIOSSERVICENAME.DELETE_DATA);
				perfiosReportEntity.setPerfiosVersion(PERFIOSVERSION.PERFIOS_V1);
				perfiosReportEntity.setTransactionNo(perfiosXMLEntity.getPerfiosTransId());
				perfiosReportEntity.setClientId(perfiosXMLEntity.gettId());
			}
			catch(Exception e)
			{
				logger.error("Exception while setting request data for perfios tracker!!",e);
			}
			/*
			 * Updating Perfios request response to credit bureau tracker
			 * Ends
			 */
			perfiosEntity.setTrackerId(perfiosXMLEntity.getTrackerId());
			perfiosEntity.settId(perfiosXMLEntity.gettId());
			perfiosEntity.setPerfiosTransId(perfiosXMLEntity.getPerfiosTransId());
			perfiosEntity.setDestination(perfiosXMLEntity.getDestinationId());
			
			perfiosEntity.setDeleteDataUrl(env.getProperty("perfios.delete.data.url"));
			
			perfiosEntity = perfiosService.getDeleteData(perfiosEntity,perfiosReportEntity);
			
			if(perfiosEntity.getApiResponseCode()!=null && !perfiosEntity.getApiResponseCode().trim().equalsIgnoreCase("200")
					&& perfiosEntity.getResponseXML()!=null && perfiosEntity.getResponseXML().trim().equalsIgnoreCase(""))
			{
				logger.info("Blank Response XML Form Perfios so we create and send API Call Status Code : "+perfiosEntity.getApiResponseCode());
				String returnXml = "<response><status>Failure</status><statusCode>"+perfiosEntity.getApiResponseCode()+"</statusCode></response>";
				perfiosEntity.setResponseXML(returnXml);
			}
		} 
		catch (Exception e)
		{
			logger.error("We are in Exception : "+e);
		}

		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Starts
		 */
		perfiosReportEntity.setUpdatedTime(new Date());
		perfiosReportEntity.setApiResponseJson(perfiosEntity.getResponseXML());
		new Thread(new Runnable() 
		{
		    public void run() 
		    {
		    	runningBackgroundProcess(perfiosReportEntity);
		    }
		}).start();
		/*
		 * Inserting all api request,response and Perfios api request and response in DB
		 * Ends
		 */
		logger.info("PerfiosSprBootRest | perfiosDeleteData() | :- END");
		ThreadContext.pop();
		return perfiosEntity.getResponseXML();
	}
	
	/*Added Via MJ~ on 14th April*/
	
}
