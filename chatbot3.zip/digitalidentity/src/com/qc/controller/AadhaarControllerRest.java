package com.qc.controller;

import java.util.List;



import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.aadhaar.action.GetBioRequestAction;
import com.qc.aadhaar.action.GetOTPRequestAction;
import com.qc.api.common.Header1;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.getdemoauthrequest.ApiRequestGetDemoAuthRequest;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getdemoauthrequest.ApiResponseGetDemoAuthRequest;
import com.qc.api.response.getdemoauthrequest.ResponseGetDemoAuthRequest;
import com.qc.service.GetDemoAuthRequestService;
import com.qc.utils.Commons;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/aadhaar/api/v1")
@Api(value="Aadhaar", description="Aadhaar service for maxlifeinsurance.com",tags = {"Aadhaar"})
public class AadhaarControllerRest 
{
private static Logger logger = LogManager.getLogger(AadhaarControllerRest.class);
	
//	@Autowired HttpSession session;
//	@Autowired ServletContext context;

	@Autowired Environment env;
	
	@Autowired
	GetDemoAuthRequestService getDemoAuthRequestService;
	
	@ApiOperation(notes = "This service will return aadhaar BIOMETRIC response for success and will return failure response for invalid request!!", value = "Get Aadhaar BioMetric with given request!", nickname = "")
	@RequestMapping(value = "/getbiorequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getAadhaarBIORequest(@RequestBody String requestJSON) 
	{
		logger.info("AadhaarControllerRest :: getAadhaarBIORequest ::Start");
		ThreadContext.push("GetBioRequest : "+UniqueId.getUniqueId());
		logger.info("Method : getAadhaarRequest :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";  
		GetBioRequestAction  bioAction=new GetBioRequestAction();
		Response response=null;		
		int statusCode=500;
		try
		{
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"() inside AadhaarControllerRest."); 
			try
			{
				try
				{
					logger.info("Request Json : "+requestJSON);
					requestData=Commons.getGsonData(requestJSON);
					String TransTrackingID=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("transTrackingID").toString();
					ThreadContext.push(TransTrackingID);
				}
				catch(Exception ex)
				{
					logger.error("We are in Exception while converting request json to Map : "+ex);
				}
				try
				{     		
					returnOutput=bioAction.processBioRequest(requestJSON,env,requestData);
				}
				catch(Exception e)
				{
					returnOutput="{\"status\":\"0\",\"message\":\"ErrorInfo While Reponse\"}";
					logger.error("ErrorInfo while generating response inside "+methodName+"():-"+e);
				}
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"ErrorInfo in Request Json\"}";
				logger.error("ErrorInfo while parsing Request Json "+methodName+"():-"+e);
			}
			logger.info("Going outside "+methodName+"().");

		}
		catch(Exception ex)
		{
			returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"ErrorInfo in Request Json\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("AadhaarControllerRest :: getAadhaarBIORequest ::End");
		return returnOutput;	
	}
	
	
	@ApiOperation(notes = "This service will return aadhaar OTP response for success and will return failure response for invalid request!!", value = "Get Aadhaar OTP with given request!", nickname = "")
	@RequestMapping(value = "/getotprequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getAadhaarOTPRequest(@RequestBody String requestJSON) 
	{
		logger.info("AadhaarControllerRest :: getAadhaarOTPRequest ::Start");
		ThreadContext.push("GetOtpRequest : "+UniqueId.getUniqueId());
		logger.info("Method : getAadhaarRequest :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";  
		GetOTPRequestAction  otpAction=new GetOTPRequestAction();
		Response response=null;		
		//int statusCode=500;
		try
		{
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"() inside AadhaarControllerRest."); 
			try
			{
				try
				{
					logger.info("Request Json : "+requestJSON);
					requestData=Commons.getGsonData(requestJSON);
					String TransTrackingID=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("transTrackingID").toString();
					ThreadContext.push(TransTrackingID);
				}
				catch(Exception ex)
				{
					logger.error("We are in Exception while converting request json to Map : "+ex);
				}
				try
				{     		
					returnOutput=otpAction.processOTPRequest(requestJSON,env,requestData);
				}
				catch(Exception e)
				{
					returnOutput="{\"status\":\"0\",\"message\":\"ErrorInfo While Reponse\"}";
					logger.error("ErrorInfo while generating response inside "+methodName+"():-"+e);
				}
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"ErrorInfo in Request Json\"}";
				logger.error("ErrorInfo while parsing Request Json "+methodName+"():-"+e);
			}
			logger.debug("Going outside "+methodName+"().");

		}
		catch(Exception ex)
		{
			returnOutput="{\"STATUS\":\"E\",\"MESSAGE\":\"ErrorInfo in Request Json\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("AadhaarControllerRest :: getAadhaarOTPRequest ::End");
		return returnOutput;	
	}
	
	
	/*Added vai MJ~ on 14th APril*/
	
	@ApiOperation(notes = "This service is used to authenticate ", value = "aadhaarNumber is required to get the details!", nickname = "")
	@RequestMapping(value = "/getdemoauthrequest", method = RequestMethod.POST, consumes = { "application/json" }, produces = {
	"application/json" })
	public ApiResponseGetDemoAuthRequest generateGetDemoAuthRequest(@Valid @RequestBody ApiRequestGetDemoAuthRequest apiRequest)
	{

		logger.info( "maxservice::AadhaarControllerRest:: generateGetDemoAuthRequest : Start");
		ApiResponseGetDemoAuthRequest apiResponse = new ApiResponseGetDemoAuthRequest();
		Header1 header = null;
		MsgInfo msgInfo = new MsgInfo();
		try 
		{
			ThreadContext.push("generateGetDemoAuthRequest : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info("RequestJson :: " + ow.writeValueAsString(apiRequest));
		} 
		catch (Exception ex) 
		{
			logger.info("Error While mapping response header : " + ex);
		}
		try
		{
			if (apiRequest != null &&  apiRequest.getRequest()!=null
					&&  apiRequest.getRequest().getPayload() != null 
					&& apiRequest.getRequest().getPayload().getAadhaarNumber() != null && !(apiRequest.getRequest().getPayload().getAadhaarNumber()).isEmpty()
					&& apiRequest.getRequest().getPayload().getAadhaarName() != null && !(apiRequest.getRequest().getPayload().getAadhaarName()).isEmpty())
			{
				logger.debug("Controller to service call : Start");
				apiResponse = getDemoAuthRequestService.getDemoAuthRequestService(apiRequest);
				apiResponse.getResponse().setHeader(header);
				ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
				logger.info("ResponseJson :: " + ow.writeValueAsString(apiResponse));
				logger.debug("Controller to service call : End");
			}
			else
			{
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetDemoAuthRequest(new ResponseGetDemoAuthRequest(header, msgInfo, null));
			}
		} 
		catch (Exception e) 
		{
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			logger.error("we are in exception :: maxservice::AadhaarControllerRest:: generateGetDemoAuthRequest : "+StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetDemoAuthRequest(new ResponseGetDemoAuthRequest(header, msgInfo, null));
		}
		finally 
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info( "maxservice::AadhaarControllerRest:: generateGetDemoAuthRequest : End");
		return apiResponse;
	}
	
}



