package com.qc.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication(scanBasePackages = { "com.qc" })
//@EnableAutoConfiguration (exclude = {  DataSourceAutoConfiguration.class }) //by disabling this boot will not required any database when start
public class Application extends SpringBootServletInitializer
{
	private static final Logger logger = LogManager.getLogger(Application.class);
	public Application()
	{
		super();
		setRegisterErrorPageFilter(false);
	}
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder applicationBuilder)
	{
		return applicationBuilder.sources(Application.class);
	}
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(Application.class, args);
	}
}
