package com.qc.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.service.CreditBureauV2ApiService;
import com.qc.service.CreditBureauV3ApiService;
import com.qc.service.PanService;
import com.qc.utils.Commons;
import com.qc.utils.FlatFileMaker;
import com.qc.utils.SpecialCharacter;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/panvalidation/api")
@Api(value="Credit Bureau", description="Credit Bureau service for maxlifeinsurance.com",tags = {"Credit Bureau"})
public class CreditBureauControllerRest 
{
	private static Logger logger = LogManager.getLogger(CreditBureauControllerRest.class);
	@Autowired Environment env;
	@Autowired
	CreditBureauV2ApiService creditBureauV2ApiService;
	
	@Autowired
	CreditBureauV3ApiService creditBureauV3ApiService;

	@Autowired
	PanService panService;
	
	@ApiOperation(notes = "This service will return credit bureau v2 response for success. It does PAN matching and returns credit score as well for the user. and will return failure response for invalid request!!", value = "Get credit bureau v2 details with given request!", nickname = "")
	@ApiResponses(value = {
			@ApiResponse(code = 500, message = "ErrorInfo While Response"),
			@ApiResponse(code = 102, message = "Invalid Request Json"),
			@ApiResponse(code = 101, message = " There is some error in calling webservice"),
			@ApiResponse(code = 200, message = " Success response") })
	@RequestMapping(value = "/v2/getneopanrequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getCreditBureauRequestV2(@RequestBody String requestJSON) 
	{
		logger.info("CreditBureauControllerRest :: getCreditBureauRequestV2:: Start");
		ThreadContext.push("GetNeoPANRequest : "+UniqueId.getUniqueId());
		logger.info("Method : getCreditBureauRequestV2 :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";    	
		try
		{
			FlatFileMaker csv = new FlatFileMaker();
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"()."); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				requestJSON = SpecialCharacter.removeSpecialChar(requestJSON);
				logger.debug("Request Json After Replacing Special characters : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON);
				String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				ThreadContext.push(TransTrackingID);
			} 
			catch (Exception e) 
			{
				logger.error("We are in Exception while converting request json to Map : "+e);
			}

			try
			{     
				logger.debug("Controller to CB_V2 service call : Start");
				returnOutput = creditBureauV2ApiService.getCbV2ActionRequest(requestJSON,env,requestData);
				logger.debug("Controller to CB_V2 service call : End");
			}
			catch(Exception e)
			{
				returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"ErrorInfo While Response\"}";
				logger.error("ErrorInfo while generating response inside "+methodName+"():-"+e);
			}
			logger.info("Going outside "+methodName+"().");
		}
		catch(Exception ex)
		{
			returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"ErrorInfo While Response : 1\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			logger.debug("Return Response is : "+returnOutput);
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("CreditBureauControllerRest :: getCreditBureauRequestV2:: End");
		return returnOutput;

	}
	
	/*Added Via MJ~ on 14th April*/
	
	
	@ApiOperation(notes = "This service will return credit bureau v1 response for success. It contains PAN And DOB matched response and will return failure response for invalid request!!", value = "Get credit bureau v1 details with given request!", nickname = "")
	@ApiResponses(value = {
			@ApiResponse(code = 500, message = "ErrorInfo in Request Json"),
			@ApiResponse(code = 200, message = " Success response") })
	@RequestMapping(value = "/v1/GetPANRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getCreditBureauRequestV1(@RequestBody String requestJSON) 
	{
		ThreadContext.push("/v1/GetPANRequest :"+UniqueId.getUniqueId());
		logger.info("Method : getCreditBureauRequestV1 :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";    	
		try
		{
//			GetPANRequestAction  panAction=new GetPANRequestAction();
			FlatFileMaker csv = new FlatFileMaker();
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"()."); 
			try
			{
				logger.info(" Request JSON:"+requestJSON);
				requestJSON = SpecialCharacter.removeSpecialChar(requestJSON);
				logger.debug("Double Slash removed requestJSON : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON); 
				try
				{ 
					logger.debug("Controller to CB_V1 service call : Start");
					returnOutput=panService.processPANRequest(requestJSON,env);
					logger.debug("Controller to CB_V1 service call : End");
				}
				catch(Exception e)
				{
					returnOutput="{\"status\":\"500\",\"message\":\"ErrorInfo While Reponse\"}";
					logger.error("ErrorInfo while generating response inside "+methodName+"():-"+e);
				}
			}
			catch(Exception e)
			{
				returnOutput="{\"STATUS\":\"500\",\"MESSAGE\":\"ErrorInfo in Request Json\"}";
				logger.error("ErrorInfo while parsing Request Json "+methodName+"():-"+e);
			}
			logger.debug("Going outside "+methodName+"().");
		}
		catch(Exception ex)
		{
			returnOutput="{\"STATUS\":\"500\",\"MESSAGE\":\"ErrorInfo in Request Json\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			logger.debug("Return Response is : "+returnOutput);
			ThreadContext.pop();
		}
		return returnOutput;	
	}

/*GetNeoPANRequest extend version of v3*/
	
	@ApiOperation(notes = "This service will return credit bureau v3 response for success. It does PAN matching and returns credit score as well for the user. and will return failure response for invalid request!!", value = "Get credit bureau v3 details with given request!", nickname = "")
	@ApiResponses(value = {
			@ApiResponse(code = 500, message = "ErrorInfo While Response"),
			@ApiResponse(code = 102, message = "Invalid Request Json"),
			@ApiResponse(code = 101, message = " There is some error in calling webservice"),
			@ApiResponse(code = 200, message = " Success response") })
	@RequestMapping(value = "/v3/GetNeoPANRequest", method = RequestMethod.POST, consumes={"application/json"}, produces={"application/json"})
	public String getCreditBureauRequestV3(@RequestBody String requestJSON) 
	{
		ThreadContext.push("GetNeoPANRequest : "+UniqueId.getUniqueId());
		logger.info("Method : getCreditBureauRequestV3 :: API_REQUEST :: "+requestJSON);
		Map requestData = null;
		String returnOutput="";  
		String soacorellationId="";
		String soaAppId="";
		try
		{
			FlatFileMaker csv = new FlatFileMaker();
			String methodName=Commons.getMethodName();    	
			logger.info("Came inside "+methodName+"()."); 
			try
			{
				logger.info("Request Json : "+requestJSON);
				requestJSON = SpecialCharacter.removeSpecialChar(requestJSON);
				logger.debug("Request Json After Replacing Special characters : "+requestJSON);
				requestData=Commons.getGsonData(requestJSON);
				//String TransTrackingID=(((Map)((List)((Map)((Map)requestData.get("request")).get("payload")).get("transactions")).get(0)).get("TransTrackingID")).toString().toUpperCase();
				
				//ThreadContext.push(TransTrackingID);
			} 
			catch (Exception e) 
			{
				logger.error("We are in Exception while converting request json to Map : "+e);
			}

			try
			{    
				soacorellationId=(((Map)(Map) ((Map) requestData.get("request")).get("header"))
						.get("soaCorrelationId").toString());
				 soaAppId=(((Map)(Map) ((Map) requestData.get("request")).get("header"))
						.get("soaAppId").toString());
				logger.debug("Controller to CB_V3 service call : Start");
				returnOutput = creditBureauV3ApiService.getCbV3ActionRequest(requestJSON,env,requestData);
				logger.debug("Controller to CB_V3 service call : End");
			}
			catch(Exception e)
			{
				//returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"ErrorInfo While Response\"}";
				returnOutput = "{\"response\": {\"header\":{ \"soaCorrelationId\":\""+soacorellationId+"\","+ "\"soaAppId\":\""+soaAppId+"}, \"msgInfo\":{ \"msgCode\": \"500\", \"msg\": \"Failure\", \"msgDescription\":\"ErrorInfo While Response \" }, \"payload\" : \"null\" } } " ;
				//returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"ErrorInfo While Response\"}";
				logger.error("ErrorInfo while generating response inside "+methodName+"():-"+e);
			}
			logger.info("Going outside "+methodName+"().");
		}
		catch(Exception ex)
		{
			returnOutput = "{\"response\": {\"header\":{ \"soaCorrelationId\":\"225163708\", \"soaAppId\":\"NEO \"}, \"msgInfo\":{ \"msgCode\": \"500\", \"msg\": \"Failure\", \"msgDescription\":\"ErrorInfo While Response \" }, \"payload\" : \"null\"  } } " ;
			//returnOutput="{\"status\":\"500\",\"statusDesc\":\"Failure\",\"message\":\"ErrorInfo While Response : 1\"}";
			logger.error("we are in exception : "+ex);
		}
		finally
		{
			logger.debug("Return Response is : "+returnOutput);
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return returnOutput;

	}
}
