package com.qc.controller;

import javax.validation.Valid;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.request.elasticsearch.ApiRequestElasticSearch;
import com.qc.api.request.elasticsearch.PayloadReqElasticSearch;
import com.qc.api.request.elasticsearch.RequestElasticSearch;
import com.qc.api.response.StringConstants;
import com.qc.api.response.elasticsearch.ApiResponseElasticSearch;
import com.qc.api.response.elasticsearch.HeaderElasticSearch;
import com.qc.api.response.elasticsearch.MsgInfo;
import com.qc.api.response.elasticsearch.ResponseElasticSearch;
import com.qc.service.ElasticSearchService;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/")
@Api(value="Elastic search", description="ElasticSearch service for maxlifeinsurance.com",tags = {"ElasticSearch"})
public class ElasticSearchControllerRest 
{
	@Autowired
	ElasticSearchService elasticSearch;
	
	private static Logger logger = LogManager.getLogger(ElasticSearchControllerRest.class);
	
	@ApiOperation(notes = "This service is used to Get Elastic Search details ", value = "lyrics is required to get the details!", nickname = "")
	@RequestMapping(value = "search", method = RequestMethod.GET, consumes = { "text/plain" }, produces = {
	"application/json" })
	public ApiResponseElasticSearch generateElasticSearch(@Valid @RequestParam(value="index", required=false) String index,@RequestParam(value="type", required=false) String type,@RequestHeader("soaCorrelationId") String soaCorrelationId,@RequestHeader("soaAppId") String soaAppId,@RequestHeader("searchVar") String searchVar)
	{
		logger.info( "ElasticSearchControllerRest::ElasticSearchControllerRest:: generateElasticSearch : Start");
		ApiResponseElasticSearch apiResponse = new ApiResponseElasticSearch();
		HeaderElasticSearch header = null;
		MsgInfo msgInfo = new MsgInfo();
		RequestElasticSearch Request =new RequestElasticSearch();
		ApiRequestElasticSearch apiRequest = null;
		PayloadReqElasticSearch payloadReq ;
		try{
			header = new HeaderElasticSearch();
			header.setSoaAppId(soaAppId);
			header.setSoaCorrelationId(soaCorrelationId);
			header.setSearchVar(searchVar);
		    payloadReq =new PayloadReqElasticSearch();
		    payloadReq.setIndex(index);
		    payloadReq.setType(type);
		    Request.setRequestData(payloadReq);
		    Request.setHeader(header);
			apiRequest =new ApiRequestElasticSearch();
			apiRequest.setRequest(Request);
		}catch(Exception e){
			logger.info("creating exception while set Header values "+ e);
		}
		try 
		{
			ThreadContext.push("generatePDFByte : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info("RequestJson :: " + ow.writeValueAsString(apiRequest));
		} 
		catch (JsonProcessingException e1) 
		{
			logger.info("Error While converting request data to json : " + e1);
		} 
		catch (Exception ex) 
		{
			logger.info("Error While mapping response header : " + ex);
		}
		try
		{
			
			if (apiRequest != null &&  apiRequest.getRequest()!=null
					&&  apiRequest.getRequest().getRequestData() != null  
					&& apiRequest.getRequest().getRequestData().getIndex() != null && !(apiRequest.getRequest().getRequestData().getIndex()).isEmpty())
					//&& apiRequest.getRequest().getRequestData().getType() != null && !(apiRequest.getRequest().getRequestData().getType()).isEmpty())
			{
				logger.debug("Controller to service call : Start");
				apiResponse = elasticSearch.generateSearch(apiRequest);
				apiResponse.getResponse().setHeader(header);
				//ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
				//logger.info("ResponseJson :: " + ow.writeValueAsString(apiResponse));
				if(apiResponse != null){
					logger.info("response generated successfully");
				}
				logger.debug("Controller to service call : End");
			}
			else
			{
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseElasticSearch(new ResponseElasticSearch(header, msgInfo, null));
			}
		} 
		catch (Exception e) 
		{
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			logger.error("we are in exception :: maxservice::ElasticSearchControllerRest:: generateElasticSearch : "+StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseElasticSearch(new ResponseElasticSearch(header, msgInfo, null));
		}
		finally 
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		/*Response response=null;
		try{
		
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		response = Response.status(200).type("application/json").entity(ow.writeValueAsString(apiResponse)).build();
		}catch(Exception e){
			logger.error(""+e.getMessage());
		}*/
		logger.info( "ElasticSearchControllerRest::ElasticSearchControllerRest:: generateElasticSearch : End");
		return apiResponse;
	}
}
