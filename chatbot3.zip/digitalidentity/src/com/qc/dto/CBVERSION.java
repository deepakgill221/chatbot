package com.qc.dto;

public enum CBVERSION {

	CREDIT_BUREAU_V1,CREDIT_BUREAU_V2
}
