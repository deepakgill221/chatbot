package com.qc.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CreditBureauTrackerDTO {

	private String requestXml;
	private String responseXml;
	private CBSERVICEPROVIDER cbServiceProvider;
	private CBVERSION cbVersion;
	private String trackerId;
	private boolean pdfGenerated;
	private String pdfByte;
	private Date startTime;
	private Date endTime;
	private String policyNo;
	private String serviceType;
	private List<CrifRequestResponseTrackerDTO> crifv2RetryData = new ArrayList<CrifRequestResponseTrackerDTO>();

	public String getRequestXml() {
		return requestXml;
	}

	public void setRequestXml(String requestXml) {
		this.requestXml = requestXml;
	}

	public String getResponseXml() {
		return responseXml;
	}

	public void setResponseXml(String responseXml) {
		this.responseXml = responseXml;
	}

	public CBSERVICEPROVIDER getCbServiceProvider() {
		return cbServiceProvider;
	}

	public void setCbServiceProvider(CBSERVICEPROVIDER cbServiceProvider) {
		this.cbServiceProvider = cbServiceProvider;
	}

	public CBVERSION getCbVersion() {
		return cbVersion;
	}

	public void setCbVersion(CBVERSION cbVersion) {
		this.cbVersion = cbVersion;
	}

	public String getTrackerId() {
		return trackerId;
	}

	public void setTrackerId(String trackerId) {
		this.trackerId = trackerId;
	}

	public boolean isPdfGenerated() {
		return pdfGenerated;
	}

	public void setPdfGenerated(boolean pdfGenerated) {
		this.pdfGenerated = pdfGenerated;
	}

	public String getPdfByte() {
		return pdfByte;
	}

	public void setPdfByte(String pdfByte) {
		this.pdfByte = pdfByte;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public List<CrifRequestResponseTrackerDTO> getCrifv2RetryData() {
		return crifv2RetryData;
	}

	public void setCrifv2RetryData(List<CrifRequestResponseTrackerDTO> crifv2RetryData) {
		this.crifv2RetryData = crifv2RetryData;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
}
