package com.qc.dto;

public enum STATUSCODE {

}
