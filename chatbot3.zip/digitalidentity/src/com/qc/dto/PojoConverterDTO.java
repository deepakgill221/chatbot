package com.qc.dto;

import java.util.HashMap;

public class PojoConverterDTO {

	HashMap<String,String> pojoResult;

	public HashMap<String, String> getPojoResult() {
		return pojoResult;
	}

	public void setPojoResult(HashMap<String, String> pojoResult) {
		this.pojoResult = pojoResult;
	}

		
	
}
