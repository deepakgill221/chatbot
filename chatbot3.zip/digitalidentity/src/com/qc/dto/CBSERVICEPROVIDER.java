package com.qc.dto;

public enum CBSERVICEPROVIDER {

	CRIF,EQUIFAX
}
