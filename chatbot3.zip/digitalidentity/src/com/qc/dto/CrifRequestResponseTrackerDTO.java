package com.qc.dto;

import java.util.Date;

public class CrifRequestResponseTrackerDTO {

	private String crifRequestXml;
	private String crifResponseXml;
	private String innerTrackId;
	private String providerStatusCode;
	private Date startDate;
	private Date endDate;

	public String getCrifRequestXml() {
		return crifRequestXml;
	}

	public void setCrifRequestXml(String crifRequestXml) {
		this.crifRequestXml = crifRequestXml;
	}

	public String getCrifResponseXml() {
		return crifResponseXml;
	}

	public void setCrifResponseXml(String crifResponseXml) {
		this.crifResponseXml = crifResponseXml;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getInnerTrackId() {
		return innerTrackId;
	}

	public void setInnerTrackId(String innerTrackId) {
		this.innerTrackId = innerTrackId;
	}

	public String getProviderStatusCode() {
		return providerStatusCode;
	}

	public void setProviderStatusCode(String providerStatusCode) {
		this.providerStatusCode = providerStatusCode;
	}
	
}
