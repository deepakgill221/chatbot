package com.qc.dto;

public enum PERFIOSVERSION {
	PERFIOS_V1,PERFIOS_V2
}
