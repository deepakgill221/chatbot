package com.qc.dto;

import java.io.Serializable;

public class UserInfo implements Serializable
{
	private static final long serialVersionUID = -6854575840570533804L;
	String userName="";
	String creationDate="";
	String creationTime="";
	String sourceInfoName="";
	String requestorToken="";
	String userEmail="";
	String lastSyncDateTime="";

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getSourceInfoName() {
		return sourceInfoName;
	}

	public void setSourceInfoName(String sourceInfoName) {
		this.sourceInfoName = sourceInfoName;
	}

	public String getRequestorToken() {
		return requestorToken;
	}

	public void setRequestorToken(String requestorToken) {
		this.requestorToken = requestorToken;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getLastSyncDateTime() {
		return lastSyncDateTime;
	}

	public void setLastSyncDateTime(String lastSyncDateTime) {
		this.lastSyncDateTime = lastSyncDateTime;
	}

	@Override
	public String toString() {
		return "UserInfo [userName=" + userName + ", creationDate=" + creationDate + ", creationTime=" + creationTime
				+ ", sourceInfoName=" + sourceInfoName + ", requestorToken=" + requestorToken + ", userEmail="
				+ userEmail + ", lastSyncDateTime=" + lastSyncDateTime + "]";
	}

}
