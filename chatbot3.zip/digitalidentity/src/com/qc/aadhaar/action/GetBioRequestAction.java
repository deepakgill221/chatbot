package com.qc.aadhaar.action;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import javax.xml.rpc.ServiceException;

import org.apache.axis.AxisFault;
import org.apache.axis.encoding.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.env.Environment;

import com.qc.controller.AadhaarControllerRest;
import com.qc.utils.Commons;
import com.qc.utils.ConvertPDFToByteArray;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceRequest;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebServiceCallLocator;
import com.qualtech.webservice.AadhaarVerification.AadhaarWebServiceSoapBindingStub;

public class GetBioRequestAction 
{
	private static final Logger logger = LogManager.getLogger(AadhaarControllerRest.class);
	public String processBioRequest(String requestJson, Environment env,Map requestData) throws AxisFault, JSONException, MalformedURLException, ServiceException
	{
		String eKYCURL = env.getProperty("eKYCURL");
		String methodName=null;
		String serviceName =null;
		String aadharNo="";
		String responseString="";
		String statcode="";
		String statmsg="";
		String token_pdf="";
		String UserName = null;
		String CreationDate = null;
		String CreationTime = null;
		String SourceInfoName = null;
		String RequestorToken = null;
		String UserEmail = null;
		String LastSyncDateTime = null;
		Object outer1="";
		Object outer2="";
		Object policy_No="";
		Object _bioMetric="";
		Object _index="";
		String fingureCaptured="";
		int fingerPosition=0;
		String _transTrackingID = null;
		String aadharno="";
		String requestType="";
		String policyNo="";
		String fingerPrint="";
		StringBuilder bioResponse = new StringBuilder();
		methodName=Commons.getMethodName();
		logger.info("Came inside "+methodName+"().");
		Map<String, String> responseMap = null;

		AadhaarVerificationWebServiceCallLocator docLocator;
		AadhaarWebServiceSoapBindingStub myService=null;
		AadhaarVerificationServiceResponse response=null;
		try
		{
			requestData=Commons.getGsonData(requestJson);
			outer1=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("aadhaarNumber");
			logger.info("Aadhaar No is :-"+ outer1);
			outer2=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("requestType");
			logger.info("Request Type is :-"+ outer2);
			policy_No=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("policyno");
			logger.info("Policy No is :-"+ policy_No);
			_bioMetric=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("biometeric");
			logger.info("BioMetric Input is :-"+ _bioMetric);
			_index=((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("index");
			logger.info("Finger Index Position is :-"+ _index);
		}
		catch(Exception e)
		{
			bioResponse.append("{");
			bioResponse.append("\"statusCode\":\"500\",");
			bioResponse.append("\"statusDesc\":\"Failure\",");
			bioResponse.append("\"message\":\"Invalid Json Request/Invalid Input Parameter\",");
			bioResponse.append("\"status\":\"E\"");
			bioResponse.append("}");
			logger.error("Exception Description--"+e.getMessage());
			logger.error(e);
			return bioResponse.toString();
		}
		if(!outer1.equals("") && !outer2.equals("") && !policy_No.equals("") && !_bioMetric.equals("") && !_index.equals(""))
		{
			aadharno= outer1.toString();
			requestType= outer2.toString();
			policyNo=policy_No.toString();
			fingerPrint=_bioMetric.toString();
			fingerPosition=Integer.parseInt(_index.toString());
		}
		else
		{
			bioResponse.append("{");
			bioResponse.append("\"statusCode\":\"500\",");
			bioResponse.append("\"statusDesc\":\"Failure\",");
			bioResponse.append("\"message\":\"Invalid Json Request/Invalid Input Parameter\",");
			bioResponse.append("\"status\":\"E\"");
			bioResponse.append("}");
			return bioResponse.toString();
		}
		if(fingerPosition>0 && fingerPosition <11) 
		{
			fingureCaptured=getFindgerPosition(fingerPosition);
			logger.info("Valid Finger Print Captured"+fingureCaptured);
		}
		else
		{		
			logger.info("Finger Print Not Captured Or Invalid Finger Print Captured");
			bioResponse.append("{");
			bioResponse.append("\"statusCode\":\"500\",");
			bioResponse.append("\"statusDesc\":\"Failure\",");
			bioResponse.append("\"message\":\"Invalid Json Request/Invalid Input Parameter\",");
			bioResponse.append("\"status\":\"E\"");
			bioResponse.append("}");
			return bioResponse.toString();
		}
		logger.info("Finger Position Captured:--"+fingerPosition);
		try
		{
			_transTrackingID = ((Map)((List)((Map)((Map)requestData.get("Request")).get("RequestPayload")).get("Transactions")).get(0)).get("transTrackingID").toString();
			UserName =  ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("UserName").toString();
			CreationDate = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("CreationDate").toString();
			CreationTime = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("CreationTime").toString();
			SourceInfoName = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("SourceInfoName").toString();
			RequestorToken = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("RequestorToken").toString();
			UserEmail = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("UserEmail").toString();
			LastSyncDateTime = ((Map)((Map)requestData.get("Request")).get("RequestInfo")).get("LastSyncDateTime").toString();
		}catch(Exception e)
		{
			bioResponse.append("{");
			bioResponse.append("\"statusCode\":\"500\",");
			bioResponse.append("\"statusDesc\":\"Failure\",");
			bioResponse.append("\"message\":\"Invalid Request Json/Invalid Input Parameter\",");
			bioResponse.append("\"status\":\"E\"");
			bioResponse.append("}");
			logger.error("Exception Description--"+e.getMessage());
			logger.error(e);
			return bioResponse.toString();
		}

		if(requestData!=null && !requestData.isEmpty())
		{
			bioResponse.append(" 	{	 ");
			bioResponse.append(" 	\"Response\": {	 ");
			bioResponse.append(" 	\"ResponseInfo\": {	 ");
			bioResponse.append(" 	\"UserName\": \""+UserName+"\",	 ");
			bioResponse.append(" 	\"CreationDate\": \""+CreationDate+"\",	 ");
			bioResponse.append(" 	\"CreationTime\": \""+CreationTime+"\",	 ");
			bioResponse.append(" 	\"SourceInfoName\": \""+SourceInfoName+"\",	 ");
			bioResponse.append(" 	\"RequestorToken\": \""+RequestorToken+"\",	 ");
			bioResponse.append(" 	\"UserEmail\": \""+UserEmail+"\",	 ");
			bioResponse.append(" 	\"LastSyncDateTime\": \""+LastSyncDateTime+"\"	 ");
			bioResponse.append("},");
			bioResponse.append(" 	\"ResponsePayload\": {	 ");
			bioResponse.append(" 	\"Transactions\": [	 ");
			bioResponse.append(" 	{	 ");
			bioResponse.append(" 	\"key1\": \"\",	 ");
			bioResponse.append(" 	\"key2\": \"\",	 ");
			bioResponse.append(" 	\"key3\": \"\",	 ");
			bioResponse.append(" 	\"key4\": \"\",	 ");
			bioResponse.append(" 	\"key5\": \"\",	 ");
			bioResponse.append(" 	\"transTrackingID\": \"\",	 ");
			bioResponse.append(" 	\"transactionData\": {	 ");

			try
			{
				docLocator = new AadhaarVerificationWebServiceCallLocator();
				myService = new AadhaarWebServiceSoapBindingStub();	
				logger.info(" Creating verification object:---");
				logger.info(eKYCURL);
				myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL(eKYCURL));
				logger.info("Verification object created ---");
				logger.info("Request Type is --::---"+myService);
			}
			catch(Exception e)
			{
				bioResponse.append("\"statusCode\":\"500\",");
				bioResponse.append("\"statusDesc\":\"Failure\",");
				bioResponse.append("\"message\":\"There is some error in calling Aadhaar webservice\",");
				bioResponse.append("\"status\":\"E\"");
				bioResponse.append("}}]}}}");
				logger.error("Exception Description--"+e.getMessage());
				logger.error(e);
				return bioResponse.toString();
			}
			if(requestType.equals("A") && aadharno!=null && !aadharno.equals("") && !_index.equals("") && _index!=null && !_bioMetric.equals("") && aadharno.length()==12)
			{
				logger.info("Inside request type A & hit service for response ---");	
				try
				{
					response=myService.saveAadhaarVerificationInformation(					
							new AadhaarVerificationServiceRequest( "A",
									aadharno,"QC","dypnU7milCCtWzrnBcXWgA==","00","",null,null,null,policyNo,
									"","M",	"K",null,null,null,null,null,null,null,null,null,null,null,
									fingerPrint,fingureCaptured,null,null,null));
				}
				catch (RemoteException e) 
				{
					bioResponse.append("\"statusCode\":\"500\",");
					bioResponse.append("\"statusDesc\":\"Failure\",");
					bioResponse.append("\"message\":\"There is some error in calling Aadhaar webservice\",");
					bioResponse.append("\"status\":\"E\"");
					bioResponse.append("}}]}}}");
					logger.error("Exception Description--"+e.getMessage());
					logger.error(e);
					return bioResponse.toString();
				}
				logger.info("Complete the saveAadhaarVerificationInformation method and Getting response from UIDAI");
				logger.info("Service Response fetched ---"+response.getOutputStatus()+" -- "+response.getOutputMessage());

				statcode=response.getOutputStatus();
				statmsg=response.getOutputMessage();
				if(statcode.equals("E"))
				{
					logger.info("Getting Failure StatCode-->>>>"+statcode);
					bioResponse.append("\"statusCode\":\"500\",");
					bioResponse.append("\"statusDesc\":\"Failure\",");
					bioResponse.append("\"message\":\""+statmsg+"\",");
					bioResponse.append("\"status\":\"E\"");	
					bioResponse.append("}}]}}}");
					return bioResponse.toString();
				}
				if(statcode.equalsIgnoreCase("-1"))
				{
					logger.info("Getting Failure StatCode-->>>>"+statcode);
					bioResponse.append("\"statusCode\":\"500\",");
					bioResponse.append("\"statusDesc\":\"Failure\",");
					bioResponse.append("\"message\":\""+statmsg+"\",");
					bioResponse.append("\"status\":\"E\"");	
					bioResponse.append("}}]}}}");
					return bioResponse.toString();
				}
				logger.info("Start :- Going to Convert pdf to byte Array:- ");
				ConvertPDFToByteArray convertpdftobytearray = new ConvertPDFToByteArray();
				logger.info("END :- Going to Convert pdf to byte Array:-");
				JSONObject addressJson=new JSONObject(response.getCustomerAddress());
				logger.info("AddressJson object created"+ addressJson);

				bioResponse.append("\"statusCode\":\"200\",");
				bioResponse.append("\"statusDesc\":\"Success\",");
				bioResponse.append("\"message\":\"Response Successfully Generated\",");
				bioResponse.append("\"name\":\""+response.getCustomerName()+"\",");
				bioResponse.append("\"gender\":\""+response.getCustomerGender()+"\",");
				bioResponse.append("\"tokenNo\":\""+token_pdf+"\",");
				bioResponse.append("\"status\":\"S\""+",");
				bioResponse.append("\"aadharNo\":\""+aadharno+"\",");
				bioResponse.append("\"DOB\":\""+response.getCustomerDOB()+"\",");
				bioResponse.append("\"phone\":\""+response.getOutputParam1()+"\",");
				bioResponse.append("\"email\":\""+response.getOutputParam2()+"\",");
				bioResponse.append("\"CareOf\":\""+addressJson.getString("CAREOF")+"\",");
				bioResponse.append("\"House\":\""+addressJson.getString("HOUSE")+"\",");
				bioResponse.append("\"Street\":\""+addressJson.getString("STREET")+"\",");
				bioResponse.append("\"Landmark\":\""+addressJson.getString("LANDMARK")+"\",");
				bioResponse.append("\"Location\":\""+addressJson.getString("LOCATION")+"\",");
				bioResponse.append("\"Pin Code\":\""+addressJson.getString("PIN")+"\",");
				bioResponse.append("\"Post Office\":\""+addressJson.getString("POSTOFFICE")+"\",");
				bioResponse.append("\"Vill/City\":\""+addressJson.getString("VILL/CITY")+"\",");
				bioResponse.append("\"Sub-Dist\":\""+addressJson.getString("SUB-DIST")+"\",");
				bioResponse.append("\"Dist\":\""+addressJson.getString("DIST")+"\",");
				bioResponse.append("\"State\":\""+addressJson.getString("STATE")+"\",");
				bioResponse.append("\"image\":\""+response.getOutputParam3()+"\",");
				try
				{
					ConvertPDFToByteArray  objthisclass= new ConvertPDFToByteArray();
					String newpdfpathlocation=objthisclass.newPdfByteArray(addressJson,response.getCustomerName(),response.getCustomerGender(),response.getCustomerDOB(),response.getOutputParam1(),response.getOutputParam2(),aadharno,response.getOutputParam3(),policyNo);
					String encodednewpdfbyte=Base64.encode(objthisclass.convertPDFToByteArray(newpdfpathlocation));
					bioResponse.append("\"pdffile\":\""+encodednewpdfbyte+"\"");
					bioResponse.append("}}]}}}");
					logger.info("Response in A type-:"+bioResponse.toString());
				}
				catch(Exception e)
				{
					logger.info("Getting Failure StatCode-->>>>"+statcode);
					bioResponse.append("\"statusCode\":\"500\",");
					bioResponse.append("\"statusDesc\":\"Failure\",");
					bioResponse.append("\"message\":\"Problem Occured during TemplatePDF Conversion \",");
					bioResponse.append("\"status\":\"E\"");	
					bioResponse.append("}}]}}}");
					return bioResponse.toString();
				}
			}
			else
			{ 
				logger.info("Getting wrong either 'requestType'---aadharno----index");
				bioResponse.append("\"statusCode\":\"500\",");
				bioResponse.append("\"statusDesc\":\"Failure\",");
				bioResponse.append("\"message\":\"Invalid Input Request Type!!\",");
				bioResponse.append("\"status\":\"E\" ");
				bioResponse.append("}}]}}}");
			}
		}
		else
		{  
			logger.info("Request Data Found Null");
			bioResponse.append("{");
			bioResponse.append("\"statusCode\":\"500\",");
			bioResponse.append("\"statusDesc\":\"Failure\",");
			bioResponse.append("\"message\":\"Invalid Input Request! Request found null!\",");
			bioResponse.append("\"status\":\"E\" ");
			bioResponse.append("}");
		}
		return bioResponse.toString();
	}
	private String getFindgerPosition(int fingerPosition)
	{
		String fingertype="";
		switch(fingerPosition)
		{
		case 1:
			fingertype="LEFT_LITTLE";
			break;
		case 2:
			fingertype="LEFT_RING";
			break;
		case 3:
			fingertype="LEFT_MIDDLE";
			break;
		case 4:
			fingertype="LEFT_INDEX";
			break;
		case 5:
			fingertype="LEFT_THUMB";
			break;
		case 6:
			fingertype="RIGHT_THUMB";
			break;
		case 7:
			fingertype="RIGHT_INDEX";
			break;
		case 8:
			fingertype="RIGHT_MIDDLE";
			break;
		case 9:
			fingertype="RIGHT_RING";
			break;
		case 10:
			fingertype="RIGHT_LITTLE";
		default :
			fingertype="Invalid";
		}
		return fingertype;
	}
}
