package com.qc.db.dao;

import com.qc.api.response.otp.PayloadOtpDetails;

public interface OtpDao 
{
	public PayloadOtpDetails call_Numeric(int noOfchars);
	public PayloadOtpDetails call_AlphaNumeric(int noOfchars);
	public PayloadOtpDetails call_AlphaNumericSpecial(int noOfchars);
	public PayloadOtpDetails call_Alpha(int noOfchars);
}
