package com.qc.db.dao;

import com.qc.entity.PerfiosReportEntity;

public interface PerfiosReportDBDao {

	public Long getSequenceValue();
	
	public void savePerfiosReport(PerfiosReportEntity perfiosReportEntity);
}
