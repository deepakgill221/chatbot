package com.qc.db.dao;

import com.qc.entity.CreditBureauReportEntity;

public interface CreditBureauReportDBDao {

	Long getSequenceValue();
	
	public void saveCreditBureauReport(CreditBureauReportEntity cbReportEntity);
}
