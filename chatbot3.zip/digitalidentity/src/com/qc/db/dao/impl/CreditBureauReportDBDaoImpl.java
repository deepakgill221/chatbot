package com.qc.db.dao.impl;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.db.dao.CreditBureauReportDBDao;
import com.qc.entity.CreditBureauReportEntity;

@Repository
@Transactional
public class CreditBureauReportDBDaoImpl implements CreditBureauReportDBDao{

	private static Logger logger = LogManager.getLogger(CreditBureauReportDBDaoImpl.class);
	
	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory")
	private LocalSessionFactoryBean sessionFactory;
	
//	@Autowired
//	@Qualifier("hibernateSessionFactory1")
//	private LocalSessionFactoryBean sessionFactory1;
	
	protected Session getSession() {
		return sessionFactory.getObject().getCurrentSession();
	}
	
	@Override
	public Long getSequenceValue() {
		try
		{
			Query query = getSession().createSQLQuery( "select cb_tracking_sequence.NEXTVAL from DUAL" );
			query.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			return ((BigDecimal) query.uniqueResult()).longValue();
		}catch(Exception e){
			logger.error("Exception while generating sequence for credit bureau :: "+e);
		}
		return null;
	}

	@Override
	public void saveCreditBureauReport(CreditBureauReportEntity cbReportEntity) {
		logger.info("CreditBureauReportDBDaoImpl : Inserting to DB : saveCreditBureauReport : STARTS");
		try
		{
			getSession().save(cbReportEntity);
		}
		catch(Exception e)
		{
			logger.error("Exception while saving saveCreditBureauReport :: "+e);
			e.printStackTrace();
		}
		logger.info("CreditBureauReportDBDaoImpl : Inserting to DB : saveCreditBureauReport : ENDS");		
	}

	
}
