package com.qc.db.dao.impl;

import java.security.SecureRandom;

import java.util.Random;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import com.qc.api.response.otp.PayloadOtpDetails;
import com.qc.db.dao.OtpDao;

@Repository
public class OtpDaoImpl implements OtpDao 
{
	private static Logger logger = LogManager.getLogger(OtpDaoImpl.class);

	private final String NUMERIC="123456789";
	private final String ALPHANUMERIC="abcdefghijklmnopqrstuvwxyz"
			+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			+ "0123456789";
	private final String ALPHA="abcdefghijklmnopqrstuvwxyz"
			+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private final String ALPHANUMERICSPECIAL="abcdefghijklmnopqrstuvwxyz"
			+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			+ "0123456789!@%$%&^?|~'\"#+="
			+ "\\*/.,:;[]()-_<>";
	private final String SUCCESS="SUCCESS";
	private final String FAILURE="FAILURE";
	private final String OTP="OTP";
	private final String STATUS="STATUS";
	private final String MSG="MSG";
	
	PayloadOtpDetails resPayload=null;

	@Override
	public PayloadOtpDetails call_Numeric(int noOfchars)
	{
		resPayload= new PayloadOtpDetails();
		logger.info("OTPDAOImpl --> call_Numeric Starts...");
		try 
		{
			Random rnd = new SecureRandom();
			StringBuilder pass = new StringBuilder();
			for (int i = 0; i < noOfchars; i++)
			{
				pass.append(NUMERIC.charAt(rnd.nextInt(NUMERIC.length())));
			}
			resPayload.setStatus(SUCCESS);
			resPayload.setMsg(SUCCESS);
			resPayload.setOtp(pass.toString());
			logger.info("OTP generated Success : "+pass.toString());
		} 
		catch (Exception e)
		{
			resPayload.setStatus(FAILURE);
			resPayload.setMsg(e+"");
			resPayload.setOtp("");
			logger.error("call_Numeric --> Error Occurred::" + e);
		}
		logger.info("OTPDAOImpl --> call_Numeric Stop.");
		return resPayload;
	}	
	
	@Override
	public PayloadOtpDetails call_Alpha(int noOfchars)
	{
		resPayload= new PayloadOtpDetails();
		logger.info("OTPDAOImpl --> call_Alpha Starts...");
		try 
		{
			Random rnd = new SecureRandom();
			StringBuilder pass = new StringBuilder();
			for (int i = 0; i < noOfchars; i++)
			{
				pass.append(ALPHA.charAt(rnd.nextInt(ALPHA.length())));
			}
			resPayload.setStatus(SUCCESS);
			resPayload.setMsg(SUCCESS);
			resPayload.setOtp(pass.toString());
			logger.info("OTP generated Success : "+pass.toString());
		} 
		catch (Exception e)
		{
			resPayload.setStatus(FAILURE);
			resPayload.setMsg(e+"");
			resPayload.setOtp("");
			logger.error("call_Alpha --> Error Occurred::" + e);
		}
		logger.info("OTPDAOImpl --> call_Alpha Stop.");
		return resPayload;
	}

	@Override
	public PayloadOtpDetails call_AlphaNumeric(int noOfchars)
	{
		resPayload= new PayloadOtpDetails();
		logger.info("OTPDAOImpl --> call_AlphaNumeric Starts...");
		try 
		{
			Random rnd = new SecureRandom();
			StringBuilder pass = new StringBuilder();
			for (int i = 0; i < noOfchars; i++)
			{
				pass.append(ALPHANUMERIC.charAt(rnd.nextInt(ALPHANUMERIC.length())));
			}
			resPayload.setStatus(SUCCESS);
			resPayload.setMsg(SUCCESS);
			resPayload.setOtp(pass.toString());
			logger.info("OTP generated Success : "+pass.toString());
		} 
		catch (Exception e)
		{
			resPayload.setStatus(FAILURE);
			resPayload.setMsg(e+"");
			resPayload.setOtp("");
			logger.error("call_AlphaNumeric --> Error Occurred::" + e);
		}
		logger.info("OTPDAOImpl --> call_AlphaNumeric Stop.");
		return resPayload;
	}

	@Override
	public PayloadOtpDetails call_AlphaNumericSpecial(int noOfchars)
	{
		resPayload= new PayloadOtpDetails();
		logger.info("OTPDAOImpl --> call_AlphaNumericSpecial Starts...");
		try 
		{
			Random rnd = new SecureRandom();
			StringBuilder pass = new StringBuilder();
			for (int i = 0; i < noOfchars; i++)
			{
				pass.append(ALPHANUMERICSPECIAL.charAt(rnd.nextInt(ALPHANUMERICSPECIAL.length())));
			}
			resPayload.setStatus(SUCCESS);
			resPayload.setMsg(SUCCESS);
			resPayload.setOtp(pass.toString());
			logger.info("OTP generated Success : "+pass.toString());
		} 
		catch (Exception e)
		{
			resPayload.setStatus(FAILURE);
			resPayload.setMsg(e+"");
			resPayload.setOtp("");
			logger.error("call_AlphaNumericSpecial --> Error Occurred::" + e);
		}
		logger.info("OTPDAOImpl --> call_AlphaNumericSpecial Stop.");
		return resPayload;
	}


}
