package com.qc.db.dao.impl;


import java.util.Map;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.db.dao.PanDao;
import com.qc.utils.Commons;


@Repository
@Transactional
public class PanDaoImpl implements PanDao {
	
	private static Logger logger = LogManager.getLogger(PanDaoImpl.class);
	Map requestData=null;
	
	@Autowired
	@Qualifier("hibernateSessionFactory")
	private LocalSessionFactoryBean sessionFactory;


	protected Session getSession() {
		return sessionFactory.getObject().getCurrentSession();
	}

	
	
	@Override
	public String getStatusThroughProcedures(String reqType) throws HibernateException
	{
		logger.info("came inside DBConnection class getStatusThroughProcedures method");
		String status = null;
		try {
			requestData=Commons.getGsonData(reqType);

			String pan=(String) requestData.get("pan");
			String dob=(String) requestData.get("dob");
			String validationType=(String) requestData.get("validationType");
			
			ProcedureCall call = getSession().createStoredProcedureCall("PR_PAN_DOB");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue(pan);
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue(dob);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue(validationType);
			call.registerParameter(4, String.class,ParameterMode.OUT); 
			
			ProcedureOutputs output = call.getOutputs();
			
			status=(String) output.getOutputParameterValue(4);
		} catch (Exception e) {
			logger.info("Exception generated in getStatusThroughProcedures "+e);
		//	e.printStackTrace();
		}  
		logger.info("go outside inside DBConnection class getStatusThroughProcedures method"+status);
		return status;
	}

}
