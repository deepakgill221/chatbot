package com.qc.db.dao;


public interface PanDao {

	
	public String getStatusThroughProcedures(String reqType);
}
