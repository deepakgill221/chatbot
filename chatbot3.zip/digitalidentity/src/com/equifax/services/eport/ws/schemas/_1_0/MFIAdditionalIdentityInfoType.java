/**
 * MFIAdditionalIdentityInfoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class MFIAdditionalIdentityInfoType  implements java.io.Serializable {
    private java.lang.String MFIVoterID;

    private java.lang.String MFIPANCardID;

    private java.lang.String MFIRationCard;

    private java.lang.String MFIUID;

    private java.lang.String MFIOtherID;

    public MFIAdditionalIdentityInfoType() {
    }

    public MFIAdditionalIdentityInfoType(
           java.lang.String MFIVoterID,
           java.lang.String MFIPANCardID,
           java.lang.String MFIRationCard,
           java.lang.String MFIUID,
           java.lang.String MFIOtherID) {
           this.MFIVoterID = MFIVoterID;
           this.MFIPANCardID = MFIPANCardID;
           this.MFIRationCard = MFIRationCard;
           this.MFIUID = MFIUID;
           this.MFIOtherID = MFIOtherID;
    }


    /**
     * Gets the MFIVoterID value for this MFIAdditionalIdentityInfoType.
     * 
     * @return MFIVoterID
     */
    public java.lang.String getMFIVoterID() {
        return MFIVoterID;
    }


    /**
     * Sets the MFIVoterID value for this MFIAdditionalIdentityInfoType.
     * 
     * @param MFIVoterID
     */
    public void setMFIVoterID(java.lang.String MFIVoterID) {
        this.MFIVoterID = MFIVoterID;
    }


    /**
     * Gets the MFIPANCardID value for this MFIAdditionalIdentityInfoType.
     * 
     * @return MFIPANCardID
     */
    public java.lang.String getMFIPANCardID() {
        return MFIPANCardID;
    }


    /**
     * Sets the MFIPANCardID value for this MFIAdditionalIdentityInfoType.
     * 
     * @param MFIPANCardID
     */
    public void setMFIPANCardID(java.lang.String MFIPANCardID) {
        this.MFIPANCardID = MFIPANCardID;
    }


    /**
     * Gets the MFIRationCard value for this MFIAdditionalIdentityInfoType.
     * 
     * @return MFIRationCard
     */
    public java.lang.String getMFIRationCard() {
        return MFIRationCard;
    }


    /**
     * Sets the MFIRationCard value for this MFIAdditionalIdentityInfoType.
     * 
     * @param MFIRationCard
     */
    public void setMFIRationCard(java.lang.String MFIRationCard) {
        this.MFIRationCard = MFIRationCard;
    }


    /**
     * Gets the MFIUID value for this MFIAdditionalIdentityInfoType.
     * 
     * @return MFIUID
     */
    public java.lang.String getMFIUID() {
        return MFIUID;
    }


    /**
     * Sets the MFIUID value for this MFIAdditionalIdentityInfoType.
     * 
     * @param MFIUID
     */
    public void setMFIUID(java.lang.String MFIUID) {
        this.MFIUID = MFIUID;
    }


    /**
     * Gets the MFIOtherID value for this MFIAdditionalIdentityInfoType.
     * 
     * @return MFIOtherID
     */
    public java.lang.String getMFIOtherID() {
        return MFIOtherID;
    }


    /**
     * Sets the MFIOtherID value for this MFIAdditionalIdentityInfoType.
     * 
     * @param MFIOtherID
     */
    public void setMFIOtherID(java.lang.String MFIOtherID) {
        this.MFIOtherID = MFIOtherID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MFIAdditionalIdentityInfoType)) return false;
        MFIAdditionalIdentityInfoType other = (MFIAdditionalIdentityInfoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MFIVoterID==null && other.getMFIVoterID()==null) || 
             (this.MFIVoterID!=null &&
              this.MFIVoterID.equals(other.getMFIVoterID()))) &&
            ((this.MFIPANCardID==null && other.getMFIPANCardID()==null) || 
             (this.MFIPANCardID!=null &&
              this.MFIPANCardID.equals(other.getMFIPANCardID()))) &&
            ((this.MFIRationCard==null && other.getMFIRationCard()==null) || 
             (this.MFIRationCard!=null &&
              this.MFIRationCard.equals(other.getMFIRationCard()))) &&
            ((this.MFIUID==null && other.getMFIUID()==null) || 
             (this.MFIUID!=null &&
              this.MFIUID.equals(other.getMFIUID()))) &&
            ((this.MFIOtherID==null && other.getMFIOtherID()==null) || 
             (this.MFIOtherID!=null &&
              this.MFIOtherID.equals(other.getMFIOtherID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMFIVoterID() != null) {
            _hashCode += getMFIVoterID().hashCode();
        }
        if (getMFIPANCardID() != null) {
            _hashCode += getMFIPANCardID().hashCode();
        }
        if (getMFIRationCard() != null) {
            _hashCode += getMFIRationCard().hashCode();
        }
        if (getMFIUID() != null) {
            _hashCode += getMFIUID().hashCode();
        }
        if (getMFIOtherID() != null) {
            _hashCode += getMFIOtherID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MFIAdditionalIdentityInfoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAdditionalIdentityInfoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIVoterID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIVoterID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIPANCardID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIPANCardID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIRationCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIRationCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIOtherID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIOtherID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
