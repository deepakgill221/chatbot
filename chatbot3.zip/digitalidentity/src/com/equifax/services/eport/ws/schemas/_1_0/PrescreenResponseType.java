/**
 * PrescreenResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class PrescreenResponseType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.HeaderDataType headerData;

    private com.equifax.services.eport.ws.schemas._1_0.PIIDataType PIIData;

    private com.equifax.services.eport.ws.schemas._1_0.BureauAttributesType bureauAttributes;

    private com.equifax.services.eport.ws.schemas._1_0.NonBureauAttributesType nonBureauAttributes;

    private com.equifax.services.eport.ws.schemas._1_0.ResponseDataType responseData;

    public PrescreenResponseType() {
    }

    public PrescreenResponseType(
           com.equifax.services.eport.ws.schemas._1_0.HeaderDataType headerData,
           com.equifax.services.eport.ws.schemas._1_0.PIIDataType PIIData,
           com.equifax.services.eport.ws.schemas._1_0.BureauAttributesType bureauAttributes,
           com.equifax.services.eport.ws.schemas._1_0.NonBureauAttributesType nonBureauAttributes,
           com.equifax.services.eport.ws.schemas._1_0.ResponseDataType responseData) {
           this.headerData = headerData;
           this.PIIData = PIIData;
           this.bureauAttributes = bureauAttributes;
           this.nonBureauAttributes = nonBureauAttributes;
           this.responseData = responseData;
    }


    /**
     * Gets the headerData value for this PrescreenResponseType.
     * 
     * @return headerData
     */
    public com.equifax.services.eport.ws.schemas._1_0.HeaderDataType getHeaderData() {
        return headerData;
    }


    /**
     * Sets the headerData value for this PrescreenResponseType.
     * 
     * @param headerData
     */
    public void setHeaderData(com.equifax.services.eport.ws.schemas._1_0.HeaderDataType headerData) {
        this.headerData = headerData;
    }


    /**
     * Gets the PIIData value for this PrescreenResponseType.
     * 
     * @return PIIData
     */
    public com.equifax.services.eport.ws.schemas._1_0.PIIDataType getPIIData() {
        return PIIData;
    }


    /**
     * Sets the PIIData value for this PrescreenResponseType.
     * 
     * @param PIIData
     */
    public void setPIIData(com.equifax.services.eport.ws.schemas._1_0.PIIDataType PIIData) {
        this.PIIData = PIIData;
    }


    /**
     * Gets the bureauAttributes value for this PrescreenResponseType.
     * 
     * @return bureauAttributes
     */
    public com.equifax.services.eport.ws.schemas._1_0.BureauAttributesType getBureauAttributes() {
        return bureauAttributes;
    }


    /**
     * Sets the bureauAttributes value for this PrescreenResponseType.
     * 
     * @param bureauAttributes
     */
    public void setBureauAttributes(com.equifax.services.eport.ws.schemas._1_0.BureauAttributesType bureauAttributes) {
        this.bureauAttributes = bureauAttributes;
    }


    /**
     * Gets the nonBureauAttributes value for this PrescreenResponseType.
     * 
     * @return nonBureauAttributes
     */
    public com.equifax.services.eport.ws.schemas._1_0.NonBureauAttributesType getNonBureauAttributes() {
        return nonBureauAttributes;
    }


    /**
     * Sets the nonBureauAttributes value for this PrescreenResponseType.
     * 
     * @param nonBureauAttributes
     */
    public void setNonBureauAttributes(com.equifax.services.eport.ws.schemas._1_0.NonBureauAttributesType nonBureauAttributes) {
        this.nonBureauAttributes = nonBureauAttributes;
    }


    /**
     * Gets the responseData value for this PrescreenResponseType.
     * 
     * @return responseData
     */
    public com.equifax.services.eport.ws.schemas._1_0.ResponseDataType getResponseData() {
        return responseData;
    }


    /**
     * Sets the responseData value for this PrescreenResponseType.
     * 
     * @param responseData
     */
    public void setResponseData(com.equifax.services.eport.ws.schemas._1_0.ResponseDataType responseData) {
        this.responseData = responseData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PrescreenResponseType)) return false;
        PrescreenResponseType other = (PrescreenResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.headerData==null && other.getHeaderData()==null) || 
             (this.headerData!=null &&
              this.headerData.equals(other.getHeaderData()))) &&
            ((this.PIIData==null && other.getPIIData()==null) || 
             (this.PIIData!=null &&
              this.PIIData.equals(other.getPIIData()))) &&
            ((this.bureauAttributes==null && other.getBureauAttributes()==null) || 
             (this.bureauAttributes!=null &&
              this.bureauAttributes.equals(other.getBureauAttributes()))) &&
            ((this.nonBureauAttributes==null && other.getNonBureauAttributes()==null) || 
             (this.nonBureauAttributes!=null &&
              this.nonBureauAttributes.equals(other.getNonBureauAttributes()))) &&
            ((this.responseData==null && other.getResponseData()==null) || 
             (this.responseData!=null &&
              this.responseData.equals(other.getResponseData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHeaderData() != null) {
            _hashCode += getHeaderData().hashCode();
        }
        if (getPIIData() != null) {
            _hashCode += getPIIData().hashCode();
        }
        if (getBureauAttributes() != null) {
            _hashCode += getBureauAttributes().hashCode();
        }
        if (getNonBureauAttributes() != null) {
            _hashCode += getNonBureauAttributes().hashCode();
        }
        if (getResponseData() != null) {
            _hashCode += getResponseData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PrescreenResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PrescreenResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "HeaderData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "HeaderDataType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PIIData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PIIData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PIIDataType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bureauAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "BureauAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "BureauAttributesType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nonBureauAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NonBureauAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NonBureauAttributesType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ResponseData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ResponseDataType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
