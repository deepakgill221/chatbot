/**
 * RequestBodyType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class RequestBodyType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions inquiryPurpose;

    private java.math.BigDecimal transactionAmount;

    private java.lang.String additionalSearchField;

    private java.lang.String fullName;

    private java.lang.String firstName;

    private java.lang.String middleName;

    private java.lang.String lastName;

    private com.equifax.services.eport.ws.schemas._1_0.FamilyInfo familyDetails;

    private java.lang.String additionalId1;

    private java.lang.String additionalId2;

    private java.lang.String addrLine1;

    private java.lang.String street;

    private java.lang.String locality1;

    private java.lang.String locality2;

    private java.lang.String city;

    private com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions state;

    private java.lang.String postal;

    private com.equifax.services.eport.ws.schemas._1_0.InquiryAddressType[] inquiryAddresses;

    private com.equifax.services.eport.ws.schemas._1_0.InquiryPhoneType[] inquiryPhones;

    private java.util.Date DOB;

    private com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions maritalStatus;

    private com.equifax.services.eport.ws.schemas._1_0.GenderOptions gender;

    private java.lang.String nationalIdCard;

    private java.lang.String rationCard;

    private java.lang.String PANId;

    private java.lang.String passportId;

    private java.lang.String voterId;

    private com.equifax.services.eport.ws.schemas._1_0.LandlineType homePhone;

    private java.lang.String mobilePhone;

    private java.lang.String driverLicense;

    private com.equifax.services.eport.ws.schemas._1_0.AccountInputType requestAccountDetails;

    private com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] inquiryCommonAccountDetails;

    private java.lang.String inquiryFieldsDsv;

    public RequestBodyType() {
    }

    public RequestBodyType(
           com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions inquiryPurpose,
           java.math.BigDecimal transactionAmount,
           java.lang.String additionalSearchField,
           java.lang.String fullName,
           java.lang.String firstName,
           java.lang.String middleName,
           java.lang.String lastName,
           com.equifax.services.eport.ws.schemas._1_0.FamilyInfo familyDetails,
           java.lang.String additionalId1,
           java.lang.String additionalId2,
           java.lang.String addrLine1,
           java.lang.String street,
           java.lang.String locality1,
           java.lang.String locality2,
           java.lang.String city,
           com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions state,
           java.lang.String postal,
           com.equifax.services.eport.ws.schemas._1_0.InquiryAddressType[] inquiryAddresses,
           com.equifax.services.eport.ws.schemas._1_0.InquiryPhoneType[] inquiryPhones,
           java.util.Date DOB,
           com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions maritalStatus,
           com.equifax.services.eport.ws.schemas._1_0.GenderOptions gender,
           java.lang.String nationalIdCard,
           java.lang.String rationCard,
           java.lang.String PANId,
           java.lang.String passportId,
           java.lang.String voterId,
           com.equifax.services.eport.ws.schemas._1_0.LandlineType homePhone,
           java.lang.String mobilePhone,
           java.lang.String driverLicense,
           com.equifax.services.eport.ws.schemas._1_0.AccountInputType requestAccountDetails,
           com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] inquiryCommonAccountDetails,
           java.lang.String inquiryFieldsDsv) {
           this.inquiryPurpose = inquiryPurpose;
           this.transactionAmount = transactionAmount;
           this.additionalSearchField = additionalSearchField;
           this.fullName = fullName;
           this.firstName = firstName;
           this.middleName = middleName;
           this.lastName = lastName;
           this.familyDetails = familyDetails;
           this.additionalId1 = additionalId1;
           this.additionalId2 = additionalId2;
           this.addrLine1 = addrLine1;
           this.street = street;
           this.locality1 = locality1;
           this.locality2 = locality2;
           this.city = city;
           this.state = state;
           this.postal = postal;
           this.inquiryAddresses = inquiryAddresses;
           this.inquiryPhones = inquiryPhones;
           this.DOB = DOB;
           this.maritalStatus = maritalStatus;
           this.gender = gender;
           this.nationalIdCard = nationalIdCard;
           this.rationCard = rationCard;
           this.PANId = PANId;
           this.passportId = passportId;
           this.voterId = voterId;
           this.homePhone = homePhone;
           this.mobilePhone = mobilePhone;
           this.driverLicense = driverLicense;
           this.requestAccountDetails = requestAccountDetails;
           this.inquiryCommonAccountDetails = inquiryCommonAccountDetails;
           this.inquiryFieldsDsv = inquiryFieldsDsv;
    }


    /**
     * Gets the inquiryPurpose value for this RequestBodyType.
     * 
     * @return inquiryPurpose
     */
    public com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions getInquiryPurpose() {
        return inquiryPurpose;
    }


    /**
     * Sets the inquiryPurpose value for this RequestBodyType.
     * 
     * @param inquiryPurpose
     */
    public void setInquiryPurpose(com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions inquiryPurpose) {
        this.inquiryPurpose = inquiryPurpose;
    }


    /**
     * Gets the transactionAmount value for this RequestBodyType.
     * 
     * @return transactionAmount
     */
    public java.math.BigDecimal getTransactionAmount() {
        return transactionAmount;
    }


    /**
     * Sets the transactionAmount value for this RequestBodyType.
     * 
     * @param transactionAmount
     */
    public void setTransactionAmount(java.math.BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }


    /**
     * Gets the additionalSearchField value for this RequestBodyType.
     * 
     * @return additionalSearchField
     */
    public java.lang.String getAdditionalSearchField() {
        return additionalSearchField;
    }


    /**
     * Sets the additionalSearchField value for this RequestBodyType.
     * 
     * @param additionalSearchField
     */
    public void setAdditionalSearchField(java.lang.String additionalSearchField) {
        this.additionalSearchField = additionalSearchField;
    }


    /**
     * Gets the fullName value for this RequestBodyType.
     * 
     * @return fullName
     */
    public java.lang.String getFullName() {
        return fullName;
    }


    /**
     * Sets the fullName value for this RequestBodyType.
     * 
     * @param fullName
     */
    public void setFullName(java.lang.String fullName) {
        this.fullName = fullName;
    }


    /**
     * Gets the firstName value for this RequestBodyType.
     * 
     * @return firstName
     */
    public java.lang.String getFirstName() {
        return firstName;
    }


    /**
     * Sets the firstName value for this RequestBodyType.
     * 
     * @param firstName
     */
    public void setFirstName(java.lang.String firstName) {
        this.firstName = firstName;
    }


    /**
     * Gets the middleName value for this RequestBodyType.
     * 
     * @return middleName
     */
    public java.lang.String getMiddleName() {
        return middleName;
    }


    /**
     * Sets the middleName value for this RequestBodyType.
     * 
     * @param middleName
     */
    public void setMiddleName(java.lang.String middleName) {
        this.middleName = middleName;
    }


    /**
     * Gets the lastName value for this RequestBodyType.
     * 
     * @return lastName
     */
    public java.lang.String getLastName() {
        return lastName;
    }


    /**
     * Sets the lastName value for this RequestBodyType.
     * 
     * @param lastName
     */
    public void setLastName(java.lang.String lastName) {
        this.lastName = lastName;
    }


    /**
     * Gets the familyDetails value for this RequestBodyType.
     * 
     * @return familyDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.FamilyInfo getFamilyDetails() {
        return familyDetails;
    }


    /**
     * Sets the familyDetails value for this RequestBodyType.
     * 
     * @param familyDetails
     */
    public void setFamilyDetails(com.equifax.services.eport.ws.schemas._1_0.FamilyInfo familyDetails) {
        this.familyDetails = familyDetails;
    }


    /**
     * Gets the additionalId1 value for this RequestBodyType.
     * 
     * @return additionalId1
     */
    public java.lang.String getAdditionalId1() {
        return additionalId1;
    }


    /**
     * Sets the additionalId1 value for this RequestBodyType.
     * 
     * @param additionalId1
     */
    public void setAdditionalId1(java.lang.String additionalId1) {
        this.additionalId1 = additionalId1;
    }


    /**
     * Gets the additionalId2 value for this RequestBodyType.
     * 
     * @return additionalId2
     */
    public java.lang.String getAdditionalId2() {
        return additionalId2;
    }


    /**
     * Sets the additionalId2 value for this RequestBodyType.
     * 
     * @param additionalId2
     */
    public void setAdditionalId2(java.lang.String additionalId2) {
        this.additionalId2 = additionalId2;
    }


    /**
     * Gets the addrLine1 value for this RequestBodyType.
     * 
     * @return addrLine1
     */
    public java.lang.String getAddrLine1() {
        return addrLine1;
    }


    /**
     * Sets the addrLine1 value for this RequestBodyType.
     * 
     * @param addrLine1
     */
    public void setAddrLine1(java.lang.String addrLine1) {
        this.addrLine1 = addrLine1;
    }


    /**
     * Gets the street value for this RequestBodyType.
     * 
     * @return street
     */
    public java.lang.String getStreet() {
        return street;
    }


    /**
     * Sets the street value for this RequestBodyType.
     * 
     * @param street
     */
    public void setStreet(java.lang.String street) {
        this.street = street;
    }


    /**
     * Gets the locality1 value for this RequestBodyType.
     * 
     * @return locality1
     */
    public java.lang.String getLocality1() {
        return locality1;
    }


    /**
     * Sets the locality1 value for this RequestBodyType.
     * 
     * @param locality1
     */
    public void setLocality1(java.lang.String locality1) {
        this.locality1 = locality1;
    }


    /**
     * Gets the locality2 value for this RequestBodyType.
     * 
     * @return locality2
     */
    public java.lang.String getLocality2() {
        return locality2;
    }


    /**
     * Sets the locality2 value for this RequestBodyType.
     * 
     * @param locality2
     */
    public void setLocality2(java.lang.String locality2) {
        this.locality2 = locality2;
    }


    /**
     * Gets the city value for this RequestBodyType.
     * 
     * @return city
     */
    public java.lang.String getCity() {
        return city;
    }


    /**
     * Sets the city value for this RequestBodyType.
     * 
     * @param city
     */
    public void setCity(java.lang.String city) {
        this.city = city;
    }


    /**
     * Gets the state value for this RequestBodyType.
     * 
     * @return state
     */
    public com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions getState() {
        return state;
    }


    /**
     * Sets the state value for this RequestBodyType.
     * 
     * @param state
     */
    public void setState(com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions state) {
        this.state = state;
    }


    /**
     * Gets the postal value for this RequestBodyType.
     * 
     * @return postal
     */
    public java.lang.String getPostal() {
        return postal;
    }


    /**
     * Sets the postal value for this RequestBodyType.
     * 
     * @param postal
     */
    public void setPostal(java.lang.String postal) {
        this.postal = postal;
    }


    /**
     * Gets the inquiryAddresses value for this RequestBodyType.
     * 
     * @return inquiryAddresses
     */
    public com.equifax.services.eport.ws.schemas._1_0.InquiryAddressType[] getInquiryAddresses() {
        return inquiryAddresses;
    }


    /**
     * Sets the inquiryAddresses value for this RequestBodyType.
     * 
     * @param inquiryAddresses
     */
    public void setInquiryAddresses(com.equifax.services.eport.ws.schemas._1_0.InquiryAddressType[] inquiryAddresses) {
        this.inquiryAddresses = inquiryAddresses;
    }


    /**
     * Gets the inquiryPhones value for this RequestBodyType.
     * 
     * @return inquiryPhones
     */
    public com.equifax.services.eport.ws.schemas._1_0.InquiryPhoneType[] getInquiryPhones() {
        return inquiryPhones;
    }


    /**
     * Sets the inquiryPhones value for this RequestBodyType.
     * 
     * @param inquiryPhones
     */
    public void setInquiryPhones(com.equifax.services.eport.ws.schemas._1_0.InquiryPhoneType[] inquiryPhones) {
        this.inquiryPhones = inquiryPhones;
    }


    /**
     * Gets the DOB value for this RequestBodyType.
     * 
     * @return DOB
     */
    public java.util.Date getDOB() {
        return DOB;
    }


    /**
     * Sets the DOB value for this RequestBodyType.
     * 
     * @param DOB
     */
    public void setDOB(java.util.Date DOB) {
        this.DOB = DOB;
    }


    /**
     * Gets the maritalStatus value for this RequestBodyType.
     * 
     * @return maritalStatus
     */
    public com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions getMaritalStatus() {
        return maritalStatus;
    }


    /**
     * Sets the maritalStatus value for this RequestBodyType.
     * 
     * @param maritalStatus
     */
    public void setMaritalStatus(com.equifax.services.eport.ws.schemas._1_0.MaritalStatusOptions maritalStatus) {
        this.maritalStatus = maritalStatus;
    }


    /**
     * Gets the gender value for this RequestBodyType.
     * 
     * @return gender
     */
    public com.equifax.services.eport.ws.schemas._1_0.GenderOptions getGender() {
        return gender;
    }


    /**
     * Sets the gender value for this RequestBodyType.
     * 
     * @param gender
     */
    public void setGender(com.equifax.services.eport.ws.schemas._1_0.GenderOptions gender) {
        this.gender = gender;
    }


    /**
     * Gets the nationalIdCard value for this RequestBodyType.
     * 
     * @return nationalIdCard
     */
    public java.lang.String getNationalIdCard() {
        return nationalIdCard;
    }


    /**
     * Sets the nationalIdCard value for this RequestBodyType.
     * 
     * @param nationalIdCard
     */
    public void setNationalIdCard(java.lang.String nationalIdCard) {
        this.nationalIdCard = nationalIdCard;
    }


    /**
     * Gets the rationCard value for this RequestBodyType.
     * 
     * @return rationCard
     */
    public java.lang.String getRationCard() {
        return rationCard;
    }


    /**
     * Sets the rationCard value for this RequestBodyType.
     * 
     * @param rationCard
     */
    public void setRationCard(java.lang.String rationCard) {
        this.rationCard = rationCard;
    }


    /**
     * Gets the PANId value for this RequestBodyType.
     * 
     * @return PANId
     */
    public java.lang.String getPANId() {
        return PANId;
    }


    /**
     * Sets the PANId value for this RequestBodyType.
     * 
     * @param PANId
     */
    public void setPANId(java.lang.String PANId) {
        this.PANId = PANId;
    }


    /**
     * Gets the passportId value for this RequestBodyType.
     * 
     * @return passportId
     */
    public java.lang.String getPassportId() {
        return passportId;
    }


    /**
     * Sets the passportId value for this RequestBodyType.
     * 
     * @param passportId
     */
    public void setPassportId(java.lang.String passportId) {
        this.passportId = passportId;
    }


    /**
     * Gets the voterId value for this RequestBodyType.
     * 
     * @return voterId
     */
    public java.lang.String getVoterId() {
        return voterId;
    }


    /**
     * Sets the voterId value for this RequestBodyType.
     * 
     * @param voterId
     */
    public void setVoterId(java.lang.String voterId) {
        this.voterId = voterId;
    }


    /**
     * Gets the homePhone value for this RequestBodyType.
     * 
     * @return homePhone
     */
    public com.equifax.services.eport.ws.schemas._1_0.LandlineType getHomePhone() {
        return homePhone;
    }


    /**
     * Sets the homePhone value for this RequestBodyType.
     * 
     * @param homePhone
     */
    public void setHomePhone(com.equifax.services.eport.ws.schemas._1_0.LandlineType homePhone) {
        this.homePhone = homePhone;
    }


    /**
     * Gets the mobilePhone value for this RequestBodyType.
     * 
     * @return mobilePhone
     */
    public java.lang.String getMobilePhone() {
        return mobilePhone;
    }


    /**
     * Sets the mobilePhone value for this RequestBodyType.
     * 
     * @param mobilePhone
     */
    public void setMobilePhone(java.lang.String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }


    /**
     * Gets the driverLicense value for this RequestBodyType.
     * 
     * @return driverLicense
     */
    public java.lang.String getDriverLicense() {
        return driverLicense;
    }


    /**
     * Sets the driverLicense value for this RequestBodyType.
     * 
     * @param driverLicense
     */
    public void setDriverLicense(java.lang.String driverLicense) {
        this.driverLicense = driverLicense;
    }


    /**
     * Gets the requestAccountDetails value for this RequestBodyType.
     * 
     * @return requestAccountDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountInputType getRequestAccountDetails() {
        return requestAccountDetails;
    }


    /**
     * Sets the requestAccountDetails value for this RequestBodyType.
     * 
     * @param requestAccountDetails
     */
    public void setRequestAccountDetails(com.equifax.services.eport.ws.schemas._1_0.AccountInputType requestAccountDetails) {
        this.requestAccountDetails = requestAccountDetails;
    }


    /**
     * Gets the inquiryCommonAccountDetails value for this RequestBodyType.
     * 
     * @return inquiryCommonAccountDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] getInquiryCommonAccountDetails() {
        return inquiryCommonAccountDetails;
    }


    /**
     * Sets the inquiryCommonAccountDetails value for this RequestBodyType.
     * 
     * @param inquiryCommonAccountDetails
     */
    public void setInquiryCommonAccountDetails(com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] inquiryCommonAccountDetails) {
        this.inquiryCommonAccountDetails = inquiryCommonAccountDetails;
    }


    /**
     * Gets the inquiryFieldsDsv value for this RequestBodyType.
     * 
     * @return inquiryFieldsDsv
     */
    public java.lang.String getInquiryFieldsDsv() {
        return inquiryFieldsDsv;
    }


    /**
     * Sets the inquiryFieldsDsv value for this RequestBodyType.
     * 
     * @param inquiryFieldsDsv
     */
    public void setInquiryFieldsDsv(java.lang.String inquiryFieldsDsv) {
        this.inquiryFieldsDsv = inquiryFieldsDsv;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RequestBodyType)) return false;
        RequestBodyType other = (RequestBodyType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.inquiryPurpose==null && other.getInquiryPurpose()==null) || 
             (this.inquiryPurpose!=null &&
              this.inquiryPurpose.equals(other.getInquiryPurpose()))) &&
            ((this.transactionAmount==null && other.getTransactionAmount()==null) || 
             (this.transactionAmount!=null &&
              this.transactionAmount.equals(other.getTransactionAmount()))) &&
            ((this.additionalSearchField==null && other.getAdditionalSearchField()==null) || 
             (this.additionalSearchField!=null &&
              this.additionalSearchField.equals(other.getAdditionalSearchField()))) &&
            ((this.fullName==null && other.getFullName()==null) || 
             (this.fullName!=null &&
              this.fullName.equals(other.getFullName()))) &&
            ((this.firstName==null && other.getFirstName()==null) || 
             (this.firstName!=null &&
              this.firstName.equals(other.getFirstName()))) &&
            ((this.middleName==null && other.getMiddleName()==null) || 
             (this.middleName!=null &&
              this.middleName.equals(other.getMiddleName()))) &&
            ((this.lastName==null && other.getLastName()==null) || 
             (this.lastName!=null &&
              this.lastName.equals(other.getLastName()))) &&
            ((this.familyDetails==null && other.getFamilyDetails()==null) || 
             (this.familyDetails!=null &&
              this.familyDetails.equals(other.getFamilyDetails()))) &&
            ((this.additionalId1==null && other.getAdditionalId1()==null) || 
             (this.additionalId1!=null &&
              this.additionalId1.equals(other.getAdditionalId1()))) &&
            ((this.additionalId2==null && other.getAdditionalId2()==null) || 
             (this.additionalId2!=null &&
              this.additionalId2.equals(other.getAdditionalId2()))) &&
            ((this.addrLine1==null && other.getAddrLine1()==null) || 
             (this.addrLine1!=null &&
              this.addrLine1.equals(other.getAddrLine1()))) &&
            ((this.street==null && other.getStreet()==null) || 
             (this.street!=null &&
              this.street.equals(other.getStreet()))) &&
            ((this.locality1==null && other.getLocality1()==null) || 
             (this.locality1!=null &&
              this.locality1.equals(other.getLocality1()))) &&
            ((this.locality2==null && other.getLocality2()==null) || 
             (this.locality2!=null &&
              this.locality2.equals(other.getLocality2()))) &&
            ((this.city==null && other.getCity()==null) || 
             (this.city!=null &&
              this.city.equals(other.getCity()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.postal==null && other.getPostal()==null) || 
             (this.postal!=null &&
              this.postal.equals(other.getPostal()))) &&
            ((this.inquiryAddresses==null && other.getInquiryAddresses()==null) || 
             (this.inquiryAddresses!=null &&
              java.util.Arrays.equals(this.inquiryAddresses, other.getInquiryAddresses()))) &&
            ((this.inquiryPhones==null && other.getInquiryPhones()==null) || 
             (this.inquiryPhones!=null &&
              java.util.Arrays.equals(this.inquiryPhones, other.getInquiryPhones()))) &&
            ((this.DOB==null && other.getDOB()==null) || 
             (this.DOB!=null &&
              this.DOB.equals(other.getDOB()))) &&
            ((this.maritalStatus==null && other.getMaritalStatus()==null) || 
             (this.maritalStatus!=null &&
              this.maritalStatus.equals(other.getMaritalStatus()))) &&
            ((this.gender==null && other.getGender()==null) || 
             (this.gender!=null &&
              this.gender.equals(other.getGender()))) &&
            ((this.nationalIdCard==null && other.getNationalIdCard()==null) || 
             (this.nationalIdCard!=null &&
              this.nationalIdCard.equals(other.getNationalIdCard()))) &&
            ((this.rationCard==null && other.getRationCard()==null) || 
             (this.rationCard!=null &&
              this.rationCard.equals(other.getRationCard()))) &&
            ((this.PANId==null && other.getPANId()==null) || 
             (this.PANId!=null &&
              this.PANId.equals(other.getPANId()))) &&
            ((this.passportId==null && other.getPassportId()==null) || 
             (this.passportId!=null &&
              this.passportId.equals(other.getPassportId()))) &&
            ((this.voterId==null && other.getVoterId()==null) || 
             (this.voterId!=null &&
              this.voterId.equals(other.getVoterId()))) &&
            ((this.homePhone==null && other.getHomePhone()==null) || 
             (this.homePhone!=null &&
              this.homePhone.equals(other.getHomePhone()))) &&
            ((this.mobilePhone==null && other.getMobilePhone()==null) || 
             (this.mobilePhone!=null &&
              this.mobilePhone.equals(other.getMobilePhone()))) &&
            ((this.driverLicense==null && other.getDriverLicense()==null) || 
             (this.driverLicense!=null &&
              this.driverLicense.equals(other.getDriverLicense()))) &&
            ((this.requestAccountDetails==null && other.getRequestAccountDetails()==null) || 
             (this.requestAccountDetails!=null &&
              this.requestAccountDetails.equals(other.getRequestAccountDetails()))) &&
            ((this.inquiryCommonAccountDetails==null && other.getInquiryCommonAccountDetails()==null) || 
             (this.inquiryCommonAccountDetails!=null &&
              java.util.Arrays.equals(this.inquiryCommonAccountDetails, other.getInquiryCommonAccountDetails()))) &&
            ((this.inquiryFieldsDsv==null && other.getInquiryFieldsDsv()==null) || 
             (this.inquiryFieldsDsv!=null &&
              this.inquiryFieldsDsv.equals(other.getInquiryFieldsDsv())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getInquiryPurpose() != null) {
            _hashCode += getInquiryPurpose().hashCode();
        }
        if (getTransactionAmount() != null) {
            _hashCode += getTransactionAmount().hashCode();
        }
        if (getAdditionalSearchField() != null) {
            _hashCode += getAdditionalSearchField().hashCode();
        }
        if (getFullName() != null) {
            _hashCode += getFullName().hashCode();
        }
        if (getFirstName() != null) {
            _hashCode += getFirstName().hashCode();
        }
        if (getMiddleName() != null) {
            _hashCode += getMiddleName().hashCode();
        }
        if (getLastName() != null) {
            _hashCode += getLastName().hashCode();
        }
        if (getFamilyDetails() != null) {
            _hashCode += getFamilyDetails().hashCode();
        }
        if (getAdditionalId1() != null) {
            _hashCode += getAdditionalId1().hashCode();
        }
        if (getAdditionalId2() != null) {
            _hashCode += getAdditionalId2().hashCode();
        }
        if (getAddrLine1() != null) {
            _hashCode += getAddrLine1().hashCode();
        }
        if (getStreet() != null) {
            _hashCode += getStreet().hashCode();
        }
        if (getLocality1() != null) {
            _hashCode += getLocality1().hashCode();
        }
        if (getLocality2() != null) {
            _hashCode += getLocality2().hashCode();
        }
        if (getCity() != null) {
            _hashCode += getCity().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getPostal() != null) {
            _hashCode += getPostal().hashCode();
        }
        if (getInquiryAddresses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInquiryAddresses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInquiryAddresses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInquiryPhones() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInquiryPhones());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInquiryPhones(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDOB() != null) {
            _hashCode += getDOB().hashCode();
        }
        if (getMaritalStatus() != null) {
            _hashCode += getMaritalStatus().hashCode();
        }
        if (getGender() != null) {
            _hashCode += getGender().hashCode();
        }
        if (getNationalIdCard() != null) {
            _hashCode += getNationalIdCard().hashCode();
        }
        if (getRationCard() != null) {
            _hashCode += getRationCard().hashCode();
        }
        if (getPANId() != null) {
            _hashCode += getPANId().hashCode();
        }
        if (getPassportId() != null) {
            _hashCode += getPassportId().hashCode();
        }
        if (getVoterId() != null) {
            _hashCode += getVoterId().hashCode();
        }
        if (getHomePhone() != null) {
            _hashCode += getHomePhone().hashCode();
        }
        if (getMobilePhone() != null) {
            _hashCode += getMobilePhone().hashCode();
        }
        if (getDriverLicense() != null) {
            _hashCode += getDriverLicense().hashCode();
        }
        if (getRequestAccountDetails() != null) {
            _hashCode += getRequestAccountDetails().hashCode();
        }
        if (getInquiryCommonAccountDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInquiryCommonAccountDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInquiryCommonAccountDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInquiryFieldsDsv() != null) {
            _hashCode += getInquiryFieldsDsv().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RequestBodyType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestBodyType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryPurpose");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPurpose"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPurposeOptions"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TransactionAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalSearchField");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalSearchField"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fullName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FullName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FirstName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("middleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MiddleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LastName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("familyDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FamilyDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "FamilyInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalId1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalId1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalId2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalId2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addrLine1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AddrLine1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("street");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Street"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locality1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Locality1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locality2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Locality2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "City"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "State"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "StateCodeOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Postal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAddress"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryPhones");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPhones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPhoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPhone"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DOB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maritalStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MaritalStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MaritalStatusOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Gender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GenderOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nationalIdCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NationalIdCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rationCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RationCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PANId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PANId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">PANId"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passportId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PassportId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">PassportId"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voterId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "VoterId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">VoterId"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("homePhone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "HomePhone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LandlineType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mobilePhone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MobilePhone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", ">MobilePhone"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("driverLicense");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DriverLicense"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestAccountDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestAccountDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryCommonAccountDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryCommonAccountDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAccount"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryFieldsDsv");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryFieldsDsv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
