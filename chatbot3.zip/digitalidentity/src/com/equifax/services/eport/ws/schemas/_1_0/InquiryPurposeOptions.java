/**
 * InquiryPurposeOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class InquiryPurposeOptions implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected InquiryPurposeOptions(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "01";
    public static final java.lang.String _value2 = "02";
    public static final java.lang.String _value3 = "03";
    public static final java.lang.String _value4 = "04";
    public static final java.lang.String _value5 = "06";
    public static final java.lang.String _value6 = "05";
    public static final java.lang.String _value7 = "07";
    public static final java.lang.String _value8 = "08";
    public static final java.lang.String _value9 = "11";
    public static final java.lang.String _value10 = "12";
    public static final java.lang.String _value11 = "13";
    public static final java.lang.String _value12 = "14";
    public static final java.lang.String _value13 = "15";
    public static final java.lang.String _value14 = "16";
    public static final java.lang.String _value15 = "3A";
    public static final java.lang.String _value16 = "10";
    public static final java.lang.String _value17 = "32";
    public static final java.lang.String _value18 = "33";
    public static final java.lang.String _value19 = "35";
    public static final java.lang.String _value20 = "36";
    public static final java.lang.String _value21 = "34";
    public static final java.lang.String _value22 = "09";
    public static final java.lang.String _value23 = "00";
    public static final java.lang.String _value24 = "0E";
    public static final java.lang.String _value25 = "1E";
    public static final java.lang.String _value26 = "2E";
    public static final java.lang.String _value27 = "3E";
    public static final java.lang.String _value28 = "1G";
    public static final java.lang.String _value29 = "51";
    public static final java.lang.String _value30 = "52";
    public static final java.lang.String _value31 = "V1";
    public static final java.lang.String _value32 = "17";
    public static final java.lang.String _value33 = "18";
    public static final java.lang.String _value34 = "19";
    public static final java.lang.String _value35 = "20";
    public static final java.lang.String _value36 = "53";
    public static final java.lang.String _value37 = "54";
    public static final java.lang.String _value38 = "55";
    public static final java.lang.String _value39 = "56";
    public static final java.lang.String _value40 = "57";
    public static final java.lang.String _value41 = "58";
    public static final java.lang.String _value42 = "59";
    public static final java.lang.String _value43 = "60";
    public static final java.lang.String _value44 = "31";
    public static final java.lang.String _value45 = "8A";
    public static final InquiryPurposeOptions value1 = new InquiryPurposeOptions(_value1);
    public static final InquiryPurposeOptions value2 = new InquiryPurposeOptions(_value2);
    public static final InquiryPurposeOptions value3 = new InquiryPurposeOptions(_value3);
    public static final InquiryPurposeOptions value4 = new InquiryPurposeOptions(_value4);
    public static final InquiryPurposeOptions value5 = new InquiryPurposeOptions(_value5);
    public static final InquiryPurposeOptions value6 = new InquiryPurposeOptions(_value6);
    public static final InquiryPurposeOptions value7 = new InquiryPurposeOptions(_value7);
    public static final InquiryPurposeOptions value8 = new InquiryPurposeOptions(_value8);
    public static final InquiryPurposeOptions value9 = new InquiryPurposeOptions(_value9);
    public static final InquiryPurposeOptions value10 = new InquiryPurposeOptions(_value10);
    public static final InquiryPurposeOptions value11 = new InquiryPurposeOptions(_value11);
    public static final InquiryPurposeOptions value12 = new InquiryPurposeOptions(_value12);
    public static final InquiryPurposeOptions value13 = new InquiryPurposeOptions(_value13);
    public static final InquiryPurposeOptions value14 = new InquiryPurposeOptions(_value14);
    public static final InquiryPurposeOptions value15 = new InquiryPurposeOptions(_value15);
    public static final InquiryPurposeOptions value16 = new InquiryPurposeOptions(_value16);
    public static final InquiryPurposeOptions value17 = new InquiryPurposeOptions(_value17);
    public static final InquiryPurposeOptions value18 = new InquiryPurposeOptions(_value18);
    public static final InquiryPurposeOptions value19 = new InquiryPurposeOptions(_value19);
    public static final InquiryPurposeOptions value20 = new InquiryPurposeOptions(_value20);
    public static final InquiryPurposeOptions value21 = new InquiryPurposeOptions(_value21);
    public static final InquiryPurposeOptions value22 = new InquiryPurposeOptions(_value22);
    public static final InquiryPurposeOptions value23 = new InquiryPurposeOptions(_value23);
    public static final InquiryPurposeOptions value24 = new InquiryPurposeOptions(_value24);
    public static final InquiryPurposeOptions value25 = new InquiryPurposeOptions(_value25);
    public static final InquiryPurposeOptions value26 = new InquiryPurposeOptions(_value26);
    public static final InquiryPurposeOptions value27 = new InquiryPurposeOptions(_value27);
    public static final InquiryPurposeOptions value28 = new InquiryPurposeOptions(_value28);
    public static final InquiryPurposeOptions value29 = new InquiryPurposeOptions(_value29);
    public static final InquiryPurposeOptions value30 = new InquiryPurposeOptions(_value30);
    public static final InquiryPurposeOptions value31 = new InquiryPurposeOptions(_value31);
    public static final InquiryPurposeOptions value32 = new InquiryPurposeOptions(_value32);
    public static final InquiryPurposeOptions value33 = new InquiryPurposeOptions(_value33);
    public static final InquiryPurposeOptions value34 = new InquiryPurposeOptions(_value34);
    public static final InquiryPurposeOptions value35 = new InquiryPurposeOptions(_value35);
    public static final InquiryPurposeOptions value36 = new InquiryPurposeOptions(_value36);
    public static final InquiryPurposeOptions value37 = new InquiryPurposeOptions(_value37);
    public static final InquiryPurposeOptions value38 = new InquiryPurposeOptions(_value38);
    public static final InquiryPurposeOptions value39 = new InquiryPurposeOptions(_value39);
    public static final InquiryPurposeOptions value40 = new InquiryPurposeOptions(_value40);
    public static final InquiryPurposeOptions value41 = new InquiryPurposeOptions(_value41);
    public static final InquiryPurposeOptions value42 = new InquiryPurposeOptions(_value42);
    public static final InquiryPurposeOptions value43 = new InquiryPurposeOptions(_value43);
    public static final InquiryPurposeOptions value44 = new InquiryPurposeOptions(_value44);
    public static final InquiryPurposeOptions value45 = new InquiryPurposeOptions(_value45);
    public java.lang.String getValue() { return _value_;}
    public static InquiryPurposeOptions fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        InquiryPurposeOptions enumeration = (InquiryPurposeOptions)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static InquiryPurposeOptions fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InquiryPurposeOptions.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryPurposeOptions"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
