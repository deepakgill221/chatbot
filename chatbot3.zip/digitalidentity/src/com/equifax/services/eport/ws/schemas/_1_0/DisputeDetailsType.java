/**
 * DisputeDetailsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;


/**
 * Individual Disputes
 */
public class DisputeDetailsType  implements java.io.Serializable {
    private java.lang.String accNum;

    private java.lang.String disputeComments;

    private java.lang.String status;

    private java.util.Date resolvedDate;

    private java.lang.String type;  // attribute

    public DisputeDetailsType() {
    }

    public DisputeDetailsType(
           java.lang.String accNum,
           java.lang.String disputeComments,
           java.lang.String status,
           java.util.Date resolvedDate,
           java.lang.String type) {
           this.accNum = accNum;
           this.disputeComments = disputeComments;
           this.status = status;
           this.resolvedDate = resolvedDate;
           this.type = type;
    }


    /**
     * Gets the accNum value for this DisputeDetailsType.
     * 
     * @return accNum
     */
    public java.lang.String getAccNum() {
        return accNum;
    }


    /**
     * Sets the accNum value for this DisputeDetailsType.
     * 
     * @param accNum
     */
    public void setAccNum(java.lang.String accNum) {
        this.accNum = accNum;
    }


    /**
     * Gets the disputeComments value for this DisputeDetailsType.
     * 
     * @return disputeComments
     */
    public java.lang.String getDisputeComments() {
        return disputeComments;
    }


    /**
     * Sets the disputeComments value for this DisputeDetailsType.
     * 
     * @param disputeComments
     */
    public void setDisputeComments(java.lang.String disputeComments) {
        this.disputeComments = disputeComments;
    }


    /**
     * Gets the status value for this DisputeDetailsType.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this DisputeDetailsType.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the resolvedDate value for this DisputeDetailsType.
     * 
     * @return resolvedDate
     */
    public java.util.Date getResolvedDate() {
        return resolvedDate;
    }


    /**
     * Sets the resolvedDate value for this DisputeDetailsType.
     * 
     * @param resolvedDate
     */
    public void setResolvedDate(java.util.Date resolvedDate) {
        this.resolvedDate = resolvedDate;
    }


    /**
     * Gets the type value for this DisputeDetailsType.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this DisputeDetailsType.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DisputeDetailsType)) return false;
        DisputeDetailsType other = (DisputeDetailsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accNum==null && other.getAccNum()==null) || 
             (this.accNum!=null &&
              this.accNum.equals(other.getAccNum()))) &&
            ((this.disputeComments==null && other.getDisputeComments()==null) || 
             (this.disputeComments!=null &&
              this.disputeComments.equals(other.getDisputeComments()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.resolvedDate==null && other.getResolvedDate()==null) || 
             (this.resolvedDate!=null &&
              this.resolvedDate.equals(other.getResolvedDate()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccNum() != null) {
            _hashCode += getAccNum().hashCode();
        }
        if (getDisputeComments() != null) {
            _hashCode += getDisputeComments().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getResolvedDate() != null) {
            _hashCode += getResolvedDate().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DisputeDetailsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisputeDetailsType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("type");
        attrField.setXmlName(new javax.xml.namespace.QName("", "type"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accNum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disputeComments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisputeComments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resolvedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ResolvedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
