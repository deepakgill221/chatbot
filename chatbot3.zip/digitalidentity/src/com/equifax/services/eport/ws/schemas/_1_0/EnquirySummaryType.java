/**
 * EnquirySummaryType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class EnquirySummaryType  implements java.io.Serializable {
    private java.lang.String purpose;

    private java.lang.String total;

    private java.lang.String past30Days;

    private java.lang.String past12Months;

    private java.lang.String past24Months;

    private java.lang.String recent;

    private int seq;  // attribute

    private java.util.Date reportedDate;  // attribute

    public EnquirySummaryType() {
    }

    public EnquirySummaryType(
           java.lang.String purpose,
           java.lang.String total,
           java.lang.String past30Days,
           java.lang.String past12Months,
           java.lang.String past24Months,
           java.lang.String recent,
           int seq,
           java.util.Date reportedDate) {
           this.purpose = purpose;
           this.total = total;
           this.past30Days = past30Days;
           this.past12Months = past12Months;
           this.past24Months = past24Months;
           this.recent = recent;
           this.seq = seq;
           this.reportedDate = reportedDate;
    }


    /**
     * Gets the purpose value for this EnquirySummaryType.
     * 
     * @return purpose
     */
    public java.lang.String getPurpose() {
        return purpose;
    }


    /**
     * Sets the purpose value for this EnquirySummaryType.
     * 
     * @param purpose
     */
    public void setPurpose(java.lang.String purpose) {
        this.purpose = purpose;
    }


    /**
     * Gets the total value for this EnquirySummaryType.
     * 
     * @return total
     */
    public java.lang.String getTotal() {
        return total;
    }


    /**
     * Sets the total value for this EnquirySummaryType.
     * 
     * @param total
     */
    public void setTotal(java.lang.String total) {
        this.total = total;
    }


    /**
     * Gets the past30Days value for this EnquirySummaryType.
     * 
     * @return past30Days
     */
    public java.lang.String getPast30Days() {
        return past30Days;
    }


    /**
     * Sets the past30Days value for this EnquirySummaryType.
     * 
     * @param past30Days
     */
    public void setPast30Days(java.lang.String past30Days) {
        this.past30Days = past30Days;
    }


    /**
     * Gets the past12Months value for this EnquirySummaryType.
     * 
     * @return past12Months
     */
    public java.lang.String getPast12Months() {
        return past12Months;
    }


    /**
     * Sets the past12Months value for this EnquirySummaryType.
     * 
     * @param past12Months
     */
    public void setPast12Months(java.lang.String past12Months) {
        this.past12Months = past12Months;
    }


    /**
     * Gets the past24Months value for this EnquirySummaryType.
     * 
     * @return past24Months
     */
    public java.lang.String getPast24Months() {
        return past24Months;
    }


    /**
     * Sets the past24Months value for this EnquirySummaryType.
     * 
     * @param past24Months
     */
    public void setPast24Months(java.lang.String past24Months) {
        this.past24Months = past24Months;
    }


    /**
     * Gets the recent value for this EnquirySummaryType.
     * 
     * @return recent
     */
    public java.lang.String getRecent() {
        return recent;
    }


    /**
     * Sets the recent value for this EnquirySummaryType.
     * 
     * @param recent
     */
    public void setRecent(java.lang.String recent) {
        this.recent = recent;
    }


    /**
     * Gets the seq value for this EnquirySummaryType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this EnquirySummaryType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }


    /**
     * Gets the reportedDate value for this EnquirySummaryType.
     * 
     * @return reportedDate
     */
    public java.util.Date getReportedDate() {
        return reportedDate;
    }


    /**
     * Sets the reportedDate value for this EnquirySummaryType.
     * 
     * @param reportedDate
     */
    public void setReportedDate(java.util.Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EnquirySummaryType)) return false;
        EnquirySummaryType other = (EnquirySummaryType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.purpose==null && other.getPurpose()==null) || 
             (this.purpose!=null &&
              this.purpose.equals(other.getPurpose()))) &&
            ((this.total==null && other.getTotal()==null) || 
             (this.total!=null &&
              this.total.equals(other.getTotal()))) &&
            ((this.past30Days==null && other.getPast30Days()==null) || 
             (this.past30Days!=null &&
              this.past30Days.equals(other.getPast30Days()))) &&
            ((this.past12Months==null && other.getPast12Months()==null) || 
             (this.past12Months!=null &&
              this.past12Months.equals(other.getPast12Months()))) &&
            ((this.past24Months==null && other.getPast24Months()==null) || 
             (this.past24Months!=null &&
              this.past24Months.equals(other.getPast24Months()))) &&
            ((this.recent==null && other.getRecent()==null) || 
             (this.recent!=null &&
              this.recent.equals(other.getRecent()))) &&
            this.seq == other.getSeq() &&
            ((this.reportedDate==null && other.getReportedDate()==null) || 
             (this.reportedDate!=null &&
              this.reportedDate.equals(other.getReportedDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPurpose() != null) {
            _hashCode += getPurpose().hashCode();
        }
        if (getTotal() != null) {
            _hashCode += getTotal().hashCode();
        }
        if (getPast30Days() != null) {
            _hashCode += getPast30Days().hashCode();
        }
        if (getPast12Months() != null) {
            _hashCode += getPast12Months().hashCode();
        }
        if (getPast24Months() != null) {
            _hashCode += getPast24Months().hashCode();
        }
        if (getRecent() != null) {
            _hashCode += getRecent().hashCode();
        }
        _hashCode += getSeq();
        if (getReportedDate() != null) {
            _hashCode += getReportedDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EnquirySummaryType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "EnquirySummaryType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reportedDate");
        attrField.setXmlName(new javax.xml.namespace.QName("", "ReportedDate"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("purpose");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Purpose"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("total");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Total"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("past30Days");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Past30Days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("past12Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Past12Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("past24Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Past24Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Recent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
