/**
 * AdditionalNameValType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class AdditionalNameValType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected AdditionalNameValType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "";
    public static final java.lang.String _value2 = "F";
    public static final java.lang.String _value3 = "H";
    public static final java.lang.String _value4 = "M";
    public static final java.lang.String _value5 = "W";
    public static final java.lang.String _value6 = "S";
    public static final java.lang.String _value7 = "D";
    public static final java.lang.String _value8 = "B";
    public static final java.lang.String _value9 = "C";
    public static final java.lang.String _value10 = "O";
    public static final java.lang.String _value11 = "Z";
    public static final java.lang.String _value12 = "Y";
    public static final java.lang.String _value13 = "V";
    public static final java.lang.String _value14 = "X";
    public static final java.lang.String _value15 = "U";
    public static final java.lang.String _value16 = "T";
    public static final java.lang.String _value17 = "K01";
    public static final java.lang.String _value18 = "K02";
    public static final java.lang.String _value19 = "K03";
    public static final java.lang.String _value20 = "K06";
    public static final java.lang.String _value21 = "K07";
    public static final java.lang.String _value22 = "K14";
    public static final java.lang.String _value23 = "K04";
    public static final java.lang.String _value24 = "K05";
    public static final java.lang.String _value25 = "K12";
    public static final java.lang.String _value26 = "K10";
    public static final java.lang.String _value27 = "K09";
    public static final java.lang.String _value28 = "K08";
    public static final java.lang.String _value29 = "K13";
    public static final java.lang.String _value30 = "K11";
    public static final java.lang.String _value31 = "K15";
    public static final AdditionalNameValType value1 = new AdditionalNameValType(_value1);
    public static final AdditionalNameValType value2 = new AdditionalNameValType(_value2);
    public static final AdditionalNameValType value3 = new AdditionalNameValType(_value3);
    public static final AdditionalNameValType value4 = new AdditionalNameValType(_value4);
    public static final AdditionalNameValType value5 = new AdditionalNameValType(_value5);
    public static final AdditionalNameValType value6 = new AdditionalNameValType(_value6);
    public static final AdditionalNameValType value7 = new AdditionalNameValType(_value7);
    public static final AdditionalNameValType value8 = new AdditionalNameValType(_value8);
    public static final AdditionalNameValType value9 = new AdditionalNameValType(_value9);
    public static final AdditionalNameValType value10 = new AdditionalNameValType(_value10);
    public static final AdditionalNameValType value11 = new AdditionalNameValType(_value11);
    public static final AdditionalNameValType value12 = new AdditionalNameValType(_value12);
    public static final AdditionalNameValType value13 = new AdditionalNameValType(_value13);
    public static final AdditionalNameValType value14 = new AdditionalNameValType(_value14);
    public static final AdditionalNameValType value15 = new AdditionalNameValType(_value15);
    public static final AdditionalNameValType value16 = new AdditionalNameValType(_value16);
    public static final AdditionalNameValType value17 = new AdditionalNameValType(_value17);
    public static final AdditionalNameValType value18 = new AdditionalNameValType(_value18);
    public static final AdditionalNameValType value19 = new AdditionalNameValType(_value19);
    public static final AdditionalNameValType value20 = new AdditionalNameValType(_value20);
    public static final AdditionalNameValType value21 = new AdditionalNameValType(_value21);
    public static final AdditionalNameValType value22 = new AdditionalNameValType(_value22);
    public static final AdditionalNameValType value23 = new AdditionalNameValType(_value23);
    public static final AdditionalNameValType value24 = new AdditionalNameValType(_value24);
    public static final AdditionalNameValType value25 = new AdditionalNameValType(_value25);
    public static final AdditionalNameValType value26 = new AdditionalNameValType(_value26);
    public static final AdditionalNameValType value27 = new AdditionalNameValType(_value27);
    public static final AdditionalNameValType value28 = new AdditionalNameValType(_value28);
    public static final AdditionalNameValType value29 = new AdditionalNameValType(_value29);
    public static final AdditionalNameValType value30 = new AdditionalNameValType(_value30);
    public static final AdditionalNameValType value31 = new AdditionalNameValType(_value31);
    public java.lang.String getValue() { return _value_;}
    public static AdditionalNameValType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        AdditionalNameValType enumeration = (AdditionalNameValType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static AdditionalNameValType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AdditionalNameValType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalNameValType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
