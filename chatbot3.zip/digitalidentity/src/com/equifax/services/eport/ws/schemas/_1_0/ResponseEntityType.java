/**
 * ResponseEntityType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class ResponseEntityType  implements java.io.Serializable {
    private java.lang.String field1;

    private java.lang.String field2;

    private java.lang.String field3;

    private java.lang.String field4;

    private java.lang.String field5;

    private java.lang.String field6;

    private java.lang.String field7;

    private java.lang.String field8;

    private java.lang.String field9;

    private java.lang.String field10;

    public ResponseEntityType() {
    }

    public ResponseEntityType(
           java.lang.String field1,
           java.lang.String field2,
           java.lang.String field3,
           java.lang.String field4,
           java.lang.String field5,
           java.lang.String field6,
           java.lang.String field7,
           java.lang.String field8,
           java.lang.String field9,
           java.lang.String field10) {
           this.field1 = field1;
           this.field2 = field2;
           this.field3 = field3;
           this.field4 = field4;
           this.field5 = field5;
           this.field6 = field6;
           this.field7 = field7;
           this.field8 = field8;
           this.field9 = field9;
           this.field10 = field10;
    }


    /**
     * Gets the field1 value for this ResponseEntityType.
     * 
     * @return field1
     */
    public java.lang.String getField1() {
        return field1;
    }


    /**
     * Sets the field1 value for this ResponseEntityType.
     * 
     * @param field1
     */
    public void setField1(java.lang.String field1) {
        this.field1 = field1;
    }


    /**
     * Gets the field2 value for this ResponseEntityType.
     * 
     * @return field2
     */
    public java.lang.String getField2() {
        return field2;
    }


    /**
     * Sets the field2 value for this ResponseEntityType.
     * 
     * @param field2
     */
    public void setField2(java.lang.String field2) {
        this.field2 = field2;
    }


    /**
     * Gets the field3 value for this ResponseEntityType.
     * 
     * @return field3
     */
    public java.lang.String getField3() {
        return field3;
    }


    /**
     * Sets the field3 value for this ResponseEntityType.
     * 
     * @param field3
     */
    public void setField3(java.lang.String field3) {
        this.field3 = field3;
    }


    /**
     * Gets the field4 value for this ResponseEntityType.
     * 
     * @return field4
     */
    public java.lang.String getField4() {
        return field4;
    }


    /**
     * Sets the field4 value for this ResponseEntityType.
     * 
     * @param field4
     */
    public void setField4(java.lang.String field4) {
        this.field4 = field4;
    }


    /**
     * Gets the field5 value for this ResponseEntityType.
     * 
     * @return field5
     */
    public java.lang.String getField5() {
        return field5;
    }


    /**
     * Sets the field5 value for this ResponseEntityType.
     * 
     * @param field5
     */
    public void setField5(java.lang.String field5) {
        this.field5 = field5;
    }


    /**
     * Gets the field6 value for this ResponseEntityType.
     * 
     * @return field6
     */
    public java.lang.String getField6() {
        return field6;
    }


    /**
     * Sets the field6 value for this ResponseEntityType.
     * 
     * @param field6
     */
    public void setField6(java.lang.String field6) {
        this.field6 = field6;
    }


    /**
     * Gets the field7 value for this ResponseEntityType.
     * 
     * @return field7
     */
    public java.lang.String getField7() {
        return field7;
    }


    /**
     * Sets the field7 value for this ResponseEntityType.
     * 
     * @param field7
     */
    public void setField7(java.lang.String field7) {
        this.field7 = field7;
    }


    /**
     * Gets the field8 value for this ResponseEntityType.
     * 
     * @return field8
     */
    public java.lang.String getField8() {
        return field8;
    }


    /**
     * Sets the field8 value for this ResponseEntityType.
     * 
     * @param field8
     */
    public void setField8(java.lang.String field8) {
        this.field8 = field8;
    }


    /**
     * Gets the field9 value for this ResponseEntityType.
     * 
     * @return field9
     */
    public java.lang.String getField9() {
        return field9;
    }


    /**
     * Sets the field9 value for this ResponseEntityType.
     * 
     * @param field9
     */
    public void setField9(java.lang.String field9) {
        this.field9 = field9;
    }


    /**
     * Gets the field10 value for this ResponseEntityType.
     * 
     * @return field10
     */
    public java.lang.String getField10() {
        return field10;
    }


    /**
     * Sets the field10 value for this ResponseEntityType.
     * 
     * @param field10
     */
    public void setField10(java.lang.String field10) {
        this.field10 = field10;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResponseEntityType)) return false;
        ResponseEntityType other = (ResponseEntityType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.field1==null && other.getField1()==null) || 
             (this.field1!=null &&
              this.field1.equals(other.getField1()))) &&
            ((this.field2==null && other.getField2()==null) || 
             (this.field2!=null &&
              this.field2.equals(other.getField2()))) &&
            ((this.field3==null && other.getField3()==null) || 
             (this.field3!=null &&
              this.field3.equals(other.getField3()))) &&
            ((this.field4==null && other.getField4()==null) || 
             (this.field4!=null &&
              this.field4.equals(other.getField4()))) &&
            ((this.field5==null && other.getField5()==null) || 
             (this.field5!=null &&
              this.field5.equals(other.getField5()))) &&
            ((this.field6==null && other.getField6()==null) || 
             (this.field6!=null &&
              this.field6.equals(other.getField6()))) &&
            ((this.field7==null && other.getField7()==null) || 
             (this.field7!=null &&
              this.field7.equals(other.getField7()))) &&
            ((this.field8==null && other.getField8()==null) || 
             (this.field8!=null &&
              this.field8.equals(other.getField8()))) &&
            ((this.field9==null && other.getField9()==null) || 
             (this.field9!=null &&
              this.field9.equals(other.getField9()))) &&
            ((this.field10==null && other.getField10()==null) || 
             (this.field10!=null &&
              this.field10.equals(other.getField10())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getField1() != null) {
            _hashCode += getField1().hashCode();
        }
        if (getField2() != null) {
            _hashCode += getField2().hashCode();
        }
        if (getField3() != null) {
            _hashCode += getField3().hashCode();
        }
        if (getField4() != null) {
            _hashCode += getField4().hashCode();
        }
        if (getField5() != null) {
            _hashCode += getField5().hashCode();
        }
        if (getField6() != null) {
            _hashCode += getField6().hashCode();
        }
        if (getField7() != null) {
            _hashCode += getField7().hashCode();
        }
        if (getField8() != null) {
            _hashCode += getField8().hashCode();
        }
        if (getField9() != null) {
            _hashCode += getField9().hashCode();
        }
        if (getField10() != null) {
            _hashCode += getField10().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResponseEntityType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ResponseEntityType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field6");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field6"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field7");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field7"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field8");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field8"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field9");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field9"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("field10");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Field10"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
