/**
 * MaritalStatusOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class MaritalStatusOptions implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected MaritalStatusOptions(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "Cohabitating";
    public static final java.lang.String _value2 = "Divorced";
    public static final java.lang.String _value3 = "Married";
    public static final java.lang.String _value4 = "Not Asked";
    public static final java.lang.String _value5 = "Not Given";
    public static final java.lang.String _value6 = "Other";
    public static final java.lang.String _value7 = "Separated";
    public static final java.lang.String _value8 = "Single";
    public static final java.lang.String _value9 = "To Be Married";
    public static final java.lang.String _value10 = "Widowed";
    public static final MaritalStatusOptions value1 = new MaritalStatusOptions(_value1);
    public static final MaritalStatusOptions value2 = new MaritalStatusOptions(_value2);
    public static final MaritalStatusOptions value3 = new MaritalStatusOptions(_value3);
    public static final MaritalStatusOptions value4 = new MaritalStatusOptions(_value4);
    public static final MaritalStatusOptions value5 = new MaritalStatusOptions(_value5);
    public static final MaritalStatusOptions value6 = new MaritalStatusOptions(_value6);
    public static final MaritalStatusOptions value7 = new MaritalStatusOptions(_value7);
    public static final MaritalStatusOptions value8 = new MaritalStatusOptions(_value8);
    public static final MaritalStatusOptions value9 = new MaritalStatusOptions(_value9);
    public static final MaritalStatusOptions value10 = new MaritalStatusOptions(_value10);
    public java.lang.String getValue() { return _value_;}
    public static MaritalStatusOptions fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        MaritalStatusOptions enumeration = (MaritalStatusOptions)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static MaritalStatusOptions fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MaritalStatusOptions.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MaritalStatusOptions"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
