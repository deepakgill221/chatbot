/**
 * InquiryRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class InquiryRequestType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType requestHeader;

    private com.equifax.services.eport.ws.schemas._1_0.AccountInputType requestAccountDetails;

    private com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] inquiryCommonAccountDetails;

    private com.equifax.services.eport.ws.schemas._1_0.RequestBodyType requestBody;

    public InquiryRequestType() {
    }

    public InquiryRequestType(
           com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType requestHeader,
           com.equifax.services.eport.ws.schemas._1_0.AccountInputType requestAccountDetails,
           com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] inquiryCommonAccountDetails,
           com.equifax.services.eport.ws.schemas._1_0.RequestBodyType requestBody) {
           this.requestHeader = requestHeader;
           this.requestAccountDetails = requestAccountDetails;
           this.inquiryCommonAccountDetails = inquiryCommonAccountDetails;
           this.requestBody = requestBody;
    }


    /**
     * Gets the requestHeader value for this InquiryRequestType.
     * 
     * @return requestHeader
     */
    public com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType getRequestHeader() {
        return requestHeader;
    }


    /**
     * Sets the requestHeader value for this InquiryRequestType.
     * 
     * @param requestHeader
     */
    public void setRequestHeader(com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType requestHeader) {
        this.requestHeader = requestHeader;
    }


    /**
     * Gets the requestAccountDetails value for this InquiryRequestType.
     * 
     * @return requestAccountDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountInputType getRequestAccountDetails() {
        return requestAccountDetails;
    }


    /**
     * Sets the requestAccountDetails value for this InquiryRequestType.
     * 
     * @param requestAccountDetails
     */
    public void setRequestAccountDetails(com.equifax.services.eport.ws.schemas._1_0.AccountInputType requestAccountDetails) {
        this.requestAccountDetails = requestAccountDetails;
    }


    /**
     * Gets the inquiryCommonAccountDetails value for this InquiryRequestType.
     * 
     * @return inquiryCommonAccountDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] getInquiryCommonAccountDetails() {
        return inquiryCommonAccountDetails;
    }


    /**
     * Sets the inquiryCommonAccountDetails value for this InquiryRequestType.
     * 
     * @param inquiryCommonAccountDetails
     */
    public void setInquiryCommonAccountDetails(com.equifax.services.eport.ws.schemas._1_0.AccountInputType[] inquiryCommonAccountDetails) {
        this.inquiryCommonAccountDetails = inquiryCommonAccountDetails;
    }


    /**
     * Gets the requestBody value for this InquiryRequestType.
     * 
     * @return requestBody
     */
    public com.equifax.services.eport.ws.schemas._1_0.RequestBodyType getRequestBody() {
        return requestBody;
    }


    /**
     * Sets the requestBody value for this InquiryRequestType.
     * 
     * @param requestBody
     */
    public void setRequestBody(com.equifax.services.eport.ws.schemas._1_0.RequestBodyType requestBody) {
        this.requestBody = requestBody;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InquiryRequestType)) return false;
        InquiryRequestType other = (InquiryRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.requestHeader==null && other.getRequestHeader()==null) || 
             (this.requestHeader!=null &&
              this.requestHeader.equals(other.getRequestHeader()))) &&
            ((this.requestAccountDetails==null && other.getRequestAccountDetails()==null) || 
             (this.requestAccountDetails!=null &&
              this.requestAccountDetails.equals(other.getRequestAccountDetails()))) &&
            ((this.inquiryCommonAccountDetails==null && other.getInquiryCommonAccountDetails()==null) || 
             (this.inquiryCommonAccountDetails!=null &&
              java.util.Arrays.equals(this.inquiryCommonAccountDetails, other.getInquiryCommonAccountDetails()))) &&
            ((this.requestBody==null && other.getRequestBody()==null) || 
             (this.requestBody!=null &&
              this.requestBody.equals(other.getRequestBody())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRequestHeader() != null) {
            _hashCode += getRequestHeader().hashCode();
        }
        if (getRequestAccountDetails() != null) {
            _hashCode += getRequestAccountDetails().hashCode();
        }
        if (getInquiryCommonAccountDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInquiryCommonAccountDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInquiryCommonAccountDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRequestBody() != null) {
            _hashCode += getRequestBody().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InquiryRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestHeaderType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestAccountDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestAccountDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inquiryCommonAccountDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryCommonAccountDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountInputType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InquiryAccount"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestBody");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestBody"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RequestBodyType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
