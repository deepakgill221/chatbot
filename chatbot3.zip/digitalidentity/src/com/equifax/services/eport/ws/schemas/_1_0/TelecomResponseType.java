/**
 * TelecomResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class TelecomResponseType  implements java.io.Serializable {
    private java.lang.String TRField1;

    private java.lang.String TRField2;

    private java.lang.String TRField3;

    private java.lang.String TRField4;

    private java.lang.String TRField5;

    private java.lang.String TRField6;

    private java.lang.String TRField7;

    private java.lang.String TRField8;

    private java.lang.String TRField9;

    private java.lang.String TRField10;

    private java.lang.String TRField11;

    public TelecomResponseType() {
    }

    public TelecomResponseType(
           java.lang.String TRField1,
           java.lang.String TRField2,
           java.lang.String TRField3,
           java.lang.String TRField4,
           java.lang.String TRField5,
           java.lang.String TRField6,
           java.lang.String TRField7,
           java.lang.String TRField8,
           java.lang.String TRField9,
           java.lang.String TRField10,
           java.lang.String TRField11) {
           this.TRField1 = TRField1;
           this.TRField2 = TRField2;
           this.TRField3 = TRField3;
           this.TRField4 = TRField4;
           this.TRField5 = TRField5;
           this.TRField6 = TRField6;
           this.TRField7 = TRField7;
           this.TRField8 = TRField8;
           this.TRField9 = TRField9;
           this.TRField10 = TRField10;
           this.TRField11 = TRField11;
    }


    /**
     * Gets the TRField1 value for this TelecomResponseType.
     * 
     * @return TRField1
     */
    public java.lang.String getTRField1() {
        return TRField1;
    }


    /**
     * Sets the TRField1 value for this TelecomResponseType.
     * 
     * @param TRField1
     */
    public void setTRField1(java.lang.String TRField1) {
        this.TRField1 = TRField1;
    }


    /**
     * Gets the TRField2 value for this TelecomResponseType.
     * 
     * @return TRField2
     */
    public java.lang.String getTRField2() {
        return TRField2;
    }


    /**
     * Sets the TRField2 value for this TelecomResponseType.
     * 
     * @param TRField2
     */
    public void setTRField2(java.lang.String TRField2) {
        this.TRField2 = TRField2;
    }


    /**
     * Gets the TRField3 value for this TelecomResponseType.
     * 
     * @return TRField3
     */
    public java.lang.String getTRField3() {
        return TRField3;
    }


    /**
     * Sets the TRField3 value for this TelecomResponseType.
     * 
     * @param TRField3
     */
    public void setTRField3(java.lang.String TRField3) {
        this.TRField3 = TRField3;
    }


    /**
     * Gets the TRField4 value for this TelecomResponseType.
     * 
     * @return TRField4
     */
    public java.lang.String getTRField4() {
        return TRField4;
    }


    /**
     * Sets the TRField4 value for this TelecomResponseType.
     * 
     * @param TRField4
     */
    public void setTRField4(java.lang.String TRField4) {
        this.TRField4 = TRField4;
    }


    /**
     * Gets the TRField5 value for this TelecomResponseType.
     * 
     * @return TRField5
     */
    public java.lang.String getTRField5() {
        return TRField5;
    }


    /**
     * Sets the TRField5 value for this TelecomResponseType.
     * 
     * @param TRField5
     */
    public void setTRField5(java.lang.String TRField5) {
        this.TRField5 = TRField5;
    }


    /**
     * Gets the TRField6 value for this TelecomResponseType.
     * 
     * @return TRField6
     */
    public java.lang.String getTRField6() {
        return TRField6;
    }


    /**
     * Sets the TRField6 value for this TelecomResponseType.
     * 
     * @param TRField6
     */
    public void setTRField6(java.lang.String TRField6) {
        this.TRField6 = TRField6;
    }


    /**
     * Gets the TRField7 value for this TelecomResponseType.
     * 
     * @return TRField7
     */
    public java.lang.String getTRField7() {
        return TRField7;
    }


    /**
     * Sets the TRField7 value for this TelecomResponseType.
     * 
     * @param TRField7
     */
    public void setTRField7(java.lang.String TRField7) {
        this.TRField7 = TRField7;
    }


    /**
     * Gets the TRField8 value for this TelecomResponseType.
     * 
     * @return TRField8
     */
    public java.lang.String getTRField8() {
        return TRField8;
    }


    /**
     * Sets the TRField8 value for this TelecomResponseType.
     * 
     * @param TRField8
     */
    public void setTRField8(java.lang.String TRField8) {
        this.TRField8 = TRField8;
    }


    /**
     * Gets the TRField9 value for this TelecomResponseType.
     * 
     * @return TRField9
     */
    public java.lang.String getTRField9() {
        return TRField9;
    }


    /**
     * Sets the TRField9 value for this TelecomResponseType.
     * 
     * @param TRField9
     */
    public void setTRField9(java.lang.String TRField9) {
        this.TRField9 = TRField9;
    }


    /**
     * Gets the TRField10 value for this TelecomResponseType.
     * 
     * @return TRField10
     */
    public java.lang.String getTRField10() {
        return TRField10;
    }


    /**
     * Sets the TRField10 value for this TelecomResponseType.
     * 
     * @param TRField10
     */
    public void setTRField10(java.lang.String TRField10) {
        this.TRField10 = TRField10;
    }


    /**
     * Gets the TRField11 value for this TelecomResponseType.
     * 
     * @return TRField11
     */
    public java.lang.String getTRField11() {
        return TRField11;
    }


    /**
     * Sets the TRField11 value for this TelecomResponseType.
     * 
     * @param TRField11
     */
    public void setTRField11(java.lang.String TRField11) {
        this.TRField11 = TRField11;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TelecomResponseType)) return false;
        TelecomResponseType other = (TelecomResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.TRField1==null && other.getTRField1()==null) || 
             (this.TRField1!=null &&
              this.TRField1.equals(other.getTRField1()))) &&
            ((this.TRField2==null && other.getTRField2()==null) || 
             (this.TRField2!=null &&
              this.TRField2.equals(other.getTRField2()))) &&
            ((this.TRField3==null && other.getTRField3()==null) || 
             (this.TRField3!=null &&
              this.TRField3.equals(other.getTRField3()))) &&
            ((this.TRField4==null && other.getTRField4()==null) || 
             (this.TRField4!=null &&
              this.TRField4.equals(other.getTRField4()))) &&
            ((this.TRField5==null && other.getTRField5()==null) || 
             (this.TRField5!=null &&
              this.TRField5.equals(other.getTRField5()))) &&
            ((this.TRField6==null && other.getTRField6()==null) || 
             (this.TRField6!=null &&
              this.TRField6.equals(other.getTRField6()))) &&
            ((this.TRField7==null && other.getTRField7()==null) || 
             (this.TRField7!=null &&
              this.TRField7.equals(other.getTRField7()))) &&
            ((this.TRField8==null && other.getTRField8()==null) || 
             (this.TRField8!=null &&
              this.TRField8.equals(other.getTRField8()))) &&
            ((this.TRField9==null && other.getTRField9()==null) || 
             (this.TRField9!=null &&
              this.TRField9.equals(other.getTRField9()))) &&
            ((this.TRField10==null && other.getTRField10()==null) || 
             (this.TRField10!=null &&
              this.TRField10.equals(other.getTRField10()))) &&
            ((this.TRField11==null && other.getTRField11()==null) || 
             (this.TRField11!=null &&
              this.TRField11.equals(other.getTRField11())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTRField1() != null) {
            _hashCode += getTRField1().hashCode();
        }
        if (getTRField2() != null) {
            _hashCode += getTRField2().hashCode();
        }
        if (getTRField3() != null) {
            _hashCode += getTRField3().hashCode();
        }
        if (getTRField4() != null) {
            _hashCode += getTRField4().hashCode();
        }
        if (getTRField5() != null) {
            _hashCode += getTRField5().hashCode();
        }
        if (getTRField6() != null) {
            _hashCode += getTRField6().hashCode();
        }
        if (getTRField7() != null) {
            _hashCode += getTRField7().hashCode();
        }
        if (getTRField8() != null) {
            _hashCode += getTRField8().hashCode();
        }
        if (getTRField9() != null) {
            _hashCode += getTRField9().hashCode();
        }
        if (getTRField10() != null) {
            _hashCode += getTRField10().hashCode();
        }
        if (getTRField11() != null) {
            _hashCode += getTRField11().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TelecomResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TelecomResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField6");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField6"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField7");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField7"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField8");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField8"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField9");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField9"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField10");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField10"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRField11");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TRField11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
