/**
 * AdditionalMFIDetailsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class AdditionalMFIDetailsType  implements java.io.Serializable {
    private java.lang.String MFIClientFullname;

    private java.lang.String MFIDOB;

    private java.lang.String MFIGender;

    private com.equifax.services.eport.ws.schemas._1_0.MFIAdditionalIdentityInfoType MFIIdentification;

    private com.equifax.services.eport.ws.schemas._1_0.MFIAddlAdrsDetailsType[] MFIAddress;

    private com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phone;

    private java.lang.String memberId;

    private int id;  // attribute

    public AdditionalMFIDetailsType() {
    }

    public AdditionalMFIDetailsType(
           java.lang.String MFIClientFullname,
           java.lang.String MFIDOB,
           java.lang.String MFIGender,
           com.equifax.services.eport.ws.schemas._1_0.MFIAdditionalIdentityInfoType MFIIdentification,
           com.equifax.services.eport.ws.schemas._1_0.MFIAddlAdrsDetailsType[] MFIAddress,
           com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phone,
           java.lang.String memberId,
           int id) {
           this.MFIClientFullname = MFIClientFullname;
           this.MFIDOB = MFIDOB;
           this.MFIGender = MFIGender;
           this.MFIIdentification = MFIIdentification;
           this.MFIAddress = MFIAddress;
           this.phone = phone;
           this.memberId = memberId;
           this.id = id;
    }


    /**
     * Gets the MFIClientFullname value for this AdditionalMFIDetailsType.
     * 
     * @return MFIClientFullname
     */
    public java.lang.String getMFIClientFullname() {
        return MFIClientFullname;
    }


    /**
     * Sets the MFIClientFullname value for this AdditionalMFIDetailsType.
     * 
     * @param MFIClientFullname
     */
    public void setMFIClientFullname(java.lang.String MFIClientFullname) {
        this.MFIClientFullname = MFIClientFullname;
    }


    /**
     * Gets the MFIDOB value for this AdditionalMFIDetailsType.
     * 
     * @return MFIDOB
     */
    public java.lang.String getMFIDOB() {
        return MFIDOB;
    }


    /**
     * Sets the MFIDOB value for this AdditionalMFIDetailsType.
     * 
     * @param MFIDOB
     */
    public void setMFIDOB(java.lang.String MFIDOB) {
        this.MFIDOB = MFIDOB;
    }


    /**
     * Gets the MFIGender value for this AdditionalMFIDetailsType.
     * 
     * @return MFIGender
     */
    public java.lang.String getMFIGender() {
        return MFIGender;
    }


    /**
     * Sets the MFIGender value for this AdditionalMFIDetailsType.
     * 
     * @param MFIGender
     */
    public void setMFIGender(java.lang.String MFIGender) {
        this.MFIGender = MFIGender;
    }


    /**
     * Gets the MFIIdentification value for this AdditionalMFIDetailsType.
     * 
     * @return MFIIdentification
     */
    public com.equifax.services.eport.ws.schemas._1_0.MFIAdditionalIdentityInfoType getMFIIdentification() {
        return MFIIdentification;
    }


    /**
     * Sets the MFIIdentification value for this AdditionalMFIDetailsType.
     * 
     * @param MFIIdentification
     */
    public void setMFIIdentification(com.equifax.services.eport.ws.schemas._1_0.MFIAdditionalIdentityInfoType MFIIdentification) {
        this.MFIIdentification = MFIIdentification;
    }


    /**
     * Gets the MFIAddress value for this AdditionalMFIDetailsType.
     * 
     * @return MFIAddress
     */
    public com.equifax.services.eport.ws.schemas._1_0.MFIAddlAdrsDetailsType[] getMFIAddress() {
        return MFIAddress;
    }


    /**
     * Sets the MFIAddress value for this AdditionalMFIDetailsType.
     * 
     * @param MFIAddress
     */
    public void setMFIAddress(com.equifax.services.eport.ws.schemas._1_0.MFIAddlAdrsDetailsType[] MFIAddress) {
        this.MFIAddress = MFIAddress;
    }


    /**
     * Gets the phone value for this AdditionalMFIDetailsType.
     * 
     * @return phone
     */
    public com.equifax.services.eport.ws.schemas._1_0.PhoneType[] getPhone() {
        return phone;
    }


    /**
     * Sets the phone value for this AdditionalMFIDetailsType.
     * 
     * @param phone
     */
    public void setPhone(com.equifax.services.eport.ws.schemas._1_0.PhoneType[] phone) {
        this.phone = phone;
    }

    public com.equifax.services.eport.ws.schemas._1_0.PhoneType getPhone(int i) {
        return this.phone[i];
    }

    public void setPhone(int i, com.equifax.services.eport.ws.schemas._1_0.PhoneType _value) {
        this.phone[i] = _value;
    }


    /**
     * Gets the memberId value for this AdditionalMFIDetailsType.
     * 
     * @return memberId
     */
    public java.lang.String getMemberId() {
        return memberId;
    }


    /**
     * Sets the memberId value for this AdditionalMFIDetailsType.
     * 
     * @param memberId
     */
    public void setMemberId(java.lang.String memberId) {
        this.memberId = memberId;
    }


    /**
     * Gets the id value for this AdditionalMFIDetailsType.
     * 
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this AdditionalMFIDetailsType.
     * 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AdditionalMFIDetailsType)) return false;
        AdditionalMFIDetailsType other = (AdditionalMFIDetailsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MFIClientFullname==null && other.getMFIClientFullname()==null) || 
             (this.MFIClientFullname!=null &&
              this.MFIClientFullname.equals(other.getMFIClientFullname()))) &&
            ((this.MFIDOB==null && other.getMFIDOB()==null) || 
             (this.MFIDOB!=null &&
              this.MFIDOB.equals(other.getMFIDOB()))) &&
            ((this.MFIGender==null && other.getMFIGender()==null) || 
             (this.MFIGender!=null &&
              this.MFIGender.equals(other.getMFIGender()))) &&
            ((this.MFIIdentification==null && other.getMFIIdentification()==null) || 
             (this.MFIIdentification!=null &&
              this.MFIIdentification.equals(other.getMFIIdentification()))) &&
            ((this.MFIAddress==null && other.getMFIAddress()==null) || 
             (this.MFIAddress!=null &&
              java.util.Arrays.equals(this.MFIAddress, other.getMFIAddress()))) &&
            ((this.phone==null && other.getPhone()==null) || 
             (this.phone!=null &&
              java.util.Arrays.equals(this.phone, other.getPhone()))) &&
            ((this.memberId==null && other.getMemberId()==null) || 
             (this.memberId!=null &&
              this.memberId.equals(other.getMemberId()))) &&
            this.id == other.getId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMFIClientFullname() != null) {
            _hashCode += getMFIClientFullname().hashCode();
        }
        if (getMFIDOB() != null) {
            _hashCode += getMFIDOB().hashCode();
        }
        if (getMFIGender() != null) {
            _hashCode += getMFIGender().hashCode();
        }
        if (getMFIIdentification() != null) {
            _hashCode += getMFIIdentification().hashCode();
        }
        if (getMFIAddress() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMFIAddress());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMFIAddress(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPhone() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPhone());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPhone(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMemberId() != null) {
            _hashCode += getMemberId().hashCode();
        }
        _hashCode += getId();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AdditionalMFIDetailsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalMFIDetailsType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("id");
        attrField.setXmlName(new javax.xml.namespace.QName("", "id"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIClientFullname");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIClientFullname"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIDOB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIDOB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIGender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIGender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIIdentification");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIIdentification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAdditionalIdentityInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MFIAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MFIAddlAdrsDetailsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalAddressDetails"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("memberId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MemberId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
