/**
 * AccountType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class AccountType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.AdditionalMFIDetailsType additionalMFIDetails;

    private java.lang.String clientName;

    private java.lang.String accountNumber;

    private java.math.BigDecimal currentBalance;

    private java.lang.String institution;

    private java.lang.String accountType;

    private java.lang.String ownershipType;

    private java.math.BigDecimal balance;

    private java.math.BigDecimal pastDueAmount;

    private java.lang.String datePastDue;

    private java.math.BigDecimal disbursedAmount;

    private java.lang.String loanCategory;

    private java.lang.String loanPurpose;

    private java.math.BigDecimal lastPayment;

    private java.math.BigDecimal writeOffAmount;

    private java.lang.String open;

    private java.math.BigDecimal sanctionAmount;

    private java.math.BigDecimal highCredit;

    private java.util.Date lastPaymentDate;

    private java.util.Date dateReported;

    private java.util.Date dateOpened;

    private java.util.Date dateClosed;

    private java.lang.String reason;

    private java.util.Date dateWrittenOff;

    private java.lang.String loanCycleID;

    private java.util.Date dateSanctioned;

    private java.util.Date dateApplied;

    private java.lang.String interestRate;

    private java.math.BigDecimal appliedAmount;

    private java.lang.Integer noOfInstallments;

    private java.lang.String repaymentTenure;

    private java.lang.String disputeCode;

    private java.math.BigDecimal installmentAmount;

    private com.equifax.services.eport.ws.schemas._1_0.RelationInfoType keyPerson;

    private com.equifax.services.eport.ws.schemas._1_0.RelationInfoType nominee;

    private java.lang.String termFrequency;

    private java.math.BigDecimal creditLimit;

    private java.lang.String collateralValue;

    private java.lang.String collateralType;

    private java.lang.String accountStatus;

    private java.lang.String assetClassification;

    private java.lang.String suitFiledStatus;

    private com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] history48Months;

    private com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] history24Months;

    private java.lang.String branchIDMFI;

    private java.lang.String kendraIDMFI;

    private java.lang.Integer daysPastDue;

    private java.lang.String typeOfInsurance;

    private java.math.BigDecimal insurancePolicyAmount;

    private java.lang.Integer numberOfMeetingsHeld;

    private java.lang.Integer numberOfMeetingsMissed;

    private java.lang.String typeCode;  // attribute

    private int seq;  // attribute

    private int id;  // attribute

    private java.util.Date reportedDate;  // attribute

    public AccountType() {
    }

    public AccountType(
           com.equifax.services.eport.ws.schemas._1_0.AdditionalMFIDetailsType additionalMFIDetails,
           java.lang.String clientName,
           java.lang.String accountNumber,
           java.math.BigDecimal currentBalance,
           java.lang.String institution,
           java.lang.String accountType,
           java.lang.String ownershipType,
           java.math.BigDecimal balance,
           java.math.BigDecimal pastDueAmount,
           java.lang.String datePastDue,
           java.math.BigDecimal disbursedAmount,
           java.lang.String loanCategory,
           java.lang.String loanPurpose,
           java.math.BigDecimal lastPayment,
           java.math.BigDecimal writeOffAmount,
           java.lang.String open,
           java.math.BigDecimal sanctionAmount,
           java.math.BigDecimal highCredit,
           java.util.Date lastPaymentDate,
           java.util.Date dateReported,
           java.util.Date dateOpened,
           java.util.Date dateClosed,
           java.lang.String reason,
           java.util.Date dateWrittenOff,
           java.lang.String loanCycleID,
           java.util.Date dateSanctioned,
           java.util.Date dateApplied,
           java.lang.String interestRate,
           java.math.BigDecimal appliedAmount,
           java.lang.Integer noOfInstallments,
           java.lang.String repaymentTenure,
           java.lang.String disputeCode,
           java.math.BigDecimal installmentAmount,
           com.equifax.services.eport.ws.schemas._1_0.RelationInfoType keyPerson,
           com.equifax.services.eport.ws.schemas._1_0.RelationInfoType nominee,
           java.lang.String termFrequency,
           java.math.BigDecimal creditLimit,
           java.lang.String collateralValue,
           java.lang.String collateralType,
           java.lang.String accountStatus,
           java.lang.String assetClassification,
           java.lang.String suitFiledStatus,
           com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] history48Months,
           com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] history24Months,
           java.lang.String branchIDMFI,
           java.lang.String kendraIDMFI,
           java.lang.Integer daysPastDue,
           java.lang.String typeOfInsurance,
           java.math.BigDecimal insurancePolicyAmount,
           java.lang.Integer numberOfMeetingsHeld,
           java.lang.Integer numberOfMeetingsMissed,
           java.lang.String typeCode,
           int seq,
           int id,
           java.util.Date reportedDate) {
           this.additionalMFIDetails = additionalMFIDetails;
           this.clientName = clientName;
           this.accountNumber = accountNumber;
           this.currentBalance = currentBalance;
           this.institution = institution;
           this.accountType = accountType;
           this.ownershipType = ownershipType;
           this.balance = balance;
           this.pastDueAmount = pastDueAmount;
           this.datePastDue = datePastDue;
           this.disbursedAmount = disbursedAmount;
           this.loanCategory = loanCategory;
           this.loanPurpose = loanPurpose;
           this.lastPayment = lastPayment;
           this.writeOffAmount = writeOffAmount;
           this.open = open;
           this.sanctionAmount = sanctionAmount;
           this.highCredit = highCredit;
           this.lastPaymentDate = lastPaymentDate;
           this.dateReported = dateReported;
           this.dateOpened = dateOpened;
           this.dateClosed = dateClosed;
           this.reason = reason;
           this.dateWrittenOff = dateWrittenOff;
           this.loanCycleID = loanCycleID;
           this.dateSanctioned = dateSanctioned;
           this.dateApplied = dateApplied;
           this.interestRate = interestRate;
           this.appliedAmount = appliedAmount;
           this.noOfInstallments = noOfInstallments;
           this.repaymentTenure = repaymentTenure;
           this.disputeCode = disputeCode;
           this.installmentAmount = installmentAmount;
           this.keyPerson = keyPerson;
           this.nominee = nominee;
           this.termFrequency = termFrequency;
           this.creditLimit = creditLimit;
           this.collateralValue = collateralValue;
           this.collateralType = collateralType;
           this.accountStatus = accountStatus;
           this.assetClassification = assetClassification;
           this.suitFiledStatus = suitFiledStatus;
           this.history48Months = history48Months;
           this.history24Months = history24Months;
           this.branchIDMFI = branchIDMFI;
           this.kendraIDMFI = kendraIDMFI;
           this.daysPastDue = daysPastDue;
           this.typeOfInsurance = typeOfInsurance;
           this.insurancePolicyAmount = insurancePolicyAmount;
           this.numberOfMeetingsHeld = numberOfMeetingsHeld;
           this.numberOfMeetingsMissed = numberOfMeetingsMissed;
           this.typeCode = typeCode;
           this.seq = seq;
           this.id = id;
           this.reportedDate = reportedDate;
    }


    /**
     * Gets the additionalMFIDetails value for this AccountType.
     * 
     * @return additionalMFIDetails
     */
    public com.equifax.services.eport.ws.schemas._1_0.AdditionalMFIDetailsType getAdditionalMFIDetails() {
        return additionalMFIDetails;
    }


    /**
     * Sets the additionalMFIDetails value for this AccountType.
     * 
     * @param additionalMFIDetails
     */
    public void setAdditionalMFIDetails(com.equifax.services.eport.ws.schemas._1_0.AdditionalMFIDetailsType additionalMFIDetails) {
        this.additionalMFIDetails = additionalMFIDetails;
    }


    /**
     * Gets the clientName value for this AccountType.
     * 
     * @return clientName
     */
    public java.lang.String getClientName() {
        return clientName;
    }


    /**
     * Sets the clientName value for this AccountType.
     * 
     * @param clientName
     */
    public void setClientName(java.lang.String clientName) {
        this.clientName = clientName;
    }


    /**
     * Gets the accountNumber value for this AccountType.
     * 
     * @return accountNumber
     */
    public java.lang.String getAccountNumber() {
        return accountNumber;
    }


    /**
     * Sets the accountNumber value for this AccountType.
     * 
     * @param accountNumber
     */
    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }


    /**
     * Gets the currentBalance value for this AccountType.
     * 
     * @return currentBalance
     */
    public java.math.BigDecimal getCurrentBalance() {
        return currentBalance;
    }


    /**
     * Sets the currentBalance value for this AccountType.
     * 
     * @param currentBalance
     */
    public void setCurrentBalance(java.math.BigDecimal currentBalance) {
        this.currentBalance = currentBalance;
    }


    /**
     * Gets the institution value for this AccountType.
     * 
     * @return institution
     */
    public java.lang.String getInstitution() {
        return institution;
    }


    /**
     * Sets the institution value for this AccountType.
     * 
     * @param institution
     */
    public void setInstitution(java.lang.String institution) {
        this.institution = institution;
    }


    /**
     * Gets the accountType value for this AccountType.
     * 
     * @return accountType
     */
    public java.lang.String getAccountType() {
        return accountType;
    }


    /**
     * Sets the accountType value for this AccountType.
     * 
     * @param accountType
     */
    public void setAccountType(java.lang.String accountType) {
        this.accountType = accountType;
    }


    /**
     * Gets the ownershipType value for this AccountType.
     * 
     * @return ownershipType
     */
    public java.lang.String getOwnershipType() {
        return ownershipType;
    }


    /**
     * Sets the ownershipType value for this AccountType.
     * 
     * @param ownershipType
     */
    public void setOwnershipType(java.lang.String ownershipType) {
        this.ownershipType = ownershipType;
    }


    /**
     * Gets the balance value for this AccountType.
     * 
     * @return balance
     */
    public java.math.BigDecimal getBalance() {
        return balance;
    }


    /**
     * Sets the balance value for this AccountType.
     * 
     * @param balance
     */
    public void setBalance(java.math.BigDecimal balance) {
        this.balance = balance;
    }


    /**
     * Gets the pastDueAmount value for this AccountType.
     * 
     * @return pastDueAmount
     */
    public java.math.BigDecimal getPastDueAmount() {
        return pastDueAmount;
    }


    /**
     * Sets the pastDueAmount value for this AccountType.
     * 
     * @param pastDueAmount
     */
    public void setPastDueAmount(java.math.BigDecimal pastDueAmount) {
        this.pastDueAmount = pastDueAmount;
    }


    /**
     * Gets the datePastDue value for this AccountType.
     * 
     * @return datePastDue
     */
    public java.lang.String getDatePastDue() {
        return datePastDue;
    }


    /**
     * Sets the datePastDue value for this AccountType.
     * 
     * @param datePastDue
     */
    public void setDatePastDue(java.lang.String datePastDue) {
        this.datePastDue = datePastDue;
    }


    /**
     * Gets the disbursedAmount value for this AccountType.
     * 
     * @return disbursedAmount
     */
    public java.math.BigDecimal getDisbursedAmount() {
        return disbursedAmount;
    }


    /**
     * Sets the disbursedAmount value for this AccountType.
     * 
     * @param disbursedAmount
     */
    public void setDisbursedAmount(java.math.BigDecimal disbursedAmount) {
        this.disbursedAmount = disbursedAmount;
    }


    /**
     * Gets the loanCategory value for this AccountType.
     * 
     * @return loanCategory
     */
    public java.lang.String getLoanCategory() {
        return loanCategory;
    }


    /**
     * Sets the loanCategory value for this AccountType.
     * 
     * @param loanCategory
     */
    public void setLoanCategory(java.lang.String loanCategory) {
        this.loanCategory = loanCategory;
    }


    /**
     * Gets the loanPurpose value for this AccountType.
     * 
     * @return loanPurpose
     */
    public java.lang.String getLoanPurpose() {
        return loanPurpose;
    }


    /**
     * Sets the loanPurpose value for this AccountType.
     * 
     * @param loanPurpose
     */
    public void setLoanPurpose(java.lang.String loanPurpose) {
        this.loanPurpose = loanPurpose;
    }


    /**
     * Gets the lastPayment value for this AccountType.
     * 
     * @return lastPayment
     */
    public java.math.BigDecimal getLastPayment() {
        return lastPayment;
    }


    /**
     * Sets the lastPayment value for this AccountType.
     * 
     * @param lastPayment
     */
    public void setLastPayment(java.math.BigDecimal lastPayment) {
        this.lastPayment = lastPayment;
    }


    /**
     * Gets the writeOffAmount value for this AccountType.
     * 
     * @return writeOffAmount
     */
    public java.math.BigDecimal getWriteOffAmount() {
        return writeOffAmount;
    }


    /**
     * Sets the writeOffAmount value for this AccountType.
     * 
     * @param writeOffAmount
     */
    public void setWriteOffAmount(java.math.BigDecimal writeOffAmount) {
        this.writeOffAmount = writeOffAmount;
    }


    /**
     * Gets the open value for this AccountType.
     * 
     * @return open
     */
    public java.lang.String getOpen() {
        return open;
    }


    /**
     * Sets the open value for this AccountType.
     * 
     * @param open
     */
    public void setOpen(java.lang.String open) {
        this.open = open;
    }


    /**
     * Gets the sanctionAmount value for this AccountType.
     * 
     * @return sanctionAmount
     */
    public java.math.BigDecimal getSanctionAmount() {
        return sanctionAmount;
    }


    /**
     * Sets the sanctionAmount value for this AccountType.
     * 
     * @param sanctionAmount
     */
    public void setSanctionAmount(java.math.BigDecimal sanctionAmount) {
        this.sanctionAmount = sanctionAmount;
    }


    /**
     * Gets the highCredit value for this AccountType.
     * 
     * @return highCredit
     */
    public java.math.BigDecimal getHighCredit() {
        return highCredit;
    }


    /**
     * Sets the highCredit value for this AccountType.
     * 
     * @param highCredit
     */
    public void setHighCredit(java.math.BigDecimal highCredit) {
        this.highCredit = highCredit;
    }


    /**
     * Gets the lastPaymentDate value for this AccountType.
     * 
     * @return lastPaymentDate
     */
    public java.util.Date getLastPaymentDate() {
        return lastPaymentDate;
    }


    /**
     * Sets the lastPaymentDate value for this AccountType.
     * 
     * @param lastPaymentDate
     */
    public void setLastPaymentDate(java.util.Date lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }


    /**
     * Gets the dateReported value for this AccountType.
     * 
     * @return dateReported
     */
    public java.util.Date getDateReported() {
        return dateReported;
    }


    /**
     * Sets the dateReported value for this AccountType.
     * 
     * @param dateReported
     */
    public void setDateReported(java.util.Date dateReported) {
        this.dateReported = dateReported;
    }


    /**
     * Gets the dateOpened value for this AccountType.
     * 
     * @return dateOpened
     */
    public java.util.Date getDateOpened() {
        return dateOpened;
    }


    /**
     * Sets the dateOpened value for this AccountType.
     * 
     * @param dateOpened
     */
    public void setDateOpened(java.util.Date dateOpened) {
        this.dateOpened = dateOpened;
    }


    /**
     * Gets the dateClosed value for this AccountType.
     * 
     * @return dateClosed
     */
    public java.util.Date getDateClosed() {
        return dateClosed;
    }


    /**
     * Sets the dateClosed value for this AccountType.
     * 
     * @param dateClosed
     */
    public void setDateClosed(java.util.Date dateClosed) {
        this.dateClosed = dateClosed;
    }


    /**
     * Gets the reason value for this AccountType.
     * 
     * @return reason
     */
    public java.lang.String getReason() {
        return reason;
    }


    /**
     * Sets the reason value for this AccountType.
     * 
     * @param reason
     */
    public void setReason(java.lang.String reason) {
        this.reason = reason;
    }


    /**
     * Gets the dateWrittenOff value for this AccountType.
     * 
     * @return dateWrittenOff
     */
    public java.util.Date getDateWrittenOff() {
        return dateWrittenOff;
    }


    /**
     * Sets the dateWrittenOff value for this AccountType.
     * 
     * @param dateWrittenOff
     */
    public void setDateWrittenOff(java.util.Date dateWrittenOff) {
        this.dateWrittenOff = dateWrittenOff;
    }


    /**
     * Gets the loanCycleID value for this AccountType.
     * 
     * @return loanCycleID
     */
    public java.lang.String getLoanCycleID() {
        return loanCycleID;
    }


    /**
     * Sets the loanCycleID value for this AccountType.
     * 
     * @param loanCycleID
     */
    public void setLoanCycleID(java.lang.String loanCycleID) {
        this.loanCycleID = loanCycleID;
    }


    /**
     * Gets the dateSanctioned value for this AccountType.
     * 
     * @return dateSanctioned
     */
    public java.util.Date getDateSanctioned() {
        return dateSanctioned;
    }


    /**
     * Sets the dateSanctioned value for this AccountType.
     * 
     * @param dateSanctioned
     */
    public void setDateSanctioned(java.util.Date dateSanctioned) {
        this.dateSanctioned = dateSanctioned;
    }


    /**
     * Gets the dateApplied value for this AccountType.
     * 
     * @return dateApplied
     */
    public java.util.Date getDateApplied() {
        return dateApplied;
    }


    /**
     * Sets the dateApplied value for this AccountType.
     * 
     * @param dateApplied
     */
    public void setDateApplied(java.util.Date dateApplied) {
        this.dateApplied = dateApplied;
    }


    /**
     * Gets the interestRate value for this AccountType.
     * 
     * @return interestRate
     */
    public java.lang.String getInterestRate() {
        return interestRate;
    }


    /**
     * Sets the interestRate value for this AccountType.
     * 
     * @param interestRate
     */
    public void setInterestRate(java.lang.String interestRate) {
        this.interestRate = interestRate;
    }


    /**
     * Gets the appliedAmount value for this AccountType.
     * 
     * @return appliedAmount
     */
    public java.math.BigDecimal getAppliedAmount() {
        return appliedAmount;
    }


    /**
     * Sets the appliedAmount value for this AccountType.
     * 
     * @param appliedAmount
     */
    public void setAppliedAmount(java.math.BigDecimal appliedAmount) {
        this.appliedAmount = appliedAmount;
    }


    /**
     * Gets the noOfInstallments value for this AccountType.
     * 
     * @return noOfInstallments
     */
    public java.lang.Integer getNoOfInstallments() {
        return noOfInstallments;
    }


    /**
     * Sets the noOfInstallments value for this AccountType.
     * 
     * @param noOfInstallments
     */
    public void setNoOfInstallments(java.lang.Integer noOfInstallments) {
        this.noOfInstallments = noOfInstallments;
    }


    /**
     * Gets the repaymentTenure value for this AccountType.
     * 
     * @return repaymentTenure
     */
    public java.lang.String getRepaymentTenure() {
        return repaymentTenure;
    }


    /**
     * Sets the repaymentTenure value for this AccountType.
     * 
     * @param repaymentTenure
     */
    public void setRepaymentTenure(java.lang.String repaymentTenure) {
        this.repaymentTenure = repaymentTenure;
    }


    /**
     * Gets the disputeCode value for this AccountType.
     * 
     * @return disputeCode
     */
    public java.lang.String getDisputeCode() {
        return disputeCode;
    }


    /**
     * Sets the disputeCode value for this AccountType.
     * 
     * @param disputeCode
     */
    public void setDisputeCode(java.lang.String disputeCode) {
        this.disputeCode = disputeCode;
    }


    /**
     * Gets the installmentAmount value for this AccountType.
     * 
     * @return installmentAmount
     */
    public java.math.BigDecimal getInstallmentAmount() {
        return installmentAmount;
    }


    /**
     * Sets the installmentAmount value for this AccountType.
     * 
     * @param installmentAmount
     */
    public void setInstallmentAmount(java.math.BigDecimal installmentAmount) {
        this.installmentAmount = installmentAmount;
    }


    /**
     * Gets the keyPerson value for this AccountType.
     * 
     * @return keyPerson
     */
    public com.equifax.services.eport.ws.schemas._1_0.RelationInfoType getKeyPerson() {
        return keyPerson;
    }


    /**
     * Sets the keyPerson value for this AccountType.
     * 
     * @param keyPerson
     */
    public void setKeyPerson(com.equifax.services.eport.ws.schemas._1_0.RelationInfoType keyPerson) {
        this.keyPerson = keyPerson;
    }


    /**
     * Gets the nominee value for this AccountType.
     * 
     * @return nominee
     */
    public com.equifax.services.eport.ws.schemas._1_0.RelationInfoType getNominee() {
        return nominee;
    }


    /**
     * Sets the nominee value for this AccountType.
     * 
     * @param nominee
     */
    public void setNominee(com.equifax.services.eport.ws.schemas._1_0.RelationInfoType nominee) {
        this.nominee = nominee;
    }


    /**
     * Gets the termFrequency value for this AccountType.
     * 
     * @return termFrequency
     */
    public java.lang.String getTermFrequency() {
        return termFrequency;
    }


    /**
     * Sets the termFrequency value for this AccountType.
     * 
     * @param termFrequency
     */
    public void setTermFrequency(java.lang.String termFrequency) {
        this.termFrequency = termFrequency;
    }


    /**
     * Gets the creditLimit value for this AccountType.
     * 
     * @return creditLimit
     */
    public java.math.BigDecimal getCreditLimit() {
        return creditLimit;
    }


    /**
     * Sets the creditLimit value for this AccountType.
     * 
     * @param creditLimit
     */
    public void setCreditLimit(java.math.BigDecimal creditLimit) {
        this.creditLimit = creditLimit;
    }


    /**
     * Gets the collateralValue value for this AccountType.
     * 
     * @return collateralValue
     */
    public java.lang.String getCollateralValue() {
        return collateralValue;
    }


    /**
     * Sets the collateralValue value for this AccountType.
     * 
     * @param collateralValue
     */
    public void setCollateralValue(java.lang.String collateralValue) {
        this.collateralValue = collateralValue;
    }


    /**
     * Gets the collateralType value for this AccountType.
     * 
     * @return collateralType
     */
    public java.lang.String getCollateralType() {
        return collateralType;
    }


    /**
     * Sets the collateralType value for this AccountType.
     * 
     * @param collateralType
     */
    public void setCollateralType(java.lang.String collateralType) {
        this.collateralType = collateralType;
    }


    /**
     * Gets the accountStatus value for this AccountType.
     * 
     * @return accountStatus
     */
    public java.lang.String getAccountStatus() {
        return accountStatus;
    }


    /**
     * Sets the accountStatus value for this AccountType.
     * 
     * @param accountStatus
     */
    public void setAccountStatus(java.lang.String accountStatus) {
        this.accountStatus = accountStatus;
    }


    /**
     * Gets the assetClassification value for this AccountType.
     * 
     * @return assetClassification
     */
    public java.lang.String getAssetClassification() {
        return assetClassification;
    }


    /**
     * Sets the assetClassification value for this AccountType.
     * 
     * @param assetClassification
     */
    public void setAssetClassification(java.lang.String assetClassification) {
        this.assetClassification = assetClassification;
    }


    /**
     * Gets the suitFiledStatus value for this AccountType.
     * 
     * @return suitFiledStatus
     */
    public java.lang.String getSuitFiledStatus() {
        return suitFiledStatus;
    }


    /**
     * Sets the suitFiledStatus value for this AccountType.
     * 
     * @param suitFiledStatus
     */
    public void setSuitFiledStatus(java.lang.String suitFiledStatus) {
        this.suitFiledStatus = suitFiledStatus;
    }


    /**
     * Gets the history48Months value for this AccountType.
     * 
     * @return history48Months
     */
    public com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] getHistory48Months() {
        return history48Months;
    }


    /**
     * Sets the history48Months value for this AccountType.
     * 
     * @param history48Months
     */
    public void setHistory48Months(com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] history48Months) {
        this.history48Months = history48Months;
    }


    /**
     * Gets the history24Months value for this AccountType.
     * 
     * @return history24Months
     */
    public com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] getHistory24Months() {
        return history24Months;
    }


    /**
     * Sets the history24Months value for this AccountType.
     * 
     * @param history24Months
     */
    public void setHistory24Months(com.equifax.services.eport.ws.schemas._1_0.MonthlyDetailType[] history24Months) {
        this.history24Months = history24Months;
    }


    /**
     * Gets the branchIDMFI value for this AccountType.
     * 
     * @return branchIDMFI
     */
    public java.lang.String getBranchIDMFI() {
        return branchIDMFI;
    }


    /**
     * Sets the branchIDMFI value for this AccountType.
     * 
     * @param branchIDMFI
     */
    public void setBranchIDMFI(java.lang.String branchIDMFI) {
        this.branchIDMFI = branchIDMFI;
    }


    /**
     * Gets the kendraIDMFI value for this AccountType.
     * 
     * @return kendraIDMFI
     */
    public java.lang.String getKendraIDMFI() {
        return kendraIDMFI;
    }


    /**
     * Sets the kendraIDMFI value for this AccountType.
     * 
     * @param kendraIDMFI
     */
    public void setKendraIDMFI(java.lang.String kendraIDMFI) {
        this.kendraIDMFI = kendraIDMFI;
    }


    /**
     * Gets the daysPastDue value for this AccountType.
     * 
     * @return daysPastDue
     */
    public java.lang.Integer getDaysPastDue() {
        return daysPastDue;
    }


    /**
     * Sets the daysPastDue value for this AccountType.
     * 
     * @param daysPastDue
     */
    public void setDaysPastDue(java.lang.Integer daysPastDue) {
        this.daysPastDue = daysPastDue;
    }


    /**
     * Gets the typeOfInsurance value for this AccountType.
     * 
     * @return typeOfInsurance
     */
    public java.lang.String getTypeOfInsurance() {
        return typeOfInsurance;
    }


    /**
     * Sets the typeOfInsurance value for this AccountType.
     * 
     * @param typeOfInsurance
     */
    public void setTypeOfInsurance(java.lang.String typeOfInsurance) {
        this.typeOfInsurance = typeOfInsurance;
    }


    /**
     * Gets the insurancePolicyAmount value for this AccountType.
     * 
     * @return insurancePolicyAmount
     */
    public java.math.BigDecimal getInsurancePolicyAmount() {
        return insurancePolicyAmount;
    }


    /**
     * Sets the insurancePolicyAmount value for this AccountType.
     * 
     * @param insurancePolicyAmount
     */
    public void setInsurancePolicyAmount(java.math.BigDecimal insurancePolicyAmount) {
        this.insurancePolicyAmount = insurancePolicyAmount;
    }


    /**
     * Gets the numberOfMeetingsHeld value for this AccountType.
     * 
     * @return numberOfMeetingsHeld
     */
    public java.lang.Integer getNumberOfMeetingsHeld() {
        return numberOfMeetingsHeld;
    }


    /**
     * Sets the numberOfMeetingsHeld value for this AccountType.
     * 
     * @param numberOfMeetingsHeld
     */
    public void setNumberOfMeetingsHeld(java.lang.Integer numberOfMeetingsHeld) {
        this.numberOfMeetingsHeld = numberOfMeetingsHeld;
    }


    /**
     * Gets the numberOfMeetingsMissed value for this AccountType.
     * 
     * @return numberOfMeetingsMissed
     */
    public java.lang.Integer getNumberOfMeetingsMissed() {
        return numberOfMeetingsMissed;
    }


    /**
     * Sets the numberOfMeetingsMissed value for this AccountType.
     * 
     * @param numberOfMeetingsMissed
     */
    public void setNumberOfMeetingsMissed(java.lang.Integer numberOfMeetingsMissed) {
        this.numberOfMeetingsMissed = numberOfMeetingsMissed;
    }


    /**
     * Gets the typeCode value for this AccountType.
     * 
     * @return typeCode
     */
    public java.lang.String getTypeCode() {
        return typeCode;
    }


    /**
     * Sets the typeCode value for this AccountType.
     * 
     * @param typeCode
     */
    public void setTypeCode(java.lang.String typeCode) {
        this.typeCode = typeCode;
    }


    /**
     * Gets the seq value for this AccountType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this AccountType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }


    /**
     * Gets the id value for this AccountType.
     * 
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this AccountType.
     * 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * Gets the reportedDate value for this AccountType.
     * 
     * @return reportedDate
     */
    public java.util.Date getReportedDate() {
        return reportedDate;
    }


    /**
     * Sets the reportedDate value for this AccountType.
     * 
     * @param reportedDate
     */
    public void setReportedDate(java.util.Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountType)) return false;
        AccountType other = (AccountType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.additionalMFIDetails==null && other.getAdditionalMFIDetails()==null) || 
             (this.additionalMFIDetails!=null &&
              this.additionalMFIDetails.equals(other.getAdditionalMFIDetails()))) &&
            ((this.clientName==null && other.getClientName()==null) || 
             (this.clientName!=null &&
              this.clientName.equals(other.getClientName()))) &&
            ((this.accountNumber==null && other.getAccountNumber()==null) || 
             (this.accountNumber!=null &&
              this.accountNumber.equals(other.getAccountNumber()))) &&
            ((this.currentBalance==null && other.getCurrentBalance()==null) || 
             (this.currentBalance!=null &&
              this.currentBalance.equals(other.getCurrentBalance()))) &&
            ((this.institution==null && other.getInstitution()==null) || 
             (this.institution!=null &&
              this.institution.equals(other.getInstitution()))) &&
            ((this.accountType==null && other.getAccountType()==null) || 
             (this.accountType!=null &&
              this.accountType.equals(other.getAccountType()))) &&
            ((this.ownershipType==null && other.getOwnershipType()==null) || 
             (this.ownershipType!=null &&
              this.ownershipType.equals(other.getOwnershipType()))) &&
            ((this.balance==null && other.getBalance()==null) || 
             (this.balance!=null &&
              this.balance.equals(other.getBalance()))) &&
            ((this.pastDueAmount==null && other.getPastDueAmount()==null) || 
             (this.pastDueAmount!=null &&
              this.pastDueAmount.equals(other.getPastDueAmount()))) &&
            ((this.datePastDue==null && other.getDatePastDue()==null) || 
             (this.datePastDue!=null &&
              this.datePastDue.equals(other.getDatePastDue()))) &&
            ((this.disbursedAmount==null && other.getDisbursedAmount()==null) || 
             (this.disbursedAmount!=null &&
              this.disbursedAmount.equals(other.getDisbursedAmount()))) &&
            ((this.loanCategory==null && other.getLoanCategory()==null) || 
             (this.loanCategory!=null &&
              this.loanCategory.equals(other.getLoanCategory()))) &&
            ((this.loanPurpose==null && other.getLoanPurpose()==null) || 
             (this.loanPurpose!=null &&
              this.loanPurpose.equals(other.getLoanPurpose()))) &&
            ((this.lastPayment==null && other.getLastPayment()==null) || 
             (this.lastPayment!=null &&
              this.lastPayment.equals(other.getLastPayment()))) &&
            ((this.writeOffAmount==null && other.getWriteOffAmount()==null) || 
             (this.writeOffAmount!=null &&
              this.writeOffAmount.equals(other.getWriteOffAmount()))) &&
            ((this.open==null && other.getOpen()==null) || 
             (this.open!=null &&
              this.open.equals(other.getOpen()))) &&
            ((this.sanctionAmount==null && other.getSanctionAmount()==null) || 
             (this.sanctionAmount!=null &&
              this.sanctionAmount.equals(other.getSanctionAmount()))) &&
            ((this.highCredit==null && other.getHighCredit()==null) || 
             (this.highCredit!=null &&
              this.highCredit.equals(other.getHighCredit()))) &&
            ((this.lastPaymentDate==null && other.getLastPaymentDate()==null) || 
             (this.lastPaymentDate!=null &&
              this.lastPaymentDate.equals(other.getLastPaymentDate()))) &&
            ((this.dateReported==null && other.getDateReported()==null) || 
             (this.dateReported!=null &&
              this.dateReported.equals(other.getDateReported()))) &&
            ((this.dateOpened==null && other.getDateOpened()==null) || 
             (this.dateOpened!=null &&
              this.dateOpened.equals(other.getDateOpened()))) &&
            ((this.dateClosed==null && other.getDateClosed()==null) || 
             (this.dateClosed!=null &&
              this.dateClosed.equals(other.getDateClosed()))) &&
            ((this.reason==null && other.getReason()==null) || 
             (this.reason!=null &&
              this.reason.equals(other.getReason()))) &&
            ((this.dateWrittenOff==null && other.getDateWrittenOff()==null) || 
             (this.dateWrittenOff!=null &&
              this.dateWrittenOff.equals(other.getDateWrittenOff()))) &&
            ((this.loanCycleID==null && other.getLoanCycleID()==null) || 
             (this.loanCycleID!=null &&
              this.loanCycleID.equals(other.getLoanCycleID()))) &&
            ((this.dateSanctioned==null && other.getDateSanctioned()==null) || 
             (this.dateSanctioned!=null &&
              this.dateSanctioned.equals(other.getDateSanctioned()))) &&
            ((this.dateApplied==null && other.getDateApplied()==null) || 
             (this.dateApplied!=null &&
              this.dateApplied.equals(other.getDateApplied()))) &&
            ((this.interestRate==null && other.getInterestRate()==null) || 
             (this.interestRate!=null &&
              this.interestRate.equals(other.getInterestRate()))) &&
            ((this.appliedAmount==null && other.getAppliedAmount()==null) || 
             (this.appliedAmount!=null &&
              this.appliedAmount.equals(other.getAppliedAmount()))) &&
            ((this.noOfInstallments==null && other.getNoOfInstallments()==null) || 
             (this.noOfInstallments!=null &&
              this.noOfInstallments.equals(other.getNoOfInstallments()))) &&
            ((this.repaymentTenure==null && other.getRepaymentTenure()==null) || 
             (this.repaymentTenure!=null &&
              this.repaymentTenure.equals(other.getRepaymentTenure()))) &&
            ((this.disputeCode==null && other.getDisputeCode()==null) || 
             (this.disputeCode!=null &&
              this.disputeCode.equals(other.getDisputeCode()))) &&
            ((this.installmentAmount==null && other.getInstallmentAmount()==null) || 
             (this.installmentAmount!=null &&
              this.installmentAmount.equals(other.getInstallmentAmount()))) &&
            ((this.keyPerson==null && other.getKeyPerson()==null) || 
             (this.keyPerson!=null &&
              this.keyPerson.equals(other.getKeyPerson()))) &&
            ((this.nominee==null && other.getNominee()==null) || 
             (this.nominee!=null &&
              this.nominee.equals(other.getNominee()))) &&
            ((this.termFrequency==null && other.getTermFrequency()==null) || 
             (this.termFrequency!=null &&
              this.termFrequency.equals(other.getTermFrequency()))) &&
            ((this.creditLimit==null && other.getCreditLimit()==null) || 
             (this.creditLimit!=null &&
              this.creditLimit.equals(other.getCreditLimit()))) &&
            ((this.collateralValue==null && other.getCollateralValue()==null) || 
             (this.collateralValue!=null &&
              this.collateralValue.equals(other.getCollateralValue()))) &&
            ((this.collateralType==null && other.getCollateralType()==null) || 
             (this.collateralType!=null &&
              this.collateralType.equals(other.getCollateralType()))) &&
            ((this.accountStatus==null && other.getAccountStatus()==null) || 
             (this.accountStatus!=null &&
              this.accountStatus.equals(other.getAccountStatus()))) &&
            ((this.assetClassification==null && other.getAssetClassification()==null) || 
             (this.assetClassification!=null &&
              this.assetClassification.equals(other.getAssetClassification()))) &&
            ((this.suitFiledStatus==null && other.getSuitFiledStatus()==null) || 
             (this.suitFiledStatus!=null &&
              this.suitFiledStatus.equals(other.getSuitFiledStatus()))) &&
            ((this.history48Months==null && other.getHistory48Months()==null) || 
             (this.history48Months!=null &&
              java.util.Arrays.equals(this.history48Months, other.getHistory48Months()))) &&
            ((this.history24Months==null && other.getHistory24Months()==null) || 
             (this.history24Months!=null &&
              java.util.Arrays.equals(this.history24Months, other.getHistory24Months()))) &&
            ((this.branchIDMFI==null && other.getBranchIDMFI()==null) || 
             (this.branchIDMFI!=null &&
              this.branchIDMFI.equals(other.getBranchIDMFI()))) &&
            ((this.kendraIDMFI==null && other.getKendraIDMFI()==null) || 
             (this.kendraIDMFI!=null &&
              this.kendraIDMFI.equals(other.getKendraIDMFI()))) &&
            ((this.daysPastDue==null && other.getDaysPastDue()==null) || 
             (this.daysPastDue!=null &&
              this.daysPastDue.equals(other.getDaysPastDue()))) &&
            ((this.typeOfInsurance==null && other.getTypeOfInsurance()==null) || 
             (this.typeOfInsurance!=null &&
              this.typeOfInsurance.equals(other.getTypeOfInsurance()))) &&
            ((this.insurancePolicyAmount==null && other.getInsurancePolicyAmount()==null) || 
             (this.insurancePolicyAmount!=null &&
              this.insurancePolicyAmount.equals(other.getInsurancePolicyAmount()))) &&
            ((this.numberOfMeetingsHeld==null && other.getNumberOfMeetingsHeld()==null) || 
             (this.numberOfMeetingsHeld!=null &&
              this.numberOfMeetingsHeld.equals(other.getNumberOfMeetingsHeld()))) &&
            ((this.numberOfMeetingsMissed==null && other.getNumberOfMeetingsMissed()==null) || 
             (this.numberOfMeetingsMissed!=null &&
              this.numberOfMeetingsMissed.equals(other.getNumberOfMeetingsMissed()))) &&
            ((this.typeCode==null && other.getTypeCode()==null) || 
             (this.typeCode!=null &&
              this.typeCode.equals(other.getTypeCode()))) &&
            this.seq == other.getSeq() &&
            this.id == other.getId() &&
            ((this.reportedDate==null && other.getReportedDate()==null) || 
             (this.reportedDate!=null &&
              this.reportedDate.equals(other.getReportedDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAdditionalMFIDetails() != null) {
            _hashCode += getAdditionalMFIDetails().hashCode();
        }
        if (getClientName() != null) {
            _hashCode += getClientName().hashCode();
        }
        if (getAccountNumber() != null) {
            _hashCode += getAccountNumber().hashCode();
        }
        if (getCurrentBalance() != null) {
            _hashCode += getCurrentBalance().hashCode();
        }
        if (getInstitution() != null) {
            _hashCode += getInstitution().hashCode();
        }
        if (getAccountType() != null) {
            _hashCode += getAccountType().hashCode();
        }
        if (getOwnershipType() != null) {
            _hashCode += getOwnershipType().hashCode();
        }
        if (getBalance() != null) {
            _hashCode += getBalance().hashCode();
        }
        if (getPastDueAmount() != null) {
            _hashCode += getPastDueAmount().hashCode();
        }
        if (getDatePastDue() != null) {
            _hashCode += getDatePastDue().hashCode();
        }
        if (getDisbursedAmount() != null) {
            _hashCode += getDisbursedAmount().hashCode();
        }
        if (getLoanCategory() != null) {
            _hashCode += getLoanCategory().hashCode();
        }
        if (getLoanPurpose() != null) {
            _hashCode += getLoanPurpose().hashCode();
        }
        if (getLastPayment() != null) {
            _hashCode += getLastPayment().hashCode();
        }
        if (getWriteOffAmount() != null) {
            _hashCode += getWriteOffAmount().hashCode();
        }
        if (getOpen() != null) {
            _hashCode += getOpen().hashCode();
        }
        if (getSanctionAmount() != null) {
            _hashCode += getSanctionAmount().hashCode();
        }
        if (getHighCredit() != null) {
            _hashCode += getHighCredit().hashCode();
        }
        if (getLastPaymentDate() != null) {
            _hashCode += getLastPaymentDate().hashCode();
        }
        if (getDateReported() != null) {
            _hashCode += getDateReported().hashCode();
        }
        if (getDateOpened() != null) {
            _hashCode += getDateOpened().hashCode();
        }
        if (getDateClosed() != null) {
            _hashCode += getDateClosed().hashCode();
        }
        if (getReason() != null) {
            _hashCode += getReason().hashCode();
        }
        if (getDateWrittenOff() != null) {
            _hashCode += getDateWrittenOff().hashCode();
        }
        if (getLoanCycleID() != null) {
            _hashCode += getLoanCycleID().hashCode();
        }
        if (getDateSanctioned() != null) {
            _hashCode += getDateSanctioned().hashCode();
        }
        if (getDateApplied() != null) {
            _hashCode += getDateApplied().hashCode();
        }
        if (getInterestRate() != null) {
            _hashCode += getInterestRate().hashCode();
        }
        if (getAppliedAmount() != null) {
            _hashCode += getAppliedAmount().hashCode();
        }
        if (getNoOfInstallments() != null) {
            _hashCode += getNoOfInstallments().hashCode();
        }
        if (getRepaymentTenure() != null) {
            _hashCode += getRepaymentTenure().hashCode();
        }
        if (getDisputeCode() != null) {
            _hashCode += getDisputeCode().hashCode();
        }
        if (getInstallmentAmount() != null) {
            _hashCode += getInstallmentAmount().hashCode();
        }
        if (getKeyPerson() != null) {
            _hashCode += getKeyPerson().hashCode();
        }
        if (getNominee() != null) {
            _hashCode += getNominee().hashCode();
        }
        if (getTermFrequency() != null) {
            _hashCode += getTermFrequency().hashCode();
        }
        if (getCreditLimit() != null) {
            _hashCode += getCreditLimit().hashCode();
        }
        if (getCollateralValue() != null) {
            _hashCode += getCollateralValue().hashCode();
        }
        if (getCollateralType() != null) {
            _hashCode += getCollateralType().hashCode();
        }
        if (getAccountStatus() != null) {
            _hashCode += getAccountStatus().hashCode();
        }
        if (getAssetClassification() != null) {
            _hashCode += getAssetClassification().hashCode();
        }
        if (getSuitFiledStatus() != null) {
            _hashCode += getSuitFiledStatus().hashCode();
        }
        if (getHistory48Months() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHistory48Months());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHistory48Months(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHistory24Months() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHistory24Months());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHistory24Months(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBranchIDMFI() != null) {
            _hashCode += getBranchIDMFI().hashCode();
        }
        if (getKendraIDMFI() != null) {
            _hashCode += getKendraIDMFI().hashCode();
        }
        if (getDaysPastDue() != null) {
            _hashCode += getDaysPastDue().hashCode();
        }
        if (getTypeOfInsurance() != null) {
            _hashCode += getTypeOfInsurance().hashCode();
        }
        if (getInsurancePolicyAmount() != null) {
            _hashCode += getInsurancePolicyAmount().hashCode();
        }
        if (getNumberOfMeetingsHeld() != null) {
            _hashCode += getNumberOfMeetingsHeld().hashCode();
        }
        if (getNumberOfMeetingsMissed() != null) {
            _hashCode += getNumberOfMeetingsMissed().hashCode();
        }
        if (getTypeCode() != null) {
            _hashCode += getTypeCode().hashCode();
        }
        _hashCode += getSeq();
        _hashCode += getId();
        if (getReportedDate() != null) {
            _hashCode += getReportedDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("typeCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "typeCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("id");
        attrField.setXmlName(new javax.xml.namespace.QName("", "id"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reportedDate");
        attrField.setXmlName(new javax.xml.namespace.QName("", "ReportedDate"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalMFIDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalMFIDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AdditionalMFIDetailsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "ClientName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentBalance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CurrentBalance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("institution");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Institution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownershipType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OwnershipType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("balance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Balance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pastDueAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PastDueAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("datePastDue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DatePastDue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disbursedAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisbursedAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loanCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LoanCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loanPurpose");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LoanPurpose"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastPayment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LastPayment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("writeOffAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "WriteOffAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("open");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Open"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sanctionAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SanctionAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("highCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "HighCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastPaymentDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LastPaymentDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateReported");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateReported"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateOpened");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateOpened"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateClosed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateClosed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reason");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Reason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateWrittenOff");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateWrittenOff"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loanCycleID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "LoanCycleID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateSanctioned");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateSanctioned"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateApplied");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateApplied"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interestRate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InterestRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appliedAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AppliedAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfInstallments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfInstallments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("repaymentTenure");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RepaymentTenure"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disputeCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DisputeCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installmentAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InstallmentAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keyPerson");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "KeyPerson"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RelationInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nominee");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Nominee"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RelationInfoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("termFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TermFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CreditLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("collateralValue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CollateralValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("collateralType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CollateralType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("assetClassification");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AssetClassification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suitFiledStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SuitFiledStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("history48Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "History48Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MonthlyDetailType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Month"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("history24Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "History24Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MonthlyDetailType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Month"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchIDMFI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "BranchIDMFI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kendraIDMFI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "KendraIDMFI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("daysPastDue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DaysPastDue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("typeOfInsurance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TypeOfInsurance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insurancePolicyAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "InsurancePolicyAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfMeetingsHeld");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NumberOfMeetingsHeld"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfMeetingsMissed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NumberOfMeetingsMissed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
