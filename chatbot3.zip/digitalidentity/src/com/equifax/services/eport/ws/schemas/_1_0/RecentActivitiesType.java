/**
 * RecentActivitiesType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class RecentActivitiesType  implements java.io.Serializable {
    private java.lang.Integer accountsDeliquent;

    private java.lang.Integer accountsOpened;

    private java.lang.Integer totalInquiries;

    private java.lang.Integer accountsUpdated;

    public RecentActivitiesType() {
    }

    public RecentActivitiesType(
           java.lang.Integer accountsDeliquent,
           java.lang.Integer accountsOpened,
           java.lang.Integer totalInquiries,
           java.lang.Integer accountsUpdated) {
           this.accountsDeliquent = accountsDeliquent;
           this.accountsOpened = accountsOpened;
           this.totalInquiries = totalInquiries;
           this.accountsUpdated = accountsUpdated;
    }


    /**
     * Gets the accountsDeliquent value for this RecentActivitiesType.
     * 
     * @return accountsDeliquent
     */
    public java.lang.Integer getAccountsDeliquent() {
        return accountsDeliquent;
    }


    /**
     * Sets the accountsDeliquent value for this RecentActivitiesType.
     * 
     * @param accountsDeliquent
     */
    public void setAccountsDeliquent(java.lang.Integer accountsDeliquent) {
        this.accountsDeliquent = accountsDeliquent;
    }


    /**
     * Gets the accountsOpened value for this RecentActivitiesType.
     * 
     * @return accountsOpened
     */
    public java.lang.Integer getAccountsOpened() {
        return accountsOpened;
    }


    /**
     * Sets the accountsOpened value for this RecentActivitiesType.
     * 
     * @param accountsOpened
     */
    public void setAccountsOpened(java.lang.Integer accountsOpened) {
        this.accountsOpened = accountsOpened;
    }


    /**
     * Gets the totalInquiries value for this RecentActivitiesType.
     * 
     * @return totalInquiries
     */
    public java.lang.Integer getTotalInquiries() {
        return totalInquiries;
    }


    /**
     * Sets the totalInquiries value for this RecentActivitiesType.
     * 
     * @param totalInquiries
     */
    public void setTotalInquiries(java.lang.Integer totalInquiries) {
        this.totalInquiries = totalInquiries;
    }


    /**
     * Gets the accountsUpdated value for this RecentActivitiesType.
     * 
     * @return accountsUpdated
     */
    public java.lang.Integer getAccountsUpdated() {
        return accountsUpdated;
    }


    /**
     * Sets the accountsUpdated value for this RecentActivitiesType.
     * 
     * @param accountsUpdated
     */
    public void setAccountsUpdated(java.lang.Integer accountsUpdated) {
        this.accountsUpdated = accountsUpdated;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RecentActivitiesType)) return false;
        RecentActivitiesType other = (RecentActivitiesType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accountsDeliquent==null && other.getAccountsDeliquent()==null) || 
             (this.accountsDeliquent!=null &&
              this.accountsDeliquent.equals(other.getAccountsDeliquent()))) &&
            ((this.accountsOpened==null && other.getAccountsOpened()==null) || 
             (this.accountsOpened!=null &&
              this.accountsOpened.equals(other.getAccountsOpened()))) &&
            ((this.totalInquiries==null && other.getTotalInquiries()==null) || 
             (this.totalInquiries!=null &&
              this.totalInquiries.equals(other.getTotalInquiries()))) &&
            ((this.accountsUpdated==null && other.getAccountsUpdated()==null) || 
             (this.accountsUpdated!=null &&
              this.accountsUpdated.equals(other.getAccountsUpdated())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccountsDeliquent() != null) {
            _hashCode += getAccountsDeliquent().hashCode();
        }
        if (getAccountsOpened() != null) {
            _hashCode += getAccountsOpened().hashCode();
        }
        if (getTotalInquiries() != null) {
            _hashCode += getTotalInquiries().hashCode();
        }
        if (getAccountsUpdated() != null) {
            _hashCode += getAccountsUpdated().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RecentActivitiesType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RecentActivitiesType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountsDeliquent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountsDeliquent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountsOpened");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountsOpened"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalInquiries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalInquiries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountsUpdated");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountsUpdated"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
