/**
 * CreditReportSummaryType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class CreditReportSummaryType  implements java.io.Serializable {
    private java.lang.Integer noOfAccounts;

    private java.lang.Integer noOfActiveAccounts;

    private java.lang.Integer noOfWriteOffs;

    private java.math.BigDecimal totalPastDue;

    private java.lang.String mostSevereStatusWithIn24Months;

    private java.math.BigDecimal singleHighestCredit;

    private java.math.BigDecimal singleHighestSanctionAmount;

    private java.math.BigDecimal totalHighCredit;

    private java.math.BigDecimal averageOpenBalance;

    private java.math.BigDecimal singleHighestBalance;

    private java.lang.Integer noOfPastDueAccounts;

    private java.lang.Integer noOfZeroBalanceAccounts;

    private java.lang.String recentAccount;

    private java.lang.String oldestAccount;

    private java.math.BigDecimal totalBalanceAmount;

    private java.math.BigDecimal totalSanctionAmount;

    private java.math.BigDecimal totalCreditLimit;

    private java.math.BigDecimal totalMonthlyPaymentAmount;

    private java.math.BigDecimal totalWrittenOffAmount;

    public CreditReportSummaryType() {
    }

    public CreditReportSummaryType(
           java.lang.Integer noOfAccounts,
           java.lang.Integer noOfActiveAccounts,
           java.lang.Integer noOfWriteOffs,
           java.math.BigDecimal totalPastDue,
           java.lang.String mostSevereStatusWithIn24Months,
           java.math.BigDecimal singleHighestCredit,
           java.math.BigDecimal singleHighestSanctionAmount,
           java.math.BigDecimal totalHighCredit,
           java.math.BigDecimal averageOpenBalance,
           java.math.BigDecimal singleHighestBalance,
           java.lang.Integer noOfPastDueAccounts,
           java.lang.Integer noOfZeroBalanceAccounts,
           java.lang.String recentAccount,
           java.lang.String oldestAccount,
           java.math.BigDecimal totalBalanceAmount,
           java.math.BigDecimal totalSanctionAmount,
           java.math.BigDecimal totalCreditLimit,
           java.math.BigDecimal totalMonthlyPaymentAmount,
           java.math.BigDecimal totalWrittenOffAmount) {
           this.noOfAccounts = noOfAccounts;
           this.noOfActiveAccounts = noOfActiveAccounts;
           this.noOfWriteOffs = noOfWriteOffs;
           this.totalPastDue = totalPastDue;
           this.mostSevereStatusWithIn24Months = mostSevereStatusWithIn24Months;
           this.singleHighestCredit = singleHighestCredit;
           this.singleHighestSanctionAmount = singleHighestSanctionAmount;
           this.totalHighCredit = totalHighCredit;
           this.averageOpenBalance = averageOpenBalance;
           this.singleHighestBalance = singleHighestBalance;
           this.noOfPastDueAccounts = noOfPastDueAccounts;
           this.noOfZeroBalanceAccounts = noOfZeroBalanceAccounts;
           this.recentAccount = recentAccount;
           this.oldestAccount = oldestAccount;
           this.totalBalanceAmount = totalBalanceAmount;
           this.totalSanctionAmount = totalSanctionAmount;
           this.totalCreditLimit = totalCreditLimit;
           this.totalMonthlyPaymentAmount = totalMonthlyPaymentAmount;
           this.totalWrittenOffAmount = totalWrittenOffAmount;
    }


    /**
     * Gets the noOfAccounts value for this CreditReportSummaryType.
     * 
     * @return noOfAccounts
     */
    public java.lang.Integer getNoOfAccounts() {
        return noOfAccounts;
    }


    /**
     * Sets the noOfAccounts value for this CreditReportSummaryType.
     * 
     * @param noOfAccounts
     */
    public void setNoOfAccounts(java.lang.Integer noOfAccounts) {
        this.noOfAccounts = noOfAccounts;
    }


    /**
     * Gets the noOfActiveAccounts value for this CreditReportSummaryType.
     * 
     * @return noOfActiveAccounts
     */
    public java.lang.Integer getNoOfActiveAccounts() {
        return noOfActiveAccounts;
    }


    /**
     * Sets the noOfActiveAccounts value for this CreditReportSummaryType.
     * 
     * @param noOfActiveAccounts
     */
    public void setNoOfActiveAccounts(java.lang.Integer noOfActiveAccounts) {
        this.noOfActiveAccounts = noOfActiveAccounts;
    }


    /**
     * Gets the noOfWriteOffs value for this CreditReportSummaryType.
     * 
     * @return noOfWriteOffs
     */
    public java.lang.Integer getNoOfWriteOffs() {
        return noOfWriteOffs;
    }


    /**
     * Sets the noOfWriteOffs value for this CreditReportSummaryType.
     * 
     * @param noOfWriteOffs
     */
    public void setNoOfWriteOffs(java.lang.Integer noOfWriteOffs) {
        this.noOfWriteOffs = noOfWriteOffs;
    }


    /**
     * Gets the totalPastDue value for this CreditReportSummaryType.
     * 
     * @return totalPastDue
     */
    public java.math.BigDecimal getTotalPastDue() {
        return totalPastDue;
    }


    /**
     * Sets the totalPastDue value for this CreditReportSummaryType.
     * 
     * @param totalPastDue
     */
    public void setTotalPastDue(java.math.BigDecimal totalPastDue) {
        this.totalPastDue = totalPastDue;
    }


    /**
     * Gets the mostSevereStatusWithIn24Months value for this CreditReportSummaryType.
     * 
     * @return mostSevereStatusWithIn24Months
     */
    public java.lang.String getMostSevereStatusWithIn24Months() {
        return mostSevereStatusWithIn24Months;
    }


    /**
     * Sets the mostSevereStatusWithIn24Months value for this CreditReportSummaryType.
     * 
     * @param mostSevereStatusWithIn24Months
     */
    public void setMostSevereStatusWithIn24Months(java.lang.String mostSevereStatusWithIn24Months) {
        this.mostSevereStatusWithIn24Months = mostSevereStatusWithIn24Months;
    }


    /**
     * Gets the singleHighestCredit value for this CreditReportSummaryType.
     * 
     * @return singleHighestCredit
     */
    public java.math.BigDecimal getSingleHighestCredit() {
        return singleHighestCredit;
    }


    /**
     * Sets the singleHighestCredit value for this CreditReportSummaryType.
     * 
     * @param singleHighestCredit
     */
    public void setSingleHighestCredit(java.math.BigDecimal singleHighestCredit) {
        this.singleHighestCredit = singleHighestCredit;
    }


    /**
     * Gets the singleHighestSanctionAmount value for this CreditReportSummaryType.
     * 
     * @return singleHighestSanctionAmount
     */
    public java.math.BigDecimal getSingleHighestSanctionAmount() {
        return singleHighestSanctionAmount;
    }


    /**
     * Sets the singleHighestSanctionAmount value for this CreditReportSummaryType.
     * 
     * @param singleHighestSanctionAmount
     */
    public void setSingleHighestSanctionAmount(java.math.BigDecimal singleHighestSanctionAmount) {
        this.singleHighestSanctionAmount = singleHighestSanctionAmount;
    }


    /**
     * Gets the totalHighCredit value for this CreditReportSummaryType.
     * 
     * @return totalHighCredit
     */
    public java.math.BigDecimal getTotalHighCredit() {
        return totalHighCredit;
    }


    /**
     * Sets the totalHighCredit value for this CreditReportSummaryType.
     * 
     * @param totalHighCredit
     */
    public void setTotalHighCredit(java.math.BigDecimal totalHighCredit) {
        this.totalHighCredit = totalHighCredit;
    }


    /**
     * Gets the averageOpenBalance value for this CreditReportSummaryType.
     * 
     * @return averageOpenBalance
     */
    public java.math.BigDecimal getAverageOpenBalance() {
        return averageOpenBalance;
    }


    /**
     * Sets the averageOpenBalance value for this CreditReportSummaryType.
     * 
     * @param averageOpenBalance
     */
    public void setAverageOpenBalance(java.math.BigDecimal averageOpenBalance) {
        this.averageOpenBalance = averageOpenBalance;
    }


    /**
     * Gets the singleHighestBalance value for this CreditReportSummaryType.
     * 
     * @return singleHighestBalance
     */
    public java.math.BigDecimal getSingleHighestBalance() {
        return singleHighestBalance;
    }


    /**
     * Sets the singleHighestBalance value for this CreditReportSummaryType.
     * 
     * @param singleHighestBalance
     */
    public void setSingleHighestBalance(java.math.BigDecimal singleHighestBalance) {
        this.singleHighestBalance = singleHighestBalance;
    }


    /**
     * Gets the noOfPastDueAccounts value for this CreditReportSummaryType.
     * 
     * @return noOfPastDueAccounts
     */
    public java.lang.Integer getNoOfPastDueAccounts() {
        return noOfPastDueAccounts;
    }


    /**
     * Sets the noOfPastDueAccounts value for this CreditReportSummaryType.
     * 
     * @param noOfPastDueAccounts
     */
    public void setNoOfPastDueAccounts(java.lang.Integer noOfPastDueAccounts) {
        this.noOfPastDueAccounts = noOfPastDueAccounts;
    }


    /**
     * Gets the noOfZeroBalanceAccounts value for this CreditReportSummaryType.
     * 
     * @return noOfZeroBalanceAccounts
     */
    public java.lang.Integer getNoOfZeroBalanceAccounts() {
        return noOfZeroBalanceAccounts;
    }


    /**
     * Sets the noOfZeroBalanceAccounts value for this CreditReportSummaryType.
     * 
     * @param noOfZeroBalanceAccounts
     */
    public void setNoOfZeroBalanceAccounts(java.lang.Integer noOfZeroBalanceAccounts) {
        this.noOfZeroBalanceAccounts = noOfZeroBalanceAccounts;
    }


    /**
     * Gets the recentAccount value for this CreditReportSummaryType.
     * 
     * @return recentAccount
     */
    public java.lang.String getRecentAccount() {
        return recentAccount;
    }


    /**
     * Sets the recentAccount value for this CreditReportSummaryType.
     * 
     * @param recentAccount
     */
    public void setRecentAccount(java.lang.String recentAccount) {
        this.recentAccount = recentAccount;
    }


    /**
     * Gets the oldestAccount value for this CreditReportSummaryType.
     * 
     * @return oldestAccount
     */
    public java.lang.String getOldestAccount() {
        return oldestAccount;
    }


    /**
     * Sets the oldestAccount value for this CreditReportSummaryType.
     * 
     * @param oldestAccount
     */
    public void setOldestAccount(java.lang.String oldestAccount) {
        this.oldestAccount = oldestAccount;
    }


    /**
     * Gets the totalBalanceAmount value for this CreditReportSummaryType.
     * 
     * @return totalBalanceAmount
     */
    public java.math.BigDecimal getTotalBalanceAmount() {
        return totalBalanceAmount;
    }


    /**
     * Sets the totalBalanceAmount value for this CreditReportSummaryType.
     * 
     * @param totalBalanceAmount
     */
    public void setTotalBalanceAmount(java.math.BigDecimal totalBalanceAmount) {
        this.totalBalanceAmount = totalBalanceAmount;
    }


    /**
     * Gets the totalSanctionAmount value for this CreditReportSummaryType.
     * 
     * @return totalSanctionAmount
     */
    public java.math.BigDecimal getTotalSanctionAmount() {
        return totalSanctionAmount;
    }


    /**
     * Sets the totalSanctionAmount value for this CreditReportSummaryType.
     * 
     * @param totalSanctionAmount
     */
    public void setTotalSanctionAmount(java.math.BigDecimal totalSanctionAmount) {
        this.totalSanctionAmount = totalSanctionAmount;
    }


    /**
     * Gets the totalCreditLimit value for this CreditReportSummaryType.
     * 
     * @return totalCreditLimit
     */
    public java.math.BigDecimal getTotalCreditLimit() {
        return totalCreditLimit;
    }


    /**
     * Sets the totalCreditLimit value for this CreditReportSummaryType.
     * 
     * @param totalCreditLimit
     */
    public void setTotalCreditLimit(java.math.BigDecimal totalCreditLimit) {
        this.totalCreditLimit = totalCreditLimit;
    }


    /**
     * Gets the totalMonthlyPaymentAmount value for this CreditReportSummaryType.
     * 
     * @return totalMonthlyPaymentAmount
     */
    public java.math.BigDecimal getTotalMonthlyPaymentAmount() {
        return totalMonthlyPaymentAmount;
    }


    /**
     * Sets the totalMonthlyPaymentAmount value for this CreditReportSummaryType.
     * 
     * @param totalMonthlyPaymentAmount
     */
    public void setTotalMonthlyPaymentAmount(java.math.BigDecimal totalMonthlyPaymentAmount) {
        this.totalMonthlyPaymentAmount = totalMonthlyPaymentAmount;
    }


    /**
     * Gets the totalWrittenOffAmount value for this CreditReportSummaryType.
     * 
     * @return totalWrittenOffAmount
     */
    public java.math.BigDecimal getTotalWrittenOffAmount() {
        return totalWrittenOffAmount;
    }


    /**
     * Sets the totalWrittenOffAmount value for this CreditReportSummaryType.
     * 
     * @param totalWrittenOffAmount
     */
    public void setTotalWrittenOffAmount(java.math.BigDecimal totalWrittenOffAmount) {
        this.totalWrittenOffAmount = totalWrittenOffAmount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CreditReportSummaryType)) return false;
        CreditReportSummaryType other = (CreditReportSummaryType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.noOfAccounts==null && other.getNoOfAccounts()==null) || 
             (this.noOfAccounts!=null &&
              this.noOfAccounts.equals(other.getNoOfAccounts()))) &&
            ((this.noOfActiveAccounts==null && other.getNoOfActiveAccounts()==null) || 
             (this.noOfActiveAccounts!=null &&
              this.noOfActiveAccounts.equals(other.getNoOfActiveAccounts()))) &&
            ((this.noOfWriteOffs==null && other.getNoOfWriteOffs()==null) || 
             (this.noOfWriteOffs!=null &&
              this.noOfWriteOffs.equals(other.getNoOfWriteOffs()))) &&
            ((this.totalPastDue==null && other.getTotalPastDue()==null) || 
             (this.totalPastDue!=null &&
              this.totalPastDue.equals(other.getTotalPastDue()))) &&
            ((this.mostSevereStatusWithIn24Months==null && other.getMostSevereStatusWithIn24Months()==null) || 
             (this.mostSevereStatusWithIn24Months!=null &&
              this.mostSevereStatusWithIn24Months.equals(other.getMostSevereStatusWithIn24Months()))) &&
            ((this.singleHighestCredit==null && other.getSingleHighestCredit()==null) || 
             (this.singleHighestCredit!=null &&
              this.singleHighestCredit.equals(other.getSingleHighestCredit()))) &&
            ((this.singleHighestSanctionAmount==null && other.getSingleHighestSanctionAmount()==null) || 
             (this.singleHighestSanctionAmount!=null &&
              this.singleHighestSanctionAmount.equals(other.getSingleHighestSanctionAmount()))) &&
            ((this.totalHighCredit==null && other.getTotalHighCredit()==null) || 
             (this.totalHighCredit!=null &&
              this.totalHighCredit.equals(other.getTotalHighCredit()))) &&
            ((this.averageOpenBalance==null && other.getAverageOpenBalance()==null) || 
             (this.averageOpenBalance!=null &&
              this.averageOpenBalance.equals(other.getAverageOpenBalance()))) &&
            ((this.singleHighestBalance==null && other.getSingleHighestBalance()==null) || 
             (this.singleHighestBalance!=null &&
              this.singleHighestBalance.equals(other.getSingleHighestBalance()))) &&
            ((this.noOfPastDueAccounts==null && other.getNoOfPastDueAccounts()==null) || 
             (this.noOfPastDueAccounts!=null &&
              this.noOfPastDueAccounts.equals(other.getNoOfPastDueAccounts()))) &&
            ((this.noOfZeroBalanceAccounts==null && other.getNoOfZeroBalanceAccounts()==null) || 
             (this.noOfZeroBalanceAccounts!=null &&
              this.noOfZeroBalanceAccounts.equals(other.getNoOfZeroBalanceAccounts()))) &&
            ((this.recentAccount==null && other.getRecentAccount()==null) || 
             (this.recentAccount!=null &&
              this.recentAccount.equals(other.getRecentAccount()))) &&
            ((this.oldestAccount==null && other.getOldestAccount()==null) || 
             (this.oldestAccount!=null &&
              this.oldestAccount.equals(other.getOldestAccount()))) &&
            ((this.totalBalanceAmount==null && other.getTotalBalanceAmount()==null) || 
             (this.totalBalanceAmount!=null &&
              this.totalBalanceAmount.equals(other.getTotalBalanceAmount()))) &&
            ((this.totalSanctionAmount==null && other.getTotalSanctionAmount()==null) || 
             (this.totalSanctionAmount!=null &&
              this.totalSanctionAmount.equals(other.getTotalSanctionAmount()))) &&
            ((this.totalCreditLimit==null && other.getTotalCreditLimit()==null) || 
             (this.totalCreditLimit!=null &&
              this.totalCreditLimit.equals(other.getTotalCreditLimit()))) &&
            ((this.totalMonthlyPaymentAmount==null && other.getTotalMonthlyPaymentAmount()==null) || 
             (this.totalMonthlyPaymentAmount!=null &&
              this.totalMonthlyPaymentAmount.equals(other.getTotalMonthlyPaymentAmount()))) &&
            ((this.totalWrittenOffAmount==null && other.getTotalWrittenOffAmount()==null) || 
             (this.totalWrittenOffAmount!=null &&
              this.totalWrittenOffAmount.equals(other.getTotalWrittenOffAmount())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNoOfAccounts() != null) {
            _hashCode += getNoOfAccounts().hashCode();
        }
        if (getNoOfActiveAccounts() != null) {
            _hashCode += getNoOfActiveAccounts().hashCode();
        }
        if (getNoOfWriteOffs() != null) {
            _hashCode += getNoOfWriteOffs().hashCode();
        }
        if (getTotalPastDue() != null) {
            _hashCode += getTotalPastDue().hashCode();
        }
        if (getMostSevereStatusWithIn24Months() != null) {
            _hashCode += getMostSevereStatusWithIn24Months().hashCode();
        }
        if (getSingleHighestCredit() != null) {
            _hashCode += getSingleHighestCredit().hashCode();
        }
        if (getSingleHighestSanctionAmount() != null) {
            _hashCode += getSingleHighestSanctionAmount().hashCode();
        }
        if (getTotalHighCredit() != null) {
            _hashCode += getTotalHighCredit().hashCode();
        }
        if (getAverageOpenBalance() != null) {
            _hashCode += getAverageOpenBalance().hashCode();
        }
        if (getSingleHighestBalance() != null) {
            _hashCode += getSingleHighestBalance().hashCode();
        }
        if (getNoOfPastDueAccounts() != null) {
            _hashCode += getNoOfPastDueAccounts().hashCode();
        }
        if (getNoOfZeroBalanceAccounts() != null) {
            _hashCode += getNoOfZeroBalanceAccounts().hashCode();
        }
        if (getRecentAccount() != null) {
            _hashCode += getRecentAccount().hashCode();
        }
        if (getOldestAccount() != null) {
            _hashCode += getOldestAccount().hashCode();
        }
        if (getTotalBalanceAmount() != null) {
            _hashCode += getTotalBalanceAmount().hashCode();
        }
        if (getTotalSanctionAmount() != null) {
            _hashCode += getTotalSanctionAmount().hashCode();
        }
        if (getTotalCreditLimit() != null) {
            _hashCode += getTotalCreditLimit().hashCode();
        }
        if (getTotalMonthlyPaymentAmount() != null) {
            _hashCode += getTotalMonthlyPaymentAmount().hashCode();
        }
        if (getTotalWrittenOffAmount() != null) {
            _hashCode += getTotalWrittenOffAmount().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CreditReportSummaryType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CreditReportSummaryType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfActiveAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfActiveAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfWriteOffs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfWriteOffs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalPastDue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalPastDue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mostSevereStatusWithIn24Months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MostSevereStatusWithIn24Months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleHighestCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SingleHighestCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleHighestSanctionAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SingleHighestSanctionAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalHighCredit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalHighCredit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("averageOpenBalance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AverageOpenBalance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleHighestBalance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SingleHighestBalance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfPastDueAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfPastDueAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfZeroBalanceAccounts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfZeroBalanceAccounts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recentAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RecentAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oldestAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "OldestAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalBalanceAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalBalanceAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSanctionAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalSanctionAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalCreditLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalCreditLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalMonthlyPaymentAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalMonthlyPaymentAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalWrittenOffAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "TotalWrittenOffAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
