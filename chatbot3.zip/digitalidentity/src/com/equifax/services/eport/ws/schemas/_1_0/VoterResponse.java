/**
 * VoterResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class VoterResponse  extends com.equifax.services.eport.ws.schemas._1_0.Response  implements java.io.Serializable {
    private java.lang.String voterRespId;

    private java.lang.String voter;

    private java.lang.String percentMatch;

    private java.lang.String title;

    private java.lang.String firstName;

    private java.lang.String middleName;

    private java.lang.String lastName;

    private java.lang.String lastUpdatedDate;

    private java.lang.String guardianName;

    private java.lang.String guardianType;

    private java.lang.String gender;

    private java.lang.String age;

    private java.lang.String address;

    private java.lang.String voterResponse;

    public VoterResponse() {
    }

    public VoterResponse(
           java.lang.String returnCode,
           java.lang.String returnCodeDesc,
           java.util.Calendar runDateTime,
           java.lang.String errorRespMessage,
           java.lang.String voterRespId,
           java.lang.String voter,
           java.lang.String percentMatch,
           java.lang.String title,
           java.lang.String firstName,
           java.lang.String middleName,
           java.lang.String lastName,
           java.lang.String lastUpdatedDate,
           java.lang.String guardianName,
           java.lang.String guardianType,
           java.lang.String gender,
           java.lang.String age,
           java.lang.String address,
           java.lang.String voterResponse) {
        super(
            returnCode,
            returnCodeDesc,
            runDateTime,
            errorRespMessage);
        this.voterRespId = voterRespId;
        this.voter = voter;
        this.percentMatch = percentMatch;
        this.title = title;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.lastUpdatedDate = lastUpdatedDate;
        this.guardianName = guardianName;
        this.guardianType = guardianType;
        this.gender = gender;
        this.age = age;
        this.address = address;
        this.voterResponse = voterResponse;
    }


    /**
     * Gets the voterRespId value for this VoterResponse.
     * 
     * @return voterRespId
     */
    public java.lang.String getVoterRespId() {
        return voterRespId;
    }


    /**
     * Sets the voterRespId value for this VoterResponse.
     * 
     * @param voterRespId
     */
    public void setVoterRespId(java.lang.String voterRespId) {
        this.voterRespId = voterRespId;
    }


    /**
     * Gets the voter value for this VoterResponse.
     * 
     * @return voter
     */
    public java.lang.String getVoter() {
        return voter;
    }


    /**
     * Sets the voter value for this VoterResponse.
     * 
     * @param voter
     */
    public void setVoter(java.lang.String voter) {
        this.voter = voter;
    }


    /**
     * Gets the percentMatch value for this VoterResponse.
     * 
     * @return percentMatch
     */
    public java.lang.String getPercentMatch() {
        return percentMatch;
    }


    /**
     * Sets the percentMatch value for this VoterResponse.
     * 
     * @param percentMatch
     */
    public void setPercentMatch(java.lang.String percentMatch) {
        this.percentMatch = percentMatch;
    }


    /**
     * Gets the title value for this VoterResponse.
     * 
     * @return title
     */
    public java.lang.String getTitle() {
        return title;
    }


    /**
     * Sets the title value for this VoterResponse.
     * 
     * @param title
     */
    public void setTitle(java.lang.String title) {
        this.title = title;
    }


    /**
     * Gets the firstName value for this VoterResponse.
     * 
     * @return firstName
     */
    public java.lang.String getFirstName() {
        return firstName;
    }


    /**
     * Sets the firstName value for this VoterResponse.
     * 
     * @param firstName
     */
    public void setFirstName(java.lang.String firstName) {
        this.firstName = firstName;
    }


    /**
     * Gets the middleName value for this VoterResponse.
     * 
     * @return middleName
     */
    public java.lang.String getMiddleName() {
        return middleName;
    }


    /**
     * Sets the middleName value for this VoterResponse.
     * 
     * @param middleName
     */
    public void setMiddleName(java.lang.String middleName) {
        this.middleName = middleName;
    }


    /**
     * Gets the lastName value for this VoterResponse.
     * 
     * @return lastName
     */
    public java.lang.String getLastName() {
        return lastName;
    }


    /**
     * Sets the lastName value for this VoterResponse.
     * 
     * @param lastName
     */
    public void setLastName(java.lang.String lastName) {
        this.lastName = lastName;
    }


    /**
     * Gets the lastUpdatedDate value for this VoterResponse.
     * 
     * @return lastUpdatedDate
     */
    public java.lang.String getLastUpdatedDate() {
        return lastUpdatedDate;
    }


    /**
     * Sets the lastUpdatedDate value for this VoterResponse.
     * 
     * @param lastUpdatedDate
     */
    public void setLastUpdatedDate(java.lang.String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }


    /**
     * Gets the guardianName value for this VoterResponse.
     * 
     * @return guardianName
     */
    public java.lang.String getGuardianName() {
        return guardianName;
    }


    /**
     * Sets the guardianName value for this VoterResponse.
     * 
     * @param guardianName
     */
    public void setGuardianName(java.lang.String guardianName) {
        this.guardianName = guardianName;
    }


    /**
     * Gets the guardianType value for this VoterResponse.
     * 
     * @return guardianType
     */
    public java.lang.String getGuardianType() {
        return guardianType;
    }


    /**
     * Sets the guardianType value for this VoterResponse.
     * 
     * @param guardianType
     */
    public void setGuardianType(java.lang.String guardianType) {
        this.guardianType = guardianType;
    }


    /**
     * Gets the gender value for this VoterResponse.
     * 
     * @return gender
     */
    public java.lang.String getGender() {
        return gender;
    }


    /**
     * Sets the gender value for this VoterResponse.
     * 
     * @param gender
     */
    public void setGender(java.lang.String gender) {
        this.gender = gender;
    }


    /**
     * Gets the age value for this VoterResponse.
     * 
     * @return age
     */
    public java.lang.String getAge() {
        return age;
    }


    /**
     * Sets the age value for this VoterResponse.
     * 
     * @param age
     */
    public void setAge(java.lang.String age) {
        this.age = age;
    }


    /**
     * Gets the address value for this VoterResponse.
     * 
     * @return address
     */
    public java.lang.String getAddress() {
        return address;
    }


    /**
     * Sets the address value for this VoterResponse.
     * 
     * @param address
     */
    public void setAddress(java.lang.String address) {
        this.address = address;
    }


    /**
     * Gets the voterResponse value for this VoterResponse.
     * 
     * @return voterResponse
     */
    public java.lang.String getVoterResponse() {
        return voterResponse;
    }


    /**
     * Sets the voterResponse value for this VoterResponse.
     * 
     * @param voterResponse
     */
    public void setVoterResponse(java.lang.String voterResponse) {
        this.voterResponse = voterResponse;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VoterResponse)) return false;
        VoterResponse other = (VoterResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.voterRespId==null && other.getVoterRespId()==null) || 
             (this.voterRespId!=null &&
              this.voterRespId.equals(other.getVoterRespId()))) &&
            ((this.voter==null && other.getVoter()==null) || 
             (this.voter!=null &&
              this.voter.equals(other.getVoter()))) &&
            ((this.percentMatch==null && other.getPercentMatch()==null) || 
             (this.percentMatch!=null &&
              this.percentMatch.equals(other.getPercentMatch()))) &&
            ((this.title==null && other.getTitle()==null) || 
             (this.title!=null &&
              this.title.equals(other.getTitle()))) &&
            ((this.firstName==null && other.getFirstName()==null) || 
             (this.firstName!=null &&
              this.firstName.equals(other.getFirstName()))) &&
            ((this.middleName==null && other.getMiddleName()==null) || 
             (this.middleName!=null &&
              this.middleName.equals(other.getMiddleName()))) &&
            ((this.lastName==null && other.getLastName()==null) || 
             (this.lastName!=null &&
              this.lastName.equals(other.getLastName()))) &&
            ((this.lastUpdatedDate==null && other.getLastUpdatedDate()==null) || 
             (this.lastUpdatedDate!=null &&
              this.lastUpdatedDate.equals(other.getLastUpdatedDate()))) &&
            ((this.guardianName==null && other.getGuardianName()==null) || 
             (this.guardianName!=null &&
              this.guardianName.equals(other.getGuardianName()))) &&
            ((this.guardianType==null && other.getGuardianType()==null) || 
             (this.guardianType!=null &&
              this.guardianType.equals(other.getGuardianType()))) &&
            ((this.gender==null && other.getGender()==null) || 
             (this.gender!=null &&
              this.gender.equals(other.getGender()))) &&
            ((this.age==null && other.getAge()==null) || 
             (this.age!=null &&
              this.age.equals(other.getAge()))) &&
            ((this.address==null && other.getAddress()==null) || 
             (this.address!=null &&
              this.address.equals(other.getAddress()))) &&
            ((this.voterResponse==null && other.getVoterResponse()==null) || 
             (this.voterResponse!=null &&
              this.voterResponse.equals(other.getVoterResponse())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getVoterRespId() != null) {
            _hashCode += getVoterRespId().hashCode();
        }
        if (getVoter() != null) {
            _hashCode += getVoter().hashCode();
        }
        if (getPercentMatch() != null) {
            _hashCode += getPercentMatch().hashCode();
        }
        if (getTitle() != null) {
            _hashCode += getTitle().hashCode();
        }
        if (getFirstName() != null) {
            _hashCode += getFirstName().hashCode();
        }
        if (getMiddleName() != null) {
            _hashCode += getMiddleName().hashCode();
        }
        if (getLastName() != null) {
            _hashCode += getLastName().hashCode();
        }
        if (getLastUpdatedDate() != null) {
            _hashCode += getLastUpdatedDate().hashCode();
        }
        if (getGuardianName() != null) {
            _hashCode += getGuardianName().hashCode();
        }
        if (getGuardianType() != null) {
            _hashCode += getGuardianType().hashCode();
        }
        if (getGender() != null) {
            _hashCode += getGender().hashCode();
        }
        if (getAge() != null) {
            _hashCode += getAge().hashCode();
        }
        if (getAddress() != null) {
            _hashCode += getAddress().hashCode();
        }
        if (getVoterResponse() != null) {
            _hashCode += getVoterResponse().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VoterResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "voterResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voterRespId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "voterRespId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Voter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentMatch");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "percentMatch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("title");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "firstName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("middleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "middleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "lastName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastUpdatedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "lastUpdatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guardianName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "guardianName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guardianType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "guardianType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "gender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("age");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "age"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("address");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voterResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "voterResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
