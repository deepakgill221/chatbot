/**
 * IdentificationType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class IdentificationType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.IDType[] PANId;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] passportID;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] driverLicence;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] voterID;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] nationalIDCard;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] rationCard;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] IDCard;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] photoCreditCard;

    private com.equifax.services.eport.ws.schemas._1_0.IDType[] IDOther;

    public IdentificationType() {
    }

    public IdentificationType(
           com.equifax.services.eport.ws.schemas._1_0.IDType[] PANId,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] passportID,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] driverLicence,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] voterID,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] nationalIDCard,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] rationCard,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] IDCard,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] photoCreditCard,
           com.equifax.services.eport.ws.schemas._1_0.IDType[] IDOther) {
           this.PANId = PANId;
           this.passportID = passportID;
           this.driverLicence = driverLicence;
           this.voterID = voterID;
           this.nationalIDCard = nationalIDCard;
           this.rationCard = rationCard;
           this.IDCard = IDCard;
           this.photoCreditCard = photoCreditCard;
           this.IDOther = IDOther;
    }


    /**
     * Gets the PANId value for this IdentificationType.
     * 
     * @return PANId
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getPANId() {
        return PANId;
    }


    /**
     * Sets the PANId value for this IdentificationType.
     * 
     * @param PANId
     */
    public void setPANId(com.equifax.services.eport.ws.schemas._1_0.IDType[] PANId) {
        this.PANId = PANId;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getPANId(int i) {
        return this.PANId[i];
    }

    public void setPANId(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.PANId[i] = _value;
    }


    /**
     * Gets the passportID value for this IdentificationType.
     * 
     * @return passportID
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getPassportID() {
        return passportID;
    }


    /**
     * Sets the passportID value for this IdentificationType.
     * 
     * @param passportID
     */
    public void setPassportID(com.equifax.services.eport.ws.schemas._1_0.IDType[] passportID) {
        this.passportID = passportID;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getPassportID(int i) {
        return this.passportID[i];
    }

    public void setPassportID(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.passportID[i] = _value;
    }


    /**
     * Gets the driverLicence value for this IdentificationType.
     * 
     * @return driverLicence
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getDriverLicence() {
        return driverLicence;
    }


    /**
     * Sets the driverLicence value for this IdentificationType.
     * 
     * @param driverLicence
     */
    public void setDriverLicence(com.equifax.services.eport.ws.schemas._1_0.IDType[] driverLicence) {
        this.driverLicence = driverLicence;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getDriverLicence(int i) {
        return this.driverLicence[i];
    }

    public void setDriverLicence(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.driverLicence[i] = _value;
    }


    /**
     * Gets the voterID value for this IdentificationType.
     * 
     * @return voterID
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getVoterID() {
        return voterID;
    }


    /**
     * Sets the voterID value for this IdentificationType.
     * 
     * @param voterID
     */
    public void setVoterID(com.equifax.services.eport.ws.schemas._1_0.IDType[] voterID) {
        this.voterID = voterID;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getVoterID(int i) {
        return this.voterID[i];
    }

    public void setVoterID(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.voterID[i] = _value;
    }


    /**
     * Gets the nationalIDCard value for this IdentificationType.
     * 
     * @return nationalIDCard
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getNationalIDCard() {
        return nationalIDCard;
    }


    /**
     * Sets the nationalIDCard value for this IdentificationType.
     * 
     * @param nationalIDCard
     */
    public void setNationalIDCard(com.equifax.services.eport.ws.schemas._1_0.IDType[] nationalIDCard) {
        this.nationalIDCard = nationalIDCard;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getNationalIDCard(int i) {
        return this.nationalIDCard[i];
    }

    public void setNationalIDCard(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.nationalIDCard[i] = _value;
    }


    /**
     * Gets the rationCard value for this IdentificationType.
     * 
     * @return rationCard
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getRationCard() {
        return rationCard;
    }


    /**
     * Sets the rationCard value for this IdentificationType.
     * 
     * @param rationCard
     */
    public void setRationCard(com.equifax.services.eport.ws.schemas._1_0.IDType[] rationCard) {
        this.rationCard = rationCard;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getRationCard(int i) {
        return this.rationCard[i];
    }

    public void setRationCard(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.rationCard[i] = _value;
    }


    /**
     * Gets the IDCard value for this IdentificationType.
     * 
     * @return IDCard
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getIDCard() {
        return IDCard;
    }


    /**
     * Sets the IDCard value for this IdentificationType.
     * 
     * @param IDCard
     */
    public void setIDCard(com.equifax.services.eport.ws.schemas._1_0.IDType[] IDCard) {
        this.IDCard = IDCard;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getIDCard(int i) {
        return this.IDCard[i];
    }

    public void setIDCard(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.IDCard[i] = _value;
    }


    /**
     * Gets the photoCreditCard value for this IdentificationType.
     * 
     * @return photoCreditCard
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getPhotoCreditCard() {
        return photoCreditCard;
    }


    /**
     * Sets the photoCreditCard value for this IdentificationType.
     * 
     * @param photoCreditCard
     */
    public void setPhotoCreditCard(com.equifax.services.eport.ws.schemas._1_0.IDType[] photoCreditCard) {
        this.photoCreditCard = photoCreditCard;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getPhotoCreditCard(int i) {
        return this.photoCreditCard[i];
    }

    public void setPhotoCreditCard(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.photoCreditCard[i] = _value;
    }


    /**
     * Gets the IDOther value for this IdentificationType.
     * 
     * @return IDOther
     */
    public com.equifax.services.eport.ws.schemas._1_0.IDType[] getIDOther() {
        return IDOther;
    }


    /**
     * Sets the IDOther value for this IdentificationType.
     * 
     * @param IDOther
     */
    public void setIDOther(com.equifax.services.eport.ws.schemas._1_0.IDType[] IDOther) {
        this.IDOther = IDOther;
    }

    public com.equifax.services.eport.ws.schemas._1_0.IDType getIDOther(int i) {
        return this.IDOther[i];
    }

    public void setIDOther(int i, com.equifax.services.eport.ws.schemas._1_0.IDType _value) {
        this.IDOther[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IdentificationType)) return false;
        IdentificationType other = (IdentificationType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PANId==null && other.getPANId()==null) || 
             (this.PANId!=null &&
              java.util.Arrays.equals(this.PANId, other.getPANId()))) &&
            ((this.passportID==null && other.getPassportID()==null) || 
             (this.passportID!=null &&
              java.util.Arrays.equals(this.passportID, other.getPassportID()))) &&
            ((this.driverLicence==null && other.getDriverLicence()==null) || 
             (this.driverLicence!=null &&
              java.util.Arrays.equals(this.driverLicence, other.getDriverLicence()))) &&
            ((this.voterID==null && other.getVoterID()==null) || 
             (this.voterID!=null &&
              java.util.Arrays.equals(this.voterID, other.getVoterID()))) &&
            ((this.nationalIDCard==null && other.getNationalIDCard()==null) || 
             (this.nationalIDCard!=null &&
              java.util.Arrays.equals(this.nationalIDCard, other.getNationalIDCard()))) &&
            ((this.rationCard==null && other.getRationCard()==null) || 
             (this.rationCard!=null &&
              java.util.Arrays.equals(this.rationCard, other.getRationCard()))) &&
            ((this.IDCard==null && other.getIDCard()==null) || 
             (this.IDCard!=null &&
              java.util.Arrays.equals(this.IDCard, other.getIDCard()))) &&
            ((this.photoCreditCard==null && other.getPhotoCreditCard()==null) || 
             (this.photoCreditCard!=null &&
              java.util.Arrays.equals(this.photoCreditCard, other.getPhotoCreditCard()))) &&
            ((this.IDOther==null && other.getIDOther()==null) || 
             (this.IDOther!=null &&
              java.util.Arrays.equals(this.IDOther, other.getIDOther())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPANId() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPANId());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPANId(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPassportID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPassportID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPassportID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDriverLicence() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDriverLicence());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDriverLicence(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVoterID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getVoterID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getVoterID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNationalIDCard() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNationalIDCard());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNationalIDCard(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRationCard() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRationCard());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRationCard(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIDCard() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIDCard());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIDCard(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPhotoCreditCard() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPhotoCreditCard());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPhotoCreditCard(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIDOther() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIDOther());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIDOther(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IdentificationType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IdentificationType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PANId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PANId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passportID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PassportID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("driverLicence");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DriverLicence"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voterID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "VoterID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nationalIDCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NationalIDCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rationCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "RationCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("photoCreditCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PhotoCreditCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDOther");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDOther"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "IDType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
