/**
 * GroupCreditSummaryType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class GroupCreditSummaryType  implements java.io.Serializable {
    private java.lang.String institution;

    private java.math.BigDecimal currentBalance;

    private java.lang.String status;

    private java.util.Date dateReported;

    private java.lang.Integer noOfMembers;

    private java.math.BigDecimal pastDueAmount;

    private java.math.BigDecimal sanctionAmount;

    private java.util.Date dateOpened;

    private java.lang.String accountNo;

    private java.lang.Integer membersPastDue;

    private java.math.BigDecimal writeOffAmount;

    private java.util.Date writeOffDate;

    private int seq;  // attribute

    private java.util.Date reportedDate;  // attribute

    public GroupCreditSummaryType() {
    }

    public GroupCreditSummaryType(
           java.lang.String institution,
           java.math.BigDecimal currentBalance,
           java.lang.String status,
           java.util.Date dateReported,
           java.lang.Integer noOfMembers,
           java.math.BigDecimal pastDueAmount,
           java.math.BigDecimal sanctionAmount,
           java.util.Date dateOpened,
           java.lang.String accountNo,
           java.lang.Integer membersPastDue,
           java.math.BigDecimal writeOffAmount,
           java.util.Date writeOffDate,
           int seq,
           java.util.Date reportedDate) {
           this.institution = institution;
           this.currentBalance = currentBalance;
           this.status = status;
           this.dateReported = dateReported;
           this.noOfMembers = noOfMembers;
           this.pastDueAmount = pastDueAmount;
           this.sanctionAmount = sanctionAmount;
           this.dateOpened = dateOpened;
           this.accountNo = accountNo;
           this.membersPastDue = membersPastDue;
           this.writeOffAmount = writeOffAmount;
           this.writeOffDate = writeOffDate;
           this.seq = seq;
           this.reportedDate = reportedDate;
    }


    /**
     * Gets the institution value for this GroupCreditSummaryType.
     * 
     * @return institution
     */
    public java.lang.String getInstitution() {
        return institution;
    }


    /**
     * Sets the institution value for this GroupCreditSummaryType.
     * 
     * @param institution
     */
    public void setInstitution(java.lang.String institution) {
        this.institution = institution;
    }


    /**
     * Gets the currentBalance value for this GroupCreditSummaryType.
     * 
     * @return currentBalance
     */
    public java.math.BigDecimal getCurrentBalance() {
        return currentBalance;
    }


    /**
     * Sets the currentBalance value for this GroupCreditSummaryType.
     * 
     * @param currentBalance
     */
    public void setCurrentBalance(java.math.BigDecimal currentBalance) {
        this.currentBalance = currentBalance;
    }


    /**
     * Gets the status value for this GroupCreditSummaryType.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this GroupCreditSummaryType.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the dateReported value for this GroupCreditSummaryType.
     * 
     * @return dateReported
     */
    public java.util.Date getDateReported() {
        return dateReported;
    }


    /**
     * Sets the dateReported value for this GroupCreditSummaryType.
     * 
     * @param dateReported
     */
    public void setDateReported(java.util.Date dateReported) {
        this.dateReported = dateReported;
    }


    /**
     * Gets the noOfMembers value for this GroupCreditSummaryType.
     * 
     * @return noOfMembers
     */
    public java.lang.Integer getNoOfMembers() {
        return noOfMembers;
    }


    /**
     * Sets the noOfMembers value for this GroupCreditSummaryType.
     * 
     * @param noOfMembers
     */
    public void setNoOfMembers(java.lang.Integer noOfMembers) {
        this.noOfMembers = noOfMembers;
    }


    /**
     * Gets the pastDueAmount value for this GroupCreditSummaryType.
     * 
     * @return pastDueAmount
     */
    public java.math.BigDecimal getPastDueAmount() {
        return pastDueAmount;
    }


    /**
     * Sets the pastDueAmount value for this GroupCreditSummaryType.
     * 
     * @param pastDueAmount
     */
    public void setPastDueAmount(java.math.BigDecimal pastDueAmount) {
        this.pastDueAmount = pastDueAmount;
    }


    /**
     * Gets the sanctionAmount value for this GroupCreditSummaryType.
     * 
     * @return sanctionAmount
     */
    public java.math.BigDecimal getSanctionAmount() {
        return sanctionAmount;
    }


    /**
     * Sets the sanctionAmount value for this GroupCreditSummaryType.
     * 
     * @param sanctionAmount
     */
    public void setSanctionAmount(java.math.BigDecimal sanctionAmount) {
        this.sanctionAmount = sanctionAmount;
    }


    /**
     * Gets the dateOpened value for this GroupCreditSummaryType.
     * 
     * @return dateOpened
     */
    public java.util.Date getDateOpened() {
        return dateOpened;
    }


    /**
     * Sets the dateOpened value for this GroupCreditSummaryType.
     * 
     * @param dateOpened
     */
    public void setDateOpened(java.util.Date dateOpened) {
        this.dateOpened = dateOpened;
    }


    /**
     * Gets the accountNo value for this GroupCreditSummaryType.
     * 
     * @return accountNo
     */
    public java.lang.String getAccountNo() {
        return accountNo;
    }


    /**
     * Sets the accountNo value for this GroupCreditSummaryType.
     * 
     * @param accountNo
     */
    public void setAccountNo(java.lang.String accountNo) {
        this.accountNo = accountNo;
    }


    /**
     * Gets the membersPastDue value for this GroupCreditSummaryType.
     * 
     * @return membersPastDue
     */
    public java.lang.Integer getMembersPastDue() {
        return membersPastDue;
    }


    /**
     * Sets the membersPastDue value for this GroupCreditSummaryType.
     * 
     * @param membersPastDue
     */
    public void setMembersPastDue(java.lang.Integer membersPastDue) {
        this.membersPastDue = membersPastDue;
    }


    /**
     * Gets the writeOffAmount value for this GroupCreditSummaryType.
     * 
     * @return writeOffAmount
     */
    public java.math.BigDecimal getWriteOffAmount() {
        return writeOffAmount;
    }


    /**
     * Sets the writeOffAmount value for this GroupCreditSummaryType.
     * 
     * @param writeOffAmount
     */
    public void setWriteOffAmount(java.math.BigDecimal writeOffAmount) {
        this.writeOffAmount = writeOffAmount;
    }


    /**
     * Gets the writeOffDate value for this GroupCreditSummaryType.
     * 
     * @return writeOffDate
     */
    public java.util.Date getWriteOffDate() {
        return writeOffDate;
    }


    /**
     * Sets the writeOffDate value for this GroupCreditSummaryType.
     * 
     * @param writeOffDate
     */
    public void setWriteOffDate(java.util.Date writeOffDate) {
        this.writeOffDate = writeOffDate;
    }


    /**
     * Gets the seq value for this GroupCreditSummaryType.
     * 
     * @return seq
     */
    public int getSeq() {
        return seq;
    }


    /**
     * Sets the seq value for this GroupCreditSummaryType.
     * 
     * @param seq
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }


    /**
     * Gets the reportedDate value for this GroupCreditSummaryType.
     * 
     * @return reportedDate
     */
    public java.util.Date getReportedDate() {
        return reportedDate;
    }


    /**
     * Sets the reportedDate value for this GroupCreditSummaryType.
     * 
     * @param reportedDate
     */
    public void setReportedDate(java.util.Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GroupCreditSummaryType)) return false;
        GroupCreditSummaryType other = (GroupCreditSummaryType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.institution==null && other.getInstitution()==null) || 
             (this.institution!=null &&
              this.institution.equals(other.getInstitution()))) &&
            ((this.currentBalance==null && other.getCurrentBalance()==null) || 
             (this.currentBalance!=null &&
              this.currentBalance.equals(other.getCurrentBalance()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.dateReported==null && other.getDateReported()==null) || 
             (this.dateReported!=null &&
              this.dateReported.equals(other.getDateReported()))) &&
            ((this.noOfMembers==null && other.getNoOfMembers()==null) || 
             (this.noOfMembers!=null &&
              this.noOfMembers.equals(other.getNoOfMembers()))) &&
            ((this.pastDueAmount==null && other.getPastDueAmount()==null) || 
             (this.pastDueAmount!=null &&
              this.pastDueAmount.equals(other.getPastDueAmount()))) &&
            ((this.sanctionAmount==null && other.getSanctionAmount()==null) || 
             (this.sanctionAmount!=null &&
              this.sanctionAmount.equals(other.getSanctionAmount()))) &&
            ((this.dateOpened==null && other.getDateOpened()==null) || 
             (this.dateOpened!=null &&
              this.dateOpened.equals(other.getDateOpened()))) &&
            ((this.accountNo==null && other.getAccountNo()==null) || 
             (this.accountNo!=null &&
              this.accountNo.equals(other.getAccountNo()))) &&
            ((this.membersPastDue==null && other.getMembersPastDue()==null) || 
             (this.membersPastDue!=null &&
              this.membersPastDue.equals(other.getMembersPastDue()))) &&
            ((this.writeOffAmount==null && other.getWriteOffAmount()==null) || 
             (this.writeOffAmount!=null &&
              this.writeOffAmount.equals(other.getWriteOffAmount()))) &&
            ((this.writeOffDate==null && other.getWriteOffDate()==null) || 
             (this.writeOffDate!=null &&
              this.writeOffDate.equals(other.getWriteOffDate()))) &&
            this.seq == other.getSeq() &&
            ((this.reportedDate==null && other.getReportedDate()==null) || 
             (this.reportedDate!=null &&
              this.reportedDate.equals(other.getReportedDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getInstitution() != null) {
            _hashCode += getInstitution().hashCode();
        }
        if (getCurrentBalance() != null) {
            _hashCode += getCurrentBalance().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getDateReported() != null) {
            _hashCode += getDateReported().hashCode();
        }
        if (getNoOfMembers() != null) {
            _hashCode += getNoOfMembers().hashCode();
        }
        if (getPastDueAmount() != null) {
            _hashCode += getPastDueAmount().hashCode();
        }
        if (getSanctionAmount() != null) {
            _hashCode += getSanctionAmount().hashCode();
        }
        if (getDateOpened() != null) {
            _hashCode += getDateOpened().hashCode();
        }
        if (getAccountNo() != null) {
            _hashCode += getAccountNo().hashCode();
        }
        if (getMembersPastDue() != null) {
            _hashCode += getMembersPastDue().hashCode();
        }
        if (getWriteOffAmount() != null) {
            _hashCode += getWriteOffAmount().hashCode();
        }
        if (getWriteOffDate() != null) {
            _hashCode += getWriteOffDate().hashCode();
        }
        _hashCode += getSeq();
        if (getReportedDate() != null) {
            _hashCode += getReportedDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GroupCreditSummaryType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GroupCreditSummaryType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("seq");
        attrField.setXmlName(new javax.xml.namespace.QName("", "seq"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reportedDate");
        attrField.setXmlName(new javax.xml.namespace.QName("", "ReportedDate"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("institution");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Institution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentBalance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "CurrentBalance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateReported");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateReported"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noOfMembers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "NoOfMembers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pastDueAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PastDueAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sanctionAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SanctionAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateOpened");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "DateOpened"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("membersPastDue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "MembersPastDue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("writeOffAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "WriteOffAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("writeOffDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "WriteOffDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
