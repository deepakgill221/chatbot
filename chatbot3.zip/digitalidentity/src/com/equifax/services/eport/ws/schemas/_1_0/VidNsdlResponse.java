/**
 * VidNsdlResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class VidNsdlResponse  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.NsdlRequest nsdlRequest;

    private com.equifax.services.eport.ws.schemas._1_0.NsdlResponse nsdlResponse;

    public VidNsdlResponse() {
    }

    public VidNsdlResponse(
           com.equifax.services.eport.ws.schemas._1_0.NsdlRequest nsdlRequest,
           com.equifax.services.eport.ws.schemas._1_0.NsdlResponse nsdlResponse) {
           this.nsdlRequest = nsdlRequest;
           this.nsdlResponse = nsdlResponse;
    }


    /**
     * Gets the nsdlRequest value for this VidNsdlResponse.
     * 
     * @return nsdlRequest
     */
    public com.equifax.services.eport.ws.schemas._1_0.NsdlRequest getNsdlRequest() {
        return nsdlRequest;
    }


    /**
     * Sets the nsdlRequest value for this VidNsdlResponse.
     * 
     * @param nsdlRequest
     */
    public void setNsdlRequest(com.equifax.services.eport.ws.schemas._1_0.NsdlRequest nsdlRequest) {
        this.nsdlRequest = nsdlRequest;
    }


    /**
     * Gets the nsdlResponse value for this VidNsdlResponse.
     * 
     * @return nsdlResponse
     */
    public com.equifax.services.eport.ws.schemas._1_0.NsdlResponse getNsdlResponse() {
        return nsdlResponse;
    }


    /**
     * Sets the nsdlResponse value for this VidNsdlResponse.
     * 
     * @param nsdlResponse
     */
    public void setNsdlResponse(com.equifax.services.eport.ws.schemas._1_0.NsdlResponse nsdlResponse) {
        this.nsdlResponse = nsdlResponse;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VidNsdlResponse)) return false;
        VidNsdlResponse other = (VidNsdlResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nsdlRequest==null && other.getNsdlRequest()==null) || 
             (this.nsdlRequest!=null &&
              this.nsdlRequest.equals(other.getNsdlRequest()))) &&
            ((this.nsdlResponse==null && other.getNsdlResponse()==null) || 
             (this.nsdlResponse!=null &&
              this.nsdlResponse.equals(other.getNsdlResponse())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNsdlRequest() != null) {
            _hashCode += getNsdlRequest().hashCode();
        }
        if (getNsdlResponse() != null) {
            _hashCode += getNsdlResponse().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VidNsdlResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "vidNsdlResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nsdlRequest");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nsdlRequest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nsdlRequest"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nsdlResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nsdlResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "nsdlResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
