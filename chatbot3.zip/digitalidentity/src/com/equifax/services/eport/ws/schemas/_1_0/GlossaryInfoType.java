/**
 * GlossaryInfoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.equifax.services.eport.ws.schemas._1_0;

public class GlossaryInfoType  implements java.io.Serializable {
    private com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] accountStatus;

    private com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] paymentHistoryStatus;

    private com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] assetClassificationStatus;

    private com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] suitFiledStatus;

    public GlossaryInfoType() {
    }

    public GlossaryInfoType(
           com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] accountStatus,
           com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] paymentHistoryStatus,
           com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] assetClassificationStatus,
           com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] suitFiledStatus) {
           this.accountStatus = accountStatus;
           this.paymentHistoryStatus = paymentHistoryStatus;
           this.assetClassificationStatus = assetClassificationStatus;
           this.suitFiledStatus = suitFiledStatus;
    }


    /**
     * Gets the accountStatus value for this GlossaryInfoType.
     * 
     * @return accountStatus
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] getAccountStatus() {
        return accountStatus;
    }


    /**
     * Sets the accountStatus value for this GlossaryInfoType.
     * 
     * @param accountStatus
     */
    public void setAccountStatus(com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] accountStatus) {
        this.accountStatus = accountStatus;
    }

    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType getAccountStatus(int i) {
        return this.accountStatus[i];
    }

    public void setAccountStatus(int i, com.equifax.services.eport.ws.schemas._1_0.AccountStatusType _value) {
        this.accountStatus[i] = _value;
    }


    /**
     * Gets the paymentHistoryStatus value for this GlossaryInfoType.
     * 
     * @return paymentHistoryStatus
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] getPaymentHistoryStatus() {
        return paymentHistoryStatus;
    }


    /**
     * Sets the paymentHistoryStatus value for this GlossaryInfoType.
     * 
     * @param paymentHistoryStatus
     */
    public void setPaymentHistoryStatus(com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] paymentHistoryStatus) {
        this.paymentHistoryStatus = paymentHistoryStatus;
    }

    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType getPaymentHistoryStatus(int i) {
        return this.paymentHistoryStatus[i];
    }

    public void setPaymentHistoryStatus(int i, com.equifax.services.eport.ws.schemas._1_0.AccountStatusType _value) {
        this.paymentHistoryStatus[i] = _value;
    }


    /**
     * Gets the assetClassificationStatus value for this GlossaryInfoType.
     * 
     * @return assetClassificationStatus
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] getAssetClassificationStatus() {
        return assetClassificationStatus;
    }


    /**
     * Sets the assetClassificationStatus value for this GlossaryInfoType.
     * 
     * @param assetClassificationStatus
     */
    public void setAssetClassificationStatus(com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] assetClassificationStatus) {
        this.assetClassificationStatus = assetClassificationStatus;
    }

    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType getAssetClassificationStatus(int i) {
        return this.assetClassificationStatus[i];
    }

    public void setAssetClassificationStatus(int i, com.equifax.services.eport.ws.schemas._1_0.AccountStatusType _value) {
        this.assetClassificationStatus[i] = _value;
    }


    /**
     * Gets the suitFiledStatus value for this GlossaryInfoType.
     * 
     * @return suitFiledStatus
     */
    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] getSuitFiledStatus() {
        return suitFiledStatus;
    }


    /**
     * Sets the suitFiledStatus value for this GlossaryInfoType.
     * 
     * @param suitFiledStatus
     */
    public void setSuitFiledStatus(com.equifax.services.eport.ws.schemas._1_0.AccountStatusType[] suitFiledStatus) {
        this.suitFiledStatus = suitFiledStatus;
    }

    public com.equifax.services.eport.ws.schemas._1_0.AccountStatusType getSuitFiledStatus(int i) {
        return this.suitFiledStatus[i];
    }

    public void setSuitFiledStatus(int i, com.equifax.services.eport.ws.schemas._1_0.AccountStatusType _value) {
        this.suitFiledStatus[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GlossaryInfoType)) return false;
        GlossaryInfoType other = (GlossaryInfoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accountStatus==null && other.getAccountStatus()==null) || 
             (this.accountStatus!=null &&
              java.util.Arrays.equals(this.accountStatus, other.getAccountStatus()))) &&
            ((this.paymentHistoryStatus==null && other.getPaymentHistoryStatus()==null) || 
             (this.paymentHistoryStatus!=null &&
              java.util.Arrays.equals(this.paymentHistoryStatus, other.getPaymentHistoryStatus()))) &&
            ((this.assetClassificationStatus==null && other.getAssetClassificationStatus()==null) || 
             (this.assetClassificationStatus!=null &&
              java.util.Arrays.equals(this.assetClassificationStatus, other.getAssetClassificationStatus()))) &&
            ((this.suitFiledStatus==null && other.getSuitFiledStatus()==null) || 
             (this.suitFiledStatus!=null &&
              java.util.Arrays.equals(this.suitFiledStatus, other.getSuitFiledStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccountStatus() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAccountStatus());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAccountStatus(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPaymentHistoryStatus() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPaymentHistoryStatus());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPaymentHistoryStatus(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAssetClassificationStatus() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAssetClassificationStatus());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAssetClassificationStatus(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSuitFiledStatus() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSuitFiledStatus());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSuitFiledStatus(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GlossaryInfoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "GlossaryInfoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentHistoryStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "PaymentHistoryStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("assetClassificationStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AssetClassificationStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suitFiledStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "SuitFiledStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://services.equifax.com/eport/ws/schemas/1.0", "AccountStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
