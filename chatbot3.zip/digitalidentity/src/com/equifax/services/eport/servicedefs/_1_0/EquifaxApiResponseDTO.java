package com.equifax.services.eport.servicedefs._1_0;

public class EquifaxApiResponseDTO {

	String policyNo="";
	String pan="";
	String dob="";
	String fName="";
	String mName="";
	String lName="";
	String address="";
	String pinCode="";
	String mobile="";
	String emailID="";
	String occptnCls="";
	String credtScr="";
	String estmtdIncm="";
	String byteArr="";

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getOccptnCls() {
		return occptnCls;
	}

	public void setOccptnCls(String occptnCls) {
		this.occptnCls = occptnCls;
	}

	public String getCredtScr() {
		return credtScr;
	}

	public void setCredtScr(String credtScr) {
		this.credtScr = credtScr;
	}

	public String getEstmtdIncm() {
		return estmtdIncm;
	}

	public void setEstmtdIncm(String estmtdIncm) {
		this.estmtdIncm = estmtdIncm;
	}

	public String getByteArr() {
		return byteArr;
	}

	public void setByteArr(String byteArr) {
		this.byteArr = byteArr;
	}

}
