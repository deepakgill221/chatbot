package com.equifax.services.eport.servicedefs._1_0;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.equifax.services.eport.ws.schemas._1_0.InquiryPurposeOptions;
import com.equifax.services.eport.ws.schemas._1_0.InquiryRequestType;
import com.equifax.services.eport.ws.schemas._1_0.InquiryResponseType;
import com.equifax.services.eport.ws.schemas._1_0.ReportFormatOptions;
import com.equifax.services.eport.ws.schemas._1_0.RequestBodyType;
import com.equifax.services.eport.ws.schemas._1_0.RequestHeaderType;
import com.equifax.services.eport.ws.schemas._1_0.StateCodeOptions;
import com.qc.utils.XTrustProvider;


public class TestClientEVDR {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {

			URL url=new URL("https://eporttrain.equifax.co.in/creditreportws/CreditReportWSInquiry/v1.0");
//			URL url=new URL("https://eport.equifax.co.in/creditreportws/CreditReportWSInquiry/v1.0/");
			
			RequestHeaderType requestHeaderType=new RequestHeaderType();
			requestHeaderType.setCustomerId(3);
			requestHeaderType.setUserId("STS_MAX");
			requestHeaderType.setPassword("Getrpt247");
			requestHeaderType.setMemberNumber("999BB00304");
			requestHeaderType.setProductCode("EVDR");
			requestHeaderType.setSecurityCode("AA3");
			requestHeaderType.setProductVersion("1.0");
			requestHeaderType.setReportFormat(ReportFormatOptions.XML);
//			
			
			
			
//			requestHeaderType.setCustomerId(2329);
//			requestHeaderType.setUserId("STS_MAX");
//			requestHeaderType.setPassword("G5Y96#9a_L");
//			requestHeaderType.setMemberNumber("006IL00034");
//			requestHeaderType.setProductCode("EVDR");
//			requestHeaderType.setSecurityCode("IL2");
//			requestHeaderType.setProductVersion("1.0");
//			requestHeaderType.setReportFormat(ReportFormatOptions.XML);
//			

			RequestBodyType requestBodyType = new RequestBodyType();
			requestBodyType.setInquiryPurpose(InquiryPurposeOptions.value1);
			requestBodyType.setFirstName("KULDEEP");
			requestBodyType.setMiddleName("");
			requestBodyType.setLastName("SINGH");

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			String dateInString = "1977-08-10";
			Date date = sdf.parse(dateInString);

			requestBodyType.setDOB(date);
			requestBodyType.setPANId("ATTPS6712P");
			requestBodyType.setAddrLine1("24-B D-1 SECTOR-22 G B NAGAR,NOIDA");
			requestBodyType.setState(StateCodeOptions.UP);
			requestBodyType.setPostal("201301");

			InquiryRequestType inquiryRequest = new InquiryRequestType();
			inquiryRequest.setRequestHeader(requestHeaderType);
			inquiryRequest.setRequestBody(requestBodyType);

			InquiryResponseType inquiryResponse = new InquiryResponseType();
			inquiryResponse.setInquiryRequestInfo(requestBodyType);


			V10 locator = new V10Locator();

			CreditReportWSInquiryPortTypeProxy cp=new CreditReportWSInquiryPortTypeProxy();

			XTrustProvider xTrustProvider = new XTrustProvider();
			xTrustProvider.install();
			System.setProperty("http.proxyHost", "cachecluster.maxlifeinsurance.com");
			//System.setProperty("http.proxyHost", "172.23.64.211");
			System.setProperty("http.proxyPort", "3128");
			InquiryResponseType response=cp.getConsumerCreditReport(inquiryRequest);

			System.out.println(response.getReportData().getVerifyIDResponse().getVidNsdlResponses()[0].getNsdlResponse().getPAN());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getFirstName());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getMiddleName());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getName().getLastName());
			
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().getDate());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().getMonth());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().getYear());
			
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().toLocaleString());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().toGMTString());
			System.out.println(response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().compareTo(date));
//			String resdate = response.getReportData().getIDAndContactInfo().getPersonalInfo().getDateOfBirth().toGMTString();
//			Date date2 = sdf.parse(resdate);
//			System.out.println(date2);

			

		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
