package com.qualtech.webservice.AadhaarVerificationotp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TEstingServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		AadhaarVerificationWebServiceCallLocator docLocator;
		AadhaarWebServiceSoapBindingStub myService;
		response.setContentType("Text/HTML");
		PrintWriter out=response.getWriter();
		try 
		{
			System.out.println("Inside Testing Servlet:----");
			
			docLocator = new AadhaarVerificationWebServiceCallLocator();
			myService = new AadhaarWebServiceSoapBindingStub();			
			//myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL("http://61.246.137.195/AadhaarVerficationWebService/services/AadhaarVerificationWebService"));			
		myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL("http://localhost:8082/AadhaarOTPKUAWebSerice/services/AadhaarVerificationWebService"));
		//myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL("http://10.72.1.15:9180/AadhaarVerficationWebService/services/AadhaarVerificationWebService"));
			//myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL("http://10.72.9.215:8081/AadhaarVerficationWebService/services/AadhaarVerificationWebService"));
		
				
		AadhaarVerificationServiceResponse response1=myService.saveAadhaarVerificationInformation(					
				new AadhaarVerificationServiceRequest(
						request.getParameter("requestType"),
						   request.getParameter("aadhaarNumber"),
				           "QC",
				           "dypnU7milCCtWzrnBcXWgA==",
				           "00",
				           request.getParameter("otp"),
				           request.getParameter("customerName"),
				           request.getParameter("customerDOB"),
				           request.getParameter("customerGender"),
				           request.getParameter("proposalNumber1"),
				           request.getParameter("proposalNumber2"),
				           request.getParameter("dataMatchRequired"),
				           "K",
				           null,
				           null,
				           null,
				           null,
				           null,
				           null,
				           null,
				           null,
				           null,
				           null,
				           null,
				           "",
				           "", 
				           null,
				           null,
				           null
				           ));
	
			//AadhaarVerificationServiceResponse response=myService.saveAadhaarVerificationInformation(	
			//new AadhaarVerificationServiceRequest("A","423995958384","QC","p@ssw0rd","00","150574","","","","","","N",null,null,null,null,null));
				
			// Ravi  423995958384 ---- 999905987814   02-07-1974
			// Rakesh 999929989823   01-01-1985        
			// Mohit Single 638808139048    999928949401      22-11-1989
			//Amit 849889269350
			System.out.println("reportXML---for response Status >"+response1.getOutputStatus());
			System.out.println("reportXML---for response Message >"+response1.getOutputMessage());
			
			
			request.setAttribute("message",response1.getOutputMessage());
			request.setAttribute("status",response1.getOutputStatus());
			
			request.setAttribute("getCustomerName",response1.getCustomerName());
			request.setAttribute("getCustomerDOB",response1.getCustomerDOB());
			request.setAttribute("getCustomerGender",response1.getCustomerGender());
			request.setAttribute("getCustomerAddress",response1.getCustomerAddress());
			request.setAttribute("Phone",response1.getOutputParam1());
			request.setAttribute("Email",response1.getOutputParam2());
			request.setAttribute("Photo",response1.getOutputParam3());
			

			out.println(response1.getOutputStatus()+"~"+ response1.getOutputMessage());
			RequestDispatcher dispatcher = request.getRequestDispatcher("authTest.jsp");  
			   if (dispatcher != null){  
			      dispatcher.forward(request, response);  
			}
		}
		catch(Exception ex)
		{
			System.err.println(ex);
			ex.printStackTrace();
			out.println("E~ErrorInfo in calling webservice");
		}	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}
}