/**
 * AadhaarVerificationWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qualtech.webservice.AadhaarVerification;

public interface AadhaarVerificationWebService extends java.rmi.Remote {
    public com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse saveAadhaarVerificationInformation(com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceRequest aadhaarVerificationServiceRequest) throws java.rmi.RemoteException;
}
