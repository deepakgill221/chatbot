/**
 * AadhaarVerificationServiceRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qualtech.webservice.AadhaarVerification;

public class AadhaarVerificationServiceRequest  implements java.io.Serializable {
    private java.lang.String requestType;

    private java.lang.String aadhaarNumber;

    private java.lang.String systemID;

    private java.lang.String password;

    private java.lang.String otpRecieveType;

    private java.lang.String otp;

    private java.lang.String customerName;

    private java.lang.String customerDOB;

    private java.lang.String customerGender;

    private java.lang.String proposalNumber1;

    private java.lang.String proposalNumber2;

    private java.lang.String dataMatchRequired;

    private java.lang.String inputType;

    private byte[] leftThumb;

    private byte[] leftForeFinger;

    private byte[] leftMiddleFinger;

    private byte[] leftRingFinger;

    private byte[] leftLittleFinger;

    private byte[] rightThumb;

    private byte[] rightForeFinger;

    private byte[] rightMiddleFinger;

    private byte[] rightRingFinger;

    private byte[] rightLittleFinger;

    private java.lang.String inputDoc;

    private java.lang.String param1;

    private java.lang.String param2;

    private java.lang.String param3;

    private java.lang.String param4;

    private java.lang.String param5;

    public AadhaarVerificationServiceRequest() {
    }

    public AadhaarVerificationServiceRequest(
           java.lang.String requestType,
           java.lang.String aadhaarNumber,
           java.lang.String systemID,
           java.lang.String password,
           java.lang.String otpRecieveType,
           java.lang.String otp,
           java.lang.String customerName,
           java.lang.String customerDOB,
           java.lang.String customerGender,
           java.lang.String proposalNumber1,
           java.lang.String proposalNumber2,
           java.lang.String dataMatchRequired,
           java.lang.String inputType,
           byte[] leftThumb,
           byte[] leftForeFinger,
           byte[] leftMiddleFinger,
           byte[] leftRingFinger,
           byte[] leftLittleFinger,
           byte[] rightThumb,
           byte[] rightForeFinger,
           byte[] rightMiddleFinger,
           byte[] rightRingFinger,
           byte[] rightLittleFinger,
           java.lang.String inputDoc,
           java.lang.String param1,
           java.lang.String param2,
           java.lang.String param3,
           java.lang.String param4,
           java.lang.String param5) {
           this.requestType = requestType;
           this.aadhaarNumber = aadhaarNumber;
           this.systemID = systemID;
           this.password = password;
           this.otpRecieveType = otpRecieveType;
           this.otp = otp;
           this.customerName = customerName;
           this.customerDOB = customerDOB;
           this.customerGender = customerGender;
           this.proposalNumber1 = proposalNumber1;
           this.proposalNumber2 = proposalNumber2;
           this.dataMatchRequired = dataMatchRequired;
           this.inputType = inputType;
           this.leftThumb = leftThumb;
           this.leftForeFinger = leftForeFinger;
           this.leftMiddleFinger = leftMiddleFinger;
           this.leftRingFinger = leftRingFinger;
           this.leftLittleFinger = leftLittleFinger;
           this.rightThumb = rightThumb;
           this.rightForeFinger = rightForeFinger;
           this.rightMiddleFinger = rightMiddleFinger;
           this.rightRingFinger = rightRingFinger;
           this.rightLittleFinger = rightLittleFinger;
           this.inputDoc = inputDoc;
           this.param1 = param1;
           this.param2 = param2;
           this.param3 = param3;
           this.param4 = param4;
           this.param5 = param5;
    }


    /**
     * Gets the requestType value for this AadhaarVerificationServiceRequest.
     * 
     * @return requestType
     */
    public java.lang.String getRequestType() {
        return requestType;
    }


    /**
     * Sets the requestType value for this AadhaarVerificationServiceRequest.
     * 
     * @param requestType
     */
    public void setRequestType(java.lang.String requestType) {
        this.requestType = requestType;
    }


    /**
     * Gets the aadhaarNumber value for this AadhaarVerificationServiceRequest.
     * 
     * @return aadhaarNumber
     */
    public java.lang.String getAadhaarNumber() {
        return aadhaarNumber;
    }


    /**
     * Sets the aadhaarNumber value for this AadhaarVerificationServiceRequest.
     * 
     * @param aadhaarNumber
     */
    public void setAadhaarNumber(java.lang.String aadhaarNumber) {
        this.aadhaarNumber = aadhaarNumber;
    }


    /**
     * Gets the systemID value for this AadhaarVerificationServiceRequest.
     * 
     * @return systemID
     */
    public java.lang.String getSystemID() {
        return systemID;
    }


    /**
     * Sets the systemID value for this AadhaarVerificationServiceRequest.
     * 
     * @param systemID
     */
    public void setSystemID(java.lang.String systemID) {
        this.systemID = systemID;
    }


    /**
     * Gets the password value for this AadhaarVerificationServiceRequest.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this AadhaarVerificationServiceRequest.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the otpRecieveType value for this AadhaarVerificationServiceRequest.
     * 
     * @return otpRecieveType
     */
    public java.lang.String getOtpRecieveType() {
        return otpRecieveType;
    }


    /**
     * Sets the otpRecieveType value for this AadhaarVerificationServiceRequest.
     * 
     * @param otpRecieveType
     */
    public void setOtpRecieveType(java.lang.String otpRecieveType) {
        this.otpRecieveType = otpRecieveType;
    }


    /**
     * Gets the otp value for this AadhaarVerificationServiceRequest.
     * 
     * @return otp
     */
    public java.lang.String getOtp() {
        return otp;
    }


    /**
     * Sets the otp value for this AadhaarVerificationServiceRequest.
     * 
     * @param otp
     */
    public void setOtp(java.lang.String otp) {
        this.otp = otp;
    }


    /**
     * Gets the customerName value for this AadhaarVerificationServiceRequest.
     * 
     * @return customerName
     */
    public java.lang.String getCustomerName() {
        return customerName;
    }


    /**
     * Sets the customerName value for this AadhaarVerificationServiceRequest.
     * 
     * @param customerName
     */
    public void setCustomerName(java.lang.String customerName) {
        this.customerName = customerName;
    }


    /**
     * Gets the customerDOB value for this AadhaarVerificationServiceRequest.
     * 
     * @return customerDOB
     */
    public java.lang.String getCustomerDOB() {
        return customerDOB;
    }


    /**
     * Sets the customerDOB value for this AadhaarVerificationServiceRequest.
     * 
     * @param customerDOB
     */
    public void setCustomerDOB(java.lang.String customerDOB) {
        this.customerDOB = customerDOB;
    }


    /**
     * Gets the customerGender value for this AadhaarVerificationServiceRequest.
     * 
     * @return customerGender
     */
    public java.lang.String getCustomerGender() {
        return customerGender;
    }


    /**
     * Sets the customerGender value for this AadhaarVerificationServiceRequest.
     * 
     * @param customerGender
     */
    public void setCustomerGender(java.lang.String customerGender) {
        this.customerGender = customerGender;
    }


    /**
     * Gets the proposalNumber1 value for this AadhaarVerificationServiceRequest.
     * 
     * @return proposalNumber1
     */
    public java.lang.String getProposalNumber1() {
        return proposalNumber1;
    }


    /**
     * Sets the proposalNumber1 value for this AadhaarVerificationServiceRequest.
     * 
     * @param proposalNumber1
     */
    public void setProposalNumber1(java.lang.String proposalNumber1) {
        this.proposalNumber1 = proposalNumber1;
    }


    /**
     * Gets the proposalNumber2 value for this AadhaarVerificationServiceRequest.
     * 
     * @return proposalNumber2
     */
    public java.lang.String getProposalNumber2() {
        return proposalNumber2;
    }


    /**
     * Sets the proposalNumber2 value for this AadhaarVerificationServiceRequest.
     * 
     * @param proposalNumber2
     */
    public void setProposalNumber2(java.lang.String proposalNumber2) {
        this.proposalNumber2 = proposalNumber2;
    }


    /**
     * Gets the dataMatchRequired value for this AadhaarVerificationServiceRequest.
     * 
     * @return dataMatchRequired
     */
    public java.lang.String getDataMatchRequired() {
        return dataMatchRequired;
    }


    /**
     * Sets the dataMatchRequired value for this AadhaarVerificationServiceRequest.
     * 
     * @param dataMatchRequired
     */
    public void setDataMatchRequired(java.lang.String dataMatchRequired) {
        this.dataMatchRequired = dataMatchRequired;
    }


    /**
     * Gets the inputType value for this AadhaarVerificationServiceRequest.
     * 
     * @return inputType
     */
    public java.lang.String getInputType() {
        return inputType;
    }


    /**
     * Sets the inputType value for this AadhaarVerificationServiceRequest.
     * 
     * @param inputType
     */
    public void setInputType(java.lang.String inputType) {
        this.inputType = inputType;
    }


    /**
     * Gets the leftThumb value for this AadhaarVerificationServiceRequest.
     * 
     * @return leftThumb
     */
    public byte[] getLeftThumb() {
        return leftThumb;
    }


    /**
     * Sets the leftThumb value for this AadhaarVerificationServiceRequest.
     * 
     * @param leftThumb
     */
    public void setLeftThumb(byte[] leftThumb) {
        this.leftThumb = leftThumb;
    }


    /**
     * Gets the leftForeFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return leftForeFinger
     */
    public byte[] getLeftForeFinger() {
        return leftForeFinger;
    }


    /**
     * Sets the leftForeFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param leftForeFinger
     */
    public void setLeftForeFinger(byte[] leftForeFinger) {
        this.leftForeFinger = leftForeFinger;
    }


    /**
     * Gets the leftMiddleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return leftMiddleFinger
     */
    public byte[] getLeftMiddleFinger() {
        return leftMiddleFinger;
    }


    /**
     * Sets the leftMiddleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param leftMiddleFinger
     */
    public void setLeftMiddleFinger(byte[] leftMiddleFinger) {
        this.leftMiddleFinger = leftMiddleFinger;
    }


    /**
     * Gets the leftRingFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return leftRingFinger
     */
    public byte[] getLeftRingFinger() {
        return leftRingFinger;
    }


    /**
     * Sets the leftRingFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param leftRingFinger
     */
    public void setLeftRingFinger(byte[] leftRingFinger) {
        this.leftRingFinger = leftRingFinger;
    }


    /**
     * Gets the leftLittleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return leftLittleFinger
     */
    public byte[] getLeftLittleFinger() {
        return leftLittleFinger;
    }


    /**
     * Sets the leftLittleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param leftLittleFinger
     */
    public void setLeftLittleFinger(byte[] leftLittleFinger) {
        this.leftLittleFinger = leftLittleFinger;
    }


    /**
     * Gets the rightThumb value for this AadhaarVerificationServiceRequest.
     * 
     * @return rightThumb
     */
    public byte[] getRightThumb() {
        return rightThumb;
    }


    /**
     * Sets the rightThumb value for this AadhaarVerificationServiceRequest.
     * 
     * @param rightThumb
     */
    public void setRightThumb(byte[] rightThumb) {
        this.rightThumb = rightThumb;
    }


    /**
     * Gets the rightForeFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return rightForeFinger
     */
    public byte[] getRightForeFinger() {
        return rightForeFinger;
    }


    /**
     * Sets the rightForeFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param rightForeFinger
     */
    public void setRightForeFinger(byte[] rightForeFinger) {
        this.rightForeFinger = rightForeFinger;
    }


    /**
     * Gets the rightMiddleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return rightMiddleFinger
     */
    public byte[] getRightMiddleFinger() {
        return rightMiddleFinger;
    }


    /**
     * Sets the rightMiddleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param rightMiddleFinger
     */
    public void setRightMiddleFinger(byte[] rightMiddleFinger) {
        this.rightMiddleFinger = rightMiddleFinger;
    }


    /**
     * Gets the rightRingFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return rightRingFinger
     */
    public byte[] getRightRingFinger() {
        return rightRingFinger;
    }


    /**
     * Sets the rightRingFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param rightRingFinger
     */
    public void setRightRingFinger(byte[] rightRingFinger) {
        this.rightRingFinger = rightRingFinger;
    }


    /**
     * Gets the rightLittleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @return rightLittleFinger
     */
    public byte[] getRightLittleFinger() {
        return rightLittleFinger;
    }


    /**
     * Sets the rightLittleFinger value for this AadhaarVerificationServiceRequest.
     * 
     * @param rightLittleFinger
     */
    public void setRightLittleFinger(byte[] rightLittleFinger) {
        this.rightLittleFinger = rightLittleFinger;
    }


    /**
     * Gets the inputDoc value for this AadhaarVerificationServiceRequest.
     * 
     * @return inputDoc
     */
    public java.lang.String getInputDoc() {
        return inputDoc;
    }


    /**
     * Sets the inputDoc value for this AadhaarVerificationServiceRequest.
     * 
     * @param inputDoc
     */
    public void setInputDoc(java.lang.String inputDoc) {
        this.inputDoc = inputDoc;
    }


    /**
     * Gets the param1 value for this AadhaarVerificationServiceRequest.
     * 
     * @return param1
     */
    public java.lang.String getParam1() {
        return param1;
    }


    /**
     * Sets the param1 value for this AadhaarVerificationServiceRequest.
     * 
     * @param param1
     */
    public void setParam1(java.lang.String param1) {
        this.param1 = param1;
    }


    /**
     * Gets the param2 value for this AadhaarVerificationServiceRequest.
     * 
     * @return param2
     */
    public java.lang.String getParam2() {
        return param2;
    }


    /**
     * Sets the param2 value for this AadhaarVerificationServiceRequest.
     * 
     * @param param2
     */
    public void setParam2(java.lang.String param2) {
        this.param2 = param2;
    }


    /**
     * Gets the param3 value for this AadhaarVerificationServiceRequest.
     * 
     * @return param3
     */
    public java.lang.String getParam3() {
        return param3;
    }


    /**
     * Sets the param3 value for this AadhaarVerificationServiceRequest.
     * 
     * @param param3
     */
    public void setParam3(java.lang.String param3) {
        this.param3 = param3;
    }


    /**
     * Gets the param4 value for this AadhaarVerificationServiceRequest.
     * 
     * @return param4
     */
    public java.lang.String getParam4() {
        return param4;
    }


    /**
     * Sets the param4 value for this AadhaarVerificationServiceRequest.
     * 
     * @param param4
     */
    public void setParam4(java.lang.String param4) {
        this.param4 = param4;
    }


    /**
     * Gets the param5 value for this AadhaarVerificationServiceRequest.
     * 
     * @return param5
     */
    public java.lang.String getParam5() {
        return param5;
    }


    /**
     * Sets the param5 value for this AadhaarVerificationServiceRequest.
     * 
     * @param param5
     */
    public void setParam5(java.lang.String param5) {
        this.param5 = param5;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AadhaarVerificationServiceRequest)) return false;
        AadhaarVerificationServiceRequest other = (AadhaarVerificationServiceRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.requestType==null && other.getRequestType()==null) || 
             (this.requestType!=null &&
              this.requestType.equals(other.getRequestType()))) &&
            ((this.aadhaarNumber==null && other.getAadhaarNumber()==null) || 
             (this.aadhaarNumber!=null &&
              this.aadhaarNumber.equals(other.getAadhaarNumber()))) &&
            ((this.systemID==null && other.getSystemID()==null) || 
             (this.systemID!=null &&
              this.systemID.equals(other.getSystemID()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.otpRecieveType==null && other.getOtpRecieveType()==null) || 
             (this.otpRecieveType!=null &&
              this.otpRecieveType.equals(other.getOtpRecieveType()))) &&
            ((this.otp==null && other.getOtp()==null) || 
             (this.otp!=null &&
              this.otp.equals(other.getOtp()))) &&
            ((this.customerName==null && other.getCustomerName()==null) || 
             (this.customerName!=null &&
              this.customerName.equals(other.getCustomerName()))) &&
            ((this.customerDOB==null && other.getCustomerDOB()==null) || 
             (this.customerDOB!=null &&
              this.customerDOB.equals(other.getCustomerDOB()))) &&
            ((this.customerGender==null && other.getCustomerGender()==null) || 
             (this.customerGender!=null &&
              this.customerGender.equals(other.getCustomerGender()))) &&
            ((this.proposalNumber1==null && other.getProposalNumber1()==null) || 
             (this.proposalNumber1!=null &&
              this.proposalNumber1.equals(other.getProposalNumber1()))) &&
            ((this.proposalNumber2==null && other.getProposalNumber2()==null) || 
             (this.proposalNumber2!=null &&
              this.proposalNumber2.equals(other.getProposalNumber2()))) &&
            ((this.dataMatchRequired==null && other.getDataMatchRequired()==null) || 
             (this.dataMatchRequired!=null &&
              this.dataMatchRequired.equals(other.getDataMatchRequired()))) &&
            ((this.inputType==null && other.getInputType()==null) || 
             (this.inputType!=null &&
              this.inputType.equals(other.getInputType()))) &&
            ((this.leftThumb==null && other.getLeftThumb()==null) || 
             (this.leftThumb!=null &&
              java.util.Arrays.equals(this.leftThumb, other.getLeftThumb()))) &&
            ((this.leftForeFinger==null && other.getLeftForeFinger()==null) || 
             (this.leftForeFinger!=null &&
              java.util.Arrays.equals(this.leftForeFinger, other.getLeftForeFinger()))) &&
            ((this.leftMiddleFinger==null && other.getLeftMiddleFinger()==null) || 
             (this.leftMiddleFinger!=null &&
              java.util.Arrays.equals(this.leftMiddleFinger, other.getLeftMiddleFinger()))) &&
            ((this.leftRingFinger==null && other.getLeftRingFinger()==null) || 
             (this.leftRingFinger!=null &&
              java.util.Arrays.equals(this.leftRingFinger, other.getLeftRingFinger()))) &&
            ((this.leftLittleFinger==null && other.getLeftLittleFinger()==null) || 
             (this.leftLittleFinger!=null &&
              java.util.Arrays.equals(this.leftLittleFinger, other.getLeftLittleFinger()))) &&
            ((this.rightThumb==null && other.getRightThumb()==null) || 
             (this.rightThumb!=null &&
              java.util.Arrays.equals(this.rightThumb, other.getRightThumb()))) &&
            ((this.rightForeFinger==null && other.getRightForeFinger()==null) || 
             (this.rightForeFinger!=null &&
              java.util.Arrays.equals(this.rightForeFinger, other.getRightForeFinger()))) &&
            ((this.rightMiddleFinger==null && other.getRightMiddleFinger()==null) || 
             (this.rightMiddleFinger!=null &&
              java.util.Arrays.equals(this.rightMiddleFinger, other.getRightMiddleFinger()))) &&
            ((this.rightRingFinger==null && other.getRightRingFinger()==null) || 
             (this.rightRingFinger!=null &&
              java.util.Arrays.equals(this.rightRingFinger, other.getRightRingFinger()))) &&
            ((this.rightLittleFinger==null && other.getRightLittleFinger()==null) || 
             (this.rightLittleFinger!=null &&
              java.util.Arrays.equals(this.rightLittleFinger, other.getRightLittleFinger()))) &&
            ((this.inputDoc==null && other.getInputDoc()==null) || 
             (this.inputDoc!=null &&
              this.inputDoc.equals(other.getInputDoc()))) &&
            ((this.param1==null && other.getParam1()==null) || 
             (this.param1!=null &&
              this.param1.equals(other.getParam1()))) &&
            ((this.param2==null && other.getParam2()==null) || 
             (this.param2!=null &&
              this.param2.equals(other.getParam2()))) &&
            ((this.param3==null && other.getParam3()==null) || 
             (this.param3!=null &&
              this.param3.equals(other.getParam3()))) &&
            ((this.param4==null && other.getParam4()==null) || 
             (this.param4!=null &&
              this.param4.equals(other.getParam4()))) &&
            ((this.param5==null && other.getParam5()==null) || 
             (this.param5!=null &&
              this.param5.equals(other.getParam5())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRequestType() != null) {
            _hashCode += getRequestType().hashCode();
        }
        if (getAadhaarNumber() != null) {
            _hashCode += getAadhaarNumber().hashCode();
        }
        if (getSystemID() != null) {
            _hashCode += getSystemID().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getOtpRecieveType() != null) {
            _hashCode += getOtpRecieveType().hashCode();
        }
        if (getOtp() != null) {
            _hashCode += getOtp().hashCode();
        }
        if (getCustomerName() != null) {
            _hashCode += getCustomerName().hashCode();
        }
        if (getCustomerDOB() != null) {
            _hashCode += getCustomerDOB().hashCode();
        }
        if (getCustomerGender() != null) {
            _hashCode += getCustomerGender().hashCode();
        }
        if (getProposalNumber1() != null) {
            _hashCode += getProposalNumber1().hashCode();
        }
        if (getProposalNumber2() != null) {
            _hashCode += getProposalNumber2().hashCode();
        }
        if (getDataMatchRequired() != null) {
            _hashCode += getDataMatchRequired().hashCode();
        }
        if (getInputType() != null) {
            _hashCode += getInputType().hashCode();
        }
        if (getLeftThumb() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLeftThumb());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLeftThumb(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLeftForeFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLeftForeFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLeftForeFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLeftMiddleFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLeftMiddleFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLeftMiddleFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLeftRingFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLeftRingFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLeftRingFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLeftLittleFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLeftLittleFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLeftLittleFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRightThumb() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRightThumb());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRightThumb(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRightForeFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRightForeFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRightForeFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRightMiddleFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRightMiddleFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRightMiddleFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRightRingFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRightRingFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRightRingFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRightLittleFinger() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRightLittleFinger());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRightLittleFinger(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInputDoc() != null) {
            _hashCode += getInputDoc().hashCode();
        }
        if (getParam1() != null) {
            _hashCode += getParam1().hashCode();
        }
        if (getParam2() != null) {
            _hashCode += getParam2().hashCode();
        }
        if (getParam3() != null) {
            _hashCode += getParam3().hashCode();
        }
        if (getParam4() != null) {
            _hashCode += getParam4().hashCode();
        }
        if (getParam5() != null) {
            _hashCode += getParam5().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AadhaarVerificationServiceRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", ">AadhaarVerificationServiceRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "requestType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aadhaarNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "aadhaarNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "systemID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("otpRecieveType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "otpRecieveType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("otp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "otp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerDOB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerDOB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerGender");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "customerGender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("proposalNumber1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "proposalNumber1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("proposalNumber2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "proposalNumber2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataMatchRequired");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "dataMatchRequired"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inputType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "inputType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftThumb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftThumb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftForeFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftForeFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftMiddleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftMiddleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftRingFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftRingFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftLittleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "leftLittleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightThumb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightThumb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightForeFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightForeFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightMiddleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightMiddleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightRingFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightRingFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightLittleFinger");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "rightLittleFinger"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inputDoc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "inputDoc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("param1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "param1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("param2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "param2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("param3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "param3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("param4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "param4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("param5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AadhaarVerification.webservice.qualtech.com", "param5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
