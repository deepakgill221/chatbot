package com.mli.leadfirst.interceptorimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.leadfirst.interceptor.SmokerIntent;
import com.mli.leadfirst.service.SmokerService;
/**
 * @author sc05216
 *
 */
@Service
public class SmokerIntentImpl implements SmokerIntent 
{
	private static Logger logger = LogManager.getLogger(SmokerIntentImpl.class);

	@Autowired
	private SmokerService smokerService;

	String speech="";
	/** 
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String customerSmokerIntent(Map<String, Map<String, String>> map, String sessionId) 
	{
		try{
		if(map.containsKey(sessionId))
		{
			String response = smokerService.smokerAPI(map, sessionId);

			if("Age is less than 18 years.".equalsIgnoreCase(response))
			{
				speech=map.get(sessionId+"Msg").get("dobError");
			}
			else{
				JSONObject object = new JSONObject(response);
				JSONObject res=(JSONObject)object.getJSONObject("response").getJSONObject("payload").getJSONArray("resPlan").get(0);
				String totalPremiumWOGST=res.get("totalPremiumWOGST")+"";

				String policyTerm = res.getString("policyTerm");
				String totalPremium=res.getString("totalPremiumWGST");

				map.get(sessionId).put("TotalPremiumWOGST", totalPremiumWOGST);
				map.get(sessionId).put("TotalPremiumWGST", totalPremium);
				map.get(sessionId).put("PolicyTerm", policyTerm);

				speech=map.get(sessionId+"Msg").get("mobile");
			}
		}
		else{
			speech=map.get(sessionId).get("Error")+" :- Smoker";
		}
		}
		catch(Exception ex){
			logger.error("Exception in validating OTP for session Id :: " + sessionId + " :: " + ex);
		}
		return speech;
	}
}
