package com.mli.leadfirst.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.leadfirst.button.InnerData;
import com.mli.leadfirst.commons.Adoptionlogs;
import com.mli.leadfirst.commons.BeanProperty;
import com.mli.leadfirst.commons.DataFromJson;
import com.mli.leadfirst.commons.SessionTimeOut;
import com.mli.leadfirst.commons.SvgBotActionHelper;
import com.mli.leadfirst.interceptor.DOBIntent;
import com.mli.leadfirst.interceptor.EmailIntent;
import com.mli.leadfirst.interceptor.GenderIntent;
import com.mli.leadfirst.interceptor.MobileNumberIntent;
import com.mli.leadfirst.interceptor.OtpValidateIntent;
import com.mli.leadfirst.interceptor.SmokerIntent;
import com.mli.leadfirst.interceptor.WelcomeIntent;
import com.mli.leadfirst.response.WebhookResponse;
import com.mli.leadfirst.service.Button;
import com.mli.leadfirst.service.GetMessageService;
import com.mli.leadfirst.service.SVGLeadCall;
import com.mli.leadfirst.service.SVGService;

/**
 * @author sc05216
 *
 */

@Service
public class SVGServiceImpl implements SVGService {

	private static Logger logger = LogManager.getLogger(SVGServiceImpl.class);

	@Autowired
	private DataFromJson dataFromJson;
	@Autowired
	private WelcomeIntent welcomeIntent;
	@Autowired
	private GenderIntent genderIntent;
	@Autowired
	private EmailIntent emailIntent;
	@Autowired
	private MobileNumberIntent mobileNumberIntent;
	@Autowired
	private DOBIntent dobIntent;
	@Autowired
	private SmokerIntent smokerIntent;
	@Autowired
	private Button button;
	@Autowired
	private SVGLeadCall svgLeadCall;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	private GetMessageService getMessageService;
	@Autowired
	private SessionTimeOut sessiontimeOut;
	@Autowired
	private BeanProperty context;
	@Autowired
	private OtpValidateIntent otpValidateIntent;

	private static Map<String, Map<String, String>> externalMap;
	private static Map<String, String> messageMap;
	private static final String WELCOME;
	private static final String DEFAULT;
	private static final String CHANNEL;
	private static final String WRONG_OTP;

	static {
		externalMap = new ConcurrentHashMap<>();
		messageMap = new ConcurrentHashMap<>();
		WELCOME = "Welcome";
		DEFAULT = "default";
		CHANNEL = "channel";
		WRONG_OTP = "Incorrect OTP is entered, please enter the correct OTP";
	}

	private void setTextMessage(String sessionId) {
		try {
			/**************************
			 * get text message Start
			 *****************************/
			String textMessage = getMessageService.getMessageAPI("svgbot");
			logger.info("Msg from rule engine ::  " + textMessage);

			JSONArray jsonArr = new JSONArray(textMessage);
			for (int i = 0; i < jsonArr.length(); i++) {
				String result = jsonArr.get(i) + "";
				String[] arr = result.split("###");
				messageMap.put(arr[0], arr[1]);
			}
			externalMap.put(sessionId + "Msg", messageMap);
		} catch (Exception ex) {
			logger.error("Exception while calling API to fetch Message from Rule Engine :: " + ex);
		}
		/**************************
		 * get text message End
		 *****************************/
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @param internalMap for storing particular data for each sessionid
	 * @param resolvedQuery user entered input
	 * @return boolean value based on success and failure excution of this method
	 */
	private boolean welcomeKit(String sessionId, Map<String, String> internalMap, String resolvedQuery) {

		boolean flag = false;

		try {
			internalMap.put("start", "start");
			externalMap.put(sessionId, internalMap);

			String source;
			String channel;
			String company;
			String category;
			String utmSource = "";
			String utmMedium = "";
			String utmCampaign = "";
			String utmTerm = "";
			String utmContent = "";

			String[] splitResolvedQuery = resolvedQuery.split("#");
			source = splitResolvedQuery[1];
			channel = splitResolvedQuery[2];
			company = splitResolvedQuery[3];

			logger.info("Source " + source + " channel " + channel + " company " + company);

			if ("WebsiteIndirect".equalsIgnoreCase(company)) {
				company = "Website Indirect";
			} else if ("WebsiteDirect".equalsIgnoreCase(company)) {
				company = "Website Direct";
			} else if ("DirectNatural".equalsIgnoreCase(company)) {
				company = "Direct Natural";
			} else if ("WebsiteDirect-mobile".equalsIgnoreCase(company)) {
				company = "Website Direct-mobile";
			}
			category = splitResolvedQuery[4];
			if ("WebsiteIndirect".equalsIgnoreCase(category)) {
				category = "Website Indirect";
			} else if ("WebsiteDirect".equalsIgnoreCase(category)) {
				category = "Website Direct";
			} else if ("DirectNatural".equalsIgnoreCase(category)) {
				category = "Direct Natural";
			} else if ("WebsiteDirect-mobile".equalsIgnoreCase(category)) {
				category = "Website Direct-mobile";
			}

			if (splitResolvedQuery.length > 7) {
				utmSource = splitResolvedQuery[5];
				utmMedium = splitResolvedQuery[6];
				utmCampaign = splitResolvedQuery[7];
				utmTerm = splitResolvedQuery[8];
				utmContent = splitResolvedQuery[9];
			}

			externalMap.get(sessionId).put("source", source);
			externalMap.get(sessionId).put(CHANNEL, channel);
			externalMap.get(sessionId).put("company", company);
			externalMap.get(sessionId).put("category", category);
			externalMap.get(sessionId).put("utm_source", utmSource);
			externalMap.get(sessionId).put("utm_medium", utmMedium);
			externalMap.get(sessionId).put("utm_campaign", utmCampaign);
			externalMap.get(sessionId).put("utm_term", utmTerm);
			externalMap.get(sessionId).put("utm_content", utmContent);

			logger.info("Values :: Session Id :- " + sessionId + "\n source :- " + source + "\n channel :- " + channel
					+ "\n company :- " + company + "\n category :- " + category + "\n utm_source :- " + utmSource
					+ "\n utm_medium :- " + utmMedium + "\n utm_campaign :- " + utmCampaign + "\n utm_term :- "
					+ utmTerm + "\n utm_content :- " + utmContent);
			flag = true;

		} catch (Exception ex) {
			logger.error("Exception ---- :: " + ex);
		}
		return flag;
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech
	 */
	private SvgBotActionHelper welcomeCase(String sessionId) {
		String speech;
		logger.info("Start action :: " + WELCOME + " :: " + sessionId);
		speech = externalMap.get(sessionId + "Msg").get(WELCOME);
		logger.info("ENd action :: " + WELCOME + " :: " + sessionId);
		return new SvgBotActionHelper(null, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech
	 */
	private SvgBotActionHelper inputName(String sessionId) {
		String speech;
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.NAME :: " + sessionId);
			speech = welcomeIntent.welcomeIntentCall(externalMap, sessionId);
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.NAME " + sessionId);
		return new SvgBotActionHelper(null, speech);
	}
	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech
	 */
	private SvgBotActionHelper inputMobile(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.MOBILE :: " + sessionId);
			speech = mobileNumberIntent.mobileNumberResponse(externalMap, sessionId);
			innerData = button.resendOtp();
		} else {
			speech = context.getSessionExpireMsg();
		}
 		logger.info("End action :: INPUT.MOBILE :: " + sessionId);
		return new SvgBotActionHelper(innerData, speech);
	}
	
	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech
	 */
	private SvgBotActionHelper validateOtp(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.OTP :: " + sessionId);
			speech = otpValidateIntent.otpValidate(externalMap, sessionId);
			if(WRONG_OTP.contains(speech))
			{
				innerData = button.resendOtp();
			}
			else{
				innerData = null;
			}
			// SVG Call start
			logger.info("Channel is for SVG ---" + externalMap.get(sessionId).get(CHANNEL) + "");
			String getChannel = externalMap.get(sessionId).get(CHANNEL) + "";
			if ("34".equalsIgnoreCase(getChannel)) {
				final String session = sessionId;
				try {

					Runnable runnable = () -> {
						svgLeadCall.svgLeadCall(externalMap, session);
						logger.info("----Lead Created on SVG.....");
					};
					Thread t1 = new Thread(runnable);

					t1.start();
					t1.join();
				} catch (Exception ex) {
					logger.info("creating exception while creating lead id in SVG" + ex);
				}
			}
			// SVG call end
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.OTP :: " + sessionId);
		return new SvgBotActionHelper(innerData, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech
	 */
	private SvgBotActionHelper inputEmail(String sessionId) {
		String speech;
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.EMAIL " + sessionId);
			speech = emailIntent.customerEmailIntent(externalMap, sessionId);
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.EMAIL :: " + sessionId);
		return new SvgBotActionHelper(null, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech and button in innerData
	 */
	private SvgBotActionHelper inputDOB(String sessionId) {

		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.DOB " + sessionId);
			speech = dobIntent.customerDOBIntent(externalMap, sessionId);
			if (speech.contains("You should be 18 years or above to apply for this plan.")) {
				innerData = null;
			} else {
				innerData = button.getButtonsGender();
			}
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.DOB " + sessionId);
		return new SvgBotActionHelper(innerData, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @return Bot response in speech and button in innerData
	 */
	private SvgBotActionHelper inputGender(String sessionId) {

		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.GENDER " + sessionId);
			speech = genderIntent.genderResponse(externalMap, sessionId);
			innerData = button.getButtonsYesNo();
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.GENDER " + sessionId);
		return new SvgBotActionHelper(innerData, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @returnBot response in speech
	 */ 
	private SvgBotActionHelper inputSmoker(String sessionId) {
		String speech;
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.SMOKER " + sessionId);
			speech = smokerIntent.customerSmokerIntent(externalMap, sessionId);
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("END action :: INPUT.SMOKER " + sessionId);
		return new SvgBotActionHelper(null, speech);
	}

	/**
	 * @return Bot response in speech
	 */
	private SvgBotActionHelper close() {

		String speech;
		externalMap.clear();
		speech = context.getChacheClear();
		return new SvgBotActionHelper(null, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @return
	 */
	private SvgBotActionHelper inputDefault(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		logger.info("Intent Not match with skill,Please connect to application owner");
		speech = externalMap.get(sessionId).get(DEFAULT);
		return new SvgBotActionHelper(innerData, speech);
	}

	/**
	 * @param sessionId unique id for one user in complete application
	 * @param action Intent name which is called by user
	 * @return
	 */
	private SvgBotActionHelper svgBotActionWork(String sessionId, String action) {
		SvgBotActionHelper svgBotActionHelper;

		switch (action.toUpperCase()) {
		case "WELCOME":
			svgBotActionHelper = welcomeCase(sessionId);
			break;

		case "INPUT.NAME":
			svgBotActionHelper = inputName(sessionId);
			break;

		case "INPUT.MOBILE":
		case "INPUT.RESENDOTP":
			svgBotActionHelper = inputMobile(sessionId);
			break;

		case "INPUT.OTP":
			svgBotActionHelper = validateOtp(sessionId);
			break;
			
		/*---------------------------------------------------------------------------------------*/
		// Email -6
		case "INPUT.EMAIL":
			svgBotActionHelper = inputEmail(sessionId);
			break;

		/*---------------------------------------------------------------------------------------*/
		case "INPUT.DOB":
			svgBotActionHelper = inputDOB(sessionId);
			break;
		/*---------------------------------------------------------------------------------------*/

		case "INPUT.GENDER":
			svgBotActionHelper = inputGender(sessionId);
			break;

		// Smoker -4
		case "INPUT.SMOKER":
			svgBotActionHelper = inputSmoker(sessionId);
			break;

		// For clear the cache
		case "CLOSE":
			svgBotActionHelper = close();
			break;

		default:
			svgBotActionHelper = inputDefault(sessionId);
		}
		return svgBotActionHelper;
	}

	@Override
	public WebhookResponse svgBotProcess(String objStr) {

		Map<String, String> internalMap = new ConcurrentHashMap<>();
		InnerData innerData = new InnerData();
		logger.info("Inside Controller");
		String speech = "";
		String sessionId = "";
		String action = "";
		String resolvedQuery = "";

		String pattern = "MM/dd/yyyy HH:mm:ss";
		Date login = new Date();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String loginTime = simpleDateFormat.format(login);

		try {
			JSONObject object = new JSONObject(objStr);
			sessionId = object.get("sessionId") + "";
			String sessionIdLogin = sessionId + "login_time";
			internalMap.put(sessionIdLogin, loginTime);

			logger.info("Session Id:: :: " + sessionId + " :: login time :: " + loginTime);

			action = object.getJSONObject("result").get("action") + "";
			logger.info("SessionId::" + sessionId + "\n Action----" + action);
			resolvedQuery = object.getJSONObject("result").get("resolvedQuery") + "";

			if (WELCOME.equalsIgnoreCase(action)) {
				setTextMessage(sessionId);
				if (!welcomeKit(sessionId, internalMap, resolvedQuery)) {
					action = DEFAULT;
				}
			}

			if (!WELCOME.equalsIgnoreCase(action) && !DEFAULT.equalsIgnoreCase(action)) {
				dataFromJson.customerNameVariable(object, sessionId, externalMap);
				dataFromJson.genderVariable(object, sessionId, externalMap);
				dataFromJson.emailVariable(object, sessionId, externalMap);
				dataFromJson.mobileVariable(object, sessionId, externalMap);
				dataFromJson.dateVariable(object, sessionId, externalMap);
				dataFromJson.smokeVariable(object, sessionId, externalMap);
				dataFromJson.otpVariable(object, sessionId, externalMap);
			}

			SvgBotActionHelper svgBotActionHelper = svgBotActionWork(sessionId, action);
			speech = svgBotActionHelper.getSpeech();
			innerData = svgBotActionHelper.getInnerData();

		} catch (Exception ex) {
			logger.error("Exception Occoured in SVG Controller " + ex);
			speech = "Communication glitch while calling API's.";
		}

		/*********************
		 * adoption log call start
		 ***********************************/

		String dbSessionId = sessionId;
		String dbActionPerformed = action;
		String dbResolvedQuery = resolvedQuery;
		String dbspeech;
		String value = dbSessionId + "login_time";
		String dbSSOId = internalMap.get(value);

		if ("INPUT.NAME".equalsIgnoreCase(action)) {
			String[] speech1 = speech.split("</strong>");
			dbspeech = speech1[0];
		} else {
			dbspeech = speech;
		}

		try {
			logger.info("Adoption Logs :: going to call adoption log api :: " + sessionId);

			Runnable runnable = () -> {
				logger.info("Run Method Start");
				String response = adoption.adoptionlogsCall(dbSessionId, dbSSOId, dbActionPerformed, dbResolvedQuery,
						dbspeech);
				logger.info("Adoption log status :: " + response);
			};
			Thread t1 = new Thread(runnable);
			t1.start();
			t1.join();
			logger.info("Adoption Logs :: END :: " + sessionId);
		}

		catch (Exception ex) {
			logger.error("Excption Occoured while saving data in to the database" + ex);
		}

		/***********************************
		 * adoption log call end
		 *******************************/

		logger.info("Final Speech--" + speech + " :: " + sessionId);

		return new WebhookResponse(speech, speech, innerData);
	}

	@Override
	public void removeUnUsedSessionFromCache() {
		logger.info("Cash Removed :: START---" );
		sessiontimeOut.cacheRemovetimeout(externalMap);
		logger.info("Cash Removed :: END---");
	}
}
