package com.mli.leadfirst.svgbotaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author sc05216
 *
 */

@Configuration
@EnableScheduling
@SpringBootApplication
@ComponentScan("com.mli.leadfirst")
public class SvgbotawsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvgbotawsApplication.class, args);
	}

}

