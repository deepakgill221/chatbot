package com.mli.leadfirst.interceptor;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface WelcomeIntent {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String welcomeIntentCall(Map<String,Map<String,String>> map, String sessionId);
}
