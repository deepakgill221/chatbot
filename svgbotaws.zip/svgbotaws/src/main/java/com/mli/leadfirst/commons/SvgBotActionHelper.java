package com.mli.leadfirst.commons;

import java.io.Serializable;

import com.mli.leadfirst.button.InnerData;

/**
 * @author sc05216
 *
 */
public class SvgBotActionHelper implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private InnerData innerData;
	private String speech;
	
	/**
	 * @param innerData
	 * @param speech
	 */
	public SvgBotActionHelper(InnerData innerData, String speech) {
		super();
		this.innerData = innerData;
		this.speech = speech;
	}
	public InnerData getInnerData() {
		return innerData;
	}
	public void setInnerData(InnerData innerData) {
		this.innerData = innerData;
	}
	public String getSpeech() {
		return speech;
	}
	public void setSpeech(String speech) {
		this.speech = speech;
	}
	@Override
	public String toString() {
		return "LeadBotActionHelper [innerData=" + innerData + ", speech=" + speech + "]";
	}
	
}
