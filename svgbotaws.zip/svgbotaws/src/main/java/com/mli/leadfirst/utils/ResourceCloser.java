package com.mli.leadfirst.utils;

import java.io.BufferedReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author sc05216
 * For closing resources write generic methods here
 *
 */
@Component
public class ResourceCloser {

	private static Logger logger = LogManager.getLogger(ResourceCloser.class);
	/**
	 * @param httpUrlConnection
	 * @param outputStreamWriter
	 * @param bufferedReader
	 */
	public void closeResourceOfHttpCall(
			HttpURLConnection httpUrlConnection,
			OutputStreamWriter outputStreamWriter,
			BufferedReader bufferedReader
			)
	{
		try
		{
			if(outputStreamWriter!=null) 
			{
				outputStreamWriter.close();
				logger.debug("OutputStreamWriter Closed");
			}
			if(bufferedReader!=null)
			{
				bufferedReader.close();
				logger.debug("BufferedReader Closed");
			}
			if(httpUrlConnection!=null) 
			{
				httpUrlConnection.disconnect();
				logger.debug("HttpURLConnection Disconnected");
			}
		}
		catch(Exception ex)
		{
			logger.error("Critical Scenario : Check on Priority As we face exception while closing the resource : "+ex);
		}
	}

}
