package com.svg.agent.service;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface SVGLeadCall 
{
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 *
	 */
	public void svgLeadCall(Map<String, Map<String, String>> map, String sessionId);
}
