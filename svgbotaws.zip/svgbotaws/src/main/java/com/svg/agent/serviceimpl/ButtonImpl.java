package com.svg.agent.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.svg.agent.button.Facebook;
import com.svg.agent.button.InnerButton;
import com.svg.agent.button.InnerData;
import com.svg.agent.service.Button;
/**
 * @author sc05216
 *
 */
@Service
public class ButtonImpl implements Button 
{
	
	private static final String APINAME="API.AI"; 
	private static final String CHATBOTNAME="Chatbot";
	private static final String MLICHATBOTNAME="MLIChatBot";
	private static final String IMAGEURL = "BOT";
	
	
	private void setInnerButtons(
			List<InnerButton> buttonList,
			String text,
			String postback,
			String link)
	{
		InnerButton button = new InnerButton();
		button.setText(text);
		button.setPostback(postback);
		button.setLink(link);		
		buttonList.add(button);
	}
	
	private void setFacebook(
			List<InnerButton> buttonList,
			Facebook fb){
		fb.setButtons(buttonList);
		fb.setTitle(MLICHATBOTNAME);
		fb.setPlatform(APINAME);
		fb.setType(CHATBOTNAME);
		fb.setImageUrl(IMAGEURL);
	}

	/** (non-Javadoc)
	 * @see com.svg.agent.service.Button#getButtonsYesNo()
	 * @return com.svg.agent.button.InnerData
	 */
	@Override
	public InnerData getButtonsYesNo() 
	{
		InnerData innerData=new InnerData();
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Yes","yes","");
		setInnerButtons(innerbuttonlist,"No","no","");
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	/** (non-Javadoc)
	 * @see com.svg.agent.service.Button#getButtonsGender()
	 * @return com.svg.agent.button.InnerData
	 */
	public InnerData getButtonsGender() 
	{
		InnerData innerData=new InnerData();
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Male","male","");
		setInnerButtons(innerbuttonlist,"Female","female","");
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	/** (non-Javadoc)
	 * @see com.svg.agent.service.Button#resendOtp()
	 * @return com.svg.agent.button.InnerData
	 */
	public InnerData resendOtp() 
	{
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		InnerData innerData=new InnerData();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Resend OTP","ResendOTP","");
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
}
