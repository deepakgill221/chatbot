package com.svg.agent.serviceimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.service.OtpValidation;
import com.svg.agent.utils.CommonUtility;
import com.svg.agent.utils.HttpCaller;

/**
 * @author sc05216
 *
 */

@Service
public class OtpValidationImpl implements OtpValidation {

	private static Logger logger = LogManager.getLogger(OtpValidationImpl.class);
	
	@Autowired
	private HttpCaller httpCaller;
	@Autowired
	private CommonUtility commonUtility;
	@Autowired
	private BeanProperty beanProperty;
	
	/**
	 * (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	
	public String validateOtp(Map<String,Map<String, String>> map , String sessionId){
		
		logger.info("ValidateOtp method Start :: sessionId :: " + sessionId);
		StringBuilder result = new StringBuilder();
		try{
		String otpUniqueTokenCode = map.get(sessionId).get("otpUniqueTokenCode");
		String otp = map.get(sessionId).get("otp");
		String url = beanProperty.getValidateOtp();
		String soaAppId = beanProperty.getValidateOtpAppId();
		int correlationId = commonUtility.getRandomNumber();
		
		StringBuilder requestData = new StringBuilder();
		
		requestData.append("	{	");
		requestData.append("	   \"header\": {	");
		requestData.append("	      \"soaCorrelationId\": \""+correlationId+"\",	");
		requestData.append("	      \"soaMsgVersion\": \"1.0\",	");
		requestData.append("	      \"soaAppId\": \""+soaAppId+"\"	");
		requestData.append("	   },	");
		requestData.append("	   \"payload\": {	");
		requestData.append("	      \"unqTokenNo\": \""+otpUniqueTokenCode+"\",	");
		requestData.append("	         \"otpCode\": \""+otp+"\",	");
		requestData.append("	      \"stepId\": \"\"	");
		requestData.append("	   }	");
		requestData.append("	}	");
		httpCaller.callHttp(url, requestData, result);
		logger.info("SessionId :: " + sessionId + " :: API :: " + "Validate OTP :: CorrelationId :: " +correlationId);
		}
		catch(Exception ex){
			logger.error("Exception in validating Otp :: SessionId :: "+sessionId + " :: " + ex );
		}
		logger.info("ValidateOtp method end :: sessionId :: " + sessionId);
		return result.toString();
	}
}

