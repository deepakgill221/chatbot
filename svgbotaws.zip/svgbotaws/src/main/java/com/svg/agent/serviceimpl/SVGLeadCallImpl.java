package com.svg.agent.serviceimpl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.service.SVGLeadCall;

//import jdk.nashorn.internal.runtime.options.LoggingOption.LoggerInfo;

@Service
public class SVGLeadCallImpl implements SVGLeadCall {

	@Autowired 
	private BeanProperty bean;
	private static Logger logger = LogManager.getLogger(SVGLeadCallImpl.class);
	//String url = "https://api.svgcolumbus.com/service/api.php";
	@Override
	public void svgLeadCall(Map<String, Map<String, String>> ExternalMap, String sessionId) 
	{
		logger.info("SVG :: SVGLeadCallImpl :: svgLeadCall  start");
		String url = bean.getSvgURL();
		String svgUserId=bean.getSvgUserId();
		String svgPassword=bean.getSvgPassword();
		String name = ExternalMap.get(sessionId).get("name");
		String mobileNum = ExternalMap.get(sessionId).get("mobileNum");
		String utm_source = ExternalMap.get(sessionId).get("utm_source");
		String utm_medium = ExternalMap.get(sessionId).get("utm_medium");
		String utm_campaign = ExternalMap.get(sessionId).get("utm_campaign");
		String utm_term = ExternalMap.get(sessionId).get("utm_term");
		String utm_content = ExternalMap.get(sessionId).get("utm_content");
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder sb=new StringBuilder();
		
		sb.append("{");
		sb.append("\"user\": \""+svgUserId+"\",");
		sb.append("\"pass\": \""+svgPassword+"\",");
		sb.append("\"camp\": 273,");
		sb.append("\"ref_id\": \"\",");
		sb.append("\"name\": \""+name+"\",");
		sb.append("\"email\": \"\",");
		sb.append("\"city\": \"\",");
		sb.append("\"date_of_birth\": \"\",");
		sb.append("\"mobile_number\": \""+mobileNum+"\",");
		sb.append("\"gender\": \"\",");
		sb.append("\"income\": \"\",");
		sb.append("\"equote\": \"\",");
		sb.append("\"smoker\": \"\",");
		sb.append("\"utm_source\": \""+utm_source + " \",");
		sb.append("\"utm_medium\": \""+utm_medium+"\",");
		sb.append("\"utm_campaign\": \""+utm_campaign+"\",");
		sb.append("\"utm_term\": \""+utm_term+"\",");
		sb.append("\"utm_keyword\": \"\",");
		sb.append("\"utm_content\": \" "+utm_content+"\",");
		sb.append("\"client_ip\": \"\",	");
		sb.append("\"user_agent\": \"\",	");
		sb.append("\"status\": \"\"	");
		sb.append("}");

		logger.info("SVG API :: "+url);
		logger.info("SVG Request :: "+sb.toString());
		HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
		logger.info("Entity :: "+entity);
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity,String.class);
		logger.info("Complete response from SVG :: "+response);
		if(response.getStatusCodeValue() == 200)
		{
			String responses = response.getBody();
			logger.info("Final response :: "+responses);
			logger.info("---Success-----"+sessionId+"---------"+responses);
		}else{
			String responses = response.getBody();
			logger.info("Final response :: "+responses);
			logger.info("---Fail-----"+sessionId+"---------"+responses);
		}
	}
}

