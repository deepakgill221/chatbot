package com.svg.agent.service;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface GetMessageService 
{
	/**
	 * @param botName
	 * @return
	 *
	 */

	public String getMessageAPI(String botName);

}
