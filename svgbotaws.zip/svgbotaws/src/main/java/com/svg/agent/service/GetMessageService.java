package com.svg.agent.service;

import java.util.Map;

public interface GetMessageService 
{
	public String getMessageAPI(String botName);

}
