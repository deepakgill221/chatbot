package com.svg.agent.service;

import com.svg.agent.button.InnerData;

/**
 * @author sc05216
 *
 */
public interface Button 
{
	/**
	 * @return
	 */
	public InnerData getButtonsYesNo();
	/**
	 * @return
	 */
	public InnerData getButtonsGender();
	/**
	 * @return
	 */
	public InnerData resendOtp();
}
