package com.svg.agent.service;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface CreateLeadService 
{
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String createLeadAPI(Map<String, Map<String, String>> map, String sessionId);

}
