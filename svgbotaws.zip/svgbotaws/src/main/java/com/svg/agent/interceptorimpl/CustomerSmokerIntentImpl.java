package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.interceptor.CustomerSmokerIntent;
import com.svg.agent.service.CreateLeadService;
import com.svg.agent.service.GetLeadService;
import com.svg.agent.service.SmokerService;

@Service
public class CustomerSmokerIntentImpl implements CustomerSmokerIntent 
{
	@Autowired
	private SmokerService smokerService;
	@Autowired
	private CreateLeadService createLeadService;
	@Autowired
	private GetLeadService getLeadService;
	@Autowired
	private BeanProperty bean;

	String speech="";
	@Override
	public String customerSmokerIntent(Map<String, Map<String, String>> map, String sessionId) 
	{
		if(map.containsKey(sessionId))
		{
			String response = smokerService.smokerAPI(map, sessionId);

			if("Age is less than 18 years.".equalsIgnoreCase(response))
			{
				speech=map.get(sessionId+"Msg").get("dobError");
			}
			else{
				JSONObject object = new JSONObject(response.toString());
				JSONObject res=(JSONObject)object.getJSONObject("response").getJSONObject("payload").getJSONArray("resPlan").get(0);
				String totalPremiumWOGST=res.get("totalPremiumWOGST")+"";

				String policyTerm = res.getString("policyTerm");
				String totalPremium=res.getString("totalPremiumWGST");
				double doubletotalPremiumWGST=Double.parseDouble(totalPremium);

				String convertedtotalPremiumWGST = String.valueOf(doubletotalPremiumWGST);
				String arr [] = convertedtotalPremiumWGST.split("\\.");
				String totalPremiumWGST = arr[0];

				map.get(sessionId).put("TotalPremiumWOGST", totalPremiumWOGST);
				map.get(sessionId).put("TotalPremiumWGST", totalPremium);
				map.get(sessionId).put("PolicyTerm", policyTerm);

				speech=map.get(sessionId+"Msg").get("mobile");


			}
		}
		else{
			speech=map.get(sessionId).get("Error")+" :- Smoker";
			//speech="Internal Glitch Please try after some time :-smoker";
		}
		return speech;
	}
}
