package com.svg.agent.interceptor;

import java.util.Map;

public interface WelcomeIntent {
	public String welcomeIntentCall(Map<String,Map<String,String>> map, String SessionId, String name);
}
