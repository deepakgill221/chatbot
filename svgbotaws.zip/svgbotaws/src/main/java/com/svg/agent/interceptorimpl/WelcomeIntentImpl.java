package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.svg.agent.interceptor.WelcomeIntent;
/**
 * @author sc05216
 *
 */
@Service
public class WelcomeIntentImpl implements WelcomeIntent 
{
	private static Logger logger = LogManager.getLogger(WelcomeIntentImpl.class);
	
	String speech="";
	/** 
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String welcomeIntentCall(Map<String, Map<String,String>> map, String sessionId)
	{
		try{
		speech=map.get(sessionId+"Msg").get("name");
		speech=speech.replace("<Insert_checkbox>", "<input type=\"checkbox\"  checked=\"checked\" disabled>");
		
		}
		catch(Exception ex)
		{
			logger.error("Exception in validating OTP for session Id :: " + sessionId + " :: " + ex);
		}
		return speech;
	}
}