package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.svg.agent.interceptor.WelcomeIntent;

@Service
public class WelcomeIntentImpl implements WelcomeIntent 
{
	String speech="";
	@Override
	public String welcomeIntentCall(Map<String, Map<String,String>> map, String sessionId, String name)
	{
		speech=map.get(sessionId+"Msg").get("name");
		speech=speech.replace("<Insert_checkbox>", "<input type=\"checkbox\"  checked=\"checked\" disabled>")
		/*speech="To know more about this term plan, please enter your <strong>10 digit mobile number</strong>.<hr>"+
				"<input type=\"checkbox\"  checked=\"checked\" disabled>" + 
				" I have read and accept the various <a href=\"https://www.maxlifeinsurance.com/content/dam/neo/pdf/TermsAndConditions_Common_2017%2011%2014.pdf\" target=\"_blank\">T&amp;Cs. </a>I agree to be contacted by Max Life Insurance, overriding my NDNC registry."*/ ;
		
		return speech;
	}
}