package com.svg.agent.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.svg.agent.response.WebhookResponse;

/**
 * @author sc05216
 *
 */

public interface SVGService {
	/**
	 * @param jsonStr : Request data in JSON Format
	 * @return
	 */
	public WebhookResponse svgBotProcess(@RequestBody String jsonStr);
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	public void removeUnUsedSessionFromCache();
}
