package com.svg.agent.interceptorimpl;

import java.util.Map;
import org.springframework.stereotype.Service;

import com.svg.agent.interceptor.CustomerMobileNumberIntent;
@Service
public class CustomerMobileNumberIntentImpl implements CustomerMobileNumberIntent 
{
	String speech="";
	@Override
	public String customerMobileNumberIntent(Map<String, Map<String, String>> map, String sessionId) {
		String name=map.get(sessionId).get("name");
		if(map.containsKey(sessionId))
		{
			speech=map.get(sessionId+"Msg").get("email");
			speech=speech.replace("<br>", "\n");
			//speech=name +" "+ map.get(sessionId+"Msg").get("mobile");
			/*speech=name+" Please enter your email address (in abc@xyz.com format).";*/
		}
		else{
			speech=map.get(sessionId+"Msg").get("Error")+"mobile";
			//speech="Internal Glitch Please try after some time :- mobile";
		}
		return speech;
	}
}