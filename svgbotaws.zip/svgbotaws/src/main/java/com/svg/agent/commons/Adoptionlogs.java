package com.svg.agent.commons;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.utils.HttpCaller;

/**
 * @author sc05216
 *
 */
@Service
public class Adoptionlogs 
{
	
	@Autowired
	private BeanProperty bean;
	@Autowired
	private HttpCaller httpCaller;
	
	private static Logger logger = LogManager.getLogger(Adoptionlogs.class);
	
	/**
	 * @param sessionId
	 * @param sSOId
	 * @param action
	 * @param resolvedQuery
	 * @param speech
	 * @return
	 */
	public String adoptionlogsCall(String sessionId, String sSOId, String action, String resolvedQuery, String speech)
	{
		logger.info("start executing adoptionlogsCall ...");
		String extURL = bean.getAdoptionlogs();
		String speechmodified = speech.replace("\n", " ");
		String platform="SVGBOTUAT";
		StringBuilder result = new StringBuilder();
		Calendar cal = Calendar.getInstance(); // creates calendar
		cal.setTime(new Date()); // sets calendar time/date
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		try
		{
			StringBuilder requestdata=new StringBuilder();
			requestdata.append("	{				");
			requestdata.append("		\"header\": {		");
			requestdata.append("		\"uniqueId\": \"\",		");
			requestdata.append("		\"creationTime\": \"\",	");
			requestdata.append("		\"userId\": \"\",	");
			requestdata.append("		\"password\": \"\"	");
			requestdata.append("	},				");
			requestdata.append("		\"payload\": {			");
			requestdata.append("	     \"transaction\": [{	");
			requestdata.append("			\"session_Id\": \""+sessionId+"\",");
			requestdata.append("			\"ssoId\": \""+sSOId+"\",");
			requestdata.append("			\"kpiAsked\": \""+action+"\",		");
			requestdata.append("			\"intentCalled\": \""+resolvedQuery+"\",");
			requestdata.append("			\"platform\": \""+platform+"\",		");
			requestdata.append("			\"loginTime\": \""+dateFormat.format(cal.getTime())+"\",");
			requestdata.append("			\"apiResponse\": \""+speechmodified+"\" ");
			requestdata.append("		     }]			");
			requestdata.append("		}	");
			requestdata.append("	}	");
			httpCaller.callHttp(extURL, requestdata, result);
		}
		catch(Exception e)
		{
			logger.error("creating exception while inserting adoption logs in SVG "+e);
		}
		logger.info("Finished Adption logs ..End");
		return "Success";
	}

}