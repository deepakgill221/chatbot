package com.svg.agent.commons;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.svg.agent.commons.CalculateTimeDiff;
import com.svg.agent.controller.LeadAgentController;

@Service
public class SessionTimeOut {
	@Autowired
	private CalculateTimeDiff calculateTimeDiff;
	public void cashRemovetimeout(Map<String, Map<String,String>> ExternalMap)
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		for(Map.Entry<String, Map<String, String>> entry : ExternalMap.entrySet())
		{
			String keytoremove = entry.getKey();
			Map<String,String> valueMap = entry.getValue();
			for(Map.Entry<String,String> getKeyValueMap : valueMap.entrySet())
			{
				if(getKeyValueMap.getKey().contains(keytoremove+"login_time"))
				{
					String logntimevalue = getKeyValueMap.getValue();
					String currentTime = dtf.format(now);
					long diffminutes = calculateTimeDiff.timediff(currentTime, logntimevalue);
					if(diffminutes > 10)
					{
						System.out.println("Removed SessionID :: "+keytoremove);
						ExternalMap.remove(keytoremove);
						System.out.println("Removed SessionID :: "+keytoremove);
						ExternalMap.remove(keytoremove+"Msg");
					}
					break;
				}
			}
		}
	}
}
