package com.svg.agent.commons;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author sc05216
 *
 */

@Service
public class SessionTimeOut {
	
	private static Logger logger = LogManager.getLogger(SessionTimeOut.class);
	@Autowired
	private CalculateTimeDiff calculateTimeDiff;
	/**
	 * @param externalMap
	 * Used for removing sessions from cache
	 */
	public void cacheRemovetimeout(Map<String, Map<String,String>> externalMap)
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		for(Map.Entry<String, Map<String, String>> entry : externalMap.entrySet())
		{
			String keytoremove = entry.getKey();
			Map<String,String> valueMap = entry.getValue();
			for(Map.Entry<String,String> getKeyValueMap : valueMap.entrySet())
			{
				if(getKeyValueMap.getKey().contains(keytoremove+"login_time"))
				{
					String logntimevalue = getKeyValueMap.getValue();
					String currentTime = dtf.format(now);
					long diffminutes = calculateTimeDiff.timeDiffInMinute(currentTime, logntimevalue);
					removeSessions(externalMap, keytoremove, diffminutes);
					break;
				}
			}
		}
	}
	
	/**
	 * @param externalMap
	 * @param keytoremove
	 * @param diffminutes
	 */
	private void removeSessions(Map<String, Map<String,String>> externalMap, String keytoremove, long diffminutes)
	{
		if(diffminutes > 10)
		{
			logger.info("Removed SessionID :: "+keytoremove);
			externalMap.remove(keytoremove);
			logger.info("Removed SessionID :: "+keytoremove);
			externalMap.remove(keytoremove+"Msg");
		}
	}
	
}
