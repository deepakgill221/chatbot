package com.svg.agent.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.svg.agent.response.WebhookResponse;
import com.svg.agent.service.SVGService;

/**
 * @author sc05216
 *
 */

@RestController
@RequestMapping("/svg")
public class SVGController 
{
	private static Logger logger = LogManager.getLogger(SVGController.class);
	
	@Autowired
	private SVGService sVGService;
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	
	@Scheduled(cron = "0 0/10 * * * ?")
	public void removeCasheTenMinute() 
	{
		logger.info("Cron job to remove un-used session from cache : Start");
		sVGService.removeUnUsedSessionFromCache();
	}
	
	/**
	 * @param request : Request data in JSON Format
	 * @return
	 */
	
	@PostMapping()
	public WebhookResponse webhook(@RequestBody String request)
	{
		logger.info("SVGBotService Start");
		return sVGService.svgBotProcess(request);
	}
}
