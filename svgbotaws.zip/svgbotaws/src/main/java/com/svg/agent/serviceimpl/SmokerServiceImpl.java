package com.svg.agent.serviceimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.commons.CalculateAge;
import com.svg.agent.service.SmokerService;
import com.svg.agent.utils.HttpCaller;

/**
 * @author sc05216
 *
 */
@Service
public class SmokerServiceImpl implements SmokerService
{
	private static Logger logger = LogManager.getLogger(SmokerServiceImpl.class);
	
	@Autowired
	private BeanProperty bean;
	@Autowired
	private HttpCaller httpCaller;
	@Autowired
	private CalculateAge calculateAge;

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.lead.agent.service.SmokerService#callSmokerAPI(java.util.Map,
	 * java.lang.String)
	 */
	@Override
	public String smokerAPI(Map<String, Map<String, String>> map, String sessionId) {
		logger.info("SMOKER API : - Inside Smoker API:: START");
		StringBuilder result = new StringBuilder();
		String soaCorrelationId = "CorelationId"+System.currentTimeMillis();
		try {
			int finalage=calculateAge.getAge(map,sessionId);

			if(finalage<=17)
			{
				return "Age is less than 18 years.";
			}
			else{
			String age=String.valueOf(finalage);
			logger.info("SMOKER API : AGE IS  -"+age );
			int age1=Integer.parseInt(age);
			int policyTerm=85-age1;
			if(policyTerm>50)
			{
				policyTerm=50;
			}
			map.get(sessionId).put("policyTerm", String.valueOf(policyTerm));
			logger.info("Policy term ------"+policyTerm);
			
			String gender=map.get(sessionId).get("gender");
			String smoker=map.get(sessionId).get("smoke");
			String extURL = bean.getProductpremium();
			StringBuilder requestdata = new StringBuilder();
			requestdata.append("	{	");
			requestdata.append("	  \"request\": {	");
			requestdata.append("	    \"header\": {	");
			requestdata.append("	      \"soaCorrelationId\": \""+soaCorrelationId+"\",	");
			requestdata.append("	      \"soaAppId\": \"NEO\"	");
			requestdata.append("	    },	");
			requestdata.append("	    \"payload\": {	");
			requestdata.append("	      \"reqPlan\": [	");
			requestdata.append("	        {	");
			requestdata.append("	          \"planId\": \"TCOTP2\",	");
			requestdata.append("	          \"variantId\": \"SA\",	");
			requestdata.append("	          \"gender\": \""+gender+"\",	");
			requestdata.append("	          \"age\": \""+age+"\",	");
			requestdata.append("	          \"empDiscount\": \"N\",	");
			requestdata.append("	          \"planSumAssured\": \"10000000\",	");
			requestdata.append("	          \"policyTerm\": \""+policyTerm+"\",	");
			requestdata.append("	          \"policyPayTerm\": \""+policyTerm+"\",	");
			requestdata.append("	          \"smoke\": \""+smoker+"\",	");
			requestdata.append("	          \"mode\": \"Monthly\",	");
			requestdata.append("	          \"reqRider\": [	");
			requestdata.append("	          	");
			requestdata.append("	          ]	");
			requestdata.append("	        }	");
			requestdata.append("	      ]	");
			requestdata.append("	    }	");
			requestdata.append("	  }	");
			requestdata.append("	}	");
			httpCaller.callHttp(extURL, requestdata, result);
		}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured While Calling API's " + e);
		}
		return result.toString();

	}

}
