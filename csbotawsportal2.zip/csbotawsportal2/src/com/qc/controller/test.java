package com.qc.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

public class test 
{
	public Void te()
	{
		return null;
	}
	public static void main(String...ar)
	{
		String textValue="punch request of AGR0180";
		
		String[] splitIntent = textValue.split(" ");
		String finalIntent = splitIntent[3];
		System.out.println(finalIntent);
	}
}
