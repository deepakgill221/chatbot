package com.qc.Interceptors;

public interface LifeStage 
{
	public String getLifeStage(String LifeStage);
	

}
