package com.qc.Interceptors;

import java.util.Map;

public interface PolicyNumberValidation 
{
	public String getPolicyNumberValidation(Map<String, Map> responsecache_onsessionId);

}
