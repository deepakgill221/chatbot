package com.qc.Interceptors;

import java.util.Map;

public interface InputPolicyPack {

	public String getInputPolicyPock(String sessionId, Map<String, Map> responsecache_onsessionId);

}
