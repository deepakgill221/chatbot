package com.qc.Interceptors;

public interface LocateusPinCode 
{
	public String getLocateUsPinCode(String pinCode);

}
