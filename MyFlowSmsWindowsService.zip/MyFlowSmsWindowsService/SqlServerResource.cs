﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFlowSmsWindowsService
{
    class SqlServerResource
    {
        //private String ORACLE_MIN_SEQ_SQL = "SELECT MIN(SEQ_NUM) AS MIN_SEQ_NUM FROM MYFLOWMQXML WHERE SUCCESS_FLAG_YN in ('N','E') AND SEQ_NUM > ?";

        //private String SQLSERVER_MIN_SEQ_SQL = "SELECT MIN(SequenceNo) AS MIN_SEQ_NUM FROM MYFLOWMQXML WHERE SUCCESS_FLAG_YN in ('N','E') AND SequenceNo > ?";

        private String SQL_UPDATE_NULL_XML_SQL_EMAIL = "update myflowmqxml set SUCCESS_FLAG_YN='E',ERROR_DESC='E-Mail Not Sent',TRIGGER_DATE=getdate() where MESSAGE_TYPE='MYFLOWEMAIL' and XML_CONTENT is NULL";
        #region changed by Ripon on 29-4-2017
        //private String SQL_UPDATE_NULL_XML_SQL_SMS = "update myflowmqxml set SUCCESS_FLAG_YN='E',ERROR_DESC='SMS Not Sent',TRIGGER_DATE=getdate() where MESSAGE_TYPE='MYFLOWSMS' and XML_CONTENT is NULL";

        private String SQL_UPDATE_NULL_XML_SQL_SMS = "update myflowmqxml set SUCCESS_FLAG_YN='E',ERROR_DESC='SMS Not Sent',TRIGGER_DATE=getdate() where MESSAGE_TYPE='MYFLOWSMS' and (ERROR_DESC !='ACR SMS triggered prior to TAT breach, hence TAT breach SMS not triggered' OR ERROR_DESC IS NULL) and XML_CONTENT is NULL";
        #endregion
        private String ORACLE_DELETE_PROCESSED_XML_SQL = "DELETE FROM MYFLOWMQXML WHERE SUCCESS_FLAG_YN = 'Y'";

        private String SQLSERVER_DELETE_PROCESSED_XML_SQL = "DELETE FROM MYFLOWMQXML WHERE SUCCESS_FLAG_YN in ('Y','E') and MESSAGE_TYPE='MYFLOWSMS'";

        private String ORACLE_MARK_PROCESSED_SQL = "UPDATE MYFLOWMQXML SET SUCCESS_FLAG_YN = 'Y', ERROR_DESC = '{0}' WHERE SEQ_NUM = {1}";

        // commented by Rishabh on 8jul14 for updating email/mob no 
        //private String SQLSERVER_MARK_PROCESSED_SQL = "UPDATE MYFLOWMQXML SET SUCCESS_FLAG_YN = 'Y', ERROR_DESC = ? WHERE SequenceNo = ?";

        private String SQLSERVER_MARK_PROCESSED_SQL = "UPDATE MYFLOWMQXML SET SUCCESS_FLAG_YN = 'Y', ERROR_DESC = '{0}',EMAIL_ID='{1}', " +
                        " TRIGGER_DATE=GETDATE(),MOBILE_NUMBER='{2}' WHERE SequenceNo = {3}";


        private String ORACLE_MARK_ERROR_SQL = "UPDATE MYFLOWMQXML SET SUCCESS_FLAG_YN = 'E', ERROR_DESC = '{0}' WHERE SEQ_NUM = {1}";


        // commented by Rishabh on 8jul14 for updating email/mob no 
        private String SQLSERVER_MARK_ERROR_SQL = "UPDATE MYFLOWMQXML SET SUCCESS_FLAG_YN = 'E', ERROR_DESC = '{0}',EMAIL_ID='{1}', " +
                        " TRIGGER_DATE=GETDATE(),MOBILE_NUMBER='{2}' WHERE SequenceNo = {3}";


        private String ORACLE_CALL_PROCEDURE_SQL = "{CALL PR_MYFLOWSMS()}";

        private String SQLSERVER_CALL_PROCEDURE_SQL_SMS = "PR_MYFLOWSMS";

        private String SQLSERVER_CALL_PROCEDURE_SQL_EMAIL = "PR_MYFLOWEMAIL";

        //private String ORACLE_CALL_PROCEDURE_SQL_ABP = "{CALL PR_MYFLOABPSMS(?)}";

        //private String SQLSERVER_CALL_PROCEDURE_SQL_ABP = "{CALL PR_MYFLOWABPSMS(?)}";

        //private String ORACLE_CALL_PROCEDURE_SQL_ACCEPT = "{CALL PR_MYFLOWACCEPTSMS(?)}";

        //private String SQLSERVER_CALL_PROCEDURE_SQL_ACCEPT = "{CALL PR_MYFLOWACCEPTSMS(?)}";

        //private String ORACLE_CALL_PROCEDURE_SQL_DECLINE = "{CALL PR_MYFLOWDECLINESMS(?)}";

        //private String SQLSERVER_CALL_PROCEDURE_SQL_DECLINE = "{CALL PR_MYFLOWDECLINESMS(?)}";

        /**
         * takes key and returns query
         * 
         * @return SQL string
         * @param a_strkeyString
         *            key to be used to retrieve the SQL String
         */
        public String getORACLESQLString(String a_strkeyString)
        {
            if (a_strkeyString.Equals("ORACLE_CLIENT_DETAILS"))
            {
                return getORACLE_CLIENT_DETAILS();
            }


            if (a_strkeyString.Equals("ORACLE_AXIS_DETAILS"))
            {
                return getORACLE_AXIS_DETAILS();
            }

            if (a_strkeyString.Equals("ORACLE_XML_EXTRACT_SQL"))
            {
                return getORACLE_XML_EXTRACT_SQL();
            }
            if (a_strkeyString.Equals("ORACLE_DELETE_PROCESSED_XML_SQL"))
            {
                return ORACLE_DELETE_PROCESSED_XML_SQL;
            }
            //if (a_strkeyString.Equals("ORACLE_MIN_SEQ_SQL"))
            //{
            //    return ORACLE_MIN_SEQ_SQL;
            //}
            if (a_strkeyString.Equals("ORACLE_MARK_PROCESSED_XML_SQL"))
            {
                return getORACLE_MARK_PROCESSED_XML_SQL();
            }
            if (a_strkeyString.Equals("ORACLE_MARK_PROCESSED_SQL"))
            {
                return SQLSERVER_MARK_PROCESSED_SQL;
            }
            if (a_strkeyString.Equals("ORACLE_MARK_ERROR_SQL"))
            {
                return SQLSERVER_MARK_ERROR_SQL;
            }
            //if (a_strkeyString.Equals("ORACLE_CALL_PROCEDURE_SQL_ACCEPT"))
            //{
            //    return ORACLE_CALL_PROCEDURE_SQL_ACCEPT;
            //}
            //if (a_strkeyString.Equals("ORACLE_CALL_PROCEDURE_SQL_DECLINE"))
            //{
            //    return ORACLE_CALL_PROCEDURE_SQL_DECLINE;
            //}
            //if (a_strkeyString.Equals("ORACLE_CALL_PROCEDURE_SQL_ABP"))
            //{
            //    return ORACLE_CALL_PROCEDURE_SQL_ABP;
            //}
            if (a_strkeyString.Equals("ORACLE_CALL_PROCEDURE_SQL"))
            {
                return ORACLE_CALL_PROCEDURE_SQL;
            }


            return null;
        }


        private String getORACLE_AXIS_DETAILS()
        {
            String ORACLE_AXIS_DETAILS = " SELECT count(pol_id) as axiscount FROM tpol WHERE co_id = 'CP'  AND pol_id=rpad({0},10,' ')  AND serv_br_id LIKE 'X%' ";
            return ORACLE_AXIS_DETAILS;

        }

        private String getORACLE_CLIENT_DETAILS()
        {

            String ORACLE_CLIENT_DETAILS = @"SELECT B.CLI_ID,TCLNM.CLI_INDV_TITL_TXT, TCLNM.ENTR_GIV_NM, TCLNM.ENTR_SUR_NM,MAIL_ID,CLI_HNI_IND FROM 
TCLNM left join 
(SELECT CLI_ID,pol_id as pol_id FROM TPOLC WHERE CO_ID='CP' AND TRIM(POL_ID)={0} AND POL_CLI_REL_TYP_CD='{1}') B 
on B.CLI_ID=TCLNM.CLI_ID left join 
(SELECT CLI_CNTCT_ID_TXT AS MAIL_ID,CLI_ID FROM TCLIC WHERE CO_ID='CP' AND CLI_CNTCT_ID_CD='E') C 
on B.CLI_ID= C.CLI_ID left join 
(SELECT  CLI_HNI_IND,CLI_ID FROM TCLI WHERE CO_ID='CP') D
on B.CLI_ID = D.CLI_ID
WHERE B.POL_ID= {0}";

            return ORACLE_CLIENT_DETAILS;
        }

        //private String getORACLE_XML_EXTRACT_SQL()
        //{
        //    String ORACLE_XML_EXTRACT_SQL = "SELECT SEQ_NUM, SOURCE_SYSTEM, MESSAGE_TYPE, XML_CONTENT,CREATED_DATE,SUCCESS_FLAG_YN FROM TPORTALXML WHERE SEQ_NUM  BETWEEN  ";
        //    // + BatchUtil.getMinSeqNum()
        //    //+ " AND "
        //    // + BatchUtil.getMaxSeqNum()
        //    // + " ORDER BY SEQ_NUM";
        //    return ORACLE_XML_EXTRACT_SQL;
        //}

        private String getORACLE_XML_EXTRACT_SQL()
        {
            String ORACLE_XML_EXTRACT_SQL = "SELECT SEQ_NUM, SOURCE_SYSTEM, MESSAGE_TYPE, XML_CONTENT,CREATED_DATE,SUCCESS_FLAG_YN FROM TPORTALXML WHERE SEQ_NUM  BETWEEN  ";
            // + BatchUtil.getMinSeqNum()
            //+ " AND "
            // + BatchUtil.getMaxSeqNum()
            // + " ORDER BY SEQ_NUM";
            return ORACLE_XML_EXTRACT_SQL;
        }

        private String getORACLE_MARK_PROCESSED_XML_SQL()
        {
            String ORACLE_MARK_PROCESSED_XML_SQL = "UPDATE TPORTALXML SET SUCCESS_FLAG_YN = 'Y' WHERE SEQ_NUM BETWEEN ";
            // + BatchUtil.getMinSeqNum() + " AND " + BatchUtil.getMaxSeqNum();
            return ORACLE_MARK_PROCESSED_XML_SQL;
        }

        /**
         * takes key and returns query
         * 
         * @return SQL string
         * @param a_strkeyString
         *            key to be used to retrieve the SQL String
         */
        public String getSQLSERVERSQLString(String a_strkeyString)
        {
            if (a_strkeyString.Equals("SQLSERVER_XML_EXTRACT_SQL"))
            {
                return getSQLSERVER_XML_EXTRACT_SQL();
            }
            if (a_strkeyString.Equals("SQLSERVER_DELETE_PROCESSED_XML_SQL"))
            {
                return SQLSERVER_DELETE_PROCESSED_XML_SQL;
            }

            if (a_strkeyString.Equals("SQLSERVER_MARK_PROCESSED_XML_SQL"))
            {
                return getSQLSERVER_MARK_PROCESSED_XML_SQL();
            }
            if (a_strkeyString.Equals("SQLSERVER_MARK_PROCESSED_SQL"))
            {
                return SQLSERVER_MARK_PROCESSED_SQL;
            }
            if (a_strkeyString.Equals("SQLSERVER_MARK_ERROR_SQL"))
            {
                return SQLSERVER_MARK_ERROR_SQL;
            }

            if (a_strkeyString.Equals("SQLSERVER_CALL_PROCEDURE_SQL_SMS"))
            {
                return SQLSERVER_CALL_PROCEDURE_SQL_SMS;
            }

            if (a_strkeyString.Equals("SQLSERVER_CALL_PROCEDURE_SQL_EMAIL"))
            {
                return SQLSERVER_CALL_PROCEDURE_SQL_EMAIL;
            }

            if (a_strkeyString.Equals("SQL_UPDATE_NULL_XML_SQL_EMAIL"))
            {
                return SQL_UPDATE_NULL_XML_SQL_EMAIL;
            }

            if (a_strkeyString.Equals("SQL_UPDATE_NULL_XML_SQL_SMS"))
            {
                return SQL_UPDATE_NULL_XML_SQL_SMS;
            }
            return null;
        }

        #region Added By Ripon On 27-3-2017
        public string getExecount(string ProcessInstanceID, string POL_NUM, string SMS_TYPE)
        {
            string SQL_Get_ExeCount = "Select ExeCount from myflowmqxml where ProcessInstanceID = " + ProcessInstanceID + " and POL_NUM=" + POL_NUM + " and SMS_TYPE=" + SMS_TYPE + "";
            return SQL_Get_ExeCount;
        }
        public string UPDATE_Execount(string ProcessInstanceID, string POL_NUM, string SMS_TYPE, int execount)
        {
            string SQL_UPDATE_ExeCount = "Update myflowmqxml set ExeCount =  " + Convert.ToInt32(execount + 1) + " where ProcessInstanceID = " + ProcessInstanceID + " and POL_NUM=" + POL_NUM + " and SMS_TYPE=" + SMS_TYPE + "";
            return SQL_UPDATE_ExeCount;
        }
        #endregion

        private String getSQLSERVER_MARK_PROCESSED_XML_SQL()
        {
            String SQLSERVER_MARK_PROCESSED_XML_SQL = "UPDATE MYFLOWMQXML SET SUCCESS_FLAG_YN = 'Y' WHERE SequenceNO BETWEEN ";
            // + BatchUtil.getMinSeqNum() + " AND " + BatchUtil.getMaxSeqNum();
            return SQLSERVER_MARK_PROCESSED_XML_SQL;
        }

        private String getSQLSERVER_XML_EXTRACT_SQL()
        {
            //String SQLSERVER_XML_EXTRACT_SQL = "SELECT SequenceNO, POL_NUM, SOURCE_SYSTEM, MESSAGE_TYPE, SMS_TYPE, XML_CONTENT,CREATED_DATE,SUCCESS_FLAG_YN FROM MYFLOWMQXML with (nolock) WHERE SUCCESS_FLAG_YN in ('N','E') AND SequenceNo"

            // commented on 27jun13 by mohit to remove E case as new case introduced from satish's side
            //String SQLSERVER_XML_EXTRACT_SQL = "SELECT SequenceNO, POL_NUM, SOURCE_SYSTEM, MESSAGE_TYPE, SMS_TYPE, XML_CONTENT,CREATED_DATE,SUCCESS_FLAG_YN,EMAIL_TYPE FROM MYFLOWMQXML with (nolock) WHERE SUCCESS_FLAG_YN in ('N','E') AND SequenceNo"

            #region changed by Ripon on 29-4-2017
            //String SQLSERVER_XML_EXTRACT_SQL = "SELECT SequenceNO, ProcessInstanceID,POL_NUM, SOURCE_SYSTEM, MESSAGE_TYPE, SMS_TYPE, XML_CONTENT,CREATED_DATE,SUCCESS_FLAG_YN,EMAIL_TYPE FROM MYFLOWMQXML with (nolock) WHERE SUCCESS_FLAG_YN in ('N') and MESSAGE_TYPE='MYFLOWSMS'"; //AND SequenceNo";
            String SQLSERVER_XML_EXTRACT_SQL = "SELECT SequenceNO, ProcessInstanceID,POL_NUM, SOURCE_SYSTEM, MESSAGE_TYPE, SMS_TYPE, XML_CONTENT,CREATED_DATE,SUCCESS_FLAG_YN,EMAIL_TYPE FROM MYFLOWMQXML with (nolock) WHERE SUCCESS_FLAG_YN in ('N') and MESSAGE_TYPE='MYFLOWSMS' order by CREATED_DATE ASC"; //AND SequenceNo";
            #endregion
            return SQLSERVER_XML_EXTRACT_SQL;


        }

    }


}
