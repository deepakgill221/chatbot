﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using log4net;

namespace MyFlowSmsWindowsService
{
    class ProcessData
    {
        DataTable dt = null;

        SMSDelegator smsDeleg = null;
        TimeSpan start = new TimeSpan(08, 0, 0); //Morning  8  AM
        TimeSpan end = new TimeSpan(21, 0, 0);   //Evening  9  PM

        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public void processxmldata(SqlConnection sqlConnection, SqlServerResource sqlServerResource)
        {
            logger.Info("Entering in ProcessXMLData..");
            if (sqlConnection.State == ConnectionState.Closed) { sqlConnection.Open(); }

            logger.Info("SQL Server Connection opened");

            using (SqlCommand cmd = new SqlCommand(string.Format(sqlServerResource.getSQLSERVERSQLString("SQLSERVER_XML_EXTRACT_SQL")), sqlConnection))
            {
                cmd.CommandTimeout = 9000;
                dt = new DataTable();
                logger.Debug("Loading Data in DataTable");
                dt.Load(cmd.ExecuteReader());
                logger.Debug("Successfully Loaded Data in DataTable");
            }

            // Rows Extracted in DataTable from SQL SERVER and Ready to Process

            logger.Debug("Start Extracting Row By Row");
            foreach (DataRow sqldr in dt.Rows)
            {
                // Extracting Row By Row
                try
                {
                    // Identifying the Type ie, SMS OR EMAIL 

                    #region SMSRegion

                    // Identify SMS

                    if (sqldr["MESSAGE_TYPE"].ToString() != "" && sqldr["MESSAGE_TYPE"].ToString().ToUpper() == "MYFLOWSMS")
                    {
                        //continue;
                        if (sqldr["SMS_TYPE"].ToString() != "")
                        {

                            TimeSpan now = DateTime.Now.TimeOfDay;

                            if ((now > start) && (now < end))
                            {
                                //match found
                                logger.Debug("-------------------------------------------------------------");
                                logger.Debug("valid time to send SMS");
                            }

                            else
                            {
                                Console.WriteLine("No SMS Sent for this time");
                                logger.Debug("No SMS Sent for this time for processinstanceID :" + sqldr["ProcessInstanceID"].ToString());
                                continue;
                            }


                            String strSMSType = sqldr["SMS_TYPE"].ToString();
                            String strMsgType = sqldr["MESSAGE_TYPE"].ToString();

                            logger.Debug("strMsgType we get is::::->" + strMsgType);
                            logger.Debug("strSMSType we get is::::->" + strSMSType);

                            logger.Debug("extracting a row");



                            bool agtFlag = false;
                            logger.Debug("creating a instance of SMS delegator");
                            smsDeleg = new SMSDelegator();
                            logger.Debug("extracting a row");

                            DataExtract dvo = smsDeleg.extractRow(sqldr);

                            logger.Debug("Row Extracted");

                            if (!strSMSType.Equals("ABP"))
                            {
                                try
                                {
                                    if (strSMSType.ToUpper().Equals("ACRA") || strSMSType.ToUpper().Equals("LOGINA"))
                                    {

                                        agtFlag = true;
                                    }
                                    else
                                    {
                                        agtFlag = false;
                                    }
                                }


                                catch (Exception ex)
                                {
                                    smsDeleg.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), "Error While Fetching Phone Number", "MYFLOWSMS", "");
                                    logger.Error("Error While Fetching Phone Number for " + dvo.getXmlSeqNum() + " " + ex.StackTrace);
                                    continue;
                                }
                            }

                            //logger.debug("extracting message in mq");
                            //beforeUpdate = System.currentTimeMillis();
                            //logger.info("Time taken in processing " + dvo.getXmlSeqNum() + " = " + (beforeUpdate - afterUpdate));

                            StringBuilder mergedMobNum = new StringBuilder();

                            SMSResponse smsDVO = null;
                            String _strErrorDesc = null;

                            if (sqldr["XML_CONTENT"].ToString() != null && !sqldr["XML_CONTENT"].ToString().Trim().Equals("") && !sqldr["XML_CONTENT"].ToString().Trim().Equals("null"))
                            {
                                if (agtFlag)
                                {
                                    logger.Info("checking sms status for agent");
                                    smsDVO = smsDeleg.SendCustomerSMS(dvo, sqlServerResource, "A");
                                    _strErrorDesc = smsDVO.getErrorDesc();


                                    if (smsDVO.isSmsSentStatus())
                                    {
                                        logger.Info("SMS sent to agent for seq no:" + dvo.getXmlSeqNum());
                                        smsDeleg.MarkRowExtracted(Convert.ToInt64(sqldr["SequenceNo"]), "SMS Sent", "MYFLOWSMS", smsDVO.getAgtMobileNum());
                                    }
                                    else
                                    {

                                        logger.Info("Error in sending sms to agent for seq no:" + dvo.getXmlSeqNum());
                                        logger.Info("Error Description For Mobile: " + _strErrorDesc);

                                        #region Changed By Ripon on 27-3-2017
                                        if (_strErrorDesc.ToString() == "Oracle Did'nt Respond")
                                        {
                                            int Execount = 0;
                                            if (sqlConnection.State == ConnectionState.Closed) { sqlConnection.Open(); }
                                            using (SqlCommand cmd1 = new SqlCommand(sqlServerResource.getExecount("'" + sqldr["ProcessInstanceID"].ToString() + "'", "'" + sqldr["POL_NUM"].ToString() + "'", "'" + sqldr["SMS_TYPE"].ToString() + "'"), sqlConnection))
                                            {
                                                logger.Info(cmd1.CommandText);
                                                cmd1.CommandTimeout = 9000;
                                                Execount = Convert.ToInt32(cmd1.ExecuteScalar());
                                                logger.Info(Execount);
                                            }

                                            if (Execount < 3)
                                            {
                                                logger.Info("Oracle Did'nt Respond will try again " + Execount);
                                                if (sqlConnection.State == ConnectionState.Closed) { sqlConnection.Open(); }
                                                using (SqlCommand cmd2 = new SqlCommand(sqlServerResource.UPDATE_Execount("'" + sqldr["ProcessInstanceID"].ToString() + "'", "'" + sqldr["POL_NUM"].ToString() + "'", "'" + sqldr["SMS_TYPE"].ToString() + "'", Execount), sqlConnection))
                                                {
                                                    logger.Info(cmd2.CommandText);
                                                    cmd2.ExecuteNonQuery();
                                                }
                                            }
                                        }
                                        #endregion

                                        else
                                        {
                                            smsDeleg.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), _strErrorDesc, "MYFLOWSMS", smsDVO.getAgtMobileNum());
                                        }
                                    }
                                }
                                else
                                {
                                    bool ownerSMSSentFlag = false;
                                    bool assineSMSSentFlag = false;


                                    logger.Info("checking sms status for customer owner");
                                    smsDVO = smsDeleg.SendCustomerSMS(dvo, sqlServerResource, "C");  // for owner
                                    ownerSMSSentFlag = smsDVO.isSmsSentStatus();
                                    mergedMobNum.Append(smsDVO.getCustOwnerMobileNum()).Append(",");
                                    smsDVO = null;


                                    logger.Info("checking sms status for customer assignee");
                                    smsDVO = smsDeleg.SendCustomerSMS(dvo, sqlServerResource, "I");  // for assignee
                                    assineSMSSentFlag = smsDVO.isSmsSentStatus();
                                    mergedMobNum.Append(smsDVO.getCustAssgneMobileNum());
                                    _strErrorDesc = smsDVO.getErrorDesc();

                                    if (ownerSMSSentFlag || assineSMSSentFlag)
                                    {
                                        logger.Info("SMS sent to customer for seq no:" + dvo.getXmlSeqNum());
                                        logger.Debug("updating row as extracted");

                                        smsDeleg.MarkRowExtracted(Convert.ToInt64(sqldr["SequenceNo"]), "SMS Sent", "MYFLOWSMS", mergedMobNum.ToString());
                                    }
                                    else
                                    {
                                        logger.Info("Error in sending SMS to customer for seq no:" + dvo.getXmlSeqNum());
                                        logger.Info("Error Description For Mobile: " + _strErrorDesc);
                                        logger.Debug("updating row as extracted");

                                        #region Changed By Ripon on 27-3-2017
                                        if (_strErrorDesc.ToString() == "Oracle Did'nt Respond")
                                        {
                                            int Execount = 0;
                                            if (sqlConnection.State == ConnectionState.Closed) { sqlConnection.Open(); }
                                            using (SqlCommand cmd1 = new SqlCommand(sqlServerResource.getExecount("'" + sqldr["ProcessInstanceID"].ToString() + "'", "'" + sqldr["POL_NUM"].ToString() + "'", "'" + sqldr["SMS_TYPE"].ToString() + "'"), sqlConnection))
                                            {
                                                logger.Info(cmd1.CommandText);
                                                cmd1.CommandTimeout = 9000;
                                                Execount = Convert.ToInt32(cmd1.ExecuteScalar());
                                                logger.Info(Execount);
                                            }

                                            if (Execount < 3)
                                            {
                                                logger.Info("Oracle Did'nt Respond will try again " + Execount);
                                                if (sqlConnection.State == ConnectionState.Closed) { sqlConnection.Open(); }
                                                using (SqlCommand cmd2 = new SqlCommand(sqlServerResource.UPDATE_Execount("'" + sqldr["ProcessInstanceID"].ToString() + "'", "'" + sqldr["POL_NUM"].ToString() + "'", "'" + sqldr["SMS_TYPE"].ToString() + "'", Execount), sqlConnection))
                                                {
                                                    logger.Info(cmd2.CommandText);
                                                    cmd2.ExecuteNonQuery();
                                                }
                                            }
                                        }
                                        #endregion

                                        else
                                        {
                                            smsDeleg.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), _strErrorDesc, "MYFLOWSMS", mergedMobNum.ToString());
                                        }
                                    }
                                }

                            }
                            else
                            {
                                logger.Info("sms can not be sent as xml is null for seq no:" + dvo.getXmlSeqNum());
                                logger.Debug("updating row as extracted");

                                smsDeleg.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), "SMS Not Sent", "MYFLOWSMS", "");
                            }

                            //afterUpdate = System.DateTime.Now.Millisecond;
                            //logger.Info("Time taken by MQ client for "+ dvo.getXmlSeqNum() + " = "+ (afterUpdate - beforeUpdate));
                            //BatchUtil.setDataCount(strMsgType);


                        }

                    }

                    #endregion

                    #region No Use
                    //#region EmailRegion
                    //// Identify Email

                    //else if (sqldr["MESSAGE_TYPE"].ToString() != "" && sqldr["MESSAGE_TYPE"].ToString().ToUpper() == "MYFLOWEMAIL")
                    //{
                    //    String strMsgType = sqldr["MESSAGE_TYPE"].ToString();
                    //    if (sqldr["EMAIL_TYPE"].ToString() != "")
                    //    {

                    //        String _strEmailType = sqldr["EMAIL_TYPE"].ToString();

                    //        logger.Info("EMAIL_TYPE ::: " + _strEmailType);
                    //        logger.Debug("extracting a row");
                    //        logger.Debug("rows extracted in dvo");


                    //        bool agtflag = false;
                    //        _emaildel = new EmailDelegator();

                    //        try
                    //        {
                    //            if (sqldr["POL_NUM"].ToString() != null)
                    //            {
                    //                if (sqldr["EMAIL_TYPE"].ToString().ToUpper() == "ACRA")
                    //                {

                    //                    agtflag = true;
                    //                }

                    //            }

                    //            else
                    //            {
                    //                _emaildel.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), "Policy number not found", "MYFLOWEMAIL", "");
                    //                logger.Error("Policy number not found");
                    //                continue;
                    //            }

                    //        }

                    //        catch (Exception ex)
                    //        {
                    //            _emaildel.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), "Error While Fetching client details", "MYFLOWEMAIL", "");
                    //            logger.Error("Error While Fetching client details for " + Convert.ToInt64(sqldr["SequenceNo"]), ex);
                    //            continue;
                    //        }

                    //        EmailResponse emailResponse = null;
                    //        StringBuilder mergedEmail = new StringBuilder();
                    //        String errorDescEmail = null;


                    //        if (sqldr["XML_CONTENT"].ToString() != null && !sqldr["XML_CONTENT"].ToString().Equals(""))
                    //        {
                    //            // For Agent
                    //            if (agtflag)
                    //            {
                    //                logger.Info("checking email status for agent ");

                    //                emailResponse = _emaildel.SendAgentMail(sqldr, sqlServerResource); // for Agent 
                    //                //mstDVO = deleg.vailidateAgentEmailProcess(dvo.getRecordPolicyNumber(), dvo);

                    //                if (emailResponse.isSuccessFlag())
                    //                {
                    //                    logger.Info("Mail sent to agent for seq no:" + Convert.ToInt64(sqldr["SequenceNo"]));
                    //                    _emaildel.MarkRowExtracted(Convert.ToInt64(sqldr["SequenceNo"]), "E-Mail Sent", "MYFLOWEMAIL", emailResponse.getAgtEmaiId());
                    //                }
                    //                else
                    //                {
                    //                    logger.Info("Error in sending mail to agent for seq no:" + Convert.ToInt64(sqldr["SequenceNo"]));
                    //                    logger.Info("Error Description for Email: " + errorDescEmail);
                    //                    _emaildel.MarkRowExtracted(Convert.ToInt64(sqldr["SequenceNo"]), errorDescEmail, "MYFLOWEMAIL", emailResponse.getAgtEmaiId());
                    //                }


                    //            }

                    //            // For Customer and Assigne
                    //            else
                    //            {
                    //                bool ownerSentFlag = false;
                    //                bool assSentFlag = false;
                    //                logger.Info("checking email status for customer owner");
                    //                emailResponse = _emaildel.SendCustomerMail(sqldr, sqlServerResource, "O"); // for assignee 
                    //                ownerSentFlag = emailResponse.isSuccessFlag();
                    //                logger.Info("customer owner isSuccessFlag value: " + ownerSentFlag);
                    //                mergedEmail.Append(emailResponse.getCustOwnerEmaiId()).Append(",");
                    //                errorDescEmail = emailResponse.getErrorDescEmail();


                    //                emailResponse = null;


                    //                logger.Info("checking email status for customer assignee");
                    //                emailResponse = _emaildel.SendCustomerMail(sqldr, sqlServerResource, "A"); // for assignee                                     
                    //                assSentFlag = emailResponse.isSuccessFlag();
                    //                logger.Info("customer assignee isSuccessFlag value: " + assSentFlag);
                    //                mergedEmail.Append(emailResponse.getCustAssgneEmaiId());



                    //                if (ownerSentFlag || assSentFlag)
                    //                {
                    //                    logger.Info("Mail sent to customer for seq no:" + Convert.ToInt64(sqldr["SequenceNo"]));
                    //                    _emaildel.MarkRowExtracted(Convert.ToInt64(sqldr["SequenceNo"]), "E-Mail Sent", "MYFLOWEMAIL", mergedEmail.ToString());
                    //                }
                    //                else
                    //                {
                    //                    logger.Info("Error in sending mail to customer for seq no:" + Convert.ToInt64(sqldr["SequenceNo"]));
                    //                    logger.Info("Error Description for Email: " + errorDescEmail);
                    //                    _emaildel.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), errorDescEmail, "MYFLOWEMAIL", mergedEmail.ToString());
                    //                }

                    //            }
                    //        }
                    //        else
                    //        {
                    //            logger.Info("mail can not be sent as xml is null for seq no:" + Convert.ToInt64(sqldr["SequenceNo"]));
                    //            _emaildel.markRowError(Convert.ToInt64(sqldr["SequenceNo"]), "E-Mail Not Sent", "MYFLOWEMAIL", "");
                    //        }

                    //        //afterUpdate = System.currentTimeMillis();
                    //        //logger.info("Inside Email block Time taken by MQ client for " + dvo.getXmlSeqNum() + " = " + (afterUpdate - beforeUpdate));
                    //        //logger.debug("updating row as extracted");
                    //    }

                    //}

                    //#endregion
                    #endregion

                    else
                    {
                        // No Valid Message Type
                        logger.Error("No Valid Message Type" + Convert.ToInt64(sqldr["SequenceNo"]) + " and Message Type is :" + sqldr["MESSAGE_TYPE"].ToString());
                    }

                }

                catch (Exception ex)
                {
                    logger.Error("Message -> " + ex.Message);
                    logger.Error("StackTrace -> " + ex.StackTrace);

                }
            }
        }

    }

}