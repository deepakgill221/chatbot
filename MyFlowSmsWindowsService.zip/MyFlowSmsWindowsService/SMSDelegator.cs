﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

using System.Text.RegularExpressions;
using System.Configuration;
using log4net;
using System.Net;
using Newtonsoft.Json.Linq;

namespace MyFlowSmsWindowsService
{
    public class MliSmsServiceResponse
    {
        public string Status { get; set; }
        public string code { get; set; }
        public string description { get; set; }
        public string transactionId { get; set; }
    }
    public class MliSmsServiceRequest
    {
        public string msgTo { get; set; }
        public string msgText { get; set; }
    }
    class SMSDelegator
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        string errordesc = "";
        DataExtract _dataExtract = null;
        SMSResponse _smsResponse = null;

        ConnectToOracle _conntooracle = null;

        public MliSmsServiceResponse SendSMS(DataExtract _dataExtract)
        {
            MliSmsServiceResponse _MliSmsServiceResponse = new MliSmsServiceResponse();
            MliSmsServiceRequest _MliSmsServiceRequest = new MliSmsServiceRequest();
            try
            {
                _MliSmsServiceRequest.msgTo = _dataExtract.getPhoneNum();

                String _strSMSText = "null";
                String _strHolderName = "";

                String _strXmlContent = _dataExtract.getXmlContent();

                if (_strXmlContent != null && _strXmlContent != "")
                {
                    if (_dataExtract.getCharType().Equals("A"))
                    {
                        string _strSMSText1 = _strXmlContent.Substring(_strXmlContent.IndexOf("<SMSTEXT>") + 9, _strXmlContent.IndexOf("</SMSTEXT>") - _strXmlContent.IndexOf("<SMSTEXT>") - 9);
                        _strSMSText = _strSMSText1.Replace("#", " ");
                        _strSMSText = _strSMSText1.Replace("<policyholder>", _dataExtract.getHolderName());
                        //_strHolderName = _strXmlContent.Substring(_strXmlContent.IndexOf("<polholder>") + 11, _strXmlContent.IndexOf("</polholder>") - _strXmlContent.IndexOf("<polholder>") - 11);

                        logger.Debug("Policy Number :---" + _dataExtract.getRecordPolicyNumber());
                        logger.Debug("SMS text:---" + _strSMSText);
                        logger.Debug("Holder Name inserted in sms text:---" + _strHolderName);
                    }
                    else
                    {
                        string _strSMSText1 = _strXmlContent.Substring(_strXmlContent.IndexOf("<SMSTEXT>") + 9, _strXmlContent.IndexOf("</SMSTEXT>") - _strXmlContent.IndexOf("<SMSTEXT>") - 9);
                        _strSMSText = _strSMSText1.Replace("#", " ");
                        logger.Debug("Policy Number :---" + _dataExtract.getRecordPolicyNumber());
                        logger.Debug("SMS text:---" + _strSMSText);

                    }
                    _MliSmsServiceRequest.msgText = _strSMSText;
                }

                #region Changed by Ripon
                // SMS                
                string result = "";
                using (var client = new WebClient())
                {
                    #region Post Method to call Soa api
                    Guid correlationId = Guid.NewGuid();
                    //string mobno = "8130784727";
                    string json = "{\"MliSmsService\": {\"requestHeader\": {\"generalConsumerInformation\": {\"messageVersion\": \"1.0\",\"consumerId\": \"MyFlow\",\"correlationId\": \"'" + correlationId + "'\"}},\"requestBody\": {\"appAccId\": \"SRV_MYFLOW\",\"appAccPass\": \"r(7Ca(5X\",\"appId\": \"MAXLIT\",\"msgTo\": \"'" + _MliSmsServiceRequest.msgTo + "'\",\"msgText\": \"'" + _MliSmsServiceRequest.msgText + "'\"}}}";
                    //var Request = JObject.Parse(json);
                    //string CheckmsgText = (string)Request.SelectToken("MliSmsService.requestHeader.generalConsumerInformation.requestBody.msgText");
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    #endregion

                    if (_MliSmsServiceRequest.msgText != null || _MliSmsServiceRequest.msgText != "")
                    {
                        logger.Debug("Sending SMS with WebService");
                        //result = client.UploadString("https://gatewayuat.maxlifeinsurance.com/apimgm/dev/soa/sms/v1/real", "POST", json);
                        //result = client.UploadString("https://gatewayuat.maxlifeinsurance.com/apimgm/sb/soa/sms/v1/real", "POST", json);
                       // result = client.UploadString("https://mligateway.maxlifeinsurance.com/mli/prod/soa/sendsms/rest", "POST", json);
                        string API = ConfigurationManager.AppSettings["SOA_API"].ToString();
                        result = client.UploadString(API, "POST", json);
                        //result = "";
                        #region Get Response

                        var obj = JObject.Parse(result);
                        _MliSmsServiceResponse.Status = (string)obj.SelectToken("MliSmsServiceResponse.responseHeader.generalResponse.status");
                        _MliSmsServiceResponse.code = (string)obj.SelectToken("MliSmsServiceResponse.responseHeader.generalResponse.code");
                        _MliSmsServiceResponse.description = (string)obj.SelectToken("MliSmsServiceResponse.responseHeader.generalResponse.description");
                        _MliSmsServiceResponse.transactionId = (string)obj.SelectToken("MliSmsServiceResponse.responseBody.transactionId");
                        logger.Debug("SMS sent Scuccesfully. Transaction ID is :>" + _MliSmsServiceResponse.transactionId);
                        logger.Debug("SMS sent description :>" + _MliSmsServiceResponse.description);
                        logger.Debug("correlationId : " + correlationId);
                        return _MliSmsServiceResponse;

                        #endregion
                    }

                    else
                    {
                        return _MliSmsServiceResponse;
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                logger.Error("Message -> " + ex.Message);
                logger.Error("StackTrace -> " + ex.StackTrace);
                return _MliSmsServiceResponse;
            }
        }


        public SMSResponse SendCustomerSMS(DataExtract _dataExtract, SqlServerResource sqlServerResource, string custype)
        {
            MliSmsServiceResponse _MliSmsServiceResponse = new MliSmsServiceResponse();
            _conntooracle = new ConnectToOracle();
            _smsResponse = new SMSResponse();
            int mobNum;
            String _strMobnum;

            try
            {
                logger.Debug("Getting Customer Details");
                _dataExtract = getSMSdetails(_dataExtract, custype);
                logger.Debug("Customer details extracted");

                if (custype.Equals("A"))
                    _smsResponse.setAgtMobileNum(_dataExtract.getPhoneNum());
                else if (custype.Equals("C"))
                    _smsResponse.setCustOwnerMobileNum(_dataExtract.getPhoneNum());
                else if (custype.Equals("I"))
                    _smsResponse.setCustAssgneMobileNum(_dataExtract.getPhoneNum());


                if (custype.ToUpper().Equals("A"))
                {
                    if (_dataExtract.getPhoneNum() != null && !_dataExtract.getPhoneNum().Trim().Equals(""))
                    {
                        if (_dataExtract.getHolderName() != null && !_dataExtract.getHolderName().Trim().Equals(""))
                        {
                            _strMobnum = _dataExtract.getPhoneNum();
                            mobNum = _strMobnum.Length;
                            if (mobNum == 10 && Regex.IsMatch(mobNum.ToString(), "\\d+"))
                            {
                                //					extract.insertXML(dvo);
                                logger.Debug("Sending SMS to mobile Number :>" + mobNum);
                                _MliSmsServiceResponse= SendSMS(_dataExtract);
                                if (_MliSmsServiceResponse.description == "The request has been processed successfully.") { _smsResponse.setSmsSentStatus(true); }
                                else { _smsResponse.setSmsSentStatus(false); }
                            }
                            else
                            {
                                logger.Debug("Incomplete Mobile Number" + _dataExtract.getPhoneNum());
                                //System.out.println("Incomplete Mobile Number"+_dataExtract.getPhoneNum());
                                _smsResponse.setSmsSentStatus(false);
                                _smsResponse.setErrorDesc("Incomplete Mobile Number");
                            }
                        }
                        else
                        {
                            logger.Debug("Policy Holder Name not in Ingenium. " + custype);
                            //System.out.println("Policy Holder Name not in Ingenium "+custype);
                            //_smsResponse.setAgtMobileNum("");
                            _smsResponse.setSmsSentStatus(false);
                            _smsResponse.setErrorDesc("Policy Holder Name not in Ingenium.");
                        }
                    }

                    else
                    {
                        if (custype.Equals("A"))
                        {
                            logger.Debug("Mobile number not in My agent " + custype);
                            //System.out.println("Mobile number not in My agent "+custype);
                            _smsResponse.setAgtMobileNum("");
                            _smsResponse.setSmsSentStatus(false);
                            _smsResponse.setErrorDesc("Mobile number not in My agent");
                        }
                    }
                }
                else
                {
                    if (_dataExtract.getPhoneNum() != null && !_dataExtract.getPhoneNum().Trim().Equals(""))
                    {
                        _strMobnum = _dataExtract.getPhoneNum();
                        mobNum = _strMobnum.Length;


                        if (mobNum == 10 && Regex.IsMatch(mobNum.ToString(), "\\d+"))
                        {
                            //				extract.insertXML(_dataExtract);

                            logger.Debug("Sending SMS to mobile Number :>" + mobNum);
                            _MliSmsServiceResponse = SendSMS(_dataExtract);
                            if (_MliSmsServiceResponse.description == "The request has been processed successfully.") { _smsResponse.setSmsSentStatus(true); }
                            else { _smsResponse.setSmsSentStatus(false); }
                        }

                        else
                        {
                            logger.Debug("Incomplete Mobile Number" + _dataExtract.getPhoneNum());
                            //System.out.println("Incomplete Mobile Number"+_dataExtract.getPhoneNum());
                            _smsResponse.setSmsSentStatus(false);
                            _smsResponse.setErrorDesc("Incomplete Mobile Number");

                        }
                    }

                    else
                    {
                        if (custype.Equals("C") || custype.Equals("I"))
                        {
                            logger.Debug("Mobile number not in ingenium " + custype);
                            //System.out.println("Mobile number not in ingenium "+custype);
                            _smsResponse.setAgtMobileNum("");
                            _smsResponse.setSmsSentStatus(false);
                            _smsResponse.setErrorDesc("Mobile number not in ingenium");
                        }
                    }


                }
            }
            //catch(Exception pe)
            //{
            //    logger.error("PortalException in fetching phone number",pe);
            //    _smsResponse.setSmsSentStatus(false);
            //    _smsResponse.setErrorDesc("SMS Not Sent");
            //}
            catch (Exception e)
            {
                logger.Error("exception in validating SMS process for Customer ", e);
                logger.Error("Message -> " + e.Message);
                logger.Error("StackTrace -> " + e.StackTrace);
                _smsResponse.setSmsSentStatus(false);

                #region Changed By Ripon
                if (e.Message == "ORA-12570: Network Session: Unexpected packet read error")
                {
                    _smsResponse.setErrorDesc("Oracle Did'nt Respond");
                }
                else
                {
                    _smsResponse.setErrorDesc("SMS Not Sent");
                }
                #endregion

            }

            return _smsResponse;
        }

        public DataExtract getSMSdetails(DataExtract _dataExtract, string charType)
        {
            String phoneNum = "";
            String _strHolderName = "";
            _dataExtract.setCharType(charType);

            using (OracleConnection oraconn = new OracleConnection(_conntooracle.GetConnectionstring()))
            {
                logger.Debug("opening Oracle DB Connection");
                if (oraconn.State == ConnectionState.Closed) oraconn.Open();
                logger.Debug("Oracle DB Connection successfully opened");

                logger.Debug("Intializing function pr_mflowmob");
                using (OracleCommand oracom = new OracleCommand("pr_mflowmob", oraconn))
                {

                    oracom.Connection = oraconn;
                    //                    cmd.CommandText = "pr_mflowmob";
                    oracom.CommandType = CommandType.StoredProcedure;


                    oracom.Parameters.Add("vc_mobno", OracleDbType.Varchar2, 5000);
                    oracom.Parameters["vc_mobno"].Direction = ParameterDirection.ReturnValue;

                    oracom.Parameters.Add("vc_polid", OracleDbType.Varchar2);
                    oracom.Parameters["vc_polid"].Value = _dataExtract.getRecordPolicyNumber();
                    //oracom.Parameters["vc_polid"].Value = "797086477";

                    oracom.Parameters.Add("vc_type", OracleDbType.Char);
                    //oracom.Parameters["vc_type"].Value = "C";
                    oracom.Parameters["vc_type"].Value = charType;
                    logger.Debug("Started getting mobile number from Ingenium");
                    oracom.ExecuteNonQuery();
                    logger.Debug("Ended getting mobile number from Ingenium");
                    phoneNum = oracom.Parameters["vc_mobno"].Value.ToString();
                    logger.Debug("Mobile Number for customer is :" + phoneNum + " for policy number is :" + _dataExtract.getRecordPolicyNumber());

                }

                if (phoneNum == null || phoneNum.Equals("null") || phoneNum.Equals("")) { phoneNum = ""; logger.Debug("Mobile Number is Blank"); }

                _dataExtract.setPhoneNum(phoneNum.Trim());

                // logger.debug("Ph num fetched "+phoneNum+", for policy "+_dataExtract.getRecordPolicyNumber());
                // System.out.println("Ph num fetched "+phoneNum+", for policy "+_dataExtract.getRecordPolicyNumber());


                if (charType.Equals("A"))
                {
                    logger.Debug("getting agent name from Igneium");
                    if (oraconn.State == ConnectionState.Closed) oraconn.Open();

                    using (OracleCommand oracom = new OracleCommand("PR_MFLOWNAME", oraconn))
                    {
                        //using (OracleDataReader rdr = oracom.ExecuteReader())
                        //{

                        //    _strHolderName = rdr[""].ToString();

                        //}

                        oracom.Connection = oraconn;
                        oracom.CommandType = CommandType.StoredProcedure;

                        oracom.Parameters.Add("vc_name", OracleDbType.Varchar2, 5000);
                        oracom.Parameters["vc_name"].Direction = ParameterDirection.ReturnValue;

                        #region To add a space with polid as the proc expects a extra space with the polid 
                        string vc_polid_Space = _dataExtract.getRecordPolicyNumber();
                        vc_polid_Space = vc_polid_Space + " ";
                        #endregion
                        oracom.Parameters.Add("vc_polid", OracleDbType.Varchar2);
                        //oracom.Parameters["vc_polid"].Value = _dataExtract.getRecordPolicyNumber();
                        oracom.Parameters["vc_polid"].Value = vc_polid_Space.ToString();

                        oracom.Parameters.Add("vc_type", OracleDbType.Char);
                        oracom.Parameters["vc_type"].Value = charType;

                        oracom.ExecuteNonQuery();
                        _strHolderName = oracom.Parameters["vc_name"].Value.ToString();

                        //command.Dispose();
                        //connection.Close();
                        //connection.Dispose();
                    }

                    if (_strHolderName == null || _strHolderName.Equals("null") || _strHolderName.Equals("")) _strHolderName = "";

                    _dataExtract.setHolderName(_strHolderName.Trim());

                    logger.Debug("Holder Name fetched " + _strHolderName + ", for policy " + _dataExtract.getRecordPolicyNumber());
                    //System.out.println("Holder Name fetched "+_strHolderName+", for policy "+_dataExtract.getRecordPolicyNumber());
                }
            }

            return _dataExtract;
        }

        public DataExtract extractRow(DataRow messagedr)
        {

            _dataExtract = new DataExtract();
            _dataExtract.setMessageType(messagedr["MESSAGE_TYPE"].ToString().Trim());
            //  _dataExtract.setRecordCreatedDate("");
            _dataExtract.setRecordPolicyNumber(messagedr["POL_NUM"].ToString().Trim());
            _dataExtract.setSourceSystem(messagedr["SOURCE_SYSTEM"].ToString().Trim());
            _dataExtract.setXmlContent(messagedr["XML_CONTENT"].ToString().Trim());
            _dataExtract.setXmlSeqNum(Convert.ToInt64(messagedr["SequenceNo"]));
            return _dataExtract;

        }

        public int MarkRowExtracted(long seqNum, String errDesc, String myFlowType, String mobOrEmail)
        {
            int flag = 0;
            String strSearchSql = "";
            try
            {
                SqlServerResource sqlServerResource = new SqlServerResource();

                strSearchSql = sqlServerResource.getSQLSERVERSQLString("SQLSERVER_MARK_PROCESSED_SQL");

                if (myFlowType.ToUpper().Equals("MYFLOWEMAIL"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, mobOrEmail, "", seqNum);

                }
                else if (myFlowType.ToUpper().Equals("MYFLOWSMS"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, "", mobOrEmail, seqNum);
                }

                logger.Debug("");
                flag = executeUpdate(strSearchSql);

            }
            catch (Exception ex)
            {
                logger.Error("Message -> " + ex.Message);
                logger.Error("StackTrace -> " + ex.StackTrace);
            }//ex.StackTrace; }
            return flag;
        }

        public int markRowError(long seqNum, String errDesc, String myFlowType, String mobOrEmail)
        {
            int flag = 0;
            String strSearchSql = "";
            try
            {

                SqlServerResource sqlServerResource = new SqlServerResource();
                strSearchSql = sqlServerResource.getSQLSERVERSQLString("SQLSERVER_MARK_ERROR_SQL");


                if (myFlowType.ToUpper().Equals("MYFLOWEMAIL"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, mobOrEmail, "", seqNum);

                }
                else if (myFlowType.ToUpper().Equals("MYFLOWSMS"))
                {

                    strSearchSql = string.Format(strSearchSql, errDesc, "", mobOrEmail, seqNum);
                }

                flag = executeUpdate(strSearchSql);

            }
            catch (Exception ex)
            {
                logger.Error("Message -> " + ex.Message);
                logger.Error("StackTrace -> " + ex.StackTrace);
            }//ex.printStackTrace();}
            return flag;
        }

        public int executeUpdate(string commandtext)
        {
            using (SqlConnection sqlConnection = ConnectToSqlServer.GetConnection())
            {
                try
                {
                    if (sqlConnection.State == ConnectionState.Closed) sqlConnection.Open();

                    using (SqlCommand sqlCommand = new SqlCommand(commandtext, sqlConnection))
                    {
                        sqlCommand.CommandTimeout = 300;
                        sqlCommand.ExecuteNonQuery();
                        return 1;
                    }
                }

                catch (Exception ex)
                {
                    logger.Error("Message -> " + ex.Message);
                    logger.Error("StackTrace -> " + ex.StackTrace);
                    return 0;
                }
            }

        }

    }

}