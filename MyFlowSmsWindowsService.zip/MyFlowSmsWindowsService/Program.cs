﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using log4net;
using System.Data;
using System.Configuration;
using System.Net;
using Newtonsoft.Json.Linq;
using System.ServiceProcess;


namespace MyFlowSmsWindowsService
{
    class Program
    {                        
        
        static void Main(string[] args)
        {
            ServiceBase[] ServicesToRun;

            // More than one user Service may run within the same process. To add
            // another service to this process, change the following line to
            // create a second service object. For example,
            //
            //   ServicesToRun = new ServiceBase[] {new Service1(), new MySecondUserService()};
            //
            ServicesToRun = new ServiceBase[] { new Service1() };

            ServiceBase.Run(ServicesToRun);
        }        
    }

}
