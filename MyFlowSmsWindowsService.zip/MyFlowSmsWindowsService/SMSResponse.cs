﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFlowSmsWindowsService
{
    class SMSResponse
    {
        private bool smsSentStatus;
        private String agtMobileNum;
        private String custOwnerMobileNum;
        private String custAssgneMobileNum;
        private String errorDesc;



        public String getErrorDesc()
        {
            return errorDesc;
        }
        public void setErrorDesc(String errorDesc)
        {
            this.errorDesc = errorDesc;
        }


        public bool isSmsSentStatus()
        {
            return smsSentStatus;
        }
        public void setSmsSentStatus(bool smsSentStatus)
        {
            this.smsSentStatus = smsSentStatus;
        }
        public String getAgtMobileNum()
        {
            return agtMobileNum;
        }
        public void setAgtMobileNum(String agtMobileNum)
        {
            this.agtMobileNum = agtMobileNum;
        }
        public String getCustOwnerMobileNum()
        {
            return custOwnerMobileNum;
        }
        public void setCustOwnerMobileNum(String custOwnerMobileNum)
        {
            this.custOwnerMobileNum = custOwnerMobileNum;
        }
        public String getCustAssgneMobileNum()
        {
            return custAssgneMobileNum;
        }
        public void setCustAssgneMobileNum(String custAssgneMobileNum)
        {
            this.custAssgneMobileNum = custAssgneMobileNum;
        }


    }

}
