package com.max.report.utils;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Commons 
{
	
	public static String fileName(String fName,String extn)
	{
		String folderName=null;
		String folderName2=null;
		File file=null;
		File ffile=null;
		File ffile2=null;
		DateFormat dateFormat1 = new SimpleDateFormat("dd");
	    Calendar cal1 = Calendar.getInstance();
	    cal1.add(Calendar.DATE, -1);
	    
		folderName=(new SimpleDateFormat("MMM").format(Calendar.getInstance().getTime()))+ ""+(Calendar.getInstance().get(Calendar.YEAR));
		folderName2=(dateFormat1.format(cal1.getTime()))+ ""+(new SimpleDateFormat("MMM").format(Calendar.getInstance().getTime()))+ ""+(Calendar.getInstance().get(Calendar.YEAR));
		file=new File(fName);
		if(file!=null && file.isDirectory())
		{
			ffile=new File(fName+File.separator+folderName);
			if(!ffile.exists())
			       ffile.mkdir();
		}
		if(ffile!=null && ffile.isDirectory())
		{
			ffile2=new File(ffile+File.separator+folderName2);
			if(!ffile2.exists())
			       ffile2.mkdir();
			
		}
		/*String fileName=fName+"-"
						+(Calendar.getInstance().get(Calendar.DATE))+ "-"
						+(new SimpleDateFormat("MMM").format(Calendar.getInstance().getTime()))+ "-" 
						+(Calendar.getInstance().get(Calendar.YEAR))+ "-" 
						+(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))+ "-" 
						+(Calendar.getInstance().get(Calendar.MINUTE))+ "-" 
						+(Calendar.getInstance().get(Calendar.SECOND))+"."+extn;
		*/
		System.out.println(dateFormat1.format(cal1.getTime()));
		return fName+"/"+folderName+"/"+folderName2+"/"+"Detailed-Application-Stats-Axis.xls";
		//+"/"+"Detailed-Application-Stats-Axis";
		//+;
	}
	
	public static String createFolder(String path,String baseFolderName)
	{
		File file=null;
		File ffile=null;
		String folderName=null;
		String batchFileName=null;
		int count=0;
		String totalCount[]=null;
		String totalCount1[]=null;
		boolean flag=true;
		boolean flag1=true;
		
	    //(Calendar.getInstance().get(Calendar.DATE))+ "-"+
		folderName=(new SimpleDateFormat("MMM").format(Calendar.getInstance().getTime()))+ ""+(Calendar.getInstance().get(Calendar.YEAR));
		file=new File(path);
		if(file!=null && file.isDirectory())
		{
			totalCount=file.list();
			for (count=0;count<totalCount.length;count++)
			{				
				if(totalCount[count].equalsIgnoreCase(baseFolderName))
				{
					batchFileName=totalCount[count];
					ffile=new File(path+File.separator+batchFileName);
					if(!ffile.isDirectory())
					{
						batchFileName=batchFileName.substring(0,batchFileName.lastIndexOf("."))+Calendar.getInstance().get(Calendar.HOUR)+"-"+Calendar.getInstance().get(Calendar.MINUTE)+"-"+Calendar.getInstance().get(Calendar.SECOND)+batchFileName.substring(batchFileName.lastIndexOf("."),batchFileName.length());
						ffile.renameTo(new File(path+File.separator+batchFileName));
						ffile.mkdir();
					}
					flag=false;
					totalCount1=ffile.list();
					for (count=0;count<totalCount1.length;count++)
					{
						if(totalCount1[count].equalsIgnoreCase(folderName))
						{
							batchFileName=totalCount1[count];
							ffile=new File(path+File.separator+baseFolderName+File.separator+batchFileName);
							if(!ffile.isDirectory())
							{
								batchFileName=batchFileName.substring(0,batchFileName.lastIndexOf("."))+Calendar.getInstance().get(Calendar.HOUR)+"-"+Calendar.getInstance().get(Calendar.MINUTE)+"-"+Calendar.getInstance().get(Calendar.SECOND)+batchFileName.substring(batchFileName.lastIndexOf("."),batchFileName.length());
								ffile.renameTo(new File(path+File.separator+batchFileName));
								ffile.mkdir();
							}
							flag1=false;							
							break;
							
						}
					}
					count=totalCount.length;
				}
			}
			if(flag)
			{				
				ffile=new File(path+File.separator+baseFolderName);
				ffile.mkdir();
				totalCount=ffile.list();
				for (count=0;count<totalCount.length;count++)
				{
					if(totalCount[count].equalsIgnoreCase(folderName))
					{
						ffile=new File(path+File.separator+baseFolderName+File.separator+totalCount[count]);
						if(!ffile.isDirectory())
						{
							ffile.renameTo(new File(path+File.separator+baseFolderName+File.separator+totalCount[count]+".bak"));
							ffile.mkdir();
						}
						flag1=false;
						break;
					}
				}				
			}
			if(flag1)
			{
				ffile=new File(path+File.separator+baseFolderName+File.separator+folderName);
				ffile.mkdir();
			}
		}
		return folderName;
	}
}