package com.max.report.utils;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class POIExcelGeneration 
{
	private static Logger logger=Logger.getLogger(POIExcelGeneration.class.getName());
	private static ResourceBundle res = ResourceBundle.getBundle("com.max.report.resources.ApplicationResources");	
	
	public void generateFile(String type,String fileName,List<List<String>> data)
	{
		if(type.equalsIgnoreCase("xls"))
		{
			generateExcel(fileName,data);	
		}
		else if(type.equalsIgnoreCase("csv"))
		{
			generateCSV(fileName,data);
		}			
	}
	
	public Sheet createSheet(Workbook wb,String sheetName,List<String> dataRowHeader)
	{
		logger.debug("Going to createSheet and Header Row:");
	    Sheet sheet=null;	
		Row rw = null;				
		Cell cl = null;
		int size=0;
		int count=0;
		try
		{
			sheet = wb.createSheet(sheetName);
			rw=sheet.createRow(0);
			size=dataRowHeader.size();			
			for(count= 0; count<size; count++)
			{
				cl = rw.getCell((short)count);
				cl = rw.createCell((short)count);
				cl.setCellValue(dataRowHeader.get(count).replaceAll("_", " "));																			
			}	
			sheet.setDefaultColumnWidth((short)15);
		}
		catch(Exception e)
		{
			logger.error("Error in createSheet and Header Row creation:"+e,new Throwable());
			e.printStackTrace();
		}
		logger.debug("Going out from createSheet and Header Row:");
		return sheet;
	}
	
	public void generateExcel(String file,List<List<String>> data)
	{
		logger.debug("Going to generateExcel:");
	    Sheet sh=null;	
		HSSFWorkbook wb = null;
		Row rw = null;				
		Cell cl = null;
		List<String> dataRow=null;
		List<String> dataRowHeader=null;
		short size=0;
		short count=0;
		int rowCount=0;
		int sheetCount=0;
		int totalRows=0;// Till the last row of the excel change sheet
		try
		{
			if(res.getString("com.max.report.rowCount")!=null && !res.getString("com.max.report.rowCount").trim().equalsIgnoreCase(""))			
			{
				totalRows=Integer.parseInt(res.getString("com.max.report.rowCount"));
			}
		}
		catch(Exception e)
		{
			logger.error("Error in Getting rowcount"+e,new Throwable());
			totalRows=65536;
		}
		try
		{
			wb = new HSSFWorkbook();
			dataRowHeader=data.get(0);
			size=(short)dataRowHeader.size();
			sh=createSheet(wb,res.getString("com.max.report.sheetName")+(sheetCount+1),dataRowHeader);			
			try
			{	
				System.out.println(">>>>>>>>"+data.size());
				logger.debug("Data in Excel sheet"+(sheetCount+1)+" appending Started-:");
				for(rowCount=1;rowCount<data.size();rowCount++)
				{
					System.out.println(">>>>>>>>"+rowCount);
					if((rowCount % totalRows==0 && sheetCount==0) || ((rowCount - totalRows)%(totalRows-1)==0 && sheetCount!=0))
					{
						try
						{
							logger.debug("Excel sheet"+(sheetCount+1)+" get Filled with Maximum no of rows allowed-:");
							sheetCount++;
							sh=createSheet(wb,res.getString("com.max.report.sheetName")+(sheetCount+1),dataRowHeader);
							logger.debug("Data in Excel sheet"+(sheetCount+1)+" appending Started-:");
						}
						catch(Exception e)
						{
							logger.error("Error in generateExcel header creation:"+e,new Throwable());
							e.printStackTrace();
						}
					}
					int rowNum = sh.getPhysicalNumberOfRows();
					rw = sh.createRow(rowNum);					
					dataRow=data.get(rowCount);				
					for(count=0;count<size;count++)
					{								
						cl = rw.getCell(count);
						cl = rw.createCell(count);
						if(dataRowHeader.get(count).equalsIgnoreCase(res.getString("com.max.report.field")))
						{
							String value=dataRow.get(count);
							try
							{
								if(value!=null && !value.trim().equalsIgnoreCase(""))
								{
									value=value.replaceAll("\r\n"," ").replaceAll("&AMP;","").replaceAll("&amp;","").replaceAll("&nbsp;"," ").replaceAll("&NBSP;"," ").replaceAll("&LT;","").replaceAll("&lt;","").replaceAll("&gt;","").replaceAll("&GT;","");
									while(value.indexOf("<")!=-1 && value.indexOf(">")!=-1)
									{
										int start=value.indexOf("<")<1 ?0:value.indexOf("<");
										int end=value.indexOf(">")<1 || value.indexOf(">")==value.length()?value.length():value.indexOf(">")+1;
										value=value.substring(0,start)+" "+value.substring(end);
									}
									value=value.trim().replaceAll(" +", " ");
								}
							}
							catch(Exception e)
							{
								logger.error("Error while");
								e.printStackTrace();
							}
							cl.setCellValue(value);
							value=null;
						}
						else
						{
							cl.setCellValue(dataRow.get(count));
						}
					}
				}
				try
				{
					logger.debug("Excel sheet"+(sheetCount+1)+" get Filled with present data-:");
					OutputStream out = new FileOutputStream(file);
					wb.write(out);
					out.flush();
					out.close();
				}
				catch(Exception e)
				{
					logger.error("Error in generateExcel at Report Saving:"+e,new Throwable());
					e.printStackTrace();
				}	
			}
			catch(Exception e)
			{
				logger.error("Error in generateExcel data creation:"+e,new Throwable());
				e.printStackTrace();
			}
		}
		catch(Exception e)
		{
			logger.error("Error in generateExcel header creation:"+e,new Throwable());
			e.printStackTrace();
		}
		logger.debug("Going out from generateExcel:");		
	}
	
	public void generateCSV(String file,List<List<String>> data)
	{
		logger.debug("Going to generateCSV:");
		BufferedWriter bufferedWriterALL = null;
		if(data != null && data.size()>1 )
		{
			try
			{
				bufferedWriterALL = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file),"UTF8"));
			    int excelLength = (data.get(0)).size();  
				for(int i=0; i<data.size(); i++)
				{				
					List<String> dataRow=data.get(i);
					String dataRowString="";				
					for(int j=0; j<excelLength; j++)
					{
						if((Object)dataRow.get(j)!=null)
						{
							dataRowString+="\""+(((Object)dataRow.get(j)).toString())+"\",";
						}
						else
						{
							dataRowString+=",";	
						}
					}
					bufferedWriterALL.write(dataRowString.substring(0,dataRowString.length()-1)+"\n"); 						         
				}
			}
			catch(Exception e)
			{
				logger.error("Error in Report Generation in generateCSV:-"+e,new Throwable());
				e.printStackTrace();
			}
			try
			{
				bufferedWriterALL.flush();
				bufferedWriterALL.close();
			}
			catch(Exception e)
			{
				logger.error("Error in Report Generationg Resource Closing in generateCSV:-"+e,new Throwable());
				e.printStackTrace();
			}			
		}
		logger.debug("Going out from generateCSV:");
	}
	public static void main(String args[])
	{
		String a="<dfla>";
		System.out.println(a.indexOf("<")+"    "+a.indexOf(">")+"::::"+a.substring(0,0));
	}
}