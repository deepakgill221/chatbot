package com.max.report.db;

public class SQLConstants 
{	
	//TEMP_DD_VH_1 Table
	//public static final String ReportQry="SELECT TO_CHAR(ASSIGNED_DTM,'DD-MON-YYYY') \"Marked_Date\",CASE_ID \"Case_ID\",POLICY_NUMBER \"Proposal_Number\",GO_NAME \"GO_Name\",WORKITEM_DESC \"Workitem_Name\",CASE_STAT_DESC \"Case Status\",REQT_DISP_NM \"Case Requirement\",CASE_REQT_DSC \"Requirement_Discription\",CASE_TXT \"Notes\" FROM TEMP_DD_VH_1";
	
	
	public static final String ReportQry = "select pol_id,PLAN_ID,decode(POL_BILL_MODE_CD,12,round((POL_MPREM_AMT/1),2),6,round((POL_MPREM_AMT/0.5),2),3,round((POL_MPREM_AMT/0.25),2),1,round((POL_MPREM_AMT/0.083333),2))POL_MPREM_AMT,decode(POL_BILL_MODE_CD,12,'1',6,'2',3,'3',1,'4')POL_BILL_MODE_CD, CVG_PREM_CHNG_DUR,POL_TRM_DUR,PREV_NNCBA_AMT,fnd_id,alloc_pct,nav_iss_amt,nav_crnt_amt,riy_yr,CVG_ORIG_FACE_AMT from tzriy where (IFTS_STAT_CD='P' or IFTS_STAT_CD='P') and rownum<=200";
	//(IFTS_STAT_CD='P' or IFTS_STAT_CD='P') and rownum<=200"; 
	public static final String ReportQry6="MERGE INTO fund_sepration USING (SELECT 1 FROM DUAL) ON (polid=? and RIYYEAR=?) WHEN MATCHED THEN UPDATE  SET FUND_A1 =?,  FUND_A2 =?,FUND_A3=?,FUND_A4 =?,FUND_A5 =?,ALLOC_VALUE1 =?,ALLOC_VALUE2 =?,ALLOC_VALUE3=?,ALLOC_VALUE4 =?,ALLOC_VALUE5 =?,    NAV_AMOUNT1 =?,    NAV_AMOUNT2 =?,    NAV_AMOUNT3=?,    NAV_AMOUNT4 =?,    NAV_AMOUNT5 =?,    NAV_CRNT_AMOUNT1 =?,    NAV_CRNT_AMOUNT2 =?,    NAV_CRNT_AMOUNT3=?,    NAV_CRNT_AMOUNT4 =?,    NAV_CRNT_AMOUNT5 =? ,IFTSTRING=? ,plan_id=?  WHEN NOT MATCHED THEN  INSERT    ( POLID,FUND_A1,FUND_A2,FUND_A3,FUND_A4,FUND_A5 ,ALLOC_VALUE1,ALLOC_VALUE2,ALLOC_VALUE3,ALLOC_VALUE4,ALLOC_VALUE5,NAV_AMOUNT1,NAV_AMOUNT2,NAV_AMOUNT3,NAV_AMOUNT4,NAV_AMOUNT5,NAV_CRNT_AMOUNT1,NAV_CRNT_AMOUNT2,NAV_CRNT_AMOUNT3,NAV_CRNT_AMOUNT4,NAV_CRNT_AMOUNT5,RIYYEAR,IFTSTRING,plan_id)    VALUES    (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String ReportQry2="update tzriy set IFTS_STAT_CD='S',PREV_UPDT_USER_ID='IFTIS',PREV_UPDT_TS=?, GRS_YLD_AMT=?, NET_YLD_AMT=?, ACT_RIY=?, PRJ_FND_VAL_1_AMT=?, PRJ_FND_VAL_2_AMT=? , NNCBA_AMT=?,RIY_NUM=? where (pol_id=? and riy_yr=?)";
	public static final String ReportQry7="update tzriy set IFTS_STAT_CD='F',PREV_UPDT_USER_ID='IFTIS' where (pol_id=? and riy_yr=?)";
	public static final String ReportQry3="insert into IFTIS_ING_RIY_MST values(IFTS_ING_RIY.nextval,?,?,?)";
	public static final String ReportQry8="select FLAG from riy_batch_flag";
	public static final String ReportQry9="update riy_batch_flag set flag=?";
	public static final String ReportQry4="insert into IFTIS_ING_RIY_TRANS values(IFTIS_ING_SEQ_TRANS.nextval,?,?,?,?,?,?,?,?)";
	public static final String ReportQry5="select clawback, GROSSYD, NETYIELD, ACTRIY, PJFV1, PJFV2, RIY from iftisoutparams where rowfetch=(select max(rowfetch) from iftisoutparams)";
	
   
	
	//public static final String ReportProc="PR_DW_DETAILED_APPL_STAT_AXIS";
		
}