package com.max.report.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

public class DBConnection
{	
	static Logger logger = Logger.getLogger(DBConnection.class);
	static ResourceBundle res=ResourceBundle.getBundle("com.max.report.resources.ApplicationResources");
	public static List<String> riyyear=new ArrayList<String>();
	static StringBuilder strbuff= new StringBuilder();
	static int riycounter=0;
	String ClawValue=null;
	String Grossyd="";
	String Actriy=null;
	String Netyd=null;
	String pjf1=null;
	String pjf2=null;
	String riynum=null;

	public List<String> executeQuery(String query) throws SQLException
	{        
		logger.debug("Comes to DBConnection in ExecuteQuery Method: ");    
		//POIExcelGeneration excelGeneration=new POIExcelGeneration();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement stmt =null;
		int count=0;
		//Hashtable<String,String> iftisString = new Hashtable<String,String>();
		List<String> PLANID=new ArrayList<String>();
		List<String> PREMIUMAMT=new ArrayList<String>();
		List<String> PaymentModeList=new ArrayList<String>();
		List<String> PREMPAYTERMCOMBO=new ArrayList<String>();
		List<String> PAYMENTPERIODLIST=new ArrayList<String>();
		List<String> prevclawback=new ArrayList<String>();
		List<String> PAYMENTPERIODLIST3=new ArrayList<String>();
		List<String> policyNum=new ArrayList<String>();
		List<String> fund_sep_fundis=new ArrayList<String>();
		List<String> fund_sep_alloc=new ArrayList<String>();
		List<String> fund_sep_nav=new ArrayList<String>();
		List<String> fund_sep_naccrt=new ArrayList<String>();
		List<String> fund_sep_finalstring=new ArrayList<String>();
		List<String> face_amount=new ArrayList<String>();
		String PaymentTypeList1="";
		String pcombo="";
		String prevclback="";

		//  StringBuilder strbuff= new StringBuilder();
		StringBuilder fundstring= new StringBuilder();
		String PLAN_ID="100";
		try
		{
			con=DBHelper.getInstance().getSourceConnection();		
			if(con!=null)
			{
				stmt = con.prepareStatement(query);		  
				stmt.setQueryTimeout(0);
				rs=stmt.executeQuery();
				if(rs!=null)
				{
					ResultSetMetaData resultSetMetaData = rs.getMetaData();
					int noOfColumns = resultSetMetaData.getColumnCount();
					List<String> colName=new ArrayList<String>();
					for (int i = 1; i <= noOfColumns; i++)
					{
						colName.add(resultSetMetaData.getColumnName(i));
					}
					System.out.println(">>>>"+(colName.get(0)));
					//result.add(colName);
					count=0;
					int c=0;

					logger.debug("total No of Columns fetch are:-"+noOfColumns);
					while(rs.next())
					{
						policyNum.add(rs.getString("pol_id")); 
						PLANID.add(rs.getString("PLAN_ID"));
						PREMIUMAMT.add(rs.getString("POL_MPREM_AMT"));
						PaymentModeList.add(rs.getString("POL_BILL_MODE_CD"));
						PREMPAYTERMCOMBO.add(rs.getString("CVG_PREM_CHNG_DUR"));
						PAYMENTPERIODLIST.add(rs.getString("POL_TRM_DUR"));
						prevclawback.add(rs.getString("PREV_NNCBA_AMT").trim());
						fund_sep_fundis.add(rs.getString("fnd_id"));
						fund_sep_alloc.add(rs.getString("alloc_pct"));
						fund_sep_nav.add(rs.getString("nav_iss_amt"));
						fund_sep_naccrt.add(rs.getString("nav_crnt_amt"));
						riyyear.add(rs.getString("riy_yr"));
						face_amount.add(rs.getString("CVG_ORIG_FACE_AMT").trim());
						count++;
					}
					logger.debug("total No of Records fetch are:-"+count);
				}			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in ExecuteQuery Method:- ");  
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in ExecuteQuery Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteQuery Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}

		if(fund_sep_fundis.size()>=1)
			for(int i=0;i<policyNum.size();i++)
			{
				if(PLANID.get(i).equalsIgnoreCase("U2ESFV") || PLANID.get(i).equalsIgnoreCase("U2ESF5"))
					PLAN_ID="120";
				else if(PLANID.get(i).equalsIgnoreCase("U2MF10") || PLANID.get(i).equalsIgnoreCase("U2MF07"))
					PLAN_ID="115";
				else if(PLANID.get(i).equalsIgnoreCase("U2NIF5")){
					PLAN_ID="116";
					pcombo="5";
				}
				else if( PLANID.get(i).equalsIgnoreCase("U2NIFS")){
					PLAN_ID="116";
					pcombo="1";
				}
				else if( PLANID.get(i).equalsIgnoreCase("U2NF20")){
					PLAN_ID="116";
					pcombo="20";
				}
				else if(PLANID.get(i).equalsIgnoreCase("UIPWFS") || PLANID.get(i).equalsIgnoreCase("UIPWPS")){
					PLAN_ID="134";
					PaymentTypeList1="1";
				}
				else if(PLANID.get(i).equalsIgnoreCase("UIPWF5") || PLANID.get(i).equalsIgnoreCase("UIPWP5")){
					PLAN_ID="134";
					PaymentTypeList1="2";
				}
				else if(PLANID.get(i).equalsIgnoreCase("UIPWFR") || PLANID.get(i).equalsIgnoreCase("UIPWPR")){
					PLAN_ID="134";
					PaymentTypeList1="3";
				}
				else if(PLANID.get(i).equalsIgnoreCase("UPPRPF") || PLANID.get(i).equalsIgnoreCase("UPPSPF")|| PLANID.get(i).equalsIgnoreCase("UPPSCF"))
					PLAN_ID="110";

				strbuff.append("txtpolid="+policyNum.get(i).trim());
				strbuff.append("&PLAN_ID="+PLAN_ID);
				strbuff.append("&RIYYEAR="+riyyear.get(i));
				strbuff.append("&PREMIUMAMT="+PREMIUMAMT.get(i));
				strbuff.append("&PaymentModeList="+PaymentModeList.get(i));
				if(PLAN_ID.equals("134"))  
				{
					strbuff.append("&PAYMENTPERIODLIST3="+PAYMENTPERIODLIST.get(i));
					strbuff.append("&PaymentTypeList1="+PaymentTypeList1);
				}
				if(!PLAN_ID.equalsIgnoreCase("116"))
					strbuff.append("&PREMPAYTERMCOMBO="+PREMPAYTERMCOMBO.get(i));
				else if(PLAN_ID.equalsIgnoreCase("116"))
					strbuff.append("&PREMPAYTERMCOMBO="+pcombo);

				strbuff.append("&PAYMENTPERIODLIST="+PAYMENTPERIODLIST.get(i));
				strbuff.append("&FACEAMT="+face_amount.get(i));
				strbuff.append("&tblClawbackAddition= ");
				strbuff.append("&tblClawbackAddition= ");
				strbuff.append("&tblClawbackAddition= ");
				strbuff.append("&tblClawbackAddition= ");
				if(!riyyear.get(i).equalsIgnoreCase("5") && !(prevclawback.get(i).isEmpty())){
					prevclback=executeClawBack(prevclawback.get(i),Integer.valueOf(riyyear.get(i)));
					strbuff.append(prevclback);
				}
				strbuff.append("&");
				//fundstring.append(fund_sep_fundis.get(0));
				fundstring.append(isNullThanBlank(fund_sep_alloc.get(i)));
				fundstring.append(","+isNullThanBlank(fund_sep_nav.get(i)));
				fundstring.append(","+isNullThanBlank(fund_sep_naccrt.get(i)));

				fund_sep_finalstring.add(fundstring.toString());
				executeFundDetails(fund_sep_fundis.get(i),fund_sep_finalstring.get(i),policyNum.get(i),riyyear.get(i),strbuff.toString(),PLAN_ID);
				strbuff.setLength(0);
				fundstring.setLength(0);
			}

		logger.debug("Getting out from DBConnection in ExecuteQuery Method : ");
		return policyNum;
	}

	private static String isNullThanBlank(String str)
	{
		String temp="";
		temp=str;
		temp=temp==null?"":temp.trim();
		return temp;
	}

	public void executeQueryI(String query) throws SQLException
	{        
		logger.debug("Comes to DBConnection in ExecuteQueryI Method: ");    
		// POIExcelGeneration excelGeneration=new POIExcelGeneration();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement stmt =null;
		int count=0;

		String claw=null;
		String GROSSYD="";
		String PJFV2="";
		String NETYIELD="";
		String ACTRIY="";
		String PJFV1="";
		String RIYNUM="";

		try
		{
			con=DBHelper.getInstance().getSourceConnectionI();		
			if(con!=null)
			{
				stmt = con.prepareStatement(query);		  
				stmt.setQueryTimeout(0);
				rs=stmt.executeQuery();
				if(rs!=null)
				{
					count=0;
					int c=0;

					logger.debug("total No of Columns fetch using query:-"+query);
					while(rs.next())
					{
						claw=rs.getString("clawback"); 
						GROSSYD=rs.getString("GROSSYD");
						PJFV2=rs.getString("PJFV2");
						PJFV1=rs.getString("PJFV1");
						NETYIELD=rs.getString("NETYIELD");
						ACTRIY=rs.getString("ACTRIY");
						RIYNUM=rs.getString("RIY");
						count++;
					}
					logger.debug("total No of Records fetch are:-"+count);
				}	

			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in ExecuteQueryI Method:- ");  
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in ExecuteQueryI Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteQueryI Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}

		logger.debug("Getting out from DBConnection in ExecuteQuery Method : ");
		ClawValue=claw; Grossyd=GROSSYD;pjf1=PJFV1;pjf2=PJFV2;Actriy=ACTRIY;
		Netyd=NETYIELD;riynum=RIYNUM;
	}

	public boolean executeUpdate(String query,String param) throws SQLException
	{
		logger.debug("Comes to DBConnection in ExecuteUpdate Method : ");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		String user_update=dateFormat.format(cal.getTime()).toString();
		logger.info("Update Time is : "+user_update);
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		boolean flag=false;
		try
		{
			con=DBHelper.getInstance().getSourceConnection();		
			if(con!=null)
			{
				con.setAutoCommit(true);
				stmt=con.prepareStatement(query);
				if(param!=null)
				{
					logger.debug("SQL query to be executed : "+query +" with Parameters :-"+param);
					//  while(i<param.length)
					{
						stmt.setString(1,user_update);
						stmt.setString(2,isNullThanBlank(Grossyd));
						//stmt.setString(2,ClawValue);
						stmt.setString(3,isNullThanBlank(Netyd));
						stmt.setString(4,isNullThanBlank(Actriy));
						stmt.setString(5,isNullThanBlank(pjf1));
						stmt.setString(6,isNullThanBlank(pjf2));
						stmt.setString(7,isNullThanBlank(ClawValue));
						stmt.setString(8,isNullThanBlank(riynum));
						stmt.setString(9,param);
						stmt.setString(10,(riyyear.get(riycounter)));
						//if(Grossyd!=null){stmt.setInt(2, new Integer(Grossyd));}else{stmt.setNull(2, Types.NUMERIC);}
						//stmt.setString(2,ClawValue);
						//stmt.setNull(3, Types.NUMERIC);
						//if(Netyd!=null){stmt.setInt(3, new Integer(Netyd));}else{stmt.setNull(3, Types.NUMERIC);}
						//if(Actriy!=null){stmt.setInt(4, new Integer(Actriy));}else{stmt.setNull(4, Types.NUMERIC);}
						//if(Actriy!=null){stmt.setInt(4, new Integer(Actriy));}else{stmt.setNull(4, Types.NUMERIC);}


						//i++;
					}
				}
				else
				{
					logger.debug("SQL query to be executed : "+query);
				}
				int count=stmt.executeUpdate();
				logger.info("Update status is : "+count);
				if(count>0)
				{
					flag=true;
					riycounter++;
				}
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update records : "+e,new Throwable());
			executeUpdateFail(param,(riyyear.get(riycounter)));
			System.out.println("Status F updated for this Policy");
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in ExecuteUpdate Method:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in ExecuteUpdate Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteUpdate Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in ExecuteUpdate Method : ");      
		return flag;
	}


	public void executeUpdateFail(String polid,String riyyr) throws SQLException
	{
		logger.debug("Comes to DBConnection in executeUpdateFail Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		String query=SQLConstants.ReportQry7;
		try
		{
			con=DBHelper.getInstance().getSourceConnection();		
			if(con!=null)
			{
				con.setAutoCommit(true);
				stmt=con.prepareStatement(query);
				if(polid!=null)
				{
					logger.debug("SQL query to be executed : "+query +" with Parameters :-"+polid);
					stmt.setString(1,polid);
					stmt.setString(2,(riyyear.get(riycounter)));
				}
				else
				{
					logger.debug("SQL query to be executed : "+query);
				}
				int count=stmt.executeUpdate();
				if(count>0)
				{
					logger.info("Successfully updated!!!!");		
				}
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update records in fail case method: "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in executeUpdateFail Method:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in executeUpdateFail Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in executeUpdateFail Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in executeUpdateFail Method : ");      

	}

	public static boolean executePendingDetails(String st_tm, String ed_tm, int tot_pol) throws SQLException
	{
		logger.debug("Comes to DBConnection in executePendingDetails Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		String query=SQLConstants.ReportQry3;
		String datetimedtls=getDTdetails();
		boolean flag=false;
		try
		{
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date start_time = sdf.parse(st_tm);
			Date end_time = sdf.parse(ed_tm);
			Timestamp st_tm1= new java.sql.Timestamp(start_time.getTime());
			Timestamp ed_tm2= new java.sql.Timestamp(end_time.getTime());

			con=DBHelper.getInstance().getSourceConnection();		
			if(con!=null)
			{
				con.setAutoCommit(true);
				stmt=con.prepareStatement(query);
				if(datetimedtls!=null)
				{
					logger.debug("SQL query to be executed : "+query +" with Parameters :-"+st_tm1);

					stmt.setTimestamp(1, st_tm1);
					stmt.setTimestamp(2, ed_tm2);        			
					stmt.setInt(3, tot_pol);
				}
				else
				{
					logger.debug("SQL query to be executed : "+query);
				}
				int done=stmt.executeUpdate();
				if(done>0)
				{
					flag=true;

				}
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in executePendingDetails:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in executePendingDetails Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in executePendingDetails Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in executePendingDetails Method : ");      
		return flag;
	}

	public static boolean updateFlag(String flag_value) throws SQLException
	{
		logger.debug("Comes to DBConnection in updateFlag Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		String query=SQLConstants.ReportQry9;
		String datetimedtls=getDTdetails();
		boolean flag=false;
		try
		{  	con=DBHelper.getInstance().getSourceConnectionI();		
		if(con!=null)
		{
			con.setAutoCommit(true);
			stmt=con.prepareStatement(query);
			logger.debug("SQL query to be executed : "+query +" with Parameters :-"+flag_value);
			stmt.setString(1, flag_value);
			int done=stmt.executeUpdate();
			if(done>0)
			{
				flag=true;
				System.out.println(done+"--Records-Affected");
			}
		}
		else
		{
			logger.error("Connection is Not Available Service unavailable.");				
		}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in updateFlag:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in updateFlag Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in updateFlag Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in updateFlag Method : ");      
		return flag;
	}


	public static String checkFlag() throws SQLException
	{
		logger.debug("Comes to DBConnection in checkFlag Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		ResultSet rs=null;
		int i=0;
		String query=SQLConstants.ReportQry8;
		String datetimedtls=getDTdetails();
		String  flag_val="";
		try
		{  	con=DBHelper.getInstance().getSourceConnectionI();		
		if(con!=null)
		{
			con.setAutoCommit(true);
			stmt=con.prepareStatement(query);
			rs=stmt.executeQuery();
			if(rs!=null)
			{
				if(rs.next())
				{
					flag_val=rs.getString("FLAG");
					System.out.println("flag status is-"+flag_val);
				}
			}
		}
		else
		{
			logger.error("Connection is Not Available Service unavailable.");				
		}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update flag : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in checkflag:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in checkflag Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in checkflag Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in checkflag Method : ");      
		return flag_val;
	}


	public void executeAuditDetails(String polid,String strbuff2) throws SQLException,NumberFormatException
	{
		DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String str_date=dateformat.format(date);

		logger.debug("Comes to DBConnection in executeAuditDetails Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		String query=SQLConstants.ReportQry4;
		String full_string = strbuff.toString();
		String[] out = full_string.split("&");
		System.out.println(out);
		String datetimedtls=getDTdetails();
		boolean flag=false;
		try
		{
			con=DBHelper.getInstance().getSourceConnectionI();		
			if(con!=null)
			{
				con.setAutoCommit(true);
				stmt=con.prepareStatement(query);
				if(datetimedtls!=null)
				{
					logger.debug("SQL query to be executed : "+query +" with Parameters :-"+datetimedtls);

					stmt.setString(1,polid);
					stmt.setString(2,polid);
					stmt.setString(3,"");
					stmt.setString(4,"dffsd");
					stmt.setString(5,str_date);
					stmt.setString(6,"IFTIS");
					stmt.setString(7,str_date);
					stmt.setString(8,"IFTIS");

				}
				else
				{
					logger.debug("SQL query to be executed : "+query);
				}
				int done=stmt.executeUpdate();
				if(done>0)
				{
					flag=true;
				}
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in executePendingDetails:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in executeAuditDetails Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in executeAuditDetails Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in executeAuditDetails Method : ");      
		//return flag;
	}


	public void executeFundDetails(String fundids,String fund_all,String polnmbr,String riyyear,String iftiString,String planid) throws SQLException,NumberFormatException
	{
		logger.debug("Comes to DBConnection in executeFundDetails Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		ArrayList<String> fund_details=new ArrayList<String>();
		ArrayList<String> fund_all_values=new ArrayList<String>();
		String query=SQLConstants.ReportQry6;
		String datetimedtls=getDTdetails();
		boolean flag=false;
		try
		{
			con=DBHelper.getInstance().getSourceConnection();		
			if(con!=null)
			{
				con.setAutoCommit(true);
				stmt=con.prepareStatement(query);
				logger.debug("SQL query to be executed : "+query +" with Parameters :-"+datetimedtls);

				String [] fund_sep=fundids.split(",");
				for (String retfund: fund_sep)
					fund_details.add(retfund);

						String [] fund_values=fund_all.split(",");
						for (String retval: fund_values)
							fund_all_values.add(retval);
								//for(i=0;i<fund_details.size();i++)
								//System.out.println("@@@@@>>>>>>>>>>"+fund_details.get(i));

								if(fund_details.size()==1 ) 
								{
									stmt.setString(1,polnmbr);
									stmt.setString(2,riyyear);
									stmt.setString(3,fund_details.get(0));
									stmt.setString(4,"0");
									stmt.setString(5,"0");
									stmt.setString(6,"0");
									stmt.setString(7,"0");
									stmt.setString(8,fund_all_values.get(0));
									stmt.setString(9,"0");
									stmt.setString(10,"0");
									stmt.setString(11,"0");
									stmt.setString(12,"0");
									stmt.setString(13,fund_all_values.get(1));
									stmt.setString(14,"0");
									stmt.setString(15,"0");
									stmt.setString(16,"0");
									stmt.setString(17,"0");
									stmt.setString(18,fund_all_values.get(2));
									stmt.setString(19,"0");
									stmt.setString(20,"0");
									stmt.setString(21,"0");
									stmt.setString(22,"0");
									stmt.setString(23,iftiString);
									stmt.setString(24,planid);

									stmt.setString(25,polnmbr);
									stmt.setString(26,fund_details.get(0));
									stmt.setString(27,"0");
									stmt.setString(28,"0");
									stmt.setString(29,"0");
									stmt.setString(30,"0");
									stmt.setString(31,fund_all_values.get(0));
									stmt.setString(32,"0");
									stmt.setString(33,"0");
									stmt.setString(34,"0");
									stmt.setString(35,"0");
									stmt.setString(36,fund_all_values.get(1));
									stmt.setString(37,"0");
									stmt.setString(38,"0");
									stmt.setString(39,"0");
									stmt.setString(40,"0");
									stmt.setString(41,fund_all_values.get(2));
									stmt.setString(42,"0");
									stmt.setString(43,"0");
									stmt.setString(44,"0");
									stmt.setString(45,"0");
									stmt.setString(46,riyyear);
									stmt.setString(47,iftiString);
									stmt.setString(48,planid);
									int done=stmt.executeUpdate();
									if(done>0)
									{
										flag=true;
										System.out.println("fund-updated-1");
									}

								}
								else if(fund_details.size()==2)
								{
									stmt.setString(1,polnmbr);
									stmt.setString(2,riyyear);
									stmt.setString(3,fund_details.get(0));
									stmt.setString(4,fund_details.get(1));
									stmt.setString(5,"0");
									stmt.setString(6,"0");
									stmt.setString(7,"0");
									stmt.setString(8,fund_all_values.get(0));	
									stmt.setString(9,fund_all_values.get(1));
									stmt.setString(10,"0");
									stmt.setString(11,"0");
									stmt.setString(12,"0");
									stmt.setString(13,fund_all_values.get(2));
									stmt.setString(14,fund_all_values.get(3));
									stmt.setString(15,"0");
									stmt.setString(16,"0");
									stmt.setString(17,"0");
									stmt.setString(18,fund_all_values.get(4));
									stmt.setString(19,fund_all_values.get(5));
									stmt.setString(20,"0");
									stmt.setString(21,"0");
									stmt.setString(22,"0");
									stmt.setString(23,iftiString);
									stmt.setString(24,planid);

									stmt.setString(25,polnmbr);
									stmt.setString(26,fund_details.get(0));
									stmt.setString(27,fund_details.get(1));
									stmt.setString(28,"0");
									stmt.setString(29,"0");
									stmt.setString(30,"0");
									stmt.setString(31,fund_all_values.get(0));
									stmt.setString(32,fund_all_values.get(1));
									stmt.setString(33,"0");
									stmt.setString(34,"0");
									stmt.setString(35,"0");
									stmt.setString(36,fund_all_values.get(2));
									stmt.setString(37,fund_all_values.get(3));
									stmt.setString(38,"0");
									stmt.setString(39,"0");
									stmt.setString(40,"0");
									stmt.setString(41,fund_all_values.get(4));
									stmt.setString(42,fund_all_values.get(5));
									stmt.setString(43,"0");
									stmt.setString(44,"0");
									stmt.setString(45,"0");
									stmt.setString(46,riyyear);
									stmt.setString(47,iftiString);	
									stmt.setString(48,planid);

									int done=stmt.executeUpdate();
									if(done>0)
									{
										flag=true;
										System.out.println("fund-updated-2");
									}
								}

								else if(fund_details.size()==3)
								{
									stmt.setString(1,polnmbr);
									stmt.setString(2,riyyear);
									stmt.setString(3,fund_details.get(0));
									stmt.setString(4,fund_details.get(1));
									stmt.setString(5,fund_details.get(2));
									stmt.setString(6,"0");
									stmt.setString(7,"0");
									stmt.setString(8,fund_all_values.get(0));
									stmt.setString(9,fund_all_values.get(1));
									stmt.setString(10,fund_all_values.get(2));
									stmt.setString(11,"0");
									stmt.setString(12,"0");
									stmt.setString(13,fund_all_values.get(3));
									stmt.setString(14,fund_all_values.get(4));
									stmt.setString(15,fund_all_values.get(5));
									stmt.setString(16,"0");
									stmt.setString(17,"0");
									stmt.setString(18,fund_all_values.get(6));
									stmt.setString(19,fund_all_values.get(7));
									stmt.setString(20,fund_all_values.get(8));
									stmt.setString(21,"0");
									stmt.setString(22,"0");
									stmt.setString(23,iftiString);
									stmt.setString(24,planid);

									stmt.setString(25,polnmbr);
									stmt.setString(26,fund_details.get(0));
									stmt.setString(27,fund_details.get(1));
									stmt.setString(28,fund_details.get(2));
									stmt.setString(29,"0");
									stmt.setString(30,"0");
									stmt.setString(31,fund_all_values.get(0));
									stmt.setString(32,fund_all_values.get(1));
									stmt.setString(33,fund_all_values.get(2));
									stmt.setString(34,"0");
									stmt.setString(35,"0");
									stmt.setString(36,fund_all_values.get(3));
									stmt.setString(37,fund_all_values.get(4));
									stmt.setString(38,fund_all_values.get(5));
									stmt.setString(39,"0");
									stmt.setString(40,"0");
									stmt.setString(41,fund_all_values.get(6));
									stmt.setString(42,fund_all_values.get(7));
									stmt.setString(43,fund_all_values.get(8));
									stmt.setString(44,"0");
									stmt.setString(45,"0");
									stmt.setString(46,riyyear);
									stmt.setString(47,iftiString);
									stmt.setString(48,planid);
									int done=stmt.executeUpdate();
									if(done>0)
									{
										flag=true;
										System.out.println("fund-updated-3");
									}

								}
								else if(fund_details.size()==4)     
								{
									stmt.setString(1,polnmbr);
									stmt.setString(2,riyyear);
									stmt.setString(3,fund_details.get(0));
									stmt.setString(4,fund_details.get(1));
									stmt.setString(5,fund_details.get(2));
									stmt.setString(6,fund_details.get(3));
									stmt.setString(7,"0");
									stmt.setString(8,fund_all_values.get(0));
									stmt.setString(9,fund_all_values.get(1));
									stmt.setString(10,fund_all_values.get(2));
									stmt.setString(11,fund_all_values.get(3));

									stmt.setString(12,"0");
									stmt.setString(13,fund_all_values.get(4));
									stmt.setString(14,fund_all_values.get(5));
									stmt.setString(15,fund_all_values.get(6));
									stmt.setString(16,fund_all_values.get(7));
									stmt.setString(17,"0");

									stmt.setString(18,fund_all_values.get(8));
									stmt.setString(19,fund_all_values.get(9));
									stmt.setString(20,fund_all_values.get(10));
									stmt.setString(21,fund_all_values.get(11));
									stmt.setString(22,"0");
									stmt.setString(23,iftiString);
									stmt.setString(24,planid);

									stmt.setString(25,polnmbr);
									stmt.setString(26,fund_details.get(0));
									stmt.setString(27,fund_details.get(1));
									stmt.setString(28,fund_details.get(2));
									stmt.setString(29,fund_details.get(3));
									stmt.setString(30,"0");
									stmt.setString(31,fund_all_values.get(0));
									stmt.setString(32,fund_all_values.get(1));
									stmt.setString(33,fund_all_values.get(2));
									stmt.setString(34,fund_all_values.get(3));
									stmt.setString(35,"0");
									stmt.setString(36,fund_all_values.get(4));
									stmt.setString(37,fund_all_values.get(5));
									stmt.setString(38,fund_all_values.get(6));
									stmt.setString(39,fund_all_values.get(7));
									stmt.setString(40,"0");
									stmt.setString(41,fund_all_values.get(8));
									stmt.setString(42,fund_all_values.get(9));
									stmt.setString(43,fund_all_values.get(10));
									stmt.setString(44,fund_all_values.get(11));
									stmt.setString(45,"0");
									stmt.setString(46,riyyear);
									stmt.setString(47,iftiString);
									stmt.setString(48,planid);
									int done=stmt.executeUpdate();
									if(done>0)
									{
										flag=true;
										System.out.println("fund-updated-4");
									}

								}

								else if(fund_details.size()==5 ) 
								{
									stmt.setString(1,polnmbr);
									stmt.setString(2,riyyear);
									stmt.setString(3,fund_details.get(0));
									stmt.setString(4,fund_details.get(1));
									stmt.setString(5,fund_details.get(2));
									stmt.setString(6,fund_details.get(3));
									stmt.setString(7,fund_details.get(4));

									stmt.setString(8,fund_all_values.get(0));
									stmt.setString(9,fund_all_values.get(1));
									stmt.setString(10,fund_all_values.get(2));
									stmt.setString(11,fund_all_values.get(3));
									stmt.setString(12,fund_all_values.get(4));
									stmt.setString(13,fund_all_values.get(5));
									stmt.setString(14,fund_all_values.get(6));
									stmt.setString(15,fund_all_values.get(7));
									stmt.setString(16,fund_all_values.get(8));
									stmt.setString(17,fund_all_values.get(9));
									stmt.setString(18,fund_all_values.get(10));
									stmt.setString(19,fund_all_values.get(11));
									stmt.setString(20,fund_all_values.get(12));
									stmt.setString(21,fund_all_values.get(13));
									stmt.setString(22,fund_all_values.get(14));
									stmt.setString(23,iftiString);
									stmt.setString(24,planid);

									stmt.setString(25,polnmbr);
									stmt.setString(26,fund_details.get(0));
									stmt.setString(27,fund_details.get(1));
									stmt.setString(28,fund_details.get(2));
									stmt.setString(29,fund_details.get(3));
									stmt.setString(30,fund_details.get(4));

									stmt.setString(31,fund_all_values.get(0));
									stmt.setString(32,fund_all_values.get(1));
									stmt.setString(33,fund_all_values.get(2));
									stmt.setString(34,fund_all_values.get(3));
									stmt.setString(35,fund_all_values.get(4));
									stmt.setString(36,fund_all_values.get(5));
									stmt.setString(37,fund_all_values.get(6));
									stmt.setString(38,fund_all_values.get(7));
									stmt.setString(39,fund_all_values.get(8));
									stmt.setString(40,fund_all_values.get(9));
									stmt.setString(41,fund_all_values.get(10));
									stmt.setString(42,fund_all_values.get(11));
									stmt.setString(43,fund_all_values.get(12));
									stmt.setString(44,fund_all_values.get(13));
									stmt.setString(45,fund_all_values.get(14));
									stmt.setString(46,riyyear);
									stmt.setString(47,iftiString);
									stmt.setString(48,planid);
									int done=stmt.executeUpdate();
									if(done>0)
									{
										flag=true;
										System.out.println("fund-updated-5");
									}

								}


			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while update records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in executeFundDetails:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in executeFundDetails Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in executeFundDetails Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in executeFundDetails Method : ");  
		//System.exit(0);
		//return flag;
	}



	public String executeClawBack(String prevclaw,int pol_riy) throws SQLException,NumberFormatException
	{

		//System.out.println(">>>>>>>>>>>>>>"+fund_all);
		logger.debug("Comes to DBConnection in executeClawBack Method : ");
		Connection con=null;
		PreparedStatement stmt =null;
		int i=0;
		ArrayList<String> sep_comma=new ArrayList<String>();
		ArrayList<Integer> ryear=new ArrayList<Integer>();
		ArrayList<String> yrwiseclaw=new ArrayList<String>();
		String [] fund_values;
		StringBuilder strbuff= new StringBuilder();
		// String query=SQLConstants.ReportQry6;
		String datetimedtls=getDTdetails();
		boolean flag=false;
		try
		{
			con=DBHelper.getInstance().getSourceConnection();		
			if(prevclaw!=null)
			{
				//	con.setAutoCommit(true);
				//	stmt=con.prepareStatement(query);
				//	logger.debug("SQL query to be executed : "+query +" with Parameters :-"+datetimedtls);

				String [] seprate=prevclaw.split(",");
				for (String sep: seprate)
					sep_comma.add(sep);
						int yridx=0,clwidx=1,yrm=5;
						for(int k=0;k<sep_comma.size();k++)
						{
							int counter=0;
							for (String year: sep_comma.get(k).split("-"))
							{  		
								if(counter%2==0)
								{
									ryear.add(k,Integer.parseInt(year));
									counter++;
								}
								else
									yrwiseclaw.add(k,year);
							}
						}


						int yearcounter=ryear.size();
						// int yrc=0;
						for(int ry=5;ry<pol_riy;ry++)
						{
							int yrc=0,adder=9;;
							while(yrc<yearcounter)
							{
								if(ry==((ryear.get(yrc)))){
									strbuff.append("&tblClawbackAddition="+yrwiseclaw.get(yrc));
									adder=6;  }
								yrc++;

							}
							if(adder!=6)
								strbuff.append("&tblClawbackAddition= ");
						}

			}		        
			//strbuff.append("&tblClawbackAddition= ");	

		}catch(Exception e)
		{			
			logger.error("Some exception occured in executeClawBack method  : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in executeClawBack Method:- ");   
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in executeClawBack Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in executeClawBack Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in executeClawBack Method : ");     
		return strbuff.toString();
	}

	public static String getDTdetails()
	{
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		return ( sdf.format(cal.getTime()).toString() );
	}

	public String getSeqNextValue(String seqName) throws SQLException
	{
		logger.debug("Comes to DBConnection in getSeqNextValue Method: ");        
		ResultSet rs=null;
		Connection con=null;
		Statement stmt =null;
		String result=null;
		try
		{
			con=DBHelper.getInstance().getSourceConnection();		
			if(con!=null)
			{
				String query="SELECT "+seqName+".NEXTVAL FROM DUAL";
				logger.debug("SQL query to be executed : "+query);
				stmt = con.createStatement();	
				stmt.setQueryTimeout(0);
				rs=stmt.executeQuery(query);
				if(rs.next())
				{
					result=rs.getString(1);
				}			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching next Sequence Value : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				logger.debug("Trying to close Resources DBConnection in getSeqNextValue Method:- ");     
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in getSeqNextValue Method:- ");
			}
			catch(Exception e)
			{				
				logger.error("Exception while closing resources DBConnection in getSeqNextValue Method: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Getting out from DBConnection in getSeqNextValue Method : ");
		return result;
	}    
}