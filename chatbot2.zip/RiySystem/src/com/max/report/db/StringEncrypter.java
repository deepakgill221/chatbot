package com.max.report.db;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

//import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


/**
 * Utility Program for encrypting and decrypting strings
 */
public class StringEncrypter {
	/**
	 * Utility Program for encrypting and decrypting strings
	 */
//	static Logger logger = Logger.getLogger(StringEncrypter.class.getName());

	/**
	 * DESede encryption scheme
	 */
	public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";

	/**
	 * DES encryption scheme
	 */
	public static final String DES_ENCRYPTION_SCHEME = "DES";

	private static final String DEFAULT_ENCRYPTION_KEY = "This is a fairly long phrase used to encrypt";

	private static final String UNICODE_FORMAT = "UTF8";

	private KeySpec keySpec;

	private SecretKeyFactory keyFactory;

	private static final String DEFAULT_ENCRYPTION_KEY1 = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
	
	private Cipher cipher;

        public StringEncrypter() throws Exception
        {
        	this(DES_ENCRYPTION_SCHEME, DEFAULT_ENCRYPTION_KEY1);
        }
	/**
	 * Constructor that internally uses a default encryption key
	 * 
	 * @param encryptionScheme
	 *            the encryption scheme to be used. Pass one of the encryption
	 *            schemes defined in this class
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public StringEncrypter(String encryptionScheme) throws Exception 
	{
		this(encryptionScheme, DEFAULT_ENCRYPTION_KEY);
//		logger.debug("in constructor");
	}

	/**
	 * Constructor that uses the provided encryption key
	 * 
	 * @param encryptionScheme
	 *            the encryption scheme to be used. Pass one of the encryption
	 *            schemes defined in this class
	 * @param encryptionKey
	 *            encryption key to be used. While decrypting a string, the same
	 *            key used for encryption must be used
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public StringEncrypter(String encryptionScheme, String encryptionKey)throws Exception 
	{
//		logger.debug("in constructor");
		if (encryptionKey == null) 
		{
//			logger.error("encryption key was null");
			throw new Exception(new IllegalArgumentException("Encryption key was null"));
		}
		if (encryptionKey.trim().length() < 24) 
		{
			throw new Exception(new IllegalArgumentException("Encryption key was less than 24 characters"));
		}
		try 
		{
			byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);

			if (encryptionScheme.equals(DESEDE_ENCRYPTION_SCHEME)) 
			{
				keySpec = new DESedeKeySpec(keyAsBytes);
			}
			else if (encryptionScheme.equals(DES_ENCRYPTION_SCHEME)) 
			{
				keySpec = new DESKeySpec(keyAsBytes);
			}
			else 
			{
				throw new Exception(new IllegalArgumentException("Encryption scheme not supported: " + encryptionScheme));
			}
			keyFactory = SecretKeyFactory.getInstance(encryptionScheme);
			cipher = Cipher.getInstance(encryptionScheme);
		} 
		catch (InvalidKeyException e) 
		{
			throw new Exception(e);
		}
		catch (UnsupportedEncodingException e) 
		{
			throw new Exception(e);
		}
		catch (NoSuchAlgorithmException e) 
		{
			throw new Exception(e);
		}
		catch (NoSuchPaddingException e) 
		{
			throw new Exception(e);
		}
	}

	/**
	 * Encrypt a string
	 * 
	 * @param unencryptedString
	 *            the string to be encrypted
	 * @return the encrypted string
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public String encrypt(String unencryptedString) throws Exception 
	{
		if ((unencryptedString == null)	|| (unencryptedString.trim().length() == 0)) 
		{
			throw new Exception(new IllegalArgumentException("unencrypted string was null or empty"));
		}
		try 
		{
			SecretKey key = keyFactory.generateSecret(keySpec);
			cipher.init(Cipher.ENCRYPT_MODE, key);

			byte[] cleartext = unencryptedString.getBytes(UNICODE_FORMAT);
			byte[] ciphertext = cipher.doFinal(cleartext);

			BASE64Encoder base64encoder = new BASE64Encoder();

			return base64encoder.encode(ciphertext);
		}
		catch (InvalidKeyException e) 
		{
			throw new Exception(e);
		}
		catch (InvalidKeySpecException e) 
		{
			throw new Exception(e);
		}
		catch (UnsupportedEncodingException e) 
		{
			throw new Exception(e);
		} 
		catch (IllegalStateException e) 
		{
			throw new Exception(e);
		}
		catch (IllegalBlockSizeException e) 
		{
			throw new Exception(e);
		} 
		catch (BadPaddingException e) 
		{
			throw new Exception(e);
		}
	}

	/**
	 * Decrypt a string that was encrypted by this utility earlier
	 * 
	 * @param encryptedString
	 *            the string to be decrypted
	 * @return the decrypted string
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public String decrypt(String encryptedString) throws Exception 
	{
		if ((encryptedString == null) || (encryptedString.trim().length() <= 0)) 
		{
			throw new Exception(new IllegalArgumentException("encrypted string was null or empty"));
		}
		try 
		{
			SecretKey key = keyFactory.generateSecret(keySpec);
			cipher.init(Cipher.DECRYPT_MODE, key);

			BASE64Decoder base64decoder = new BASE64Decoder();
			byte[] cleartext = base64decoder.decodeBuffer(encryptedString);
			byte[] ciphertext = cipher.doFinal(cleartext);

			return bytes2String(ciphertext);
		}
		catch (InvalidKeyException e) 
		{
			throw new Exception(e);
		}
		catch (InvalidKeySpecException e) 
		{
			throw new Exception(e);
		}
		catch (IllegalStateException e) 
		{
			throw new Exception(e);
		}
		catch (IllegalBlockSizeException e) 
		{
			throw new Exception(e);
		}
		catch (BadPaddingException e) 
		{
			throw new Exception(e);
		}
		catch (IOException e) 
		{
			throw new Exception(e);
		}
	}

	private static String bytes2String(byte[] bytes) 
	{
		StringBuffer stringBuffer = new StringBuffer();

		for (int i = 0; i < bytes.length; i++) 
		{
			stringBuffer.append((char) bytes[i]);
		}
		return stringBuffer.toString();
	}

	/**
	 * Use this method for generating encrypted strings.
	 * 
	 * @param args
	 *            Provide the string to be encrypted
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public String getPassword(String args) throws Exception 
	{		
		String encryptionKey = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
		String encryptionScheme = StringEncrypter.DES_ENCRYPTION_SCHEME;
		StringEncrypter encrypter = new StringEncrypter(encryptionScheme,encryptionKey);				
        return encrypter.decrypt(args);		
	}	
	
	public static void main(String args[])
	{		
		try
		{
			
			long startTime = System.currentTimeMillis();
			long elapsedTime = 0L;

			while (elapsedTime < 20*1000) {
			    //perform db poll/check
			    elapsedTime = (new Date()).getTime() - startTime;
			}
			String pwd = new StringEncrypter().getPassword("fYxRS1rfdYarpz7mfoMNzw==");
			System.out.println("Decripted Pwd: "+pwd);
		//	System.out.println("Encrypted IFTISAXIS#2013 = "+new StringEncrypter().encrypt("amsur#Apr12"));
//			pwd = new StringEncrypter().getPassword("1NE5FZH+l5v0nnOuvkPAvQ==");
//			System.out.println("Decripted Pwd: "+pwd);
		//	System.out.println("Encrypted = "+new StringEncrypter().encrypt("2016@jan"));
//			pwd = new StringEncrypter().getPassword("nJR5VYXqMsy8h4ublyKAeQ==");
//			System.out.println("Decripted Pwd: "+pwd);
//			System.out.println("Encrypted = "+new StringEncrypter().encrypt("INQUIZ#DEV"));
//			pwd = new StringEncrypter().getPassword("nZ8cjT0MsDDQsJcNutffNQ==");
//			System.out.println("Decripted Pwd: "+pwd);
			System.out.println("Encrypted = "+new StringEncrypter().encrypt("report247"));
		}
		catch(Exception ex){}
	}
}