package com.max.report.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.max.report.db.DBConnection;
import com.max.report.db.SQLConstants;

public class ReportDAO 
{
	static Logger logger = Logger.getLogger(ReportDAO.class.getName());
	DBConnection dbConnection=new DBConnection();

	public List<String> getReportData()
	{	
		logger.debug("Came inside ReportDAO in getReportData:-");
		List<String> dataArray=null;		
		try
		{
			dataArray=dbConnection.executeQuery(SQLConstants.ReportQry);
		}
		catch(Exception e)
		{			
			logger.error("Error in ReportDAO in getReportData:-"+e,new Throwable());
			e.printStackTrace();
		}				
		logger.debug("Came outside ReportDAO in getReportData:-");
		return dataArray;
	}
	public boolean updateReportData(String policyNum)
	{	
		logger.debug("Came inside updateReportData in ReportDao:-");
		boolean flag=false;		
		try
		{        dbConnection.executeQueryI(SQLConstants.ReportQry5);
		logger.info("Going to update TZRIY Table : Start : with Policy No : "+policyNum);
		flag=dbConnection.executeUpdate(SQLConstants.ReportQry2,policyNum);
		logger.info("Going to update TZRIY Table : End : with Flag : "+flag);
		}
		catch(Exception e)
		{			
			logger.error("Error in ReportDAO in getReportData:-"+e,new Throwable());
			e.printStackTrace();
		}				
		logger.debug("Came outside ReportDAO in getReportData:-");
		return flag;
	}


}