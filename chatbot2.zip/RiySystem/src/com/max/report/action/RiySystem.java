package com.max.report.action;

import java.sql.*;
import java.util.*;

/**
 *
 * @author rs01138
 */
public class RiySystem {
    
    static ResultSet rs=null;
    static Connection con=null;
    static PreparedStatement stmt =null;
    static String URL="jdbc:oracle:thin:@172.23.51.16:1875:aryaing";
    static String USER="kcapuat3";
    static String PWD="Oct#2014";
    
    /** Creates a new instance of RiySystem */
    public RiySystem() { }
    
    public static void main(String [] str)
    {
        RiySystem res = new RiySystem();
        res.riyfunds();
    }
    
    //String polnmbr Hashtable
    
    public void  riyfunds()  //String polnmbr,String riy_year)         
    {
      Hashtable hasTable=new Hashtable();
      Hashtable hasTable2=new Hashtable();
      String strbuff= new String();
      String polnmbr="777074667";
      String riy_year="5";
      String planid=null;
      
      try
      {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        con = DriverManager.getConnection(URL, USER, PWD);
       if(con!=null)
        {
          String query="select  fund_a1 ,fund_a2 ,fund_a3 ,fund_a4 ,fund_a5 , alloc_value1 , alloc_value2 , alloc_value3 , alloc_value4 ,alloc_value5 , nav_amount1 , nav_amount2 , nav_amount3 , nav_amount4 ,nav_amount5 , nav_crnt_amount1 , nav_crnt_amount2 , nav_crnt_amount3 , nav_crnt_amount4 ,nav_crnt_amount5 ,IFTSTRING,plan_id  from  fund_sepration where trim(polid)=? and trim(RIYYEAR)=?";
          stmt=con.prepareStatement(query);
          stmt.setString(1,polnmbr);
          stmt.setString(2,riy_year);
          rs=stmt.executeQuery();
          if(rs!=null)
	  {
              HashMap map=new HashMap();
              map.put("UEBL1","BalanceFRate@@##BFShdwNAVIncpt@@##BFShdwNAVRIY");
              map.put("UECN1","SecurePFRate@@##CFShdwNAVIncpt@@##CFShdwNAVRIY");
              map.put("UEGR1","GrowthFRate@@##GFShdwNAVIncpt@@##GFShdwNAVRIY");
              map.put("UEPEQ","GrowthSRate@@##GSFShdwNAVIncpt@@##GSFShdwNAVRIY");
              map.put("UEDB1","SecureFRate@@##SFShdwNAVIncpt@@##SFShdwNAVRIY");
               HashMap map2=new HashMap();
              map2.put("UEPWA","PensionMaxFund@@##SFShdwNAVIncpt@@##SFShdwNAVRIY");
              map2.put("UEPWC","PensionPreFund@@##CFShdwNAVIncpt@@##CFShdwNAVRIY");
              
              ArrayList mapArrayList=new ArrayList();
              mapArrayList.add("BalanceFRate");
              mapArrayList.add("SecurePFRate");
              mapArrayList.add("GrowthFRate");
              mapArrayList.add("GrowthSRate");
              mapArrayList.add("SecureFRate");
              ArrayList mapArrayList2=new ArrayList();
              mapArrayList2.add("PensionMaxFund");
              mapArrayList2.add("PensionPreFund");
                			       
              String temp="";
              String[] strtoken=null;
              String fundval,fundname,allocval,navamt,navcrtamt;
              
              String temp2="";
              String[] strtoken2=null;
              String fundval2,fundname2,allocval2,navamt2,navcrtamt2;
              
                if(rs.next())
		 {
                  
                   strbuff=rs.getString("IFTSTRING");
                    planid=rs.getString("plan_id");
                   hasTable.put("iftisstring",strbuff );
                  if(!planid.equalsIgnoreCase("110")) 
                  for(int i=1;i<6;i++)
                  {
                   fundval=isNullThanBlank(rs.getString("fund_a"+i));
                   //System.out.println(">>>>>>>"+fundval);
                    if(!"".equalsIgnoreCase(fundval) && map.get(fundval)!=null)
                      {
                      // System.out.println("@@@@@@@@@@"+fundval);
                       fundname=(String)map.get(fundval);
                       allocval=isNullThanBlank(rs.getString("alloc_value"+i));
                       navamt=isNullThanBlank(rs.getString("nav_amount"+i));
                       navcrtamt=isNullThanBlank(rs.getString("nav_crnt_amount"+i));
                       strtoken=fundname.split("@@##");
                                        
                         hasTable.put(strtoken[0], allocval);
                         hasTable.put(strtoken[1], navamt);
                         hasTable.put(strtoken[2], navcrtamt);
                         mapArrayList.remove(mapArrayList.indexOf(strtoken[0]));
                      }
                    }
                  else
                  {
                    for(int i=1;i<3;i++)
                    {
                      fundval2=isNullThanBlank(rs.getString("fund_a"+i)); 
                      if(!"".equalsIgnoreCase(fundval2)&& map2.get(fundval2)!=null)
                      {
                       fundname2=(String)map2.get(fundval2);
                       allocval2=isNullThanBlank(rs.getString("alloc_value"+i));
                       navamt2=isNullThanBlank(rs.getString("nav_amount"+i));
                       navcrtamt2=isNullThanBlank(rs.getString("nav_crnt_amount"+i));
                       strtoken2=fundname2.split("@@##");
                                        
                         hasTable2.put(strtoken2[0], allocval2);
                         hasTable2.put(strtoken2[1], navamt2);
                         hasTable2.put(strtoken2[2], navcrtamt2);
                         System.out.println(">>>>>>"+strtoken2[0]);
                         mapArrayList2.remove(mapArrayList2.indexOf(strtoken2[0]));
                      }
                    }
                  }       
                   }
              
              
              if(mapArrayList != null && !planid.equalsIgnoreCase("110"))
              {
                for(int i =0;i<mapArrayList.size();i++)
                hasTable.put(mapArrayList.get(i), "0");
              }
              if(mapArrayList2 != null && planid.equalsIgnoreCase("110")) 
              {
                  for(int i =1;i<=mapArrayList2.size();i++)
                 hasTable2.put(mapArrayList2.get(i), "0");
              }
                       
              
                           System.out.println("hasTable::"+hasTable2.toString());
                                if(!hasTable.isEmpty()){
                                // URLStringBuilder.processFile(policyNumber, path, URLStringBuilder.procesIFTIS(hasTable, new StringBuffer(), new StringBuffer()));
			        }
	      }			
          
          }
      }catch(Exception ex)
      {
          System.out.println("Exception in riyfunds method-"+ex.getMessage());
          ex.printStackTrace();
      }
      finally
		{
			try
			{
		    	//logger.debug("Trying to close Resources DBConnection in ExecuteQuery Method:- ");  
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		    	//logger.debug("Successfully closed Resources DBConnection in ExecuteQuery Method:- ");  
			}
			catch(Exception e)
			{				
				//logger.error("SQL exception while closing resources DBConnection in ExecuteQuery Method: "+e,new Throwable());
				e.printStackTrace();
			}
        }
    //  if(!planid.equalsIgnoreCase("110"))
    //  return hasTable;
   //   else
     //    return hasTable2;
    }
       private static String isNullThanBlank(String str)
       {
      String temp="";
      temp=str;
      temp=temp==null?"":temp.trim();
      return temp;
       }
       
  }