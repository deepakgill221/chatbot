package com.max.report.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import com.max.report.db.DBConnection;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.max.report.dao.ReportDAO;

public class ETLReportBatch 
{
	static Logger logger=null;
    static String status="";
    static String st_tm="";
    static String ed_tm="";
    static String flag="";
    static String  flagcopy="";
	public static void main(String[] args) 
	{
		ETLReportBatch etlReportBatch=new ETLReportBatch();
		etlReportBatch.start();
	}
	
	public void start()
	{
		try
		{
			initializing();
			logger.debug("Came inside Batch Initialization and Starting Policy processing:-");	
			getDetails();
		}
		catch(Exception e)
		{
			logger.error("Error while initializing batch:: " +e,new Throwable());
			e.printStackTrace();
		}					
	}
	public static String starttime()
    {  	String start_time=DBConnection.getDTdetails();
    	return start_time;
    }
    public static String endtime()
    {  	String end_time=DBConnection.getDTdetails();
    	return end_time;
    }
	
	private static void initializing() throws IOException 
	{		
		ResourceBundle rb = ResourceBundle.getBundle("com.max.report.resources.ApplicationResources");			
		String log4j = rb.getString("com.max.report.log4j");
		PropertyConfigurator.configure(log4j);
		System.out.println("log4j :: " + log4j);
		logger = Logger.getLogger(ETLReportBatch.class.getName());
	}
	
	private static void getDetails() throws IOException
	{		
		boolean finalFlag;
		logger.debug("Came inside for getting policy number from database:-");
		try
		{
			String fvalue=DBConnection.checkFlag();
			if(fvalue.equalsIgnoreCase("R"))
			{
				logger.info("Batch is already in running---");
				System.exit(1);
			}
			List<String> polId=new ArrayList<String>();
			ReportDAO reportDAO=new ReportDAO();
			polId=reportDAO.getReportData();
			logger.debug("policy"+polId+"fetched from table");
			IllustrationBuilder illus=new IllustrationBuilder();

			int i=0;
			st_tm=ETLReportBatch.starttime();
			flag="R";
			DBConnection.updateFlag(flag);
			int polcount=polId.size();
			System.out.println("Total Policy count-"+polcount);
			for(i=0;i<polId.size();)
			{
				System.out.println("Policy No->"+polcount);
				status=illus.processPolicy(polId.get(i),DBConnection.riyyear.get(i));
				if(status.equals("|Y|"))
				{
					System.out.println(">>>Action Performed Successfully for policy-"+polId.get(i));
					logger.info("Illustration generated for Policy"+polId.get(i));
					finalFlag=reportDAO.updateReportData(polId.get(i));
					if(finalFlag==true)
						logger.info("Table updated for Policy"+polId.get(i));
				}
				else if(status.equals("|E|"))
				{
					logger.info("URL is not responding---- ");
					System.out.println("URL is not responding---->"+polId.get(i));
				}
				else
				{
					System.out.println("Data not found for policy"+polId.get(i));	
				}
				i++;
				polcount--;
			}
			ed_tm=ETLReportBatch.endtime();
			DBConnection.executePendingDetails(st_tm, ed_tm, polId.size());
			flag="C";
			DBConnection.updateFlag(flag);
			logger.info("Flag is updated to Completed Status---- ");
		}catch(Exception ex)
		{
			flag="C";
			//DBConnection.updateFlag(flag);
			logger.error("Exception caught in processpolicy method:-");	
		}
		finally
		{
			try
			{
				flag="C";
				DBConnection.updateFlag(flag);
				logger.debug("Trying to exit from batch:- ");   
				if(status.equals("|Y|"))
				{
					logger.debug("Iftis hit was successfull:-");
					//System.exit(1);
				}
				else
				{
					logger.debug("Something messed up-");	
					//System.exit(2);
				}

			}
			catch(Exception e)
			{				
				logger.error("Something wrong in exiting Batch-------: "+e,new Throwable());
				e.printStackTrace();
			}
		}
		logger.debug("Going outside after generating pdf:-");
	}
}