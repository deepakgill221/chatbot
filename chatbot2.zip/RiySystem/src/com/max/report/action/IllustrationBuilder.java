package com.max.report.action;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.HashMap;
import com.max.report.db.*;

import org.apache.log4j.Logger;

//import com.max.report.dao.ReportDAO;

public class IllustrationBuilder {
	static Logger logger = Logger.getLogger(IllustrationBuilder.class.getName());
	static ResourceBundle res=ResourceBundle.getBundle("com.max.report.resources.ApplicationResources");
	DBConnection dbconobj= new DBConnection();
	
	
	public static void main(String [] args) throws Exception
	{
		IllustrationBuilder obj= new 	IllustrationBuilder();
		obj.processPolicy("139558324","2011");
	}
	
	public  String processPolicy(String pol_id,String riyyear)throws Exception 
	{
		String returnFlag=null;
		logger.debug("Came inside processPolicy for url hit:-");
		//System.out.println("\nSend Http POST request");
		try
		{
		returnFlag=sendPost(pol_id,riyyear);
		}catch(Exception ex)
		{
	    logger.error("Exception raised processing sendpost method:-");	
		ex.printStackTrace();
		}
		logger.debug("Came after processing sendpost method:-");
        return returnFlag;
	}
	
	// HTTP POST request
	public  String sendPost(String polid,String riy) throws Exception {
        
		StringBuffer strbuff2= new StringBuffer();
		String url = res.getString("ABPAPIURL");
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		logger.debug("open connection  to url:-"+url);
		//add reuqest header
		String USER_AGENT="Chrome";
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", USER_AGENT);
		con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		logger.debug("sending post request to url:-"+url+"for policy num"+polid);
		String urlParameters = "policyNumber="+polid.trim()+"&path=D:\\&riy="+riy;
	//	String urlParameters = "policyNumber="+polid.trim()+"&path=D:\\";
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Request parameters : " + urlParameters);

		// Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(urlParameters);
		wr.flush();
		wr.close();

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Request parameters : " + urlParameters);
		logger.debug("url parameter :-"+urlParameters);
		strbuff2.append("Response Code-"+responseCode);
		System.out.println(strbuff2.toString());
		logger.debug("Response code :-"+responseCode);
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//print result
		strbuff2.append("Status-"+response.toString()+" data not found for Policy-"+polid);
		String resparameter=response.toString();
		//dbconobj.executeAuditDetails(polid,strbuff2.toString());
		System.out.println(response.toString());
		return response.toString();

	}
}
