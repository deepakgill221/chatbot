package com.max.report.action;

import java.io.Serializable;


public class IllustrationDTO implements Serializable
{
   
	private static final long serialVersionUID = 6965906090487852496L;
	private boolean successful;
    //private InputStream illustration;
	private byte[] illustration;
    private String message;
    private char[] headerXML;
    //  komal
    private char[] fundXML;
    
    private char[]uasfyXML;//Added by Sandeep 30/05/2014

    
    public char[] getUasfyXML() {
		return uasfyXML;
	}

	public void setUasfyXML(char[] uasfyXML) {
		this.uasfyXML = uasfyXML;
	}

/**
	 * @return Returns the fundXML.
	 */
	public char[] getFundXML() {
		return fundXML;
	}

	/**
	 * @param fundXML The fundXML to set.
	 */
	public void setFundXML(char[] fundXML) {
		this.fundXML = fundXML;
	}

/**
	 * @return Returns the headerXML.
	 */
	public char[] getHeaderXML() {
		return headerXML;
	}

	/**
	 * @param headerXML The headerXML to set.
	 */
	public void setHeaderXML(char[] headerXML) {
		this.headerXML = headerXML;
	}

	//    public void setIllustration(InputStream illustration)
//    {
//        this.illustration = illustration;
//    }
    public void setIllustration(byte[] illustration)
    {
        this.illustration = illustration;
    }
    
    public void setMessage(String message)
    {
        this.message = message;
    }

    public void setSuccessful(boolean successful)
    {
        this.successful = successful;
    }
    
    public byte[] getIllustration()
    {
        return this.illustration;
    }
    
    public String getMessage()
    {
        return this.message;
    }
    
    public boolean isSuccessful()
    {
        return this.successful;
    }
}
