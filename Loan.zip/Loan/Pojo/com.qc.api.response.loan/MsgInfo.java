package com.qc.api.response.loan;

import java.io.Serializable;

import com.qc.dto.ERRORSTATUS;

public class MsgInfo implements Serializable
{
 
	private static final long serialVersionUID = 4791741636298196030L;

	private String msgDescription;

    private String msgCode;

    private ERRORSTATUS msg;

    public String getMsgDescription ()
    {
        return msgDescription;
    }

    public void setMsgDescription (String msgDescription)
    {
        this.msgDescription = msgDescription;
    }

    public String getMsgCode ()
    {
        return msgCode;
    }

    public void setMsgCode (String msgCode)
    {
        this.msgCode = msgCode;
    }

    
    public ERRORSTATUS getMsg() {
		return msg;
	}

	public void setMsg(ERRORSTATUS msg) {
		this.msg = msg;
	}

	@Override
    public String toString()
    {
        return "MsgInfo {msgDescription = "+msgDescription+", msgCode = "+msgCode+", msg = "+msg+"}";
    }
}