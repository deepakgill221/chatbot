package com.qc.api.response.loan;

import java.io.Serializable;

import com.qc.api.request.loan.Header;

public class Response implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 7285012191474755838L;

	private Payload payload;

    private MsgInfo msgInfo;

    private Header header;

    public Payload getPayload ()
    {
        return payload;
    }

    public void setPayload (Payload payload)
    {
        this.payload = payload;
    }

    public MsgInfo getMsgInfo ()
    {
        return msgInfo;
    }

    public void setMsgInfo (MsgInfo msgInfo)
    {
        this.msgInfo = msgInfo;
    }

    public Header getHeader ()
    {
        return header;
    }

    public void setHeader (Header header)
    {
        this.header = header;
    }

    @Override
    public String toString()
    {
        return "Response {payload = "+payload+", msgInfo = "+msgInfo+", header = "+header+"}";
    }
}
			
