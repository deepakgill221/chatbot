package com.qc.api.response.loan;

import java.io.Serializable;
import java.util.List;

public class Payload implements Serializable
{
	private static final long serialVersionUID = 8712598917535243691L;
	
	private String lsirReturnCd;
	private String mirReturnCd;
	private String policyNo;
	private String mirPolicyIdSfx;
	private String mirDvEffDt;
	private String mirDvLoanRepayAmt;
	private String mirDvIntDueAmt;
	private List<TableMirLoanIntYtdAmt> tableMirLoanIntYtdAmt;
    private String mirDvMaxLoanAmt;

    private String severity;

    public String getMirDvMaxLoanAmt ()
    {
        return mirDvMaxLoanAmt;
    }

    public void setMirDvMaxLoanAmt (String mirDvMaxLoanAmt)
    {
        this.mirDvMaxLoanAmt = mirDvMaxLoanAmt;
    }

    public String getMirPolicyIdSfx ()
    {
        return mirPolicyIdSfx;
    }

    public void setMirPolicyIdSfx (String mirPolicyIdSfx)
    {
        this.mirPolicyIdSfx = mirPolicyIdSfx;
    }

    public String getMirReturnCd ()
    {
        return mirReturnCd;
    }

    public void setMirReturnCd (String mirReturnCd)
    {
        this.mirReturnCd = mirReturnCd;
    }

    public String getLsirReturnCd ()
    {
        return lsirReturnCd;
    }

    public void setLsirReturnCd (String lsirReturnCd)
    {
        this.lsirReturnCd = lsirReturnCd;
    }

    public String getPolicyNo ()
    {
        return policyNo;
    }

    public void setPolicyNo (String policyNo)
    {
        this.policyNo = policyNo;
    }

    public String getSeverity ()
    {
        return severity;
    }

    public void setSeverity (String severity)
    {
        this.severity = severity;
    }

    public List<TableMirLoanIntYtdAmt> getTableMirLoanIntYtdAmt() {
		return tableMirLoanIntYtdAmt;
	}

	public void setTableMirLoanIntYtdAmt(List<TableMirLoanIntYtdAmt> tableMirLoanIntYtdAmt) {
		this.tableMirLoanIntYtdAmt = tableMirLoanIntYtdAmt;
	}

	public String getMirDvEffDt ()
    {
        return mirDvEffDt;
    }

    public void setMirDvEffDt (String mirDvEffDt)
    {
        this.mirDvEffDt = mirDvEffDt;
    }

    public String getMirDvIntDueAmt ()
    {
        return mirDvIntDueAmt;
    }

    public void setMirDvIntDueAmt (String mirDvIntDueAmt)
    {
        this.mirDvIntDueAmt = mirDvIntDueAmt;
    }

    public String getMirDvLoanRepayAmt ()
    {
        return mirDvLoanRepayAmt;
    }

    public void setMirDvLoanRepayAmt (String mirDvLoanRepayAmt)
    {
        this.mirDvLoanRepayAmt = mirDvLoanRepayAmt;
    }

    @Override
    public String toString()
    {
        return "Payload {mirDvMaxLoanAmt = "+mirDvMaxLoanAmt+", mirPolicyIdSfx = "+mirPolicyIdSfx+", mirReturnCd = "+mirReturnCd+", lsirReturnCd = "+lsirReturnCd+", policyNo = "+policyNo+", severity = "+severity+", tableMirLoanIntYtdAmt = "+tableMirLoanIntYtdAmt+", mirDvEffDt = "+mirDvEffDt+", mirDvIntDueAmt = "+mirDvIntDueAmt+", mirDvLoanRepayAmt = "+mirDvLoanRepayAmt+"}";
    }
}
			
