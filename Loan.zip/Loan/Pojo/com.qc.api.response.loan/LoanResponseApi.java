package com.qc.api.response.loan;

import java.io.Serializable;

public class LoanResponseApi implements Serializable
{
	private static final long serialVersionUID = -4773406005277014145L;
	
	private Response response;

    public Response getResponse ()
    {
        return response;
    }

    public void setResponse (Response response)
    {
        this.response = response;
    }

    @Override
    public String toString()
    {
        return "LoanResponseApi {response = "+response+"}";
    }
}
			
	