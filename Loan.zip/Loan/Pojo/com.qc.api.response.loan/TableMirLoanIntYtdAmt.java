package com.qc.api.response.loan;

import java.io.Serializable;

public class TableMirLoanIntYtdAmt implements Serializable
{
   
	private static final long serialVersionUID = -5642747314818333856L;
	
	private String mirLoanIntYtdAmt;

    public String getMirLoanIntYtdAmt ()
    {
        return mirLoanIntYtdAmt;
    }

    public void setMirLoanIntYtdAmt (String mirLoanIntYtdAmt)
    {
        this.mirLoanIntYtdAmt = mirLoanIntYtdAmt;
    }

    @Override
    public String toString()
    {
        return "TableMirLoanIntYtdAmt [mirLoanIntYtdAmt = "+mirLoanIntYtdAmt+"]";
    }
}
	