package com.qc.api.request.loan;

import java.io.Serializable;

public class Request implements Serializable
{
	private static final long serialVersionUID = -1519294131087321345L;
	
	private Header header;
    private Payload payload;

    public Header getHeader ()
    {
        return header;
    }

    public void setHeader (Header header)
    {
        this.header = header;
    }


    public Payload getPayload ()
    {
        return payload;
    }

    public void setPayload (Payload payload)
    {
        this.payload = payload;
    }

    @Override
    public String toString()
    {
        return "Request {payload = "+payload+", header = "+header+"}";
    }
}