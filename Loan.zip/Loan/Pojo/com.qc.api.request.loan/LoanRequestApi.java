package com.qc.api.request.loan;

import java.io.Serializable;

public class LoanRequestApi implements Serializable
{
	private static final long serialVersionUID = 2842153820679655759L;
	
	private Request request;

    public Request getRequest ()
    {
        return request;
    }

    public void setRequest (Request request)
    {
        this.request = request;
    }

    @Override
    public String toString()
    {
        return "LoanRequestApi {request = "+request+"}";
    }
}