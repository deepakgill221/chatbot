package com.qc.api.request.loan;

import java.io.Serializable;

public class Payload implements Serializable
{
	private static final long serialVersionUID = -5317372173570488442L;

	private String processClassId;
	private String statisticLogging;
    private String mirCoId;
    private String localeId;
    private String policyNo;

    public String getLocaleId ()
    {
        return localeId;
    }

    public void setLocaleId (String localeId)
    {
        this.localeId = localeId;
    }

    public String getPolicyNo ()
    {
        return policyNo;
    }

    public void setPolicyNo (String policyNo)
    {
        this.policyNo = policyNo;
    }

    public String getMirCoId ()
    {
        return mirCoId;
    }

    public void setMirCoId (String mirCoId)
    {
        this.mirCoId = mirCoId;
    }

    public String getStatisticLogging ()
    {
        return statisticLogging;
    }

    public void setStatisticLogging (String statisticLogging)
    {
        this.statisticLogging = statisticLogging;
    }

    public String getProcessClassId ()
    {
        return processClassId;
    }

    public void setProcessClassId (String processClassId)
    {
        this.processClassId = processClassId;
    }

    @Override
    public String toString()
    {
        return "Payload {localeId = "+localeId+", policyNo = "+policyNo+", mirCoId = "+mirCoId+", statisticLogging = "+statisticLogging+", processClassId = "+processClassId+"}";
    }
}