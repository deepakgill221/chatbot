package com.qc.api.request.loan;

import java.io.Serializable;

public class Header implements Serializable
{
	private static final long serialVersionUID = -712486775530559056L;

	private String soaCorrelationId;

    private String soaAppId;

    public String getSoaCorrelationId ()
    {
        return soaCorrelationId;
    }

    public void setSoaCorrelationId (String soaCorrelationId)
    {
        this.soaCorrelationId = soaCorrelationId;
    }

    public String getSoaAppId ()
    {
        return soaAppId;
    }

    public void setSoaAppId (String soaAppId)
    {
        this.soaAppId = soaAppId;
    }

    @Override
    public String toString()
    {
        return "Header {soaCorrelationId = "+soaCorrelationId+", soaAppId = "+soaAppId+"}";
    }
}