package com.qc.api.loan.service;

import com.qc.api.request.loan.Payload;
import com.qc.api.response.loan.LoanResponseApi;

public interface LoanService 
{
	public LoanResponseApi getLoanDetails(Payload requestPayload );

}
