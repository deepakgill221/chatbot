package com.qc.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.qc.api.loan.service.LoanService;
import com.qc.api.request.loan.Header;
import com.qc.api.request.loan.LoanRequestApi;
import com.qc.api.request.loan.Payload;
import com.qc.api.response.loan.LoanResponseApi;
import com.qc.api.response.loan.MsgInfo;
import com.qc.dto.ERRORSTATUS;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = "/entity/api", produces = MediaType.APPLICATION_JSON_VALUE)
@Api(value="MliLoan", description="MliLoan service for maxlifeinsurance.com",tags = {"MliLoan"})
public class LoanController 
{
	private static Logger logger = LogManager.getLogger(LoanController.class);

	@Autowired 
	LoanService loanService ;
	
	@Autowired 
	DozerBeanMapper dozerBeanMapper;

	@SuppressWarnings("unused")
	@ApiOperation(notes = "Service for Loan details internally calling enginium backend service", value = "processClassId | localeId | policyNo", nickname = "Loan Service V1")
	//@RequestMapping(value = "/v1/mliloan", method = RequestMethod.POST ,consumes = { "application/json" }, produces = { "application/json" })
	@PostMapping(path = "/v1/mliloan")
	
	public LoanResponseApi getMliLoanRequest(@Valid @RequestBody LoanRequestApi apiRequest) throws JsonProcessingException 
	{
		logger.info("LoanController || getMliLoanRequest || STARTS");
		
		try 
		{
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info(" LoanRequestApi || API_REQUEST :: "+ow.writeValueAsString(apiRequest));
		} catch (JsonProcessingException jsonExc) 
		{
			logger.error(" LoanController || getMliLoanRequest() || Exception while parsing Request :: "+ jsonExc);
		}

		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		LoanResponseApi response = null;
		
		try
		{
			ThreadContext.push("/v1/mliloan : "+System.currentTimeMillis());
			if(apiRequest != null && apiRequest.getRequest().getHeader()!=null && apiRequest.getRequest().getPayload() != null)
			{
				header = apiRequest.getRequest().getHeader();
				ThreadContext.push(header.getSoaCorrelationId());
				Payload requestPayload = apiRequest.getRequest().getPayload();
				
				
				if((requestPayload.getProcessClassId()!=null && !requestPayload.getProcessClassId().isEmpty())
					 &&	(requestPayload.getLocaleId()!=null && !requestPayload.getLocaleId().isEmpty()) )
				{
					
				
					response = loanService.getLoanDetails(requestPayload);
					//clientApiResponse = mliPolicyService.getMliPlicyData(mliPolicyRequest);
					//clientApiResponse = new ClientApiResponse(apiRequest.getRequest().getHeader(), clientApiResponse.getMsgInfo(),clientApiResponse.getPayload());
					//response.setResponse(clientApiResponse);
				}
				else
				{
					logger.info("Invalid Request Json : client ID is null or blank or service list is null or blank ");
					msgInfo.setMsgCode("500");
					msgInfo.setMsg(ERRORSTATUS.FAILURE);
					msgInfo.setMsgDescription("Please verify your request json it could not be empty and invalid key!");
					//clientApiResponse = new ClientApiResponse(apiRequest.getRequest().getHeader(), msgInfo);
					//response.setResponse(clientApiResponse);
				}
			}
			else
			{
				logger.info("Invalid Request Json : Empty or Null ");
				msgInfo.setMsgCode("500");
				msgInfo.setMsg(ERRORSTATUS.FAILURE);
				msgInfo.setMsgDescription("Please verify your request json it could not be empty and invalid key!");
				//clientApiResponse = new ClientApiResponse(apiRequest.getRequest().getHeader(), msgInfo);
				//response.setResponse(clientApiResponse);
			}
		}
		catch (Exception exception) 
		{
			logger.error("LoanController || getMliLoanRequest() || Exception while accessing values from JSON :: "+exception);
			msgInfo.setMsgCode("500");
			msgInfo.setMsg(ERRORSTATUS.FAILURE);
			msgInfo.setMsgDescription("Please verify your request json! : ");
			//clientApiResponse = new ClientApiResponse(apiRequest.getRequest().getHeader(), msgInfo);
			//response.setResponse(clientApiResponse);
		}
		finally
		{
			try 
			{
				ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
				logger.info("LoanResponseApi || API_RESPONSE :: "+ow.writeValueAsString(response));
			} 
			catch (JsonProcessingException e1) 
			{
				logger.error("LoanController || getMliLoanRequest() || Exception while converting JSON response :: : "+e1);
			}
			logger.info("LoanController || getMliLoanRequest || ENDS");
			ThreadContext.pop();
			ThreadContext.pop();
		}
		
		return response;
	}
	
	
	public static void main(String[] args) throws JsonProcessingException {
		
		Gson g = new Gson();
		
		
		
		StringBuilder buffer = new StringBuilder();
		buffer.append("{");
		buffer.append("\"request\": {");
		buffer.append("\"header\": {");
		buffer.append("\"soaCorrelationId\": \"1234567890\",");
		buffer.append("\"soaAppId\": \"MLIING\"");
		buffer.append("},");
		buffer.append("\"payload\": {");
		buffer.append("\"processClassId\": \"BF6982Headless\",");
		buffer.append("\"statisticLogging\": \"true\",");
		buffer.append("\"mirCoId\": \"CP\",");
		buffer.append("\"localeId\": \"E\",");
		buffer.append("\"policyNo\": \"225742030\"");
		buffer.append("}}}");
		
		String jsonString = buffer.toString();
		
		LoanRequestApi apiRequest = g.fromJson(jsonString, LoanRequestApi.class);
		new LoanController().getMliLoanRequest(apiRequest);
		
	}
}

 

