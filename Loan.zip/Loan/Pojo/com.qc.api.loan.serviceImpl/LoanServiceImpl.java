package com.qc.api.loan.serviceImpl;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.api.loan.service.LoanService;
import com.qc.api.request.loan.Payload;
import com.qc.api.response.loan.LoanResponseApi;

@Service
public class LoanServiceImpl implements LoanService{

	private static Logger logger = LogManager.getLogger(LoanServiceImpl.class);
	@Autowired Environment env;
	
	
	@SuppressWarnings("unused")
	@Override
	public LoanResponseApi getLoanDetails(Payload requestPayload)
	{
		String soapAction = null;
		String xmlbackendInput = backendRequest(requestPayload);
		String outputString= getResultString(xmlbackendInput,soapAction);
		
		if(outputString!=null && !outputString.equalsIgnoreCase(""))
		{
		JSONObject xmlJSONObj = XML.toJSONObject(outputString);
		
		
		}
		return null;
	}

	
	@SuppressWarnings("unused")
	private String backendRequest(Payload payloadParams)
	{
		String localeId = payloadParams.getLocaleId();
		String processClassId = payloadParams.getProcessClassId();
		String mirCoId = payloadParams.getMirCoId();
		String policyNo =  payloadParams.getPolicyNo();
		String statisticLogging = payloadParams.getStatisticLogging();
		
		StringBuilder builder = new StringBuilder();
		builder.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://schema/webservices.elink.solcorp.com\">");
				   builder.append("<soapenv:Header/>");
				   builder.append("<soapenv:Body>");
				      builder.append("<web:callFlowRequest>");
				         builder.append("<ProcessClassID>"+(processClassId)+"</ProcessClassID>");
				         builder.append("<!--Optional:-->");
				         builder.append("<StatisticLogging>yes</StatisticLogging>");
				         builder.append("<!--Optional:-->");
				         builder.append("<BAMID></BAMID>");
				         builder.append("<MIR-USER-ID></MIR-USER-ID>");
				         builder.append("<MIR-USER-PSWD-TXT></MIR-USER-PSWD-TXT>");
				         builder.append("<MIR-CO-ID>"+(mirCoId)+"</MIR-CO-ID>");
				         builder.append("<LocaleID>"+(localeId)+"</LocaleID>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-DV-INT-TRAD-ID></MIR-DV-INT-TRAD-ID>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-DV-INT-MACH-IP></MIR-DV-INT-MACH-IP>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-DV-POL-OR-CLI-ID></MIR-DV-POL-OR-CLI-ID>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-DV-USER-ID></MIR-DV-USER-ID>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-POL-ID-BASE>"+(policyNo)+"</MIR-POL-ID-BASE>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-POL-ID-SFX></MIR-POL-ID-SFX>");
				         builder.append("<!--Optional:-->");
				         builder.append("<MIR-DV-EFF-DT></MIR-DV-EFF-DT>");
				      builder.append("</web:callFlowRequest>");
				   builder.append("</soapenv:Body>");
				builder.append("</soapenv:Envelope>");
				
				return builder.toString();
		
	}
	
	public String getResultString(String xmlInput,String SOAPAction)
	{
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		URL url =null;
		URLConnection connection =null;
		HttpURLConnection httpConn = null;
		String responseString = "";	
		OutputStream out = null;
		InputStreamReader isr =null;
		BufferedReader in =null;
		String outputString = "";
		byte[] buffer = null;
		byte[] b =null;
		try
		{   
			
			url = new URL(env.getProperty("app.loan.backend.url"));
			connection = url.openConnection();
			httpConn = (HttpURLConnection) connection;
			buffer=new byte[xmlInput.length()];
			buffer = xmlInput.getBytes();
			bout.write(buffer);
			b=bout.toByteArray();		
			httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
			httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
			httpConn.setRequestProperty("SOAPAction", SOAPAction);
			httpConn.setRequestMethod("POST");
			httpConn.setConnectTimeout(Integer.parseInt(env.getProperty("queryTimeout.loan.api")));
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);
			logger.info("Request sent to Backend Loan Service:-");
			
			out = httpConn.getOutputStream();
			out.write(b);
			logger.info("Response Recieved from Backend Loan Service:-");
		}
		catch(Exception e)
		{
			logger.error("Connection doesn't created"+e,new Throwable());

		}				
		try 
		{
			isr = new InputStreamReader(httpConn.getInputStream());
			in = new BufferedReader(isr);
			while ((responseString = in.readLine()) != null) 
			{
				outputString = outputString + responseString;
			}	
		} 
		catch (IOException e) 
		{
			logger.error("Error While Getting response from the Connection:-"+e,new Throwable());

		}
		finally
		{
			url=null;
			connection=null;

			if(httpConn!=null)
			{
				httpConn.disconnect();
			}  
			if(isr!=null)
			{
				try 
				{
					isr.close();
				} 
				catch (IOException e) 
				{				
					logger.error("error occured when InputStreamReader closing");;
				}				
			}
			if(in!=null)
			{
				try 
				{
					in.close();
				} 
				catch (IOException e)
				{				
					logger.error("error occured when bufferreader closing");
				}				
			}
			if(out!=null)
				try 
			{
					out.close();
			} 
			catch (IOException e) 
			{
				logger.error("error occured when OutputStream closing");
			}				
		}
		logger.debug("Output Generated from CRM Service is:-::::::"+outputString);
		return outputString;
	}
	
}
