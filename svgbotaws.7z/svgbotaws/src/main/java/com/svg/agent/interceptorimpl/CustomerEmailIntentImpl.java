package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.interceptor.CustomerEmailIntent;
import com.svg.agent.service.CreateLeadService;
import com.svg.agent.service.GetLeadService;
@Service
public class CustomerEmailIntentImpl implements CustomerEmailIntent 
{
	@Autowired
	private CreateLeadService createLeadService;
	@Autowired
	private GetLeadService getLeadService;
	@Autowired
	private BeanProperty bean;
	String speech="";
	@Override
	public String customerEmailIntent(Map<String, Map<String, String>> map, String sessionId) {
		if(map.containsKey(sessionId))
		{
			//speech=map.get(sessionId+"Msg").get("email");
			
			/**********************Create Lead API call start*********************************/
			
			String responseEquote = createLeadService.createLeadAPI(map, sessionId);

			JSONObject objectEquote = new JSONObject(responseEquote.toString());
			String soaStatusCode=objectEquote.getJSONObject("response").getJSONObject("responseData").get("soaStatusCode").toString();
			JSONObject resEquote=(JSONObject)objectEquote.getJSONObject("response").getJSONObject("responseData").getJSONArray("createLeadWithRiderResponse").get(0);
			String leadStatus=resEquote.getString("leadStatus");
			
			//int soastatus=Integer.parseInt(soaStatusCode);
			//if(soastatus==200){
				if(leadStatus.contains("The reason for the Lead failure is LeadSource Id")){
					
					speech=map.get(sessionId+"Msg").get("smokerError");
				}
					
				else{	
				//JSONObject resEquote=(JSONObject)objectEquote.getJSONObject("response").getJSONObject("responseData").getJSONArray("createLeadWithRiderResponse").get(0);
				String leadId=resEquote.get("leadID")+"";
				map.get(sessionId).put("leadId", leadId);
				String responseleadAPI=getLeadService.getLeadAPI(map, sessionId);

				JSONObject objectlead = new JSONObject(responseleadAPI.toString());
				JSONObject linkresponse=(JSONObject)objectlead.getJSONObject("response").getJSONObject("responseData").getJSONArray("leadData").get(0);
				String equoteNumber=linkresponse.getJSONObject("lead").get("equoteNumber")+"";
				map.get(sessionId).put("eQuote", equoteNumber);
				String link=bean.getReDirectURL()+equoteNumber;
				String totalPremiumWGST=map.get(sessionId).get("TotalPremiumWGST")+"";
				String policyTerm=map.get(sessionId).get("PolicyTerm");
				
				speech=map.get(sessionId+"Msg").get("smoker1")+" "+map.get(sessionId).get("name")+map.get(sessionId+"Msg").get("smoker2")+policyTerm
						+map.get(sessionId+"Msg").get("smoker3")+totalPremiumWGST+map.get(sessionId+"Msg").get("smoker4")+" "+equoteNumber
						+map.get(sessionId+"Msg").get("smoker5")+equoteNumber+map.get(sessionId+"Msg").get("smoker6")+" "+map.get(sessionId).get("leadId");
				speech=speech.replaceAll("<br>","\n");
				
			}
			
			/*********************************Create Lead API End************************/
			/*speech="Enter your date of birth in DD/MM/YYYY format \n" + 
					"<Indicative text  24/11/1988>";*/
			/*String response = createLeadService.createLeadAPI(map, sessionId);
			JSONObject object = new JSONObject(response.toString());
			JSONObject res=(JSONObject)object.getJSONObject("response").getJSONObject("responseData").getJSONArray("createLeadWithRiderResponse").get(0);
			String leadId=res.get("leadID")+"";
			map.get(sessionId).put("leadId", leadId);
			String responseleadAPI=getLeadService.getLeadAPI(map, sessionId);
			JSONObject objectlead = new JSONObject(responseleadAPI.toString());
			JSONObject linkresponse=(JSONObject)objectlead.getJSONObject("response").getJSONObject("responseData").getJSONArray("leadData").get(0);
			String equoteNumber=linkresponse.getJSONObject("lead").get("equoteNumber")+"";
			map.get(sessionId).put("eQuote", equoteNumber);
			String link=bean.getReDirectURL()+equoteNumber;
			speech=" Your equote number is <strong>"+equoteNumber+"</strong>.  "
					+ "<a href='"+link+"' target='_blank'> Click here </a> to proceed.$"+leadId+"";*/
		}
		else{
			speech=map.get(sessionId+"Msg").get("Error")+": - Email";
			//speech="Internal Glitch please try after some time";
		}
		
		return speech;
	}
}
