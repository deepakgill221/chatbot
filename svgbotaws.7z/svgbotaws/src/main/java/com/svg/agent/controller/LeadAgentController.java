package com.svg.agent.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


import com.svg.agent.button.Button;
import com.svg.agent.button.InnerData;
import com.svg.agent.commons.Adoptionlogs;
import com.svg.agent.commons.DataFromJson;
import com.svg.agent.commons.SessionTimeOut;
import com.svg.agent.interceptor.CustomerDOBIntent;
import com.svg.agent.interceptor.CustomerEmailIntent;
import com.svg.agent.interceptor.CustomerGenderIntent;
import com.svg.agent.interceptor.CustomerMobileNumberIntent;
import com.svg.agent.interceptor.CustomerSmokerIntent;
import com.svg.agent.interceptor.WelcomeIntent;
import com.svg.agent.response.WebhookResponse;
import com.svg.agent.service.GetMessageService;
import com.svg.agent.service.SVGLeadCall;

@RestController
@RequestMapping("/svg")
public class LeadAgentController 
{
	
	private static Logger logger = LogManager.getLogger(LeadAgentController.class);
	
	@Autowired
	private DataFromJson dataFromJson;
	@Autowired
	private WelcomeIntent welcomeIntent;
	@Autowired
	private CustomerGenderIntent customerGenderIntent;
	@Autowired
	private CustomerEmailIntent customerEmailIntent;
	@Autowired
	private CustomerMobileNumberIntent customerMobileNumberIntent;
	@Autowired 
	private CustomerDOBIntent customerDobIntent;
	@Autowired
	private CustomerSmokerIntent customerSmokerIntent;
	@Autowired
	private Button button;
	@Autowired
	private SVGLeadCall svgLeadCall;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	private GetMessageService getMessageService;
	@Autowired
	private SessionTimeOut sessiontimeOut;



	static Map<String,Map<String,String>> ExternalMap = new ConcurrentHashMap<String,Map<String,String>>();
	static Map<String,String> MessageMap = new ConcurrentHashMap<String,String>();
	
	@Scheduled(cron="0 0/10 * * * ?")
	public void removeCashethirtyminute()
	{
		System.out.println("cron job starts");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Cash Removed :: START---"+dtf.format(now));
		logger.info("Cash Removed :: START---"+dtf.format(now));
		sessiontimeOut.cashRemovetimeout(ExternalMap );
		logger.info("Cash Removed :: END---"+dtf.format(now));
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public WebhookResponse webhook(@RequestBody String obj)
	{
		Map<String,String> internalMap = new ConcurrentHashMap<String,String>();
		logger.info("SVG Controller start...:-"+obj);
		System.out.println("controller started");
		InnerData innerData = new InnerData();
		logger.info("Inside Controller");
		
		String speech="", sessionId = "", action="", customerName="";
		String gender="", custEmail="", mobileNum="", date="", smoke="",resolvedQuery="";
		String source="", channel="",  company="", category="";
		String utm_source="", utm_medium="", utm_campaign="",utm_term="", utm_content="";
		
		Date login =new Date();
		String pattern = "MM/dd/yyyy HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String login_time = simpleDateFormat.format(login);
		
		try {
			logger.info("Request:: "+obj.toString());
			JSONObject object = new JSONObject(obj.toString());
			sessionId = object.get("sessionId")+"";
			
			String SessionIdLogin = sessionId+"login_time";
			internalMap.put(SessionIdLogin, login_time);
			
			logger.info("Session Id:: :: "+sessionId+" :: login time :: "+login_time);
			
			System.out.println("SessionId--"+sessionId);
			action = object.getJSONObject("result").get("action") + "";
			logger.info("Action----"+action);
			logger.info("SessionId::"+sessionId+"\n Action----"+action);
			resolvedQuery = object.getJSONObject("result").get("resolvedQuery")+"";
			
			
			
			/*----------------New Requirement------------------------------*/
			if("welcome".equalsIgnoreCase(action))
			{
				try{
					/**************************get text message Start*****************************/
					
					String textMessage=getMessageService.getMessageAPI("svgbot");
					System.out.println("Msg from rule engine ::  "+textMessage);
					
					JSONArray jsonArr = new JSONArray(textMessage);
					for(int i=0; i<jsonArr.length();i++)
					{
						String result = jsonArr.get(i)+"";
						String [] arr  = result.split("###");
						MessageMap.put(arr[0], arr[1]);
					}
					ExternalMap.put(sessionId+"Msg", MessageMap);
				}catch(Exception e)
				{
					logger.error("Exception while calling API to fetch Message from Rule Engine :: "+e);
				}
				/**************************get text message End*****************************/
				
				try {
					internalMap.put("start", "start");
					ExternalMap.put(sessionId, internalMap);
					
					String [] splitResolvedQuery = resolvedQuery.split("#");
					source=splitResolvedQuery[1];
					channel=splitResolvedQuery[2];
					company=splitResolvedQuery[3];
					
					logger.info("Source "+source+" channel "+channel+" company "+company);
					
					if("WebsiteIndirect".equalsIgnoreCase(company)){
						company = "Website Indirect";
					}
					else if("WebsiteDirect".equalsIgnoreCase(company)){
						company="Website Direct";
					}
					else if("DirectNatural".equalsIgnoreCase(company)){
						company="Direct Natural";
					}
					else if("WebsiteDirect-mobile".equalsIgnoreCase(company)){
						company="Website Direct-mobile";
					}
					category=splitResolvedQuery[4];
					if("WebsiteIndirect".equalsIgnoreCase(category)){
						category = "Website Indirect";
					}
					else if("WebsiteDirect".equalsIgnoreCase(category)){
						category="Website Direct";
					}
					else if("DirectNatural".equalsIgnoreCase(category)){
						category="Direct Natural";
					}
					else if("WebsiteDirect-mobile".equalsIgnoreCase(category)){
						category="Website Direct-mobile";
					}
					utm_source=splitResolvedQuery[5];
					utm_medium=splitResolvedQuery[6];
					utm_campaign=splitResolvedQuery[7];
					utm_term=splitResolvedQuery[8];
					utm_content=splitResolvedQuery[9];
					
					ExternalMap.get(sessionId).put("source", source);
					ExternalMap.get(sessionId).put("channel", channel);
					ExternalMap.get(sessionId).put("company", company);
					ExternalMap.get(sessionId).put("category", category);
					ExternalMap.get(sessionId).put("utm_source", utm_source);
					ExternalMap.get(sessionId).put("utm_medium", utm_medium);
					ExternalMap.get(sessionId).put("utm_campaign", utm_campaign);
					ExternalMap.get(sessionId).put("utm_term", utm_term);
					ExternalMap.get(sessionId).put("utm_content", utm_content);
					
					logger.info("Values :: Session Id :- "+sessionId 
							+"\n source :- "+source
							+"\n channel :- "+channel
							+"\n company :- "+company
							+"\n category :- "+category
							+"\n utm_source :- "+utm_source
							+"\n utm_medium :- "+utm_medium
							+"\n utm_campaign :- "+utm_campaign
							+"\n utm_term :- "+utm_term
							+"\n utm_content :- "+utm_content
							);
					
				}catch(Exception ex)
				{
					speech=ExternalMap.get(sessionId+"Msg").get("WelcomCatch");
					logger.error("Exception ---- :: "+ex);
					//speech="URL Request is Not matched! Please check it properly with all fields";
					action="default";
				}
			}
			if(!"welcome".equalsIgnoreCase(action) && !"default".equalsIgnoreCase(action))
			{
				customerName=dataFromJson.customerNameVariable(object,sessionId, ExternalMap, internalMap);
				gender=dataFromJson.genderVariable(object,sessionId, ExternalMap, internalMap);
				custEmail=dataFromJson.email_Variable(object, sessionId, ExternalMap, internalMap);
				mobileNum=dataFromJson.mobile_Variable(object, sessionId, ExternalMap, internalMap);
				date=dataFromJson.date_Variable(object, sessionId, ExternalMap, internalMap);
				smoke=dataFromJson.smoke_Variable(object, sessionId, ExternalMap, internalMap);
			}
			
			
			
			switch(action.toUpperCase())
			{
			case "WELCOME":
			{
				speech=ExternalMap.get(sessionId+"Msg").get("Welcome");
				/*speech=" Hi, Thanks for showing interest in Max Life Term insurance. "
						+ "I am your online assistant. $$ I need a few details to calculate customised premium for you. "
						+ "Please share your <strong> first name </strong>.";*/
			}
			break;
			case "INPUT.NAME":
			{
				if(ExternalMap.containsKey(sessionId)){
				speech=welcomeIntent.welcomeIntentCall(ExternalMap,sessionId ,customerName);
				}
				else
				{speech="Your session is expired. To continue please reload the page.";
				}
			}
			break;

			case "INPUT.MOBILE":
			{
				if(ExternalMap.containsKey(sessionId)){
				 speech=customerMobileNumberIntent.customerMobileNumberIntent(ExternalMap, sessionId);
				
				//SVG Call start

				logger.info("Channel is for SVG ---"+ExternalMap.get(sessionId).get("channel")+"");
				String getChannel = ExternalMap.get(sessionId).get("channel")+"";
				if("34".equalsIgnoreCase(getChannel))
				{
					final String session=sessionId;
					try {
						Thread t1=new Thread(new Runnable() 
						{
							public void run() 
							{
								svgLeadCall.svgLeadCall(ExternalMap, session);
								logger.info("----Lead Created on SVG.....");
							}
						});
						t1.start();
						t1.join();
					}
					catch(Exception ex)
					{
						logger.info("creating exception while creating lead id in SVG"+ex);
					}
				}

				//SVG call end
				innerData = null;
				}
				else{
					speech="Your session is expired. To continue please reload the page.";
				}
			}
			break;
			/*---------------------------------------------------------------------------------------*/

			// Email -6
			case "INPUT.EMAIL":
			{
				if(ExternalMap.containsKey(sessionId)){
				//speech=customerSmokerIntent.customerSmokerIntent(ExternalMap, sessionId);
				speech=customerEmailIntent.customerEmailIntent(ExternalMap, sessionId);
				innerData = null;
				}
				else{
					speech="Your session is expired. To continue please reload the page.";
				}

			}
			break;

			/*---------------------------------------------------------------------------------------*/
			case "INPUT.DOB":
			{
				if(ExternalMap.containsKey(sessionId)){
				speech=customerDobIntent.customerDOBIntent(ExternalMap, sessionId);
				innerData = button.getButtonsGender();
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
			}
			break;

			/*---------------------------------------------------------------------------------------*/

			case "INPUT.GENDER":
			{
				if(ExternalMap.containsKey(sessionId)){
				speech=customerGenderIntent.customerGenderIntent(ExternalMap, sessionId);
				innerData = button.getButtonsYesNo();
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
			}
			break;

			//Smoker -4 
			case "INPUT.SMOKER":
			{
				if(ExternalMap.containsKey(sessionId)){
				speech=customerSmokerIntent.customerSmokerIntent(ExternalMap, sessionId);
				innerData = null;
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
			}
			break;

			//For clear the cache
			case "CLOSE":
			{
				ExternalMap.clear();
				internalMap.clear();
				speech="Cache Clear Thanks! ";
			}
			break;
			default : 
			{
				logger.info("Intent Not match with skill,Please connect to application owner");
				speech=ExternalMap.get(sessionId).get("default");
				//speech="Request Param is not matched. Please check it properly";
			}
			}
		}catch(Exception ex)
		{
			logger.error("Exception Occoured in SVG Controller "+ex);
			speech="Communication glitch while calling API's.";
		}

		/*********************adoption log call start***********************************/

		/*String dbSessionId = sessionId, dbActionPerformed=action;
		String dbPolicyNumber="",  dbResolvedQuery = resolvedQuery;
		String dbspeech;
		String value =dbSessionId+"login_time";
		String dbSSOId = internalMap.get(value);

		if("INPUT.NAME".equalsIgnoreCase(action))
		{
			String speech1[]=speech.split("</strong>");
			dbspeech=speech1[0];
		}
		else{
			dbspeech=speech;
		}

		try{
			//logger.info("Adoption Logs :: START");
			Thread t1=new Thread(new Runnable() 
			{
				public void run() 
				{
					System.out.println("Run Method Start");
					String status=adoption.adoptionlogsCall(dbSessionId, dbSSOId, dbActionPerformed, dbResolvedQuery, dbspeech);
					logger.info("Adoption log status :: "+status);
				}
			});
			t1.start();
			t1.join();
			//logger.info("Adoption Logs :: END");
		}catch(Exception ex)
		{
			logger.error("Excption Occoured while saving data in to the database" +ex);
		}*/

		/***********************************adoption log call end*******************************/
		logger.info("Final Speech--"+speech);
		WebhookResponse responseObj = new WebhookResponse(speech, speech, innerData);
		return responseObj;
	}

}
