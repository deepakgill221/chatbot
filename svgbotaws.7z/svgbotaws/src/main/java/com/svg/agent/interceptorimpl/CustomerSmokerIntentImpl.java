package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.interceptor.CustomerSmokerIntent;
import com.svg.agent.service.CreateLeadService;
import com.svg.agent.service.GetLeadService;
import com.svg.agent.service.SmokerService;

@Service
public class CustomerSmokerIntentImpl implements CustomerSmokerIntent 
{
	@Autowired
	private SmokerService smokerService;
	@Autowired
	private CreateLeadService createLeadService;
	@Autowired
	private GetLeadService getLeadService;
	@Autowired
	private BeanProperty bean;

	String speech="";
	@Override
	public String customerSmokerIntent(Map<String, Map<String, String>> map, String sessionId) 
	{
		if(map.containsKey(sessionId))
		{
			String response = smokerService.smokerAPI(map, sessionId);
			JSONObject object = new JSONObject(response.toString());
			JSONObject res=(JSONObject)object.getJSONObject("response").getJSONObject("payload").getJSONArray("resPlan").get(0);
			String totalPremiumWOGST=res.get("totalPremiumWOGST")+"";

			String policyTerm = res.getString("policyTerm");
			String totalPremium=res.getString("totalPremiumWGST");
			double doubletotalPremiumWGST=Double.parseDouble(totalPremium);

			String convertedtotalPremiumWGST = String.valueOf(doubletotalPremiumWGST);
			String arr [] = convertedtotalPremiumWGST.split("\\.");
			String totalPremiumWGST = arr[0];

			map.get(sessionId).put("TotalPremiumWOGST", totalPremiumWOGST);
			map.get(sessionId).put("TotalPremiumWGST", totalPremium);
			map.get(sessionId).put("PolicyTerm", policyTerm);
			
			speech=map.get(sessionId+"Msg").get("mobile");

			/*------------------------------Calling API for getting equote value start--------------------------*/
			/*String responseEquote = createLeadService.createLeadAPI(map, sessionId);

			JSONObject objectEquote = new JSONObject(responseEquote.toString());
			String soaStatusCode=objectEquote.getJSONObject("response").getJSONObject("responseData").get("soaStatusCode").toString();
			int soastatus=Integer.parseInt(soaStatusCode);
			if(soastatus==200){
				JSONObject resEquote=(JSONObject)objectEquote.getJSONObject("response").getJSONObject("responseData").getJSONArray("createLeadWithRiderResponse").get(0);
				String leadId=resEquote.get("leadID")+"";
				map.get(sessionId).put("leadId", leadId);
				String responseleadAPI=getLeadService.getLeadAPI(map, sessionId);

				JSONObject objectlead = new JSONObject(responseleadAPI.toString());
				JSONObject linkresponse=(JSONObject)objectlead.getJSONObject("response").getJSONObject("responseData").getJSONArray("leadData").get(0);
				String equoteNumber=linkresponse.getJSONObject("lead").get("equoteNumber")+"";
				map.get(sessionId).put("eQuote", equoteNumber);
				String link=bean.getReDirectURL()+equoteNumber;
				speech=" Your equote number is <strong>"+equoteNumber+"</strong>.  "
					+ "<a href='"+link+"' target='_blank'> Click here </a> to proceed.$"+leadId+"";*/

				/*------------------------------Calling API for getting equote value end--------------------------*/


				/*speech=map.get(sessionId).get("smoker1")+map.get(sessionId).get("name")+map.get(sessionId).get("smoker2")+policyTerm
						+map.get(sessionId).get("smoker3")+totalPremiumWGST+map.get(sessionId).get("smoker4")+equoteNumber
						+map.get(sessionId).get("smoker5")+map.get(sessionId).get("leadId");*/
			
			
			
			
			
			
				/*speech="Great "+map.get(sessionId).get("name")+". Here is your personalised premium quote:"
						+ "$$ Your personalised premium quote for Max Life Online Term Plan Plus(UIN-104N092V03):\n" + 
						"<table><Tr><Td>Your Sum Assured: </Td><Td><strong>Rs. 1 crore</strong> </Td></TR>"
						+ "<tr><TD>Policy Term: </td> <td><strong>"+policyTerm+" years</strong></Td></TR>"
						+ "<tr><TD>*Premium amount:  </TD><TD><strong>Rs. "+totalPremiumWGST+"</Td></TR></table> per month (GST inclusive)</strong>"
						+ "<br> Basic Life Cover Variant \n"
						+ " <hr><I>*Standard premium for a healthy individual</I>"
						+ "<hr> ARN:" //261218_WB1"
						+ "$$ Your equote number is "+equoteNumber+"  \r\n" 
						+ "$$ Redirecting you to our website$$"+map.get(sessionId).get("leadId"); */

				/*+ " $$ To know more about this term plan, please enter your 10 digit mobile number.<hr>"
					+ "<I><input type=\"checkbox\"  checked=\"checked\" disabled>" + 
					"  I have read and accept the various <a href=\"https://www.maxlifeinsurance.com/content/dam/neo/pdf/TermsAndConditions_Common_2017%2011%2014.pdf\" target=\"_blank\">T&amp;Cs. </a>I agree to be contacted by Max Life Insurance, overriding my NDNC registry."+ 
					" </I>";*/
				/*speech="<I>Your personalised premium quote for Max Life Online Term Plan Plus(UIN-104N092V03)</I>:\n" + 
					"<table><Tr><Td>Your  Sum Assured: </Td><Td><strong>Rs. 1 crore</strong> </Td></TR>"
					+ "<tr><TD>Policy Term: </td> <td><strong>"+policyTerm+" years</strong></Td></TR>"
					+ "<tr><TD>Premium amount:  </TD><TD><strong>Rs. "+totalPremiumWGST+"</Td></TR></table> per month (GST inclusive)</strong>\n"
					+ " <hr><I>*Standard premium for a healthy individual</I>"
					+ " $$ To know more about the term plan, please enter your 10 digit mobile number.<hr>"
					+ "<I><input type=\"checkbox\"  checked=\"checked\" disabled>" + 
					"  I have read and accept the various <a href=\"https://www.maxlifeinsurance.com/content/dam/neo/pdf/TermsAndConditions_Common_2017%2011%2014.pdf\" target=\"_blank\">T&amp;Cs. </a>I agree to be contacted by Max Life Insurance, overriding my NDNC registry." + 
					" </I>";
			}
			else{
				speech=map.get(sessionId).get("smokerError");
				//speech="Wrong channel Id has been passed.";
			}*/
		}
		else{
			speech=map.get(sessionId).get("Error")+" :- Smoker";
			//speech="Internal Glitch Please try after some time :-smoker";
		}
		return speech;
	}
}
