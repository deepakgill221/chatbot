package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.svg.agent.interceptor.CustomerGenderIntent;
@Service
public class CustomerGenderIntentImpl implements CustomerGenderIntent{
	
	String speech="";
	String totalPremiumWGST="";
	@Override
	public String customerGenderIntent(Map<String, Map<String, String>> map, String sessionId) {
		if(map.containsKey(sessionId))
		{
			speech=map.get(sessionId+"Msg").get("gender");
			/*speech="Got it. "
					+ "Do you smoke or chew tobacco? ";*/
					
		}
		else{
			speech=map.get(sessionId+"Msg").get("Error")+" :- Gender";
			//speech="Something went wrong! Please try again after some time: Gender";
		}
		return speech;
	}
}

