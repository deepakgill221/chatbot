package com.svg.agent.serviceimpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svg.agent.commons.BeanProperty;
import com.svg.agent.service.GetLeadService;

@Service
public class GetLeadServiceImpl implements GetLeadService 
{
	@Autowired
	private BeanProperty bean;

	@Override
	public String getLeadAPI(Map<String, Map<String, String>> map, String sessionId) {
		
		StringBuilder result = new StringBuilder();
		String output = new String();
		int leadId=0;
		HttpURLConnection conn = null;
		try {
			String leadIds=map.get(sessionId).get("leadId");
			System.out.println("Get Lead API Lead Id- "+leadIds);
			try{
			 leadId = Integer.parseInt(leadIds);
			}
			catch(Exception ex){
				System.out.println("Exception while parsing leadId"+ex);
			}
			String extURL = bean.getGetLead(); 
			String soaUserId=bean.getSoaUserId();
			String soaPassword=bean.getSoaPassword();
			
			URL url = new URL(extURL);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata = new StringBuilder();
			requestdata.append("	{	");
			requestdata.append("	  \"request\": {	");
			requestdata.append("	    \"header\": {	");
			requestdata.append("	      \"soaUserId\": \""+soaUserId+"\",	");
			//requestdata.append("	      \"soaUserId\": \"NEOPROD123\",	");
			requestdata.append("	      \"soaCorrelationId\": \"25478965874\",	");
			requestdata.append("	      \"soaPassword\": \""+soaPassword+"\",	");
			//requestdata.append("	      \"soaPassword\": \"dGhha2Fnb2xpdmU=\",	");
			requestdata.append("	      \"soaMsgVersion\": \"1.0\",	");
			requestdata.append("	      \"soaAppId\": \"NEO\"	");
			requestdata.append("	    },	");
			requestdata.append("	    \"requestData\": {	");
			requestdata.append("	      \"getLead\": {	");
			requestdata.append("	        \"leadId\": "+leadId+"	");
			requestdata.append("	      }	");
			requestdata.append("	    }	");
			requestdata.append("	  }	");
			requestdata.append("	}	");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}
			int apiResponseCode = conn.getResponseCode();
			System.out.println("Get Lead API Calling Response Code:- "+apiResponseCode);
			if (apiResponseCode == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception Occoured While Calling API's " + e);
		}
		return result.toString();
	}
}
