package com.svg.agent.interceptorimpl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.svg.agent.interceptor.CustomerDOBIntent;

@Service
public class CustomerDOBIntentImpl implements CustomerDOBIntent 
{
	String speech="";
	@Override
	public String customerDOBIntent(Map<String, Map<String, String>> map, String sessionId) {
		if(map.containsKey(sessionId))
		{
			speech=map.get(sessionId+"Msg").get("dob1") +" "+ map.get(sessionId).get("name") + map.get(sessionId+"Msg").get("dob2");
			//speech=" Thanks "+map.get(sessionId).get("name")+". Please select your gender.";
		}
		else{
			speech=map.get(sessionId+"Msg").get("Error")+" : - DOB";
			//speech="Somethig went wrong ! Please try again after some time :-customerDOB";
		}
		return speech;
	}
}
