package com.lead.agent.leadbotaws;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author aD01084
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LeadbotawsApplicationTests {

	/**
	 * wE CAN START OUR uNIT TESTING HERE AS WELL
	 */
	@Test
	public void contextLoads() {
		//DO NOTHING : WHEN NEED TO DO UNIT TESTING WE CAN WRITE CODE HERE
	}

}

