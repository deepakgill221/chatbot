package com.lead.agent.interceptorimpl;

import java.text.MessageFormat;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lead.agent.interceptor.CustomerEmailDetail;
import com.lead.agent.service.CreateLeadService;
import com.lead.agent.service.GetLeadService;
/**
 * @author ad01084
 *
 */
@Service
public class CustomerEmailDetailImpl implements CustomerEmailDetail 
{
	private static Logger logger = LogManager.getLogger(CustomerEmailDetailImpl.class);
	
	ResourceBundle resb = ResourceBundle.getBundle("application");
	@Autowired
	private CreateLeadService createLeadService;
	@Autowired
	private GetLeadService getLeadService;

	private static final String RESPONSE="response";
	private static final String RESPONSEDATA="responseData";
	/** 
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String getEmail(Map<String, Map<String, String>> map, String sessionId) {
		String speech;
		if(map.containsKey(sessionId))
		{
			logger.info("START CREATE LEAD:");
			String response = createLeadService.createLeadAPI(map, sessionId);
			logger.info("END CREATE LEAD:");
			JSONObject object = new JSONObject(response);
			String soaStatusCode=object.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).get("soaStatusCode").toString();
			int soastatus=Integer.parseInt(soaStatusCode);
			logger.info("SOA Status Code :: "+soastatus);
			if(soastatus==200)
			{
			JSONObject res=(JSONObject)object.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).getJSONArray("createLeadWithRiderResponse").get(0);
			String leadId=res.get("leadID")+"";
			map.get(sessionId).put("leadId", leadId);
			logger.info("START GET LEAD API:");
			String responseleadAPI=getLeadService.getLeadAPI(map, sessionId);
			logger.info("END GET LEAD API:");
			JSONObject objectlead = new JSONObject(responseleadAPI);
			JSONObject linkresponse=(JSONObject)objectlead.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).getJSONArray("leadData").get(0);
			String equoteNumber=linkresponse.getJSONObject("lead").get("equoteNumber")+"";
			map.get(sessionId).put("eQuote", equoteNumber);
			String message1 = map.get(sessionId+"Msg").get("email1"); 
			String message2 = map.get(sessionId+"Msg").get("email2");  
			String message3 = map.get(sessionId+"Msg").get("email3"); 
			String part1 = MessageFormat.format(message1, equoteNumber);
			String part3 = MessageFormat.format(message3, leadId);
			speech = part1+message2+part3;
			}
			else
			{
				speech="Wrong channel Id has been passed.";
			}
		}
		else{
			speech="Internal Glitch please try after some time";
		}
		logger.info("Speech :: "+speech);
		return speech;
	}
}
