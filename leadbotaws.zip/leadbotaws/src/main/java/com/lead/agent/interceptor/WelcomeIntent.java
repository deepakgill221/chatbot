package com.lead.agent.interceptor;

public interface WelcomeIntent {
	public String welcomeIntentCall(String name);
}
