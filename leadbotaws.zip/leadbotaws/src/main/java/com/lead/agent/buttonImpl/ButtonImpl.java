package com.lead.agent.buttonImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lead.agent.button.Button;
import com.lead.agent.button.Facebook;
import com.lead.agent.button.InnerButton;
import com.lead.agent.button.InnerData;
import com.lead.agent.commons.BeanProperty;

@Service
public class ButtonImpl implements Button 
{
	@Autowired
	private BeanProperty bean;
	
	List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
	Facebook fb = new Facebook();
	InnerData innerData = new InnerData();
	InnerButton button = new InnerButton();
	InnerButton button2 = new InnerButton();

	@Override
	public InnerData getButtonsYesNo() 
	{
		innerbuttonlist=new ArrayList<InnerButton>();;
		innerData=new InnerData();

		button.setText("Yes");
		button.setPostback("yes");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("No");
		button2.setPostback("no");
		button2.setLink("");
		innerbuttonlist.add(button2);

		fb.setButtons(innerbuttonlist);
		fb.setTitle("MLIChatBot");
		fb.setPlatform("API.AI");
		fb.setType("Chatbot");
		fb.setImageUrl("BOT");
		innerData.setFacebook(fb);

		return innerData;
	}
	public InnerData getButtonsGender() 
	{
		innerbuttonlist=new ArrayList<InnerButton>();;
		innerData=new InnerData();

		button.setText("Male");
		button.setPostback("male");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("Female");
		button2.setPostback("female");
		button2.setLink("");
		innerbuttonlist.add(button2);

		fb.setButtons(innerbuttonlist);
		fb.setTitle("MLIChatBot");
		fb.setPlatform("API.AI");
		fb.setType("Chatbot");
		fb.setImageUrl("BOT");
		innerData.setFacebook(fb);

		return innerData;
	}
	public InnerData letsProceed() 
	{
		innerbuttonlist=new ArrayList<InnerButton>();;
		innerData=new InnerData();

		button.setText("Lets Proceed");
		button.setPostback("Hi");
		button.setLink("");
		innerbuttonlist.add(button);

		fb.setButtons(innerbuttonlist);
		fb.setTitle("MLIChatBot");
		fb.setPlatform("API.AI");
		fb.setType("Chatbot");
		fb.setImageUrl("BOT");
		innerData.setFacebook(fb);

		return innerData;
	}
	
	public InnerData proceed(Map<String, Map<String,String>> map, String sessionId) 
	{
		String link=bean.getReDirectURL();
		String leadId=map.get(sessionId).get("leadId");
		
		innerbuttonlist=new ArrayList<InnerButton>();;
		innerData=new InnerData();

		button.setText("Proceed");
		button.setPostback("proceed");
		button.setLink(link+leadId);
		//button.setLink("<a href='"+link+leadId+"' target='_blank'>");
		innerbuttonlist.add(button);

		fb.setButtons(innerbuttonlist);
		fb.setTitle("MLIChatBot");
		fb.setPlatform("API.AI");
		fb.setType("Chatbot");
		fb.setImageUrl("BOT");
		innerData.setFacebook(fb);

		return innerData;
	}
	
	
}
