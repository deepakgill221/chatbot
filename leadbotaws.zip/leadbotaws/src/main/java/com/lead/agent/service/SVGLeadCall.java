package com.lead.agent.service;

import java.util.Map;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface SVGLeadCall 
{
	/**
	 * @param map
	 * @param sessionId
	 */
	public void svgLeadCall(Map<String, Map<String, String>> map, String sessionId);
}
