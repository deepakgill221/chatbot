package com.lead.agent.interceptorimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.lead.agent.commons.Adoptionlogs;
import com.lead.agent.interceptor.CustomerGenderIntent;
@Service
public class CustomerGenderIntentImpl implements CustomerGenderIntent{
	
	private static Logger logger = LogManager.getLogger(CustomerGenderIntentImpl.class);
	
	ResourceBundle res = ResourceBundle.getBundle("application");
	String speech="";
	String totalPremiumWGST="";
	@Override
	public String customerGenderIntent(Map<String, Map<String, String>> map, String sessionId) {
		if(map.containsKey(sessionId))
		{
			speech=map.get(sessionId+"Msg").get("customerGender");
			//speech=res.getString("customerGender");
			
		}
		else{
			speech="Something went wrong! Please try again after some time: Gender";
		}
		logger.info("speech :: "+speech);
		return speech;
	}
}

