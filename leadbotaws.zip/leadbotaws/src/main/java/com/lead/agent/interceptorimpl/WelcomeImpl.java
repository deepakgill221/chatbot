package com.lead.agent.interceptorimpl;

import java.util.ResourceBundle;

import org.springframework.stereotype.Service;
import com.lead.agent.interceptor.Welcome;

/**
 * @author ad01084
 *
 */
@Service
public class WelcomeImpl implements Welcome 
{
	ResourceBundle res = ResourceBundle.getBundle("application");
	String speech="";
	/** (non-Javadoc)
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String getWelcome(String name) {
		speech=res.getString("dob");
		return speech;
	}
}