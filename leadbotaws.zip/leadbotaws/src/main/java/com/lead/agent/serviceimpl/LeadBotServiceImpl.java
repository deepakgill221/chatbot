package com.lead.agent.serviceimpl;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lead.agent.button.InnerData;
import com.lead.agent.commons.Adoptionlogs;
import com.lead.agent.commons.BeanProperty;
import com.lead.agent.commons.DataFromJson;
import com.lead.agent.commons.LeadBotActionHelper;
import com.lead.agent.commons.SessionTimeOut;
import com.lead.agent.interceptor.CustomerDobDetail;
import com.lead.agent.interceptor.CustomerEmailDetail;
import com.lead.agent.interceptor.CustomerGenderDetail;
import com.lead.agent.interceptor.CustomerMobileNumberDetail;
import com.lead.agent.interceptor.CustomerSmokerDetail;
import com.lead.agent.interceptor.EmailDetail;
import com.lead.agent.response.WebhookResponse;
import com.lead.agent.service.Button;
import com.lead.agent.service.GetMessageService;
import com.lead.agent.service.LeadBotService;
import com.lead.agent.service.SVGLeadCall;

/**
 * @author ad01084
 *
 */
@Service
public class LeadBotServiceImpl implements LeadBotService {
	private static Logger logger = LogManager.getLogger(LeadBotServiceImpl.class);
	@Autowired
	private DataFromJson dataFromJson;
	@Autowired
	private CustomerGenderDetail customerGenderDetail;
	@Autowired
	private CustomerEmailDetail customerEmailDetail;
	@Autowired
	private CustomerMobileNumberDetail custMobileNumDetail;
	@Autowired
	private CustomerDobDetail customerDobDetail;
	@Autowired
	private EmailDetail emailDetail;
	@Autowired
	private CustomerSmokerDetail customerSmokerDetail;
	@Autowired
	private Button button;
	@Autowired
	private SVGLeadCall svgLeadCall;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	private GetMessageService getMessageService;
	@Autowired
	private SessionTimeOut sessiontimeOut;
	@Autowired
	private BeanProperty context;

	private static Map<String, Map<String, String>> externalMap;
	private static Map<String, String> messageMap;
	private static ResourceBundle res;
	private static final String WELCOME;
	private static final String DEFAULT;
	private static final String CHANNEL;

	static {
		externalMap = new ConcurrentHashMap<>();
		messageMap = new ConcurrentHashMap<>();
		res = ResourceBundle.getBundle("application");
		WELCOME = "welcome";
		DEFAULT = "default";
		CHANNEL = "channel";
	}

	private void setTextMessage(String sessionId) {
		try {
			String textMessage = getMessageService.getMessageAPI("leadbot");
			logger.info("Msg from rule engine " + textMessage);

			JSONArray jsonArr = new JSONArray(textMessage);
			for (int i = 0; i < jsonArr.length(); i++) {
				String result = jsonArr.get(i) + "";
				String[] arr = result.split("###");
				messageMap.put(arr[0], arr[1]);
			}
			externalMap.put(sessionId + "Msg", messageMap);
		} catch (Exception e) {
			logger.error("Exception while calling API to fetch Message from Rule Engine :: " + e);
		}
	}

	private boolean welcomeKit(String sessionId, Map<String, String> internalMap, String resolvedQuery) {
		boolean flag = false;
		try {
			String source;
			String channel;
			String company;
			String category;
			internalMap.put("start", "start");
			externalMap.put(sessionId, internalMap);
			String[] splitResolvedQuery = resolvedQuery.split("#");
			source = splitResolvedQuery[1];
			channel = splitResolvedQuery[2];
			company = splitResolvedQuery[3];
			if ("WebsiteIndirect".equalsIgnoreCase(company)) {
				company = "Website Indirect";
			} else if ("WebsiteDirect".equalsIgnoreCase(company)) {
				company = "Website Direct";
			} else if ("DirectNatural".equalsIgnoreCase(company)) {
				company = "Direct Natural";
			} else if ("WebsiteDirect-mobile".equalsIgnoreCase(company)) {
				company = "Website Direct-mobile";
			}
			category = splitResolvedQuery[4];
			if ("WebsiteIndirect".equalsIgnoreCase(category)) {
				category = "Website Indirect";
			} else if ("WebsiteDirect".equalsIgnoreCase(category)) {
				category = "Website Direct";
			} else if ("DirectNatural".equalsIgnoreCase(category)) {
				category = "Direct Natural";
			} else if ("WebsiteDirect-mobile".equalsIgnoreCase(category)) {
				category = "Website Direct-mobile";
			}
			externalMap.get(sessionId).put("source", source);
			externalMap.get(sessionId).put(CHANNEL, channel);
			externalMap.get(sessionId).put("company", company);
			externalMap.get(sessionId).put("category", category);
			logger.info("session id :: " + sessionId + " :: source :: " + source + "\n " + CHANNEL + " ::" + channel
					+ "\n company ::" + company + "\n category :: " + category);
			flag = true;

		} catch (Exception ex) {
			logger.info("Exception in getting value of source, " + CHANNEL + ", company and category :: " + ex);
		}
		return flag;
	}

	private LeadBotActionHelper welcomeCase(String sessionId) {
		String speech;
		InnerData innerData;
		logger.info("Start action :: " + WELCOME);
		speech = externalMap.get(sessionId + "Msg").get(WELCOME);
		innerData = button.getButtonsGender();
		logger.info("ENd action :: " + WELCOME);
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputGenderCase(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.GENDER");
			speech = customerGenderDetail.getGender(externalMap, sessionId);
			innerData = button.getButtonsYesNo();
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.GENDER");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputSmokerCase(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.SMOKER");
			speech = customerSmokerDetail.getCustSmokerDetail(externalMap, sessionId);
			innerData = null;
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.SMOKER");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputDobCase(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.DOB");
			speech = customerDobDetail.getDobDetail(externalMap, sessionId);
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.DOB");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputNameCase(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.NAME");
			speech = emailDetail.getEmailDetail(externalMap, sessionId);
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.NAME");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputEmailCase(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.EMAIL");
			speech = custMobileNumDetail.getCustMobileNum(externalMap, sessionId);
			innerData = null;
		} else {
			speech = context.getSessionExpireMsg();
		}
		logger.info("End action :: INPUT.EMAIL");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputMobileCase(String sessionId) {
		String speech;
		InnerData innerData = new InnerData();
		if (externalMap.containsKey(sessionId)) {
			logger.info("Start action :: INPUT.MOBILE");
			speech = customerEmailDetail.getEmail(externalMap, sessionId);
			innerData = button.proceed(externalMap, sessionId);
			logger.info(CHANNEL + " is for SVG ---" + externalMap.get(sessionId).get(CHANNEL) + "");
			String getChannel = externalMap.get(sessionId).get(CHANNEL) + "";
			// *****************Alsways keep this service commented for
			// UAT and dev**************//*
			if ("34".equalsIgnoreCase(getChannel)) {
				final String session = sessionId;
				try {

					Runnable runnable = () -> {
						svgLeadCall.svgLeadCall(externalMap, session);
						logger.info("----Lead Created on SVG.....");
					};
					Thread t1 = new Thread(runnable);

					t1.start();
					t1.join();
				} catch (Exception ex) {
					logger.info("Exception while calling SVGLead API :: SessionId :: " + sessionId + " :: " + ex);
				}
			}
		} else {
			speech = context.getSessionExpireMsg();
		}
		/*********************
		 * Reason :: It will save the lead on prod environment
		 ****************/
		logger.info("END action :: INPUT.MOBILE");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputCloseCase(String sessionId, Map<String, String> internalMap) {
		String speech;
		InnerData innerData = new InnerData();
		logger.info("Start action :: CLOSE : SessionId : " + sessionId);
		externalMap.clear();
		internalMap.clear();
		speech = res.getString("close");
		logger.info("End action :: CLOSE");
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper inputDefaultCase(String sessionId, String action) {
		String speech;
		InnerData innerData = new InnerData();
		logger.info("Intent Not match with skill,Please connect to application owner :: Sessionid :: " + sessionId
				+ " :: " + action);
		speech = res.getString(DEFAULT);
		return new LeadBotActionHelper(innerData, speech);
	}

	private LeadBotActionHelper leadBoatActionWork(String sessionId, String action, Map<String, String> internalMap) {
		LeadBotActionHelper leadBotActionHelper;
		switch (action.toUpperCase()) {
		case "WELCOME":
			leadBotActionHelper = welcomeCase(sessionId);
			break;
		// Gender -2
		case "INPUT.GENDER": 
			leadBotActionHelper = inputGenderCase(sessionId);
			break;
		// Smoker -3
		case "INPUT.SMOKER": 
			leadBotActionHelper = inputSmokerCase(sessionId);
			break;
		// DOB - 4
		case "INPUT.DOB": 
			leadBotActionHelper = inputDobCase(sessionId);
			break;
		// DOB -5
		case "INPUT.NAME": 
			leadBotActionHelper = inputNameCase(sessionId);
			break;
		// mobile -6
		case "INPUT.EMAIL": 
			leadBotActionHelper = inputEmailCase(sessionId);
			break;
		// Email -7
		case "INPUT.MOBILE": 
			leadBotActionHelper = inputMobileCase(sessionId);
			break;
		// For clear the cache
		case "CLOSE": 
			leadBotActionHelper = inputCloseCase(sessionId, internalMap);
			break;
		default: 
			leadBotActionHelper = inputDefaultCase(sessionId, action);
		}
		return leadBotActionHelper;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @param jsonStr
	 *            : Request in Json format
	 * @return com.lead.agent.response.WebhookResponse
	 */
	public WebhookResponse leadBotProcess(String jsonStr) {
		Map<String, String> internalMap = new ConcurrentHashMap<>();
		InnerData innerData = new InnerData();
		logger.info("Inside Controller");
		String speech = "";
		String action = "";
		String sessionId = "";
		String resolvedQuery = "";
		Date login = new Date();
		String pattern = "MM/dd/yyyy HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String loginTime = simpleDateFormat.format(login);
		try {
			JSONObject object = new JSONObject(jsonStr);
			sessionId = object.get("sessionId") + "";
			String sessionIdLogin = sessionId + "login_time";
			internalMap.put(sessionIdLogin, loginTime);
			logger.info("Session Id:: :: " + sessionId + " :: login time :: " + loginTime);

			action = object.getJSONObject("result").get("action") + "";
			logger.info("Session Id----" + sessionId + " :: Action :: " + action);
			resolvedQuery = object.getJSONObject("result").get("resolvedQuery") + "";
			if (WELCOME.equalsIgnoreCase(action)) {
				setTextMessage(sessionId);
				if (!welcomeKit(sessionId, internalMap, resolvedQuery)) {
					action = DEFAULT;
				}
			}
			if (!WELCOME.equalsIgnoreCase(action) && !DEFAULT.equalsIgnoreCase(action)) {
				dataFromJson.customerNameVariable(object, sessionId, externalMap);
				dataFromJson.genderVariable(object, sessionId, externalMap);
				dataFromJson.emailVariable(object, sessionId, externalMap);
				dataFromJson.mobileVariable(object, sessionId, externalMap);
				dataFromJson.dateVariable(object, sessionId, externalMap);
				dataFromJson.smokeVariable(object, sessionId, externalMap);
			}
			LeadBotActionHelper botActionHelper = leadBoatActionWork(sessionId, action, internalMap);
			speech = botActionHelper.getSpeech();
			innerData = botActionHelper.getInnerData();
		} catch (Exception ex) {
			logger.info("Exception Occoured :: SessionId ::" + sessionId + "\n " + ex);
			speech = "Communication glitch while calling API's.";
		}
		/*********************************
		 * Adoption Logs call start
		 *****************************/
		logger.info("Adoption logs call start");
		String dbSessionId = sessionId;
		String dbActionPerformed = action;
		String dbResolvedQuery = resolvedQuery;
		String dbspeech;
		if ("INPUT.EMAIL".equalsIgnoreCase(action)) {
			String[] speech1 = speech.split("<hr>");
			dbspeech = speech1[0];
		} else {
			dbspeech = speech;
		}

		String value = dbSessionId + "login_time";
		String dbSSOId = internalMap.get(value);
		try {
			logger.info("Adoption Logs :: going to call adoption log api");

			Runnable runnable = () -> {
				logger.info("Run Method Start");
				String response = adoption.adoptionlogsCall(dbSessionId, dbSSOId, dbActionPerformed, dbResolvedQuery,
						dbspeech);
				logger.info("Adoption log status :: " + response);
			};
			Thread t1 = new Thread(runnable);
			t1.start();
			t1.join();
			logger.info("Adoption Logs :: END");
		} catch (Exception ex) {
			logger.info("Excption Occoured while saving data into the database :: " + ex);
		}
		/****************************************
		 * Adoption log call end
		 **************************/
		logger.info("session Id :: " + sessionId + " :: Final Speech--" + speech);
		return new WebhookResponse(speech, speech, innerData);
	}

	/**
	 * Schedular is configured to run on every 10Min and remove all un-used
	 * session's from cache i.e. those sessions which are ideal from past 10
	 * Min.
	 */
	@Override
	public void removeUnUsedSessionFromCache() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		logger.info("Cash Removed :: START---" + dtf.format(now));
		logger.info("Cash Removed :: START---" + dtf.format(now));
		sessiontimeOut.cacheRemovetimeout(externalMap);
		logger.info("Cash Removed :: END---" + dtf.format(now));
	}

}
