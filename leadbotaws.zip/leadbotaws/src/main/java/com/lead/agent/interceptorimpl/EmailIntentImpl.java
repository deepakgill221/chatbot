package com.lead.agent.interceptorimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.lead.agent.commons.Adoptionlogs;
import com.lead.agent.interceptor.EmailIntent;

@Service
public class EmailIntentImpl implements EmailIntent 
{
	private static Logger logger = LogManager.getLogger(EmailIntentImpl.class);
	String speech="";
	ResourceBundle res = ResourceBundle.getBundle("application");
	@Override
	public String emailIntent(Map<String, Map<String, String>> map, String sessionId) {
		speech=map.get(sessionId+"Msg").get("mobileNumber"); 
		//speech=res.getString("mobileNumber");
		logger.info("Speech :: "+speech);
		return speech;
	}

}
