package com.lead.agent.interceptorimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.lead.agent.commons.Adoptionlogs;
import com.lead.agent.interceptor.CustomerMobileNumberIntent;
@Service
public class CustomerMobileNumberIntentImpl implements CustomerMobileNumberIntent 
{
	private static Logger logger = LogManager.getLogger(CustomerMobileNumberIntentImpl.class);
	
	ResourceBundle res = ResourceBundle.getBundle("application");
	String speech="";
	@Override
	public String customerMobileNumberIntent(Map<String, Map<String, String>> map, String sessionId) {
		if(map.containsKey(sessionId))
		{
			speech=map.get(sessionId+"Msg").get("mobileNumber2"); 
			speech=speech.replace("<Insert_checkbox>", "<input type=\"checkbox\"  checked=\"checked\" disabled>");
			//speech=res.getString("mobileNumber2");
		}
		else{
			speech="Internal Glitch Please try after some time :- mobile";
		}
		logger.info("Speech :: "+speech);
		return speech;
	}
}