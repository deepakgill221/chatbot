package com.lead.agent.serviceimpl;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lead.agent.commons.BeanProperty;
import com.lead.agent.service.GetMessageService;

/**
 * @author ad01084
 *
 */
@Service
public class GetMessageServiceImpl implements GetMessageService {
	private static Logger logger = LogManager.getLogger(GetMessageServiceImpl.class);
	@Autowired
	private BeanProperty bean;

	String textResponse;
	/** (non-Javadoc)
	 * @see com.lead.agent.service.GetMessageService#getMessageAPI(java.lang.String)
	 */
	@Override
	public String getMessageAPI(String botName){
		String url = bean.getGetMessageAPI();
		ResponseEntity<String> response;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder sb=new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"type\":\""+botName+"\"	");
		sb.append("	}	");

		HttpEntity<String> entity=new HttpEntity<>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

		response = restTemplate.exchange(url, HttpMethod.POST, entity,String.class);
		if(response.getStatusCodeValue() == 200)
		{
			textResponse = response.getBody();
			logger.info("Inside GetMessageServiceImpl:: getMessageAPI response form rule engine:: "+textResponse);
		}
		return textResponse;
	}

}
