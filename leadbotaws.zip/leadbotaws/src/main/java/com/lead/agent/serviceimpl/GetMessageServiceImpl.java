package com.lead.agent.serviceimpl;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lead.agent.commons.BeanProperty;
import com.lead.agent.service.GetMessageService;

@Service
public class GetMessageServiceImpl implements GetMessageService {
	
	@Autowired
	private BeanProperty bean;

	String textResponse;
	@Override
	public String getMessageAPI(String BotName){
		String url = bean.getGetMessageAPI();
		
		ResponseEntity<String> response=null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder sb=new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"type\":\""+BotName+"\"	");
		sb.append("	}	");

		HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		
		response = restTemplate.exchange(url, HttpMethod.POST, entity,String.class);
		if(response.getStatusCodeValue() == 200)
		{
			textResponse = response.getBody();
			System.out.println("Inside GetMessageServiceImpl:: getMessageAPI response form rule engine:: "+textResponse);

		}
		return textResponse;
	}

}
