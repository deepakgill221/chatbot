package com.lead.agent.button;

import java.util.Map;

public interface Button 
{
	public InnerData getButtonsYesNo();
	public InnerData getButtonsGender();
	public InnerData letsProceed();
	public InnerData proceed(Map<String,Map<String,String>> map, String sessionId);
}
