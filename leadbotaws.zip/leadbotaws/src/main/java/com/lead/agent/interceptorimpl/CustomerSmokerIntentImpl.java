package com.lead.agent.interceptorimpl;

import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lead.agent.commons.Adoptionlogs;
import com.lead.agent.interceptor.CustomerSmokerIntent;
import com.lead.agent.service.SmokerService;

@Service
public class CustomerSmokerIntentImpl implements CustomerSmokerIntent {
	
	private static Logger logger = LogManager.getLogger(CustomerSmokerIntentImpl.class);
	
	/*@Autowired
	private SmokerService smokerService;*/
	//ResourceBundle resb = ResourceBundle.getBundle("application");
	String speech = "";
	ResourceBundle res = ResourceBundle.getBundle("application");
	@Override
	public String customerSmokerIntent(Map<String, Map<String, String>> map, String sessionId) {
		if (map.containsKey(sessionId)) {

			/*String response = smokerService.smokerAPI(map, sessionId);
			JSONObject object = new JSONObject(response.toString());
			JSONObject res = (JSONObject) object.getJSONObject("response").getJSONObject("payload")
					.getJSONArray("resPlan").get(0);
			String totalPremiumWOGST = res.get("totalPremiumWOGST") + "";

			String policyTerm = res.getString("policyTerm");
			String totalPremium = res.getString("totalPremiumWGST");
			double doubletotalPremiumWGST = Double.parseDouble(totalPremium);

			String convertedtotalPremiumWGST = String.valueOf(doubletotalPremiumWGST);
			String arr[] = convertedtotalPremiumWGST.split("\\.");
			String totalPremiumWGST = arr[0];

			map.get(sessionId).put("TotalPremiumWOGST", totalPremiumWOGST);
			map.get(sessionId).put("totalPremiumWGST", totalPremium);

			String message1 = resb.getString("smoker1");
			String formattedMessage1 = MessageFormat.format(message1, map.get(sessionId).get("name"));
			String message2 = resb.getString("smoker2");
			String formattedMessage2 = MessageFormat.format(message2, policyTerm, totalPremiumWGST);

			speech = formattedMessage1 + formattedMessage2 + resb.getString("smoker3") + resb.getString("smoker4");*/
			speech=map.get(sessionId+"Msg").get("dob");
			//speech=res.getString("dob");

		} else {
			speech = "Internal Glitch Please try after some time :-smoker";
		}
		logger.info("speech :: "+speech);
		return speech;
	}
}
