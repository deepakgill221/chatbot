package com.lead.agent.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lead.agent.button.Button;
import com.lead.agent.button.InnerData;
import com.lead.agent.commons.Adoptionlogs;
import com.lead.agent.commons.DataFromJson;
import com.lead.agent.commons.SessionTimeOut;
import com.lead.agent.interceptor.CustomerDOBIntent;
import com.lead.agent.interceptor.CustomerEmailIntent;
import com.lead.agent.interceptor.CustomerGenderIntent;
import com.lead.agent.interceptor.CustomerMobileNumberIntent;
import com.lead.agent.interceptor.CustomerSmokerIntent;
import com.lead.agent.interceptor.EmailIntent;
import com.lead.agent.interceptor.PostWelcomeIntent;
import com.lead.agent.interceptor.WelcomeIntent;
import com.lead.agent.response.LeadAgentResponse;
import com.lead.agent.response.WebhookResponse;
import com.lead.agent.service.GetMessageService;
import com.lead.agent.service.SVGLeadCall;

@RestController
@RequestMapping("/leadAgent")
public class LeadAgentController 
{
	private static Logger logger = LogManager.getLogger(LeadAgentController.class);
	
	@Autowired
	private LeadAgentResponse leadAgentResponse;
	@Autowired
	private DataFromJson dataFromJson;
	@Autowired
	private PostWelcomeIntent postWelcomeIntent;
	@Autowired
	private WelcomeIntent welcomeIntent;
	@Autowired
	private CustomerGenderIntent customerGenderIntent;
	@Autowired
	private CustomerEmailIntent customerEmailIntent;
	@Autowired
	private CustomerMobileNumberIntent customerMobileNumberIntent;
	@Autowired 
	private CustomerDOBIntent customerDobIntent;
	@Autowired
	private EmailIntent emailIntent;
	@Autowired
	private CustomerSmokerIntent customerSmokerIntent;
	@Autowired
	private Button button;
	@Autowired
	private SVGLeadCall svgLeadCall;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	private GetMessageService getMessageService;
	@Autowired
	private SessionTimeOut sessiontimeOut;


	static Map<String,Map<String,String>> ExternalMap = new ConcurrentHashMap<String,Map<String,String>>();
	static Map<String,String> MessageMap = new ConcurrentHashMap<String,String>();

	
	@Scheduled(cron="0 0/10 * * * ?")
	public void removeCashethirtyminute()
	{
		System.out.println("cron job starts");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Cash Removed :: START---"+dtf.format(now));
		logger.info("Cash Removed :: START---"+dtf.format(now));
		sessiontimeOut.cashRemovetimeout(ExternalMap );
		logger.info("Cash Removed :: END---"+dtf.format(now));
	}
	
	
	@RequestMapping(method = RequestMethod.POST)
	public WebhookResponse webhook(@RequestBody String obj) {
		ResourceBundle res = ResourceBundle.getBundle("application");
		Map<String,String> internalMap = new ConcurrentHashMap<String,String>();
		//logger.info("Initial Request :-"+obj);
		InnerData innerData = new InnerData();
		logger.info("Inside Controller");
		//logger.info(obj.toString());
		String speech="", sessionId = "", action="", customerName="";
		String gender="", custEmail="", mobileNum="", date="", smoke="",resolvedQuery="";
		String source="", channel="",  company="", category="";
		Date login =new Date();
		String pattern = "MM/dd/yyyy HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String login_time = simpleDateFormat.format(login);
		
		try {
			JSONObject object = new JSONObject(obj.toString());
			//logger.info("Request	 "+obj.toString());
			sessionId = object.get("sessionId")+"";
			
			String SessionIdLogin = sessionId+"login_time";
			internalMap.put(SessionIdLogin, login_time);
			logger.info("Session Id:: :: "+sessionId+" :: login time :: "+login_time);
			
			action = object.getJSONObject("result").get("action") + "";
			logger.info("Session Id----"+sessionId+" :: Action :: "+action);
			resolvedQuery = object.getJSONObject("result").get("resolvedQuery")+"";
			if("welcome".equalsIgnoreCase(action))
			{
				try{
					/**************************get text message Start*****************************/
					
					String textMessage=getMessageService.getMessageAPI("leadbot");
					System.out.println("Msg from rule engine "+textMessage);
					
					JSONArray jsonArr = new JSONArray(textMessage);
					for(int i=0; i<jsonArr.length();i++)
					{
						String result = jsonArr.get(i)+"";
						String [] arr  = result.split("###");
						MessageMap.put(arr[0], arr[1]);
					}
					ExternalMap.put(sessionId+"Msg", MessageMap);
				}catch(Exception e)
				{
					logger.error("Exception while calling API to fetch Message from Rule Engine :: "+e);
				}
				/**************************get text message End*****************************/
				
				
				try {
					internalMap.put("start", "start");
					ExternalMap.put(sessionId, internalMap);
					String [] splitResolvedQuery = resolvedQuery.split("#");
					source=splitResolvedQuery[1];
					channel=splitResolvedQuery[2];
					company=splitResolvedQuery[3];
					if("WebsiteIndirect".equalsIgnoreCase(company)){
						company = "Website Indirect";
					}
					else if("WebsiteDirect".equalsIgnoreCase(company)){
						company="Website Direct";
					}
					else if("DirectNatural".equalsIgnoreCase(company)){
						company="Direct Natural";
					}
					else if("WebsiteDirect-mobile".equalsIgnoreCase(company)){
						company="Website Direct-mobile";
					}
					category=splitResolvedQuery[4];
					if("WebsiteIndirect".equalsIgnoreCase(category)){
						category = "Website Indirect";
					}
					else if("WebsiteDirect".equalsIgnoreCase(category)){
						category="Website Direct";
					}
					else if("DirectNatural".equalsIgnoreCase(category)){
						category="Direct Natural";
					}
					else if("WebsiteDirect-mobile".equalsIgnoreCase(category)){
						category="Website Direct-mobile";
					}
					ExternalMap.get(sessionId).put("source", source);
					ExternalMap.get(sessionId).put("channel", channel);
					ExternalMap.get(sessionId).put("company", company);
					ExternalMap.get(sessionId).put("category", category);
					logger.info("session id :: "+sessionId +" :: source :: "+source+"\n channel ::"+channel+"\n company ::"+company+"\n category :: "+category);
					
				}catch(Exception ex)
				{
					speech=ExternalMap.get(sessionId+"Msg").get("welcomeCatch");
					//speech=res.getString("welcomeCatch");
					action="default";
					logger.info("Exception in getting value of source, channel, company and category :: "+ex);
				}
			}
			if(!"welcome".equalsIgnoreCase(action) && !"default".equalsIgnoreCase(action))
			{
				customerName=dataFromJson.customerNameVariable(object,sessionId, ExternalMap, internalMap);
				gender=dataFromJson.genderVariable(object,sessionId, ExternalMap, internalMap);
				custEmail=dataFromJson.email_Variable(object, sessionId, ExternalMap, internalMap);
				mobileNum=dataFromJson.mobile_Variable(object, sessionId, ExternalMap, internalMap);
				date=dataFromJson.date_Variable(object, sessionId, ExternalMap, internalMap);
				smoke=dataFromJson.smoke_Variable(object, sessionId, ExternalMap, internalMap);
			}
			switch(action.toUpperCase())
			{
			//Welcome 1
			case "WELCOME":
			{
				logger.info("Start action :: WELCOME");
				speech=ExternalMap.get(sessionId+"Msg").get("welcome");
				//speech=res.getString("welcome");
				innerData = button.getButtonsGender();
				logger.info("ENd action :: WELCOME");
			}
			break;
			
			//Gender -2
			case "INPUT.GENDER":
			{
				if(ExternalMap.containsKey(sessionId)){
				logger.info("Start action :: INPUT.GENDER");
				speech=customerGenderIntent.customerGenderIntent(ExternalMap, sessionId);
				innerData = button.getButtonsYesNo();
				
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
				logger.info("End action :: INPUT.GENDER");
			}
			break;
			//Smoker -3 
			case "INPUT.SMOKER":
			{
				if(ExternalMap.containsKey(sessionId)){
				logger.info("Start action :: INPUT.SMOKER");
				speech=customerSmokerIntent.customerSmokerIntent(ExternalMap, sessionId);
				innerData = null;
				
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
				logger.info("End action :: INPUT.SMOKER");
			}
			break;
			//DOB - 4
			case "INPUT.DOB":
			{
				if(ExternalMap.containsKey(sessionId)){
				logger.info("Start action :: INPUT.DOB");
				speech=customerDobIntent.customerDOBIntent(ExternalMap, sessionId);
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
				logger.info("End action :: INPUT.DOB");
			}
			break;
			
			// DOB -5
			case "INPUT.NAME":
			{
				if(ExternalMap.containsKey(sessionId)){
				logger.info("Start action :: INPUT.NAME");
				speech=emailIntent.emailIntent(ExternalMap, sessionId);
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
				logger.info("End action :: INPUT.NAME");
			}
			break;
			//mobile -6
			case "INPUT.EMAIL":
			{
				if(ExternalMap.containsKey(sessionId)){
				logger.info("Start action :: INPUT.EMAIL");
				speech=customerMobileNumberIntent.customerMobileNumberIntent(ExternalMap, sessionId);
				innerData = null;
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
				logger.info("End action :: INPUT.EMAIL");
			}
			break;
			// Email -7
			case "INPUT.MOBILE":
			{
				if(ExternalMap.containsKey(sessionId)){
				logger.info("Start action :: INPUT.MOBILE");
				speech=customerEmailIntent.customerEmailIntent(ExternalMap, sessionId);
				innerData = button.proceed(ExternalMap, sessionId);;
				logger.info("Channel is for SVG ---"+ExternalMap.get(sessionId).get("channel")+"");
				String getChannel = ExternalMap.get(sessionId).get("channel")+"";
				//*****************Alsways keep this service commented for UAT and dev**************//*
				/*if("34".equalsIgnoreCase(getChannel))
				{
					final String session=sessionId;
					try {
						Thread t1=new Thread(new Runnable() 
						{
							public void run() 
							{
								svgLeadCall.svgLeadCall(ExternalMap, session);
								logger.info("----Lead Created on SVG.....");
							}
						});
						t1.start();
						t1.join();
					}
					catch(Exception ex)
					{
						logger.info("Exception while calling SVGLead API :: SessionId :: "+sessionId+" :: "+ex);
					}
				}*/
				}
				else
				{
					speech="Your session is expired. To continue please reload the page.";
				}
				/*********************Reason :: It will save the lead on prod environment****************/
				logger.info("END action :: INPUT.MOBILE");
			}
			break;
			//For clear the cache
			case "CLOSE":
			{
				logger.info("Start action :: CLOSE");
				ExternalMap.clear();
				internalMap.clear();
				speech=res.getString("close");
				logger.info("End action :: CLOSE");

			}
			break;
			default : 
			{
				logger.info("Intent Not match with skill,Please connect to application owner :: Sessionid :: "+sessionId +" :: "+action);
				speech=res.getString("default");
			}
			}
		}catch(Exception ex)
		{
			logger.info("Exception Occoured :: SessionId ::"+sessionId+"\n "+ex);
			speech="Communication glitch while calling API's.";
		}
		/*********************************Adoption Logs call start*****************************/
		/*logger.info("Adoption logs call start");
		String dbSessionId = sessionId, dbActionPerformed=action;
		String dbPolicyNumber="",  dbResolvedQuery = resolvedQuery;
		String dbspeech;
		if("INPUT.EMAIL".equalsIgnoreCase(action))
				{
			String speech1[]=speech.split("<hr>");
			dbspeech=speech1[0];
				}
		else{
			dbspeech=speech;
		}
		
		String value =dbSessionId+"login_time";
		String dbSSOId = internalMap.get(value);
		try{
			logger.info("Adoption Logs :: going to call adoption log api");
			Thread t1=new Thread(new Runnable() 
			{
				public void run() 
				{
					logger.info("Run Method Start");
					String status=adoption.adoptionlogsCall(dbSessionId, dbSSOId, dbActionPerformed, dbResolvedQuery, dbspeech);
					logger.info("Adoption log status :: "+status);
				}
			});
			t1.start();
			t1.join();
			logger.info("Adoption Logs :: END");
		}catch(Exception ex)
		{
			logger.info("Excption Occoured while saving data into the database :: "+ex);
		}*/
		/****************************************Adoption log call end**************************/
		
		logger.info("session Id :: "+sessionId+" :: Final Speech--"+speech);
		WebhookResponse responseObj = new WebhookResponse(speech, speech, innerData);
		return responseObj;
	}

}
