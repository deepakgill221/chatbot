package com.lead.agent.leadbotaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author ad01084
 *
 */
@Configuration
@EnableScheduling
@SpringBootApplication
@ComponentScan("com.lead")
public class LeadbotawsApplication {

	/**
	 * @param args
	 * Spring boot starter method
	 */
	public static void main(String[] args) {
		SpringApplication.run(LeadbotawsApplication.class, args);
	}

}

